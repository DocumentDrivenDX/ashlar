from pathlib import Path
import subprocess,json,os,time,sys,hashlib,sqlite3
from collections import Counter
root=Path(sys.argv[1]);base=json.loads((root/'base.json').read_bytes());python=base['python']
environment={'PATH':'/usr/bin:/bin','HOME':'/Users/erik','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','JAVA_HOME':base['java_home'],'PYSPARK_PYTHON':python,'PYSPARK_DRIVER_PYTHON':python,'PYTHONDONTWRITEBYTECODE':'1','SPARK_LOCAL_IP':'127.0.0.1'}
def write(name,value):(root/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def state():
 native=root/'native'
 with sqlite3.connect('file:'+str(native/'operations.sqlite')+'?mode=ro',uri=True)as db:
  rows={t:sorted([list(r)for r in db.execute('SELECT * FROM "'+t+'"')],key=lambda x:json.dumps(x,sort_keys=True))for t in ('local_operation','local_plan','jsonl_consumer_progress')}
 return {'registry':hashlib.sha256((native/'installation.json').read_bytes()).hexdigest(),'logs':{str(p.relative_to(native)):hashlib.sha256(p.read_bytes()).hexdigest()for p in native.glob('*/_delta_log/*.json')},'journal':hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest(),'counts':{t:len(v)for t,v in rows.items()}}
required='SELECT i.quantity, i.amount, i.active FROM Item i';complete='SELECT i.quantity, i.amount, i.active, i.note FROM Item i'
cases=[('initialize','initialize',0,None,None),('publish-1','publish',1,None,None),('required-scalars','query',1,required,[['18446744073709551615','12.50','true'],['9007199254740993','0.00','false']]),('missing-presence-refusal','query',1,complete,None),('publish-2','publish',2,None,None),('present-values','query',2,complete,[['9007199254740994','40.00','false','{"state":"value","value":"雪"}'],['9007199254740993','0.00','false','{"state":"null"}']])]
results=[]
for name,op,ordinal,sql,expected in cases:
 config={**base,'operation':op,'ordinal':ordinal,'output':str(root/name)}
 if op!='initialize':config['installation_sha256']=results[0]['result']['installation_sha256']
 if op=='query':config['query']={'profile':'ashlar-configured-local-weft/0.1','sql':sql,'compiler':{'index':'/private/tmp/ashlar-count-star-public-install-20261014-a/checkout/distributions/index.json','installation':'/private/tmp/ashlar-count-star-public-install-20261014-a/compiler'},'bounds':{'maximum_artifact_bytes':1048576,'maximum_rows':1000,'maximum_cell_bytes':65536,'maximum_total_cell_bytes':1048576}}
 path=root/(name+'.json');path.write_text(json.dumps(config,indent=2)+'\n');path.chmod(0o600)
 before=state()if op=='query'else None
 if before is not None:write(name+'-before.json',before)
 start=time.monotonic()
 command=[python,'-I','-B','-m','ashlar','run-configured-local','--configuration',str(path)]
 if name=='missing-presence-refusal':
  sdk="""from pathlib import Path
import sys,json
from ashlar_host.configured_local_cli import parse_configured_local
from ashlar_host.configured_local_runtime import query_configured_local
from ashlar_host.count_star_execution import CountStarExecutionError
c=parse_configured_local(Path(sys.argv[1]).read_bytes())
from ashlar_host.configured_local_cli import _diagnostics
try:
 with _diagnostics():query_configured_local(c.runtime,ordinal=c.ordinal,query=c.query)
except CountStarExecutionError as error:
 assert str(error)=='Original owning native guard refused'
 print(json.dumps({'status':'refused','error_type':type(error).__name__,'reason':str(error)}))
else:raise AssertionError('Missing-key guard was not discharged')
"""
  command=[python,'-I','-B','-c',sdk,str(path)]
 with(root/(name+'.stdout')).open('wb')as out,(root/(name+'.stderr')).open('wb')as err:
  process=subprocess.run(command,cwd=root,env=environment,stdout=out,stderr=err,timeout=240)
 assert process.returncode==0,(name,process.returncode)
 result=json.loads((root/(name+'.stdout')).read_bytes())
 if name=='missing-presence-refusal':
  assert result['status']=='refused';assert not(root/name/'report.json').exists()and not(root/name/'runtime-report.json').exists()
 else:
  assert result==json.loads((root/name/'report.json').read_bytes())==json.loads((root/name/'runtime-report.json').read_bytes())
  assert result['protected_ack']is False
  if op=='query':
   assert Counter(map(tuple,result['query']['rows']))==Counter(map(tuple,expected))
   protocol=result['query']['protocol'];assert protocol['response']==protocol['recompiled']
   assert all(g['native']['rows']==[['0']]for g in result['query']['evidence']['guards'])
   assert result['completed_batches']==ordinal
 if before is not None:
  after=state();write(name+'-after.json',after);assert before==after
 item={'name':name,'invocation':'installed-sdk'if name=='missing-presence-refusal'else'installed-cli','elapsed_seconds':time.monotonic()-start,'result':result};results.append(item);write(name+'-terminal.json',item);print(json.dumps({'name':name,'seconds':item['elapsed_seconds'],'status':'complete'}),flush=True)
write('after.json',state());write('results.json',{'status':'complete','cases':results,'scope':'Tiny named revision2 installed local typed Delta/Weft; five successful CLI calls plus one SDK missing-key guard refusal. No cloud or protected ACK. No absence-query pass or schema-migration claim.'})
