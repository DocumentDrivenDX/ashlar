from pathlib import Path
import json,sqlite3,hashlib
from ashlar_host.medical_inspection_selection import parse_medical_inspection
from ashlar_host.medical_installation import OriginalMedicalInstallationLease
from ashlar_host.original_medical_installation_handoff import validate_original_medical_installation_handoff
r=Path(__file__).parent
c=parse_medical_inspection((r/'inspection-configuration.json').read_bytes())
s=validate_original_medical_installation_handoff(c.recovery.installation.path.read_bytes(),c.recovery)
context=object()
with OriginalMedicalInstallationLease.open(s,context,journal_bytes=c.bounds.journal_bytes)as lease:
 with sqlite3.connect(s.journal.as_uri()+'?mode=ro',uri=True)as db:
  rows=db.execute('SELECT operation,state,before_version,length(receipt),intent_sha FROM local_operation ORDER BY operation').fetchall()
  facts={'profile':'ashlar-original-medical-retained-operation-observation/0.1','operations':[dict(zip(('operation','state','before_version','receipt_bytes','intent_sha256'),row))for row in rows],'scope':'Current exact original SQLite operation metadata under original installation lease; no native Delta or source/ACK proof.'}
 lease.renew(context)
with(r/'retained-operations-after-resume.json').open('x')as f:json.dump(facts,f,indent=2);f.write('\n')
print(json.dumps(facts))
