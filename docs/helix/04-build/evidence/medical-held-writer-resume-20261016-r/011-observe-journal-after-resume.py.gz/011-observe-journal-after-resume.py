from pathlib import Path
import json,time
from ashlar_host.medical_inspection_selection import parse_medical_inspection,create_medical_inspection
from ashlar_host.medical_installation import OriginalMedicalInstallationLease
from ashlar_host.original_medical_installation_handoff import validate_original_medical_installation_handoff

root=Path(__file__).parent
config=parse_medical_inspection((root/'inspection-configuration.json').read_bytes())
observer=create_medical_inspection(config)
selection=validate_original_medical_installation_handoff(config.recovery.installation.path.read_bytes(),config.recovery)
context=object();start=time.monotonic()
with OriginalMedicalInstallationLease.open(selection,context,journal_bytes=config.bounds.journal_bytes)as lease:
    observer.before(lease,context);observer.bind();observer.closing()
    sidecar=selection.journal.parent/('prospective-manifest-'+selection.installation_id+'-'+observer.lineage.request_digest+'.authorization.json')
    result={'profile':'ashlar-medical-post-refusal-journal-observation/0.1',
        'closing':True,'observations':observer.observations,'prospective_authorization_sidecar_present':sidecar.exists(),
        'scope':'Actual original lease and complete conditional journal comparison only; no Spark/native Delta/source/ACK proof.'}
result['elapsed_seconds']=time.monotonic()-start
with(root/'journal-after-resume.json').open('x')as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({'observed_operations':[x['current_operations']for x in observer.observations],'sidecar_present':result['prospective_authorization_sidecar_present']}))
