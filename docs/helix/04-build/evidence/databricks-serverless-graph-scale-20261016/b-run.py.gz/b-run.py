import hashlib,json,time,uuid,os
from pathlib import Path
from databricks.sdk import WorkspaceClient
from databricks.sdk.core import Config
r=Path(__file__).parent
os.umask(0o077)
assert not any((r/name).exists() for name in ('idempotency.json','started-run.json','owner-status.json','terminal-run.json')), 'An attempt already exists; no second run permitted'
w=WorkspaceClient(config=Config(profile='aidev-cus',http_timeout_seconds=10,retry_timeout_seconds=10))
job=json.loads((r/'created-job.json').read_bytes())['job_id'];config=json.loads((r/'configuration.json').read_bytes())
assert w.jobs.get(job).settings.name==config['job_name']
assert not list(w.jobs.list_runs(job_id=job,limit=1)), 'Native job already has an attempt'
token='ashlar-'+uuid.uuid4().hex
with (r/'idempotency.json').open('x') as selected:
 selected.write(json.dumps({'job_id':job,'token':token})+'\n')
started=time.monotonic();run_id=None;cancelled=False;last=None;terminal=None
try:
 response=w.jobs.run_now(job_id=job,idempotency_token=token).response
 run_id=response.run_id;assert run_id
 (r/'started-run.json').write_text(json.dumps(response.as_dict(),indent=2)+'\n')
 while True:
  elapsed=time.monotonic()-started
  if elapsed>=330 and not cancelled:
   w.jobs.cancel_run(run_id);cancelled=True
   (r/'cancel-request.json').write_text(json.dumps({'run_id':run_id,'wall_seconds':elapsed})+'\n')
  run=w.jobs.get_run(run_id);assert run.job_id==job
  data=run.as_dict();(r/'latest-run.json').write_text(json.dumps(data,indent=2)+'\n')
  state=(run.state.life_cycle_state.value,run.state.result_state.value if run.state.result_state else None)
  if state!=last:
   print(json.dumps({'run_id':run_id,'state':state,'wall_seconds':round(elapsed,3)}),flush=True);last=state
  if state[0]in ('TERMINATED','SKIPPED','INTERNAL_ERROR'):
   terminal=data;break
  if elapsed>390:raise TimeoutError('Owned serverless run has not confirmed terminal cancellation')
  time.sleep(5)
 (r/'terminal-run.json').write_text(json.dumps(terminal,indent=2)+'\n')
 assert len(run.tasks)==1
 task=run.tasks[0]
 output=w.jobs.get_run_output(task.run_id);(r/'task-output.json').write_text(json.dumps(output.as_dict(),indent=2)+'\n')
 if state[1]!='SUCCESS':raise RuntimeError('Owned run failed: '+str(state))
 assert output.notebook_output and not output.notebook_output.truncated
 raw=output.notebook_output.result
 assert type(raw)is str and len(raw.encode())<=1048576
 result=json.loads(raw)
 assert result['state']=='completed' and result['nodes']==1000000 and result['edges']==10000000
 assert result['layout_sha256']==config['layout_sha256'] and len(result['queries'])==7
 assert all(v['warmup']['passed'] and len(v['samples'])==1 and v['samples'][0]['passed'] for v in result['queries'])
 assert result['native_opening']==result['native_closing']
 (r/'result.json').write_text(raw)
 (r/'owner-status.json').write_text(json.dumps({'run_id':run_id,'job_id':job,'state':'SUCCEEDED','wall_seconds':time.monotonic()-started,'cancel_requested':cancelled,'actual_billed_usd':None},indent=2)+'\n')
 print(json.dumps({'run_id':run_id,'state':'SUCCEEDED','wall_seconds':round(time.monotonic()-started,3)}),flush=True)
finally:
 if run_id is None:
  try:w.jobs.cancel_all_runs(job_id=job)
  except Exception as error:(r/'unknown-outcome-cancel-error.json').write_text(json.dumps({'job_id':job,'error_class':type(error).__name__})+'\n')
 if run_id is not None and terminal is None:
  try:w.jobs.cancel_run(run_id)
  except Exception as error:(r/'cancel-error.json').write_text(json.dumps({'run_id':run_id,'error_class':type(error).__name__})+'\n')
