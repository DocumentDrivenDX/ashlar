import json,pathlib
from databricks.sdk import WorkspaceClient
from databricks.sdk.core import Config
from databricks.sdk.errors import NotFound
p=pathlib.Path(__file__).parent
read=lambda n:json.loads((p/n).read_text())
def save(n,d): (p/n).write_text(json.dumps(d,indent=2)+'\n')
c=read('configuration.json'); r=read('result.json'); run=read('terminal-run.json')
assert run['state']['result_state']=='SUCCESS' and r['native_opening']==r['native_closing']
assert c['schema']=='ashlar_scale_20261016_34ca9f2c67' and c['catalog']=='client_dev'
w=WorkspaceClient(config=Config(profile='aidev-cus',http_timeout_seconds=10,retry_timeout_seconds=10))
u=w.current_user.me().user_name
name=c['catalog']+'.'+c['schema']; schema=w.schemas.get(name).as_dict()
assert schema['owner']==u and schema['created_at']>=run['start_time']
tables=[x.as_dict() for x in w.tables.list(c['catalog'],c['schema'])]
assert {t['name'] for t in tables}=={'object_current','edge_current'}
for t in tables:
 n=next(x for x in r['native_closing'] if x['role']==t['name'])
 assert t['owner']==u and t['table_type']=='MANAGED' and t['data_source_format']=='DELTA'
 assert t['created_at']>=run['start_time'] and t['storage_location'].rstrip('/')==n['location'].rstrip('/')
 assert t['table_id']==n['properties']['io.unitycatalog.tableId']
save('cleanup-before.json',{'schema':schema,'tables':tables,'delta_ids_are_separate_from_uc_ids':True})
for t in tables:
 current=w.tables.get(t['full_name']).as_dict()
 assert current['table_id']==t['table_id'] and current['owner']==u and current['storage_location']==t['storage_location']
 w.tables.delete(t['full_name'])
assert not list(w.tables.list(c['catalog'],c['schema']))
w.schemas.delete(name,force=False)
try: w.schemas.get(name)
except NotFound: save('cleanup.json',{'state':'removed','schema':name,'tables':[t['full_name'] for t in tables],'via':'Unity Catalog REST; no compute job; non-forced schema delete','schema_absent':True})
else: raise RuntimeError('schema still exists')
print((p/'cleanup.json').read_text())
