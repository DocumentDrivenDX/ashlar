"""Five original supply-chain requests through existing installed041 compiler.

New host modules are reviewed source overlays, not newly installed package bytes.
No Spark/PG/native/source authority or compiler build/install.
"""
import hashlib,importlib,json,sys
from pathlib import Path
WORK=Path('/private/tmp/ashlar-supply-chain-041-compile-b');ROOT=Path('/Users/erik/Projects/ashlar');SITE=Path('/private/tmp/ashlar-count-star-installed-cli-c/venv/lib/python3.11/site-packages');SCHEMA_SITE='/private/tmp/truss-python-report-schema-env/lib/python3.11/site-packages'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,b):
 with p.open('xb')as f:f.write(b)
def enc(v):return json.dumps(v,separators=(',',':'),sort_keys=True).encode()+b'\n'
def main():
 WORK.mkdir(mode=0o700);overlay=WORK/'source-overlay';overlay.mkdir()
 for package,names in [('ashlar',['supply_chain_source']),('ashlar_host',['supply_chain_oracle','supply_chain_request','supply_chain_compile'])]:
  directory=overlay/package;directory.mkdir()
  for name in names:write(directory/(name+'.py'),(ROOT/'src'/package/(name+'.py')).read_bytes())
 sys.path[:0]=[str(SITE),SCHEMA_SITE]
 import ashlar,ashlar_host
 if Path(ashlar.__file__).resolve()!=SITE/'ashlar/__init__.py'or Path(ashlar_host.__file__).resolve()!=SITE/'ashlar_host/__init__.py':raise ValueError('base-package-selection')
 ashlar.__path__.insert(0,str(overlay/'ashlar'));ashlar_host.__path__.insert(0,str(overlay/'ashlar_host'))
 from ashlar.supply_chain_source import build_transaction
 from ashlar.weft_count_star_distribution import CountStarDistributionPaths
 from ashlar_host.supply_chain_request import supply_chain_count_star_request,supply_chain_cases
 from ashlar_host.supply_chain_compile import SupplyChainCompileConfig,compile_supply_chain_cases
 for package,names in [('ashlar',['supply_chain_source']),('ashlar_host',['supply_chain_oracle','supply_chain_request','supply_chain_compile'])]:
  for name in names:
   loaded=Path(sys.modules[package+'.'+name].__file__).resolve();expected=overlay/package/(name+'.py')
   if loaded!=expected or loaded.read_bytes()!=(ROOT/'src'/package/(name+'.py')).read_bytes():raise ValueError('new-source-selection')
 original=ROOT/'examples/domain-packs/supply-chain/upstream';pack=(original/'pack.json').read_bytes();model=(original/'ontology.json').read_bytes();graph=(original/'graph/fixture.json').read_bytes()
 report=json.loads((ROOT/'docs/helix/04-build/evidence/supply-chain-native-publication-20261009.json').read_bytes());manifest=report['native_manifest'];registry=report['table_registry'];aliases={t:t.replace('local.','spark_catalog.',1)for t in json.loads(manifest['table_versions_json'])}
 batch,bindings=build_transaction(model,graph,source_system='private-original-supply-chain-fixture')
 old=ROOT/'docs/helix/04-build/evidence/supply-chain-compiler-20261010/originals/ashlar-supply-chain-compile-candidate-20261010-h'
 for name,_ in supply_chain_cases(pack,model,graph):
  expected=json.loads((old/(name+'.request.json')).read_bytes());expected.update(interfaceVersion='weft-compile/0.4.1',dialect='weft-sql/0.4.1');expected['target']['backendVersion']='0.4.1-count-star-having-candidate'
  if supply_chain_count_star_request(name,pack,model,graph,bindings,manifest,registry,aliases)!=expected:raise ValueError('immutable-original-request-correspondence')
 observations=WORK/'observations.jsonl';seen=0;observed=0
 with observations.open('xb')as log:
  def observe(name,iteration,request,response):
   nonlocal seen,observed
   write(WORK/(name+f'-{iteration}.request'),request);write(WORK/(name+f'-{iteration}.response'),response)
   raw=enc({'id':name,'iteration':iteration,'requestHex':request.hex(),'responseHex':response.hex(),'requestSha256':sha(request),'responseSha256':sha(response)});observed+=len(raw)
   if observed>32*1024*1024:raise ValueError('observations-bound')
   log.write(raw);log.flush();seen+=1
  paths=CountStarDistributionPaths(Path('/private/tmp/ashlar-count-star-fresh-install-e/checkout/distributions/index.json'),Path('/private/tmp/ashlar-count-star-installed-cli-c/weft-installation'))
  result=compile_supply_chain_cases(SupplyChainCompileConfig(paths,16777216),pack,model,graph,bindings,manifest,registry,aliases,observe=observe)
 serial={'cases':[{k:(v.hex()if type(v)is bytes else v)for k,v in row.items()}for row in result['cases']],'qualification':result['qualification'],'runtimeScope':'Existing installed889base + reviewed new supplychain source overlay, existing installedbd49/fixed5dd041compiler. Newhost modules not installedwheel qualification. No native/source/ACK/Spark/PG/build/install.'}
 if seen!=10 or len(serial['cases'])!=5:raise ValueError('complete-five-observations')
 write(WORK/'result.json',enc(serial))
if __name__=='__main__':main()
