"""Prepared bounded installed public initializer; no import-side effects."""
import argparse,hashlib,importlib.util,json,os,stat,time,zipfile
from pathlib import Path

def choose(primary,error):
 return error if primary is None or isinstance(primary,Exception)and not isinstance(error,Exception)else primary

def read(path,maximum):
 stream=Path(path).open('rb');primary=None;value=None
 try:
  value=stream.read(maximum+1)
  if len(value)>maximum:raise ValueError('Bounded original input required')
 except BaseException as error:primary=error
 try:stream.close()
 except BaseException as error:primary=choose(primary,error)
 if primary is not None:raise primary
 return value

def retain(path,value):
 raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();stream=path.open('xb');primary=None
 try:
  if stream.write(raw)!=len(raw):raise OSError('Short retained evidence')
  stream.flush();os.fsync(stream.fileno())
 except BaseException as error:primary=error
 try:stream.close()
 except BaseException as error:primary=choose(primary,error)
 if primary is not None:raise primary

def installed_namespace(site):
 result=[]
 for path in sorted(site.rglob('*')):
  if path.is_symlink():raise ValueError('Installed namespace alias refused')
  kind='file'if path.is_file()else'directory'if path.is_dir()else None
  if kind is None:raise ValueError('Unexpected installed namespace member')
  result.append((str(path.relative_to(site)),kind))
 return result

def require_installed_namespace(site,expected):
 if installed_namespace(site)!=expected:raise ValueError('Complete installed host namespace changed')

def authored_package_payload(authored):
 # Immutable pyproject owns ashlar_host data; ashlar/README.md is retained source documentation.
 if 'ashlar/README.md' not in authored:raise ValueError('Original package documentation source required')
 return authored-{'ashlar/README.md'}

def require_payload_members(actual,expected):
 if set(actual)!=expected or len(actual)!=len(expected):raise ValueError('Complete original wheel member set required')

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--command',required=True,type=Path);parser.add_argument('--sha256',required=True);args=parser.parse_args()
 raw=read(args.command,1048576)
 if hashlib.sha256(raw).hexdigest()!=args.sha256:raise ValueError('Externally selected command required')
 command=json.loads(raw);start=time.monotonic();deadline=start+command['wholeSeconds'];output=Path(command['output']);phases=[];primary=None;closing=False;installed=[]
 def verify():
  if read(args.command,1048576)!=raw:raise ValueError('Original command changed')
  for item in command['resources']:
   path=Path(item['path']);info=path.lstat()
   if not stat.S_ISREG(info.st_mode):raise ValueError('Original selected regular input required')
   value=read(path,max(1,item['size']))
   if len(value)!=item['size']or hashlib.sha256(value).hexdigest()!=item['sha256']:raise ValueError('Selected input changed')
   if time.monotonic()>=deadline-15:raise TimeoutError('Closing budget required')
 def phase(name,argv,cwd,seconds):
  remaining=deadline-time.monotonic()-15
  if remaining<1:raise TimeoutError('No phase budget remains')
  result=capture.capture(argv,str(cwd),command['environment'],output/(name+'.stdout'),output/(name+'.stderr'),min(seconds,remaining),command['maximumStreamBytes'])
  phases.append({'phase':name,'argv':argv,'capture':result})
  if result['exitCode']!=0:raise RuntimeError('Required installed phase refused')
 try:
  verify()
  if output.exists()or output.is_symlink():raise ValueError('Fresh exclusive output required')
  output.mkdir(mode=0o700)
  spec=importlib.util.spec_from_file_location('selected_capture',command['captureModule']);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
  source=Path(command['source'])
  inventory=json.loads(read(command['sourceInventory'],1048576))
  authored={item['relative'][4:]for item in inventory['files']if item['relative'].startswith(('src/ashlar/','src/ashlar_host/'))}
  expected=authored_package_payload(authored)
  current={str(p.relative_to(source/'src'))for p in(source/'src').rglob('*')if p.is_file()and str(p.relative_to(source/'src')).startswith(('ashlar/','ashlar_host/'))}
  if current!=authored:raise ValueError('Frozen authored package namespace required')
  wheel_dir=output/'wheel';wheel_dir.mkdir(mode=0o700)
  phase('wheel',[command['installer'],'-I','-B','-m','pip','wheel','--no-deps','--no-index','--no-build-isolation','--wheel-dir',str(wheel_dir),str(source)],source,60)
  metadata=[]
  for directory in sorted((source/'src').glob('*.egg-info')):
   for path in sorted(directory.rglob('*')):
    if path.is_symlink():raise ValueError('Build metadata alias refused')
    if path.is_file():
     value=read(path,4194304);metadata.append({'path':str(path.relative_to(source)),'size':len(value),'sha256':hashlib.sha256(value).hexdigest(),'rawHex':value.hex()})
  retain(output/'generated-build-metadata.json',{'scope':'Actual generated build metadata; not original authored package payload','files':metadata})
  wheels=list(wheel_dir.glob('*.whl'))
  if len(wheels)!=1:raise ValueError('One actual wheel required')
  wheel=wheels[0];archive=zipfile.ZipFile(wheel);zip_primary=None;members=[]
  try:
   for name in archive.namelist():
    if name.startswith(('ashlar/','ashlar_host/')):
     original=source/'src'/name
     if archive.getinfo(name).file_size>4194304:raise ValueError('Bounded original wheel member required')
     if archive.read(name)!=read(original,4194304):raise ValueError('Exact source/wheel payload correspondence required')
     members.append(name)
  except BaseException as error:zip_primary=error
  try:archive.close()
  except BaseException as error:zip_primary=choose(zip_primary,error)
  if zip_primary is not None:raise zip_primary
  require_payload_members(members,expected)
  environment=output/'environment'
  phase('venv',[command['python311'],'-I','-B','-m','venv','--without-pip','--copies',str(environment)],output,30)
  python=environment/'bin/python'
  phase('install',[command['installer'],'-I','-B','-m','pip','--python',str(python),'install','--no-deps','--no-index','--no-compile',str(wheel)],output,30)
  site=environment/'lib/python3.11/site-packages'
  pth=site/'selected-sdk.pth';stream=pth.open('xb');pth_primary=None
  try:
   payload=('\n'.join(command['sdkRoots'])+'\n').encode()
   if stream.write(payload)!=len(payload):raise OSError('Short explicit SDK selector')
   stream.flush();os.fsync(stream.fileno())
  except BaseException as error:pth_primary=error
  try:stream.close()
  except BaseException as error:pth_primary=choose(pth_primary,error)
  if pth_primary is not None:raise pth_primary
  cfg=json.loads(read(command['configuration'],262144))
  if not stat.S_ISREG(python.lstat().st_mode)or hashlib.sha256(read(python,67108864)).hexdigest()!=cfg['runtime']['python_sha256']:raise ValueError('Copied interpreter differs')
  for name in members:
   p=site/name;value=read(p,4194304)
   if value!=read(source/'src'/name,4194304):raise ValueError('Installed original host payload differs')
  selected_namespace=installed_namespace(site)
  for p in sorted(site.rglob('*')):
   if p.is_symlink():raise ValueError('Installed namespace alias refused')
   if p.is_file():
    value=read(p,4194304);installed.append({'path':str(p),'size':len(value),'sha256':hashlib.sha256(value).hexdigest()})
  retain(output/'installed-host.json',{'sourceRevision':command['sourceRevision'],'files':installed,'scope':'Complete installed host bytes; selected external SDK observed import correspondence only, not hermetic SDK closure'})
  phase('runtime-import',[str(python),'-I','-B','-c',command['importProbe']],output,15)
  phase('initialize',[str(python),'-I','-B','-m','ashlar','initialize-original-commerce','--configuration',command['configuration']],output,command['nativeOuterSeconds'])
  handoff=output/'initialization/installation.json'
  if not handoff.is_file():raise ValueError('Public initialization handoff missing')
  value=json.loads(read(handoff,262144))
  if value['installation_id']!=cfg['installation_id']or len(value['targets'])!=6:raise ValueError('Actual public installation correspondence differs')
  phase('runtime-import-closing',[str(python),'-I','-B','-c',command['importProbe']],output,15)
  if read(output/'runtime-import.stdout',1048576)!=read(output/'runtime-import-closing.stdout',1048576):raise ValueError('Selected runtime import correspondence changed')
 except BaseException as error:primary=error
 finally:
  try:
   verify()
   if installed:
    require_installed_namespace(site,selected_namespace)
   for item in installed:
    if hashlib.sha256(read(item['path'],max(1,item['size']))).hexdigest()!=item['sha256']:raise ValueError('Installed host bytes changed')
   closing=True
  except BaseException as error:primary=choose(primary,error)
  if output.exists():
   try:retain(output/'outer-receipt.json',{'commandSha256':args.sha256,'phases':phases,'closing':closing,'primary':None if primary is None else type(primary).__name__,'elapsedSeconds':time.monotonic()-start,'scope':'Installed public fresh initializer only; no fixture, append or publication effects'})
   except BaseException as error:primary=choose(primary,error)
 if primary is not None:raise primary
if __name__=='__main__':main()
