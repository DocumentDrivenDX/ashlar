"""Inert installed initializer preparation controls; no SDK/native effects."""
import unittest,importlib.util,sys,tempfile,json,hashlib,ast
from pathlib import Path
from unittest import mock
ROOT=Path(__file__).parent

def load(name):
 spec=importlib.util.spec_from_file_location('selected_'+name.replace('-','_'),ROOT/name);owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner);return owner

class Tests(unittest.TestCase):
 def test_external_command_digest_precedes_parsing_import_effects(self):
  owner=load('launch-d.py')
  with tempfile.TemporaryDirectory()as directory:
   path=Path(directory)/'command';path.write_bytes(b'{}')
   with mock.patch.object(sys,'argv',['launch','--command',str(path),'--sha256','0'*64]),mock.patch.object(owner.json,'loads',side_effect=AssertionError('Parsing unadmitted command')):
    with self.assertRaises(ValueError):owner.main()
 def test_primary_read_cancellation_survives_close_failure(self):
  owner=load('runner-d.py');cancel=KeyboardInterrupt()
  class Stream:
   def read(self,n):raise cancel
   def close(self):raise OSError()
  path=mock.Mock();path.open.return_value=Stream()
  with mock.patch.object(owner,'Path',return_value=path):
   with self.assertRaises(KeyboardInterrupt)as caught:owner.read('/selected',10)
  self.assertIs(caught.exception,cancel)
 def test_exact_public_initializer_selection_and_no_provider_or_pg_effects(self):
  command=json.loads((ROOT/'command-d.json').read_bytes());config=json.loads((ROOT/'initialization.json').read_bytes())
  self.assertEqual(command['nativeSeconds'],300);self.assertEqual(command['nativeOuterSeconds'],330)
  self.assertEqual(config['installation_id'],'07c04255-73c9-40f3-a16a-000000000001')
  self.assertEqual(config['profile'],'ashlar-original-commerce-local-initialization/0.1')
  self.assertEqual(config['runtime']['python'],command['output']+'/environment/bin/python')
  self.assertFalse(any(name.startswith('PG')for name in command['environment']))
  tree=ast.parse((ROOT/'runner-d.py').read_bytes());values={node.value for node in ast.walk(tree)if isinstance(node,ast.Constant)and type(node.value)is str}
  self.assertIn('initialize-original-commerce',values)
  self.assertFalse(values.intersection({'docker','setup_private_outbox_fixture','publish-original-commerce','query-commerce-implicit-arithmetic','append','reset'}))
class NarrowCorrections(unittest.TestCase):
 def test_expected_original_members_are_captured_before_build_metadata(self):
  source=(ROOT/'runner-d.py').read_text()
  self.assertLess(source.index("expected=authored_package_payload"),source.index("phase('wheel'"))
  self.assertEqual(source.count('expected=authored_package_payload'),1)
  with tempfile.TemporaryDirectory()as directory:
   root=Path(directory);(root/'ashlar').mkdir();(root/'ashlar/__init__.py').write_bytes(b'original')
   expected={str(p.relative_to(root))for p in root.rglob('*')if p.is_file()and str(p.relative_to(root)).startswith(('ashlar/','ashlar_host/'))}
   (root/'ashlar_graph_toolkit.egg-info').mkdir();(root/'ashlar_graph_toolkit.egg-info/PKG-INFO').write_bytes(b'build metadata')
   self.assertEqual(expected,{'ashlar/__init__.py'})
 def test_installed_namespace_closing_and_exact_origin_constraints_present(self):
  source=(ROOT/'runner-d.py').read_text();self.assertIn('require_installed_namespace(site,selected_namespace)',source)
  c=json.loads((ROOT/'command-d.json').read_bytes())
  for name in ('owner.__file__','pyspark.__file__','delta.__file__','psycopg.__file__'):
   self.assertIn('Path('+name+')==Path(',c['importProbe'])
 def test_launcher_receipt_acquisition_failure_preserves_cancel_identity(self):
  owner=load('launch-d.py');cancel=KeyboardInterrupt();calls=[]
  with tempfile.TemporaryDirectory()as directory:
   path=Path(directory)/'command';path.write_text(json.dumps({'launcherResources':[],'captureModule':'/explicit/capture','environment':{}}));pin=hashlib.sha256(path.read_bytes()).hexdigest()
   fake=mock.Mock();fake.capture.side_effect=cancel
   spec=mock.Mock();spec.loader.exec_module.return_value=None
   original=owner.Path.open
   def open_path(p,*args,**kwargs):
    if p.name=='launch-receipt-d.json':raise OSError('receipt open')
    return original(p,*args,**kwargs)
   # A failed body with a returned capture is required to enter receipt retention.
   class Result(dict):
    def __getitem__(self,key):raise cancel
   fake.capture.return_value=Result(exitCode=0);fake.capture.side_effect=None
   with mock.patch.object(sys,'argv',['launch','--command',str(path),'--sha256',pin]),mock.patch.object(owner.importlib.util,'spec_from_file_location',return_value=spec),mock.patch.object(owner.importlib.util,'module_from_spec',return_value=fake),mock.patch.object(owner.Path,'open',open_path):
    with self.assertRaises(KeyboardInterrupt)as caught:owner.main()
   self.assertIs(caught.exception,cancel)
 def test_actual_owner_namespace_refuses_unlisted_pth_or_alias(self):
  owner=load('runner-d.py')
  with tempfile.TemporaryDirectory()as directory:
   root=Path(directory);(root/'owned.py').write_bytes(b'original');selected=owner.installed_namespace(root)
   owner.require_installed_namespace(root,selected)
   (root/'unadmitted.pth').write_bytes(b'/foreign')
   with self.assertRaises(ValueError):owner.require_installed_namespace(root,selected)
   (root/'unadmitted.pth').unlink();(root/'foreign-link').symlink_to(root/'owned.py')
   with self.assertRaises(ValueError):owner.require_installed_namespace(root,selected)
class ImportCorrespondence(unittest.TestCase):
 def test_actual_probe_rejects_foreign_origin_without_sdk_import(self):
  import types,importlib.metadata,contextlib,io
  command=json.loads((ROOT/'command-d.json').read_bytes());probe=command['importProbe'];roots=command['sdkRoots']
  modules={'pyspark':types.ModuleType('pyspark'),'delta':types.ModuleType('delta'),'psycopg':types.ModuleType('psycopg'),'ashlar_host':types.ModuleType('ashlar_host'),'ashlar_host.original_commerce_local_setup':types.ModuleType('ashlar_host.original_commerce_local_setup')}
  modules['ashlar_host'].__path__=[]
  modules['ashlar_host'].original_commerce_local_setup=modules['ashlar_host.original_commerce_local_setup']
  modules['pyspark'].__version__='3.5.3';modules['psycopg'].__version__='3.2.13'
  modules['pyspark'].__file__=roots[0]+'/pyspark/__init__.py';modules['delta'].__file__=roots[0]+'/delta/__init__.py';modules['psycopg'].__file__=roots[0]+'/psycopg/__init__.py'
  modules['ashlar_host.original_commerce_local_setup'].__file__=command['output']+'/environment/lib/python3.11/site-packages/ashlar_host/original_commerce_local_setup.py'
  with mock.patch.dict(sys.modules,modules),mock.patch.object(sys,'version_info',(3,11)),mock.patch.object(sys,'executable',command['output']+'/environment/bin/python'),mock.patch.object(importlib.metadata,'version',return_value='3.2.1'),contextlib.redirect_stdout(io.StringIO()):
   exec(probe,{})
   for name in ('pyspark','delta','psycopg','ashlar_host.original_commerce_local_setup'):
    original=modules[name].__file__;modules[name].__file__='/foreign/unadmitted.py'
    with self.assertRaises(AssertionError):exec(probe,{})
    modules[name].__file__=original
class PackagingSelection(unittest.TestCase):
 def test_actual_owner_excludes_only_undeclared_documentation(self):
  owner=load('runner-d.py')
  original={'ashlar/README.md','ashlar/__init__.py','ashlar_host/a.py','ashlar_host/resources/original-commerce-local/provenance.json'}
  selected=owner.authored_package_payload(original)
  self.assertEqual(selected,original-{'ashlar/README.md'})
  self.assertEqual(original-selected,{'ashlar/README.md'})
  with self.assertRaises(ValueError):owner.authored_package_payload(original-{'ashlar/README.md'})
 def test_actual_retained_wheel_positive_and_payload_mutations(self):
  import zipfile
  owner=load('runner-d.py');inv=json.loads((ROOT/'host-source-inventory.json').read_bytes())
  authored={item['relative'][4:]for item in inv['files']if item['relative'].startswith(('src/ashlar/','src/ashlar_host/'))};expected=owner.authored_package_payload(authored)
  wheel=next(Path('/private/tmp/ashlar-original-commerce-local-installed-20261011-b/wheel').glob('*.whl'))
  with zipfile.ZipFile(wheel)as archive:actual=[name for name in archive.namelist()if name.startswith(('ashlar/','ashlar_host/'))]
  owner.require_payload_members(actual,expected)
  for missing in ('ashlar/__init__.py','ashlar_host/resources/original-commerce-local/provenance.json'):
   self.assertIn(missing,actual)
   with self.assertRaises(ValueError):owner.require_payload_members([name for name in actual if name!=missing],expected)
  with self.assertRaises(ValueError):owner.require_payload_members(actual+['ashlar_host/unadmitted.py'],expected)
class ActualRetainedImport(unittest.TestCase):
 def test_corrected_probe_against_retained_c_installed_runtime(self):
  import subprocess
  c=json.loads((ROOT/'command-d.json').read_bytes());old='/private/tmp/ashlar-original-commerce-local-installed-20261011-c';probe=c['importProbe'].replace(c['output'],old)
  result=subprocess.run([old+'/environment/bin/python','-I','-B','-c',probe],env=c['environment'],capture_output=True,timeout=15)
  self.assertEqual(result.returncode,0);self.assertLess(len(result.stdout),1048576);self.assertEqual(result.stderr,b'')
  wrong=probe.replace(c['sdkRoots'][0]+'/psycopg/__init__.py','/foreign/unadmitted.py')
  result=subprocess.run([old+'/environment/bin/python','-I','-B','-c',wrong],env=c['environment'],capture_output=True,timeout=15)
  self.assertNotEqual(result.returncode,0);self.assertIn(b'AssertionError',result.stderr)
if __name__=='__main__':unittest.main()




