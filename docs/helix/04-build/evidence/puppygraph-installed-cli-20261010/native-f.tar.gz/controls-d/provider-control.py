"""Focused pure provider-policy controls; runtime inspection is explicitly inert.
No HTTP, query, connectivity check or native session. Lazy SDK factory closes.
"""
import json,runpy,tempfile
from pathlib import Path
from ashlar.graph_release import GraphRelease
from ashlar_host.puppy_release_cli import PuppyInvocation
from ashlar_host.puppy_release import PuppyReleaseHandle
source=Path('/private/tmp/ashlar-puppy-installed-20261010-c/native-runtime.json')
info=json.loads(source.read_bytes());sha=info['release_hashes'][0]
release_path=Path('/Users/erik/Projects/ashlar/docs/helix/04-build/evidence/puppygraph-releases-20261009')/(sha+'.graph.json')
release=GraphRelease(release_path.read_bytes(),sha)
def opened(directory):
    module=runpy.run_path('/private/tmp/ashlar-puppy-installed-provider-20261010-d.py')
    owner=module['open_puppy_release'].__wrapped__.__globals__
    owner['ROOT']=directory
    (directory/'native-runtime.json').write_bytes(source.read_bytes())
    original=owner['subprocess'].check_output
    owner['subprocess'].check_output=lambda *a,**kw:(info['engine']+' '+info['image']+' true').encode()
    output=directory/'invocation';output.mkdir()
    return owner,module['open_puppy_release'](PuppyInvocation('activate',release_path,sha,output),release),original,output
for altered in (False,True):
    with tempfile.TemporaryDirectory(prefix='ashlar-puppy-policy-control-')as name:
        root=Path(name);owner,session,original,output=opened(root)
        try:
            try:
                with session as supplied:
                    calls=[];admit=supplied.policy.admit
                    def counted(handle,context):
                        assert type(handle) is PuppyReleaseHandle and handle.release.payload==release.payload
                        calls.append(handle);return admit(handle,context)
                    supplied.policy.admit=counted
                    with supplied.policy.writer(None) as permit:
                        assert permit is None and len(calls)==1
                        if altered:(root/'native-runtime.json').write_bytes(source.read_bytes()+b' ')
                    assert len(calls)==2
            except ValueError as error:
                assert altered and str(error)=='Current original operator authority changed'
            else:assert not altered
            outcome=json.loads((output/'provider-outcome.json').read_bytes())
            if altered:assert outcome['primary']['type']=='ValueError' and outcome['cleanup'][0]['callback']=='closing-admission'
            else:assert outcome['primary'] is None and outcome['cleanup']==[]
        finally:owner['subprocess'].check_output=original
print('D correct public writer + original handle before/after + changed closing authority: 2 pure controls PASS')
