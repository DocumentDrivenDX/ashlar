"""SHA-selected operator for one explicitly owned local qualification fixture.
Not production grants: original carriers + exact owned engine are independently supplied.
"""
from contextlib import contextmanager
from pathlib import Path
import base64, hashlib, json, subprocess, urllib.request, urllib.error, sys
from neo4j import GraphDatabase, Query
from gremlin_python.driver import client as gremlin_client, serializer
from ashlar_host.lifecycle import finish
from ashlar_host.puppy_native import PuppyNativeReleaseAdapter, encoded, decode
from ashlar_host.puppy_gremlin import GremlinReleaseProjection
from ashlar_host.puppy_release_cli import PuppySession
from ashlar_host.puppy_release import PuppyReleaseHandle
ROOT=Path('/private/tmp/ashlar-puppy-installed-20261010-f')
INSTALLED=Path('/private/tmp/ashlar-puppy-installed-20261010-c')
USER,PASSWORD='ashlarfixture','ashlar-local-refresh-fixture'
@contextmanager
def open_puppy_release(invocation,release):
    raw=(ROOT/'native-runtime.json').read_bytes(); info=decode(raw)
    if set(info)!={'engine','image','name','prepared','release_hashes','prior_model','language'}: raise ValueError('Exact operator fixture configuration')
    prepared={key:tuple(value) for key,value in info['prepared'].items()}
    if release.sha256 not in info['release_hashes']: raise ValueError('Original source not admitted')
    site=INSTALLED/'venv/lib/python3.12/site-packages'
    if Path(sys.prefix)!=INSTALLED/'venv' or Path(sys.executable)!=INSTALLED/'venv/bin/python':raise ValueError('Actual fresh installed interpreter required')
    imports=[]
    for name,module in sorted(sys.modules.items()):
        if name in ('ashlar','ashlar_host') or name.startswith(('ashlar.','ashlar_host.')):
            path=Path(module.__file__)
            if path.is_symlink() or not path.resolve(strict=True).is_relative_to(site.resolve(strict=True)):raise ValueError('Project import escaped installed wheel')
            body=path.read_bytes();imports.append({'module':name,'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
    if not 0<len(imports)<=512:raise ValueError('Bounded actual installed module closure')
    imported={'sys_prefix':sys.prefix,'sys_executable':sys.executable,'argv':sys.argv,'modules':imports}
    (invocation.output_directory/'installed-imports.json').write_bytes(encoded(imported))
    records=[]; client=None; remote=None; primary=None; stage="opening"; cleanup=[]
    def runtime(context):
        actual=subprocess.check_output(['/usr/local/bin/docker','inspect','--format','{{.Id}} {{.Image}} {{.State.Running}}',info['name']],timeout=15).decode().strip()
        if actual!=info['engine']+' '+info['image']+' true': raise ValueError('Owned fixture identity changed')
        return info['engine'],'1.13.0'
    def http(path,data,context):
        runtime(context)
        headers={'Authorization':'Basic '+base64.b64encode((USER+':'+PASSWORD).encode()).decode()}
        if data is not None: headers['Content-Type']='application/json'
        request=urllib.request.Request('http://127.0.0.1:18883'+path,data=data,headers=headers)
        try:
            with urllib.request.urlopen(request,timeout=45 if data is not None else 15) as response:
                status,body=response.status,response.read(1024*1024+1)
        except urllib.error.HTTPError as error:
            with error: status,body=error.code,error.read(1024*1024+1)
        except BaseException as error:
            records.append({'path':path,'request':None if data is None else data.decode(),'status':'unknown','error':type(error).__name__+':'+str(error)})
            raise
        records.append({'path':path,'request':None if data is None else data.decode(),'status':status,'response':body.decode()})
        if len(body)>1024*1024 or status!=200: raise ValueError('Bounded actual HTTP refused')
        return body
    class Policy:
        @contextmanager
        def writer(self,context):
            original=PuppyReleaseHandle(release)
            self.admit(original,context)
            try:yield
            finally:self.admit(original,context)
        def admit(self,handle,context):
            runtime(context)
            if (ROOT/'native-runtime.json').read_bytes()!=raw or handle.release.sha256 not in info['release_hashes']: raise ValueError('Current original operator authority changed')
            for key,files in prepared.items():
                receipt=decode(Path(files[2]).read_bytes())
                if (hashlib.sha256(Path(files[2]).read_bytes()).hexdigest()!=files[3]
                    or receipt['release_sha256']!=key
                    or hashlib.sha256(Path(files[0]).read_bytes()).hexdigest()!=receipt['database_sha256']
                    or hashlib.sha256(Path(files[1]).read_bytes()).hexdigest()!=receipt['model_sha256']):raise ValueError('Original carrier/source authority changed')
    try:
        stage="runtime-open";runtime(None)
        stage='sdk-adapter-open'
        if info['language']=='Cypher':
            client=GraphDatabase.driver('bolt://127.0.0.1:17690',auth=(USER,PASSWORD),connection_timeout=5,connection_acquisition_timeout=5,max_connection_pool_size=1)
            def query(text,context):
                runtime(context)
                with client.session() as session:return session.run(Query(text,timeout=15)).data()
            adapter=PuppyNativeReleaseAdapter(prepared=prepared,prior_model=encoded(info['prior_model']),http=http,cypher=query,runtime=runtime,evidence=invocation.output_directory/'native')
        elif info['language']=='Gremlin':
            remote=gremlin_client.Client('ws://127.0.0.1:18182/gremlin','g',username=USER,password=PASSWORD,message_serializer=serializer.GraphSONSerializersV3d0())
            def submit(text,context):runtime(context);return remote.submit(text).all().result(timeout=15)
            adapter=PuppyNativeReleaseAdapter(prepared=prepared,prior_model=encoded(info['prior_model']),http=http,projection=GremlinReleaseProjection(submit),runtime=runtime,evidence=invocation.output_directory/'native')
        else: raise ValueError('Explicit native language required')
        stage="public-session"
        yield PuppySession(adapter,Policy(),None)
    except BaseException as error: primary=error
    def detail(error):
        return {'type':type(error).__name__,'message':str(error)[:4096]}
    def checked(name,callback):
        try:callback()
        except BaseException as error:cleanup.append({'callback':name,**detail(error)});raise
    finish(primary,[lambda:checked('cypher-close',lambda:client.close() if client is not None else None),
        lambda:checked('gremlin-close',lambda:remote.close() if remote is not None else None),
        lambda:checked('http-records',lambda:(invocation.output_directory/'native-http-records.json').write_bytes(encoded(records))),
        lambda:checked('closing-admission',lambda:Policy().admit(PuppyReleaseHandle(release),None)),
        lambda:(invocation.output_directory/'provider-outcome.json').write_bytes(encoded({'stage':stage,'primary':None if primary is None else detail(primary),'cleanup':cleanup}))])
