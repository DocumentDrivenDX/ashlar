"""Two finite offline-build/native phases. External self+recipe pins required."""
import hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
BASE=Path('/private/tmp/ashlar-puppy-installed-command-20261010-c.json')
WORK=Path('/private/tmp/ashlar-puppy-installed-20261010-c')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def verify(recipe):
    for item in recipe['files']:
        p=Path(item['path'])
        if str(p.resolve(strict=True))!=item['resolved'] or p.stat().st_size!=item['bytes'] or sha(p.read_bytes())!=item['sha256']:raise ValueError('Original resource changed: '+str(p))
def main():
    if len(sys.argv)!=4 or sha(Path(__file__).read_bytes())!=sys.argv[1] or sha(BASE.read_bytes())!=sys.argv[2]:raise ValueError('Exact externally reviewed runner/recipe pins required')
    recipe=json.loads(BASE.read_bytes()); phase=sys.argv[3]
    if phase not in ('build','native'):raise ValueError('Finite explicit phase only')
    verify(recipe); selected=recipe['phases'][phase]
    spec=importlib.util.spec_from_file_location('bounded','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
    dynamic=[];primary=None;outcome=None;errors=[]
    if phase=='native':
        receipt=json.loads((WORK/'installed-custody.json').read_bytes())
        if receipt['revision']!=recipe['revision']:raise ValueError('Original installed source revision')
        python=WORK/'venv/bin/python'
        if str(python.resolve(strict=True))!=recipe['installedInterpreter']:raise ValueError('Installed interpreter changed')
        for p in sorted((WORK/'venv/lib/python3.12/site-packages').rglob('*')):
            if p.is_dir():continue
            if p.is_symlink() or not p.is_file():raise ValueError('Installed regular payload only')
            dynamic.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
        for p in [WORK/'venv/bin/ashlar',WORK/'venv/pyvenv.cfg',WORK/'installed-custody.json',WORK/'wheel-inventory.json',WORK/'installed-RECORD.csv']:
            if p.is_symlink():raise ValueError('Installed evidence aliases refused')
            dynamic.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
        console=WORK/'venv/bin/ashlar'
        if sha(console.read_bytes())!=receipt['console_sha256'] or not console.read_bytes().startswith(('#!'+str(python)+'\n').encode()):raise ValueError('Installed entry point changed')
        if len(dynamic)>512:raise ValueError('Installed closure bound')
        (WORK/'installed-native-opening.json').write_text(json.dumps(dynamic,sort_keys=True,indent=2)+'\n')
    try:
        outcome=capture.capture(selected['argv'],selected['cwd'],selected['environment'],selected['stdout'],selected['stderr'],selected['deadline'],8*1024*1024)
        if outcome['exitCode']:raise ValueError('Actual phase refused: '+phase)
    except BaseException as error:primary=error
    def collect(callback):
        nonlocal primary
        try:callback()
        except BaseException as error:
            errors.append(type(error).__name__+':'+str(error))
            if primary is None or (isinstance(primary,Exception) and not isinstance(error,Exception)):primary=error
    def fixture_cleanup():
        if phase!='native':return
        env=selected['environment'];name=recipe['containerName']
        raw=subprocess.check_output(['/usr/local/bin/docker','ps','-aq','--filter','name=^/'+name+'$'],env=env,timeout=10).decode().strip()
        if raw:
            found=subprocess.check_output(['/usr/local/bin/docker','inspect','--format','{{.Image}} {{index .Config.Labels "ashlar.refresh.fixture"}}',raw],env=env,timeout=10).decode().strip()
            if found!=recipe['image']+' 20261010-installed-c':raise ValueError('Changed foreign fixture cleanup refused')
            subprocess.check_output(['/usr/local/bin/docker','rm','-f',raw],env=env,timeout=15)
    def closing_installation():
        if phase=='native':
            if str((WORK/'venv/bin/python').resolve(strict=True))!=recipe['installedInterpreter']:raise ValueError('Installed closing interpreter changed')
            names={str(p) for p in (WORK/'venv/lib/python3.12/site-packages').rglob('*') if not p.is_dir()}
            expected={item['path'] for item in dynamic if '/site-packages/' in item['path']}
            if names!=expected:raise ValueError('Installed closing member inventory changed')
        for item in dynamic:
            p=Path(item['path'])
            if p.is_symlink() or p.stat().st_size!=item['bytes'] or sha(p.read_bytes())!=item['sha256']:raise ValueError('Installed closing correspondence changed')
    collect(fixture_cleanup);collect(lambda:verify(recipe));collect(closing_installation)
    def renew_recipe():
        if sha(BASE.read_bytes())!=sys.argv[2]:raise ValueError('Original recipe changed')
    collect(renew_recipe)
    result={'phase':phase,'outcome':outcome,'openingClosingCustody':not errors,'cleanupErrors':errors,'primary':None if primary is None else type(primary).__name__+':'+str(primary),'installedClosureFiles':len(dynamic),'scope':'Offline exact original installed Ashlar and tiny owned local PuppyGraph only'}
    with Path(selected['receipt']).open('x') as stream:json.dump(result,stream,sort_keys=True,indent=2)
    if primary is not None:raise primary
if __name__=='__main__':main()
