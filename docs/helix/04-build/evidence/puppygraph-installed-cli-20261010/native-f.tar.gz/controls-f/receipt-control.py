"""Inert receipt failure retains original cancellation and cleanup priority."""
import runpy
module=runpy.run_path('/private/tmp/ashlar-puppy-installed-runner-20261010-f.py')
class RefusingReceipt:
    def __init__(self,error):self.error=error
    def open(self,*args,**kwargs):raise self.error
for cls in (KeyboardInterrupt,SystemExit,GeneratorExit):
    original=cls('original cancellation'); ordinary=OSError('receipt write refused')
    try:module['write_result'](RefusingReceipt(ordinary),{},original)
    except BaseException as caught:assert caught is original
    else:raise AssertionError('Original cancellation lost')
    closing=cls('closing cancellation');body=ValueError('ordinary body')
    try:module['write_result'](RefusingReceipt(closing),{},body)
    except BaseException as caught:assert caught is closing
    else:raise AssertionError('Closing cancellation lost')
body_cancel=KeyboardInterrupt('receipt body cancellation')
class ClosingStream:
    closed=False
    def write(self,value):raise body_cancel
    def close(self):self.closed=True;raise ValueError('ordinary receipt close failure')
stream=ClosingStream()
class AcquiringReceipt:
    def open(self,*args,**kwargs):return stream
try:module['write_result'](AcquiringReceipt(),{'record':True},None)
except BaseException as caught:assert caught is body_cancel and stream.closed
else:raise AssertionError('Receipt body cancellation masked by close')
print('Seven inert receipt failure/cancellation identity controls PASS; no process/native action')
