"""Preparation only: invoke installed public runtime candidate inspector."""
from pathlib import Path
import subprocess,json,os,hashlib
ROOT=Path(__file__).resolve().parent;ORIGINAL=ROOT.parent/'supply-chain-graphframes-common-20261017'
revision='25ea95b7c4ef8812082a8e1caaec9c0e61fb7fed';python=ROOT/'worker-env/bin/python'
jdk=Path(json.loads((ORIGINAL/'jdk-selection.json').read_bytes())['java_home']);base=Path('/Users/erik/.local/share/uv/python/cpython-3.11.17-macos-aarch64-none')
argv=[str(python),'-I','-B','-m','ashlar','inspect-graphframes-runtime','--worker-revision',revision,
    '--worker-root',str(ROOT/'worker-env'),'--sdk-root',str(ROOT/'worker-env/lib/python3.11/site-packages'),
    '--transitive-root',str(base),'--transitive-root',str(jdk),'--transitive-root',str(ORIGINAL/'worker-jars'),
    '--output',str(ROOT/'runtime-plan.json')]
env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1','JAVA_HOME':str(jdk)}
result=subprocess.run(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
(ROOT/'inspect.stdout').write_bytes(result.stdout);(ROOT/'inspect.stderr').write_bytes(result.stderr)
(ROOT/'inspect-result.json').write_text(json.dumps({'argv':argv,'status':result.returncode,'scope':'Public installed candidate inventory only; no Spark/source/JVM/query or authority granted','stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()},sort_keys=True,indent=2)+'\n')
assert result.returncode==0 and not result.stderr
answer=json.loads(result.stdout);raw=(ROOT/'runtime-plan.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==answer['sha256'];print(json.dumps({'runtime_plan_bytes':len(raw),'sha256':answer['sha256']}))
