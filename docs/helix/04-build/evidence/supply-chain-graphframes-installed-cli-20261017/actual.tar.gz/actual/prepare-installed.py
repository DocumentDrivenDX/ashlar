from pathlib import Path
import subprocess,tarfile,io,zipfile,json,hashlib,shutil
ROOT=Path('/Users/erik/Projects/ashlar/out/supply-chain-graphframes-cli-20261017-a');ROOT.mkdir(mode=0o700)
ORIGINAL=Path('/Users/erik/Projects/ashlar/out/supply-chain-graphframes-common-20261017');REVISION='25ea95b7c4ef8812082a8e1caaec9c0e61fb7fed'
source=ROOT/'source';source.mkdir(mode=0o700)
archive=subprocess.run(['git','archive',REVISION,'pyproject.toml','README.md','src'],cwd='/Users/erik/Projects/ashlar',capture_output=True,check=True).stdout
with tarfile.open(fileobj=io.BytesIO(archive))as t:t.extractall(source)
dist=ROOT/'dist';dist.mkdir(mode=0o700)
builder='/private/tmp/ashlar-weft-validation-wheel-20261016-cdc5wn_8/build-environment/bin/python'
result=subprocess.run([builder,'-I','-B','-c','from setuptools.build_meta import build_wheel;build_wheel('+repr(str(dist))+')'],cwd=source,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
(ROOT/'build.stdout').write_bytes(result.stdout);(ROOT/'build.stderr').write_bytes(result.stderr);assert result.returncode==0
wheel=next(dist.glob('*.whl'));base='/Users/erik/.local/share/uv/python/cpython-3.11.17-macos-aarch64-none/bin/python3.11';records=[]
for name in ('canonical-env','worker-env'):
 env=ROOT/name;subprocess.run([base,'-I','-B','-m','venv','--without-pip','--copies',str(env)],check=True,timeout=30);site=env/'lib/python3.11/site-packages'
 with zipfile.ZipFile(wheel)as z:
  z.extractall(site)
  for member in z.namelist():
   if member.endswith('/'):continue
   raw=(site/member).read_bytes();assert raw==z.read(member);records.append({'environment':name,'path':str(site/member),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 if name=='canonical-env':
  (site/'selected-sdk.pth').write_text('/private/tmp/ashlar-publication-query-runtime-20261016-b/lib/python3.11/site-packages\n')
 else:
  # Copy the proven exact SDK3/support bytes into an ordinary self-contained
  # worker install. Public inspector forbids aliases escaping inspected roots.
  selected=list((ORIGINAL/'worker-sdk').iterdir())+list((ORIGINAL/'r2/worker-support-r2').iterdir())
  for p in selected:
   if p.name=='__pycache__':continue
   destination=site/p.name;assert not destination.exists(),str(destination)
   actual=p.resolve()
   if actual.is_dir():shutil.copytree(actual,destination,ignore=shutil.ignore_patterns('__pycache__'))
   else:shutil.copy2(actual,destination)
config=(ORIGINAL/'fresh-publication-configuration.json').read_bytes();(ROOT/'existing-publication-configuration.json').write_bytes(config)
result={'revision':REVISION,'wheel':str(wheel),'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'source_archive_sha256':hashlib.sha256(archive).hexdigest(),'installed_files':records,'scope':'Exact committed wheel in fresh canonical/worker environments; canonical SDK4 explicitly reused, proven SDK3+NumPy copied into complete self-contained worker; original environments/publication/SDK untouched. Preparation only, no engine/source invocation.'}
(ROOT/'installed.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print('fresh committed wheel/env prepared',len(records))
