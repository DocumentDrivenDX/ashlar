import json,hashlib,shutil,ast
from pathlib import Path
root=Path('/Users/erik/Projects/ashlar/out/supply-chain-graphframes-cli-20261017-a')
old=root.parent/'supply-chain-graphframes-common-20261017'
site=root/'canonical-env/lib/python3.11/site-packages'
planhash=hashlib.sha256((root/'runtime-plan.json').read_bytes()).hexdigest()
argv=[str(root/'canonical-env/bin/python'),'-I','-B','-m','ashlar','query-supply-chain-graphframes','--configuration',str(root/'existing-publication-configuration.json'),'--java-home','/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home','--runtime-plan',str(root/'runtime-plan.json'),'--runtime-plan-sha256',planhash,'--graphframes-java-home',str(old/'jdk17/jdk-17.0.9+9/Contents/Home'),'--graphframes-jars',str(old/'worker-jars'),'--output',str(root/'query')]
base=(old/'r2/graphframes-control/supervise.py').read_text().split("if __name__=='__main__':")[0]
base=base.replace("SITE='/private/tmp/ashlar-projected-detail-probe-20261017-a/runtime/lib/python3.11/site-packages'",f'SITE={str(site)!r}')
main='''if __name__=='__main__':
    import hashlib
    os.umask(0o077)
    root=Path(__file__).parent
    prep=json.loads((root/'preparation.json').read_bytes())
    for pin in prep['pins']:
        raw=Path(pin['path']).read_bytes()
        if len(raw)!=pin['bytes'] or hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise PermissionError('Frozen control changed')
    installed=json.loads((root/'installed.json').read_bytes())
    for pin in installed['installed_files']:
        raw=Path(pin['path']).read_bytes()
        if len(raw)!=pin['bytes'] or hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise PermissionError('Installed wheel changed')
    if (root/'query').exists():raise FileExistsError('Fresh query output required')
    started=time.monotonic()
    value=capture(prep['argv'],seconds=600,observer=lambda stdout,stderr,terminal:retain(root,stdout,stderr,terminal),ownership_observer=lambda pid:write_record(root/'owned-session.json',{'session_leader_pid':pid}),cleanup_observer=lambda record:write_record(root/'cleanup-failure.json',dict(record)))
    record={'status':value['status'],'cleanup':value['cleanup'],'elapsed_seconds':time.monotonic()-started,'command_pass':False}
    if value['status']==0:
        protocol=json.loads(value['stdout'])
        path=root/'query/report.json';raw=path.read_bytes()
        if len(raw)>16777216:raise ValueError('Report capacity')
        report=json.loads(raw)
        if protocol!={'output':str(path),'common_cases':7} or report['profile']!='ashlar-installed-supply-chain-graphframes/0.1' or report['result']['common_cases_passed']!=7 or len(report['runtime_observations'])!=2:raise ValueError('Public completion correspondence')
        record.update(command_pass=True,report_sha256=hashlib.sha256(raw).hexdigest(),report_bytes=len(raw))
    write_record(root/'outer-attempt.json',record);print(json.dumps(record));raise SystemExit(0 if record['command_pass'] else 2)
'''
(root/'supervise.py').write_text(base+main)
shutil.copyfile('/private/tmp/prepare-supply-chain-graphframes-installed-cli.py',root/'prepare-installed.py')
shutil.copyfile('/private/tmp/freeze-supply-chain-cli-control.py',root/'freeze-control.py')
paths=[root/name for name in ['supervise.py','prepare-installed.py','freeze-control.py','existing-publication-configuration.json','runtime-plan.json','installed.json','inspect-runtime.py','inspect-result.json','preflight-worker.py','preflight-runtime.json','worker-preflight.json','probe-transport.json']]
paths += [old/name for name in ['stage2-selection.json','stage1-journal-readonly-snapshot.json','fresh-publication-configuration.json','publication/registry.json','publication/request.json','publication/report.json'] if (old/name).is_file()]
paths += list((root/'dist').glob('*.whl'))
def pin(path):
 raw=path.read_bytes();return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
prep={'profile':'ashlar-prepared-installed-supply-chain-graphframes-cli/0.1','source_commit':'25ea95b7c4ef8812082a8e1caaec9c0e61fb7fed','argv':argv,'launch_argv':[str(root/'canonical-env/bin/python'),'-I','-B',str(root/'supervise.py')],'runtime_plan_candidate_sha256':planhash,'bounds':{'outer_work_seconds':600,'cleanup_grace_seconds':5,'engine_seconds':300,'probe_each_seconds':30,'stdout_bytes':1048576,'stderr_bytes':1048576,'spark_master':'local[1]','driver_memory':'512m'},'native_executed':False,'pure_preflight':'Actual installed inspector and retained owned worker constructor/import/namespace probe passed; no Spark/source/publication/query executed','scope':'Existing genuine finite-file20objects23edges publication only; seven common GraphFrames operations, no authored scenarios/performance/ACK/cloud claim. Parent must independently select candidate hash and wait exclusive native slot. Original worker environments preserved. Canonical SDK4 closure reused from earlier qualified runtime; fresh same25ea wheel installed into both environments. Worker SDK3 copied into fresh self-contained namespace with NumPy2.4.6. No publisher invocation.','pins':[pin(p) for p in paths]}
(root/'preparation.json').write_text(json.dumps(prep,indent=2,sort_keys=True)+'\n')
ast.parse((root/'supervise.py').read_text())
print(hashlib.sha256((root/'preparation.json').read_bytes()).hexdigest(),len(paths))
