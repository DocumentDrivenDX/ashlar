"""Bounded genuine installed worker admission only; never starts Spark/source."""
from pathlib import Path
import json,hashlib,subprocess,os
ROOT=Path(__file__).resolve().parent;ORIGINAL=ROOT.parent/'supply-chain-graphframes-common-20261017'
from ashlar_host.graphframes_local import read_local_runtime_plan,local_encoded,local_digest
from ashlar_host.graphframes_release import GraphFramesRuntimeConfig
from ashlar_host.graphframes_runtime_probe import runtime_bytes
plan=ROOT/'runtime-plan.json';digest=hashlib.sha256(plan.read_bytes()).hexdigest();_,_,value,inventory=read_local_runtime_plan(plan,digest)
def records(files):return [{'path':str(f.path),'sha256':f.sha256,'size':f.size}for f in files]
python=Path(value['python']);jdk=Path(json.loads((ORIGINAL/'jdk-selection.json').read_bytes())['java_home']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
runtime=GraphFramesRuntimeConfig(python,sha(python),jdk,sha(jdk/'bin/java'),inventory.worker_revision,
 local_digest(local_encoded(records(inventory.worker))),local_digest(local_encoded({name:records(fs)for name,fs in inventory.sdks})),ORIGINAL/'worker-jars',ROOT/'query/engine',300,1048576,16777216)
payload=runtime_bytes(runtime);(ROOT/'preflight-runtime.json').write_bytes(payload)
source=Path(json.loads((ROOT/'existing-publication-configuration.json').read_bytes())['producer']['source'])
argv=[str(python),'-I','-B','-m','ashlar_host.graphframes_runtime_probe','--runtime-plan',str(plan),
 '--runtime-plan-sha256',digest,'--source',str(source),'--runtime',str(ROOT/'preflight-runtime.json')]
from ashlar_host.graphframes_release import capture_graphframes_worker
# Pure admission retains owned-group cleanup and bounded capture; current file
# identity checks below bracket the whole genuine no-Spark worker invocation.
def renew():
 if hashlib.sha256(plan.read_bytes()).hexdigest()!=digest or (ROOT/'preflight-runtime.json').read_bytes()!=payload:raise PermissionError('Selected input changed')
 runtime.renew()
out,err=capture_graphframes_worker(argv,cwd=ROOT,environment={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1','JAVA_HOME':str(jdk)},renew=renew,timeout_seconds=30,maximum_output_bytes=65536,retain_transport=lambda v:(ROOT/'probe-transport.json').write_text(json.dumps(v,sort_keys=True)+'\n'))
(ROOT/'probe.stdout').write_bytes(out);(ROOT/'probe.stderr').write_bytes(err);assert not err
value=json.loads(out);assert value['constructor']=='graphframes.classic.graphframe.GraphFrame'
(ROOT/'worker-preflight.json').write_text(json.dumps({'pure_no_spark_source':True,'observation':value,'runtime_plan_sha256':digest,'selected_worker_files':len(inventory.worker),'selected_sdk_files':{n:len(fs)for n,fs in inventory.sdks},'selected_bytes':sum(f.size for f in inventory.worker)+sum(f.size for _,fs in inventory.sdks for f in fs)},sort_keys=True,indent=2)+'\n');print('actual installed worker probe PASS, no Spark/source')
