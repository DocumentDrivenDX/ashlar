import sys,json,time,hashlib,signal
from pathlib import Path
r=Path(__file__).parent;sys.path.insert(0,str(r/'package'));import weft
assert weft.__version__=='0.4.40'
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('compile-only30s')));signal.alarm(25)
old=Path('/private/tmp/ashlar-payments-public039-20261016-mqyni0za/settled-request-020.json');raw=old.read_bytes();request=json.loads(raw);assert request['interfaceVersion']=='weft-compile/0.2.0'and request['dialect']=='weft-sql/0.2.0';cases=[]
for name,value in [('prior-declared-020',request),('qualified-declared-020',{**request,'target':{**request['target'],'backendVersion':'0.1.0-qualified','targetProfile':'dbsql2026.39-qualified'}})]:
 text=json.dumps(value,ensure_ascii=False,separators=(',',':'));(r/(name+'-request.json')).write_text(text);t=time.monotonic();response=weft.compile_json(text);elapsed=time.monotonic()-t;(r/(name+'-response.json')).write_text(response);v=json.loads(response);cases.append({'case':name,'status':v.get('status'),'diagnostics':v.get('diagnostics'),'backend':v.get('backend'),'targetContext':v.get('targetContext'),'compile_wall_seconds':elapsed,'request_sha256':hashlib.sha256(text.encode()).hexdigest()})
assert old.read_bytes()==raw
result={'compiler_version':weft.__version__,'module':weft.__file__,'native_sha256':hashlib.sha256((r/'package/weft/weft.abi3.so').read_bytes()).hexdigest(),'cases':cases,'original_sql':request['sql'],'scope':'Read-onlycompileonly; independentlyauthoreddeclared0.2requests preserveoriginalSQL/model/binding; qualifiedtarget selectedfromexactofficialreleasecommit, no nativeengine/profileadoptionorfinancialpass'};(r/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
