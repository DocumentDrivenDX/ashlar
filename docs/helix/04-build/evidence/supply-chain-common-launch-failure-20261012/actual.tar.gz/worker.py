"""Frozen installed query-only worker; execute only after root release."""
from pathlib import Path
import sys,json,os
R=Path(__file__).parent;sys.path.insert(0,str(R));sys.path.insert(0,str(R/'installed'))
from ashlar_host.lifecycle import finish,owned_context
from ashlar_host.supply_chain_producer import SupplyChainProducerConfig,HeldSupplyChainDataset,reopen_original_supply_chain_source
from ashlar_host.supply_chain_common_read import SupplyChainCommonRuntime,SupplyChainCommonReadConfig,open_supply_chain_common_read
from ashlar_host.supply_chain_common_query import SupplyChainCommonQueryConfig,query_supply_chain_common
from ashlar_host.evolution_verification_types import VerificationBounds
from ashlar.weft_count_star_distribution import CountStarDistributionPaths
from ashlar_host.path_capture import PathCaptureConfig
from ashlar.weft_path_decode import PathDecodeConfig
from ashlar_host.delta_custody import LOCAL_OPERATION_CAPACITY_8M,encoded
from collector import Collector
OLD=Path('/private/tmp/ashlar-supply-chain-native-03-prep-a');original=json.loads((OLD/'configuration.json').read_bytes())
def source_metadata(source):
 original_close=source.current_dataset.close;primary=None;metadata=None
 try:metadata=source.metadata()
 except BaseException as error:primary=error
 finish(primary,[original_close])
 return metadata
def main():
 producer=SupplyChainProducerConfig(**{k:Path(v)if k in('source','bun','git')else v for k,v in original['producer'].items()})
 dataset=None;collector=None;primary=None;report=None
 try:
  dataset=HeldSupplyChainDataset(producer,Path(original['model']),Path(original['graph']),R/'current-public-dataset.json')
  if dataset.raw!=(OLD/'publication/public-dataset.json').read_bytes():raise ValueError('Exact current receipt differs from existing publication')
  invocation=dataset.original_invocation();source=reopen_original_supply_chain_source(invocation)
  metadata=source_metadata(source)
  registry=json.loads((OLD/'publication/registry.json').read_bytes())
  # Existing-only restore independently admits this exact source metadata against
  # actual native manifest; no historical invocation/deserialized grant.
  runtime=R/'runtime';runtime.mkdir(mode=0o700)
  config=SupplyChainCommonReadConfig(invocation,OLD/'publication',OLD/'publication/registry.json',OLD/'publication/operations.sqlite',SupplyChainCommonRuntime(Path(sys.executable).resolve(),Path(os.environ['JAVA_HOME']),runtime),Path(original['jars']),Path(original['pack']),LOCAL_OPERATION_CAPACITY_8M,VerificationBounds(1048576,128,1048576,16777216,1048576,1048576))
  selected=SupplyChainCommonQueryConfig(CountStarDistributionPaths(Path(original['compiler']['index']),Path(original['compiler']['installation'])),1048576,PathCaptureConfig(128,1048576,16777216),PathDecodeConfig(1048576))
  collector=Collector(R/'protocol')
  with owned_context(open_supply_chain_common_read(config))as opened:
   report=query_supply_chain_common(opened,selected,observe=collector.observe)
   collector.complete(report)
  collector.verify()
 except BaseException as error:primary=error
 callbacks=[]
 if dataset is not None:callbacks.append(dataset.metadata)
 if collector is not None:callbacks.append(lambda:collector.close())
 finish(primary,callbacks)
 raw=(encoded(report)+'\n').encode()
 if len(raw)>67108864:raise ValueError('Closed complete report bound exceeded')
 with (R/'report.json').open('xb')as output:
  if output.write(raw)!=len(raw):raise ValueError('Complete report retention required')
 print(json.dumps({'closed':True,'queries':16,'protocolRecords':32,'source':'current exact receipt correspondence; no historical origin'},sort_keys=True))
if __name__=='__main__':main()
