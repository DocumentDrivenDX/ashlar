"""Private qualification collector; original32 protocol views, no authority."""
from pathlib import Path
import os,stat,hashlib
from ashlar_host.delta_custody import encoded
from ashlar_host.lifecycle import finish
class Collector:
 def __init__(self,root):
  self.root=Path(root);self.fd=None;self.files=[];self.entries=[];self.total=0
  self.root.mkdir(mode=0o700);primary=None
  try:self.fd=os.open(self.root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);self.info=os.fstat(self.fd)
  except BaseException as error:
   primary=error;finish(primary,[lambda:os.close(self.fd)]if self.fd is not None else[])
 def current(self):
  now=self.root.lstat();held=os.fstat(self.fd)
  if self.root.resolve()!=self.root or (now.st_dev,now.st_ino,now.st_mode)!=(self.info.st_dev,self.info.st_ino,self.info.st_mode)or(now.st_dev,now.st_ino,now.st_mode)!=(held.st_dev,held.st_ino,held.st_mode):raise ValueError('Original collector directory changed')
 def write(self,name,raw):
  self.current();fd=os.open(name,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=self.fd)
  self.files.append((name,fd,None,None))
  count=0
  while count<len(raw):
   n=os.write(fd,raw[count:count+65536])
   if n<=0:raise ValueError('Complete original write required')
   count+=n
  os.fsync(fd);info=os.fstat(fd)
  self.files[-1]=(name,fd,info,hashlib.sha256(raw).hexdigest());self.current()
 def observe(self,ordinal,iteration,request,response):
  if type(ordinal)is not int or type(iteration)is not int or (ordinal,iteration)!=divmod(len(self.entries),2)or not 0<=ordinal<16 or any(type(v)is not bytes or len(v)>1048576 for v in(request,response)):raise ValueError('Fixed complete protocol ordering required')
  family,part,qordinal=(('one-hop','relationships-0-6',ordinal)if ordinal<7 else ('one-hop','relationships-7-12',ordinal)if ordinal<13 else ('singleton','complete',0)if ordinal==13 else ('filtered-limit','complete',ordinal-14))
  entry={'ordinal':ordinal,'family':family,'part':part,'query_ordinal':qordinal,'iteration':iteration,'request_bytes':len(request),'request_sha256':hashlib.sha256(request).hexdigest(),'response_bytes':len(response),'response_sha256':hashlib.sha256(response).hexdigest()}
  line=(encoded(entry)+'\n').encode()
  if self.total+len(request)+len(response)+len(line)>8388608:raise ValueError('Original whole protocol/index budget exceeded before allocation')
  self.current();self.write('%02d-%d-request.json'%(ordinal,iteration),request);self.write('%02d-%d-response.json'%(ordinal,iteration),response)
  self.entries.append(entry);self.total+=len(request)+len(response)+len(line)
 def complete(self,report):
  if len(self.entries)!=32 or report['protocol_index']!=self.entries or report['protocol_total_bytes']!=self.total:raise ValueError('Complete original protocol/index correspondence required')
  raw=b''.join((encoded(entry)+'\n').encode()for entry in self.entries)
  self.write('index.jsonl',raw);self.verify()
 def verify(self):
  self.current()
  if set(os.listdir(self.fd))!={name for name,_,_,_ in self.files}:raise ValueError('Collector complete namespace differs')
  for name,fd,info,digest in self.files:
   if info is None:raise ValueError('Partial retained protocol cannot qualify')
   before=os.fstat(fd);named=os.stat(name,dir_fd=self.fd,follow_symlinks=False);facts=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
   if not stat.S_ISREG(before.st_mode)or before.st_nlink!=1 or facts(before)!=facts(info)or facts(named)!=facts(info):raise ValueError('Original protocol identity changed')
   os.lseek(fd,0,os.SEEK_SET);h=hashlib.sha256();count=0
   while True:
    chunk=os.read(fd,min(65536,info.st_size-count+1))
    if not chunk:break
    count+=len(chunk)
    if count>info.st_size:raise ValueError('Original protocol grew')
    h.update(chunk)
   if count!=info.st_size or h.hexdigest()!=digest or facts(os.fstat(fd))!=facts(info)or facts(os.stat(name,dir_fd=self.fd,follow_symlinks=False))!=facts(info):raise ValueError('Original complete protocol bytes changed')
  self.current()
 def close(self,primary=None):
  callbacks=[self.verify]+[lambda fd=fd:os.close(fd)for _,fd,_,_ in self.files]
  if self.fd is not None:callbacks.append(lambda:os.close(self.fd))
  finish(primary,callbacks)
