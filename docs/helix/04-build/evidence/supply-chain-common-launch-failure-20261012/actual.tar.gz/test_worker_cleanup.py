from pathlib import Path
import ast,sys,unittest
from types import SimpleNamespace
R=Path(__file__).parent;sys.path.insert(0,str(R/'installed'))
from ashlar_host.lifecycle import finish
namespace={'finish':finish};raw=(R/'worker.py').read_text();tree=ast.parse(raw)
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='source_metadata');exec(compile(ast.Module(body=[node],type_ignores=[]),str(R/'worker.py'),'exec'),namespace)
class Test(unittest.TestCase):
 def test_original_metadata_cancellation_survives_close_failure(self):
  primary=KeyboardInterrupt();calls=[]
  def metadata():calls.append('metadata');raise primary
  def close():calls.append('close');raise LookupError('secondary')
  source=SimpleNamespace(metadata=metadata,current_dataset=SimpleNamespace(close=close))
  with self.assertRaises(KeyboardInterrupt)as caught:namespace['source_metadata'](source)
  self.assertIs(caught.exception,primary);self.assertEqual(calls,['metadata','close'])
 def test_original_close_captured_before_metadata_replacement(self):
  calls=[];dataset=SimpleNamespace(close=lambda:calls.append('original'))
  def metadata():dataset.close=lambda:calls.append('foreign');return {'actual':'metadata'}
  self.assertEqual(namespace['source_metadata'](SimpleNamespace(metadata=metadata,current_dataset=dataset)),{'actual':'metadata'})
  self.assertEqual(calls,['original'])
if __name__=='__main__':unittest.main()
