"""Private fixed installed overlay supervisor; execution requires root release."""
from pathlib import Path
import sys,os,json,hashlib,stat
R=Path(__file__).parent;sys.path.insert(0,str(R));sys.path.insert(0,str(R/'installed'))
from original_custody import renew as original_renew,bounded_read
from ashlar_host.graphframes_release import capture_graphframes_worker
from ashlar_host.lifecycle import finish
RESOURCE_SHA='7a498c2d76404a53b0adb6872308e63ac90cf424eacac2d4aca3c87cc73ebe4d'
def write(path,raw):
 fd=None;primary=None
 try:
  fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);count=0
  while count<len(raw):
   size=os.write(fd,raw[count:count+65536])
   if size<=0:raise ValueError('Complete private retention required')
   count+=size
  os.fsync(fd)
 except BaseException as error:primary=error
 finish(primary,[lambda:os.close(fd)]if fd is not None else[])
def renew():
 original_renew();raw=bounded_read(R/'resources.json',8388608)
 if hashlib.sha256(raw).hexdigest()!=RESOURCE_SHA:raise ValueError('Original resource descriptor changed')
 resources=json.loads(raw)
 for key in('overlay','originalPublication'):
  expected=resources[key];root=Path(next(iter(expected))).parent
  root=R/'installed'if key=='overlay'else Path('/private/tmp/ashlar-supply-chain-native-03-prep-a/publication')
  if set(str(p)for p in root.rglob('*'))!=set(expected):raise ValueError('Complete namespace changed')
  for name,entry in expected.items():
   p=Path(name);s=p.lstat()
   if p.resolve()!=p:raise ValueError('Canonical selected namespace changed')
   if entry['kind']=='directory':
    if [s.st_dev,s.st_ino,s.st_mode]!=entry['identity']:raise ValueError('Original directory changed')
   else:bounded_read(p,entry['pin']['bytes'],selected=entry['pin'],collect=False)
 for pin in resources.get('recipeFiles',[]):bounded_read(Path(pin['path']),pin['bytes'],selected=pin,collect=False)
def retain(value):
 primary=None;callbacks=[]
 for key,name in(('stdoutHex','query.stdout'),('stderrHex','query.stderr')):
  raw=bytes.fromhex(value[key])
  if len(raw)>1048576:raise ValueError('Complete bounded stream required')
  callbacks.append(lambda name=name,raw=raw:write(R/name,raw))
 callbacks.append(lambda:write(R/'transport.json',(json.dumps({k:v for k,v in value.items()if k not in('stdoutHex','stderrHex')},sort_keys=True)+'\n').encode()))
 finish(primary,callbacks)
def main():
 primary=None;success=False;closed=[False]
 try:
  renew();command=json.loads(bounded_read(R/'command.json',65536))
  capture_graphframes_worker(command['workerArgv'],cwd=R,environment=command['environment'],renew=renew,timeout_seconds=300,maximum_output_bytes=1048576,retain_transport=retain);success=True
 except BaseException as error:primary=error
 def closing():renew();closed[0]=True
 finish(primary,[closing,lambda:write(R/'outer-result.json',(json.dumps({'bodyReturned':success,'recipeClosingPassed':closed[0],'scope':'Polling transport/custody only; actual complete report and producer/native bags require independent review'})+'\n').encode())])
if __name__=='__main__':main()
