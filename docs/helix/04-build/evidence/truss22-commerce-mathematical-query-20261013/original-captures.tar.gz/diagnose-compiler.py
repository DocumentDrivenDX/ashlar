import sys,json,hashlib,time
from pathlib import Path
r=Path(__file__).parent;sys.path.insert(0,str(r/'ashlar-target'))
from ashlar_host.weft_compatible_cli import CompatibleCompiler,compile_compatible
source=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a/queried/price-query.json')
old=json.loads(source.read_bytes());request=json.loads(old['request_original_json']);request['sql']='SELECT l.quantity AS quantity FROM order_lines l'
raw=(json.dumps(request,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode();(r/'diagnostic-request.json').write_bytes(raw)
t=time.monotonic();response=compile_compatible(CompatibleCompiler(Path('/private/tmp/ashlar-compatible-weft-compile-20261013-a/weft-runtime')),raw);(r/'diagnostic-response.json').write_bytes(response);artifact=json.loads(response)
result={'duration_seconds':time.monotonic()-t,'status':artifact.get('status'),'diagnostics':artifact.get('diagnostics'),'backend':artifact.get('backend'),'modelPins':artifact.get('modelPins'),'request_sha256':hashlib.sha256(raw).hexdigest(),'response_sha256':hashlib.sha256(response).hexdigest(),'scope':'Compiler-only diagnostic using original historical binding bytes from the successful price query with only authored SQL changed. Historical ephemeral aliases are not live tables; no source authority, native execution or guard discharge claim.'}
(r/'compiler-diagnostic.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
