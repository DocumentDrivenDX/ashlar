import sys,json,time,os
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;s=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a')
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical']
sys.path[:0]=[str(r/'ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_resume_setup import run_configure_truss_resume_command
from ashlar_host.truss_scalar_query_cli import run_query_truss_scalars_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_example import private_file
t=time.monotonic();primary=None;answer=None;previous={k:os.environ.get(k)for k in ('JAVA_HOME','PYSPARK_PYTHON','PYSPARK_DRIVER_PYTHON')}
def restore():
 for k,v in previous.items():
  if v is None:os.environ.pop(k,None)
  else:os.environ[k]=v
try:
 os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
 with owned_context(LocalPostgres(s/'data')) as runtime:
  params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);administrator=psycopg.conninfo.make_conninfo(**params);params['user']=json.loads((s/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
  def connection():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
  before=read_page(connection,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(r/'checkpoint-before.bin',before);assert before==(s/'queried/checkpoint-after.bin').read_bytes()
  publication=json.loads((s/'continued/continuation.json').read_bytes())['publications'][0]
  selection=json.loads((s/'native/publish.json').read_bytes());selection.update(connection_uri=ordinary,administrator_uri=administrator)
  publisher=private_file(r/'publisher-selection.json',selection);reader=r/'reader.json';run_configure_truss_resume_command(publisher,publication['publication_intent']['path'],reader)
  started=time.monotonic();query=run_query_truss_scalars_command(reader,r/'query.json',compiler='/private/tmp/ashlar-compatible-weft-compile-20261013-a/weft-runtime',sql='SELECT l.quantity AS quantity FROM order_lines l',revision='1',document_id='urn:umf:domain:commerce',physical_revisions=('1',),maximum_rows=1);duration=time.monotonic()-started
  assert query['rows']==[{'quantity':{'integer_token':'10'}}] and query['publication_id']==publication['manifest']['publication_id']
  source=[x for x in query['integrity']if x['check'].get('publicSourceOnly')is True]
  representation=[x for x in query['integrity']if x['check'].get('representabilityOnly')is True]
  assert len(source)==len(representation)==1 and len(source[0]['rows'])==1 and source[0]['rows'][0][-1]=='10' and representation[0]['rows']==[['0']]
  artifact=json.loads(query['response_original_json']);assert artifact['columns'][0]['representation']['logicalType']=={'family':'integer','facets':{},'nullable':False}
  after=read_page(connection,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(r/'checkpoint-after.bin',after);assert before==after
  answer={'outcome':'passed','query_seconds':duration,'rows':query['rows'],'publication_id':query['publication_id'],'source_guard_rows':len(source[0]['rows']),'original_mathematical_integer_descriptor':artifact['columns'][0]['representation']['logicalType'],'source_checkpoint_unchanged':True,'scope':'One original UMF0.8 mathematical integer Field query from completed full commerce Truss-fed local Delta publication. Original six-column full source guard and paired representability guard execute before unchanged SQL; no invented signed64 facet, filter/join/arithmetic/lifecycle/Unity Catalog claim.'}
except BaseException as error:primary=error
finish(primary,[restore]);answer['duration_seconds']=time.monotonic()-t;private_file(r/'result.json',answer);print(json.dumps(answer),flush=True)
