"""Four unchanged original commerce SQL compiles; no source/publication authority."""
import sys
if sys.path[0]!='/private/tmp':raise ValueError('Explicit selected probe required')
del sys.path[0]
import json,hashlib
from pathlib import Path
from ashlar.weft_count_star_distribution import CountStarDistributionPaths,compile_count_star_distribution,installed_count_star_schema_bundle
from ashlar_host.commerce_original_scenarios import commerce_original_cases,commerce_original_request,original_commerce_scenario_oracle
from ashlar_host.source_identity import build_transaction
from ashlar_host.count_star_admission import CountStarAdmissionConfig,admit_count_star_artifact
from ashlar_host.count_star_schema import make_offline_count_star_schema_validation
from ashlar_host.lifecycle import owned_context
WORK=Path('/private/tmp/ashlar-commerce-original-installed-compile-a');REPO=Path('/Users/erik/Projects/ashlar');SITE=WORK/'venv/lib/python3.11/site-packages';OUTPUT=WORK/'compile-output';OUTPUT.mkdir(mode=0o700)
import ashlar_host.commerce_original_scenarios as selected
if not Path(selected.__file__).is_relative_to(SITE):raise ValueError('Actual installed scenario owner required')
root=REPO/'examples/domain-packs/commerce/upstream';pack=(root/'pack.json').read_bytes();model=(root/'ontology.json').read_bytes();graph=(root/'graph/fixture.json').read_bytes()
_,bindings=build_transaction(model,graph,source_system='private-original-commerce-fixture',binding_profile='ashlar-commerce-development-bindings/0.2')
report=json.loads((REPO/'docs/helix/04-build/evidence/commerce-outbox-publication-20261009/report.json').read_bytes());manifest=report['native_manifest'];registry=report['table_registry'];aliases={table:table.replace('local.','spark_catalog.',1)for table in json.loads(manifest['table_versions_json'])}
paths=CountStarDistributionPaths(Path('/private/tmp/ashlar-count-star-fresh-install-e/checkout/distributions/index.json'),Path('/private/tmp/ashlar-count-star-installed-cli-c/weft-installation'))
whole=dict(installed_count_star_schema_bundle(paths));names=('compile-request-v0.4.1.schema.json','compile-response-v0.4.1.schema.json','logical-plan-v0.4.1.schema.json');config=CountStarAdmissionConfig(1048576,make_offline_count_star_schema_validation({n:whole[n]for n in names}));results=[];observed=0
with owned_context((OUTPUT/'observations.jsonl').open('xb'))as log:
 for name,sql in commerce_original_cases(pack):
  request=commerce_original_request(sql,model,bindings,manifest,registry,aliases,pack_bytes=pack);raw=(json.dumps(request,sort_keys=True,separators=(',',':'))+'\n').encode();responses=[]
  if len(raw)>1048576:raise ValueError('Complete request bound')
  for iteration in range(2):
   response=compile_count_star_distribution(paths,raw)
   if type(response)is not bytes or len(response)>1048576:raise ValueError('Complete response bound')
   for kind,body in (('request',raw),('response',response)):
    with owned_context((OUTPUT/('commerce-'+name+'-'+str(iteration)+'.'+kind)).open('xb'))as stream:
     if stream.write(body)!=len(body):raise ValueError('Exact original raw artifact write refused')
   observation=(json.dumps({'pack':'commerce','id':name,'iteration':iteration,'requestHex':raw.hex(),'responseHex':response.hex()},separators=(',',':'))+'\n').encode();observed+=len(observation)
   if observed>33554432:raise ValueError('Complete eight observation bound')
   if log.write(observation)!=len(observation):raise ValueError('Original compiler observation refused')
   log.flush();responses.append(response)
  if responses[0]!=responses[1]:raise ValueError('Original fresh recompile differs')
  artifact=json.loads(responses[0]);admit_count_star_artifact(request,artifact,json.loads(responses[1]),config=config)
  oracle=original_commerce_scenario_oracle(model,graph,request)
  results.append({'pack':'commerce','id':name,'requestSha256':hashlib.sha256(raw).hexdigest(),'responseSha256':hashlib.sha256(responses[0]).hexdigest(),'requiredCapabilities':artifact['logicalPlan']['requiredCapabilities'],'sourceOracle':oracle})
result={'cases':results,'originalCases':4,'actualCompiles':8,'qualification':'Four original unchanged commerce packSQL incl unaliased partial-return compiled/recompiled through actual installed041request/schema/admission and independent source oracle. Compiler correspondence only; retained publication metadata does not grant source/publication/ACK/native authority.'}
body=(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n').encode()
if len(body)>16777216:raise ValueError('Complete report bound')
with owned_context((OUTPUT/'report.json').open('xb'))as log:
 if log.write(body)!=len(body):raise ValueError('Complete report write refused')
print(json.dumps({'originalCases':4,'actualCompiles':8}))
