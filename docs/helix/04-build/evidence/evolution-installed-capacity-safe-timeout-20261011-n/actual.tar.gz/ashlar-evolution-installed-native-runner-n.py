"""Fresh installed public two-source evolution; no production or Truss authority."""
import base64,csv,gzip,hashlib,importlib.util,io,json,os,stat,sys,tarfile,zipfile,time
from pathlib import Path,PurePosixPath
from contextlib import contextmanager
WORK=Path('/private/tmp/ashlar-evolution-installed-native-20261011-n');REPO=Path('/Users/erik/Projects/ashlar');REV='46db7fbecdfdde0d89c0e4dfd75d50ee381acc4f'
PRIMARY='/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
PY311='/private/tmp/ashlar-db-client/bin/python'
ENV={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','PIP_CONFIG_FILE':'/dev/null','PIP_DISABLE_PIP_VERSION_CHECK':'1','PIP_NO_CACHE_DIR':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_TERMINAL_PROMPT':'0','GIT_ALLOW_PROTOCOL':'file'}
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return json.dumps(v,separators=(',',':'),sort_keys=True).encode()+b'\n'
def select_failure(primary,closing):
 if primary is None:return closing
 if isinstance(primary,Exception)and not isinstance(closing,Exception):return closing
 return primary

@contextmanager
def owned(stream):
 primary=None
 try:yield stream
 except BaseException as error:primary=error
 try:stream.close()
 except BaseException as error:primary=select_failure(primary,error)
 if primary is not None:raise primary

def write(p,b):
 stream=None;primary=None
 try:
  stream=p.open('xb')
  if stream.write(b)!=len(b):raise ValueError('write-refused')
 except BaseException as error:primary=error
 finally:
  if stream is not None:
   try:stream.close()
   except BaseException as error:primary=select_failure(primary,error)
 if primary is not None:raise primary

def bounded_read(p,maximum):
 if p.is_symlink()or not p.is_file()or p.stat().st_size>maximum:raise ValueError('selected-file-bound')
 with owned(p.open('rb'))as stream:raw=stream.read(maximum+1)
 if len(raw)>maximum:raise ValueError('selected-file-bound')
 return raw
def safe(name):
 p=PurePosixPath(name)
 if not name or '\\'in name or p.is_absolute()or any(v in ('','..','.')for v in name.split('/')):raise ValueError('member-path')
 return p

NAMESPACE=Path('/private/tmp/ashlar-evolution-installed-native-namespace-j.json')
def verify_namespace():
 plan=json.loads(NAMESPACE.read_bytes())
 for root,expected in plan['roots'].items():
  actual={}
  for p in Path(root).rglob('*'):
   if p.name=='.DS_Store':continue
   if p.is_symlink():actual[str(p)]={'kind':'symlink','target':os.readlink(p),'resolved':str(p.resolve())}
   elif p.is_file():actual[str(p)]={'kind':'file','bytes':p.stat().st_size}
   elif p.is_dir():actual[str(p)]={'kind':'directory'}
   else:raise ValueError('unknown selected runtime entry')
  if actual!=expected:raise ValueError('complete selected runtime namespace changed')
 for root,expected in plan.get('site_startups',{}).items():
  actual={}
  for p in Path(root).iterdir():
   if p.suffix=='.pth'or p.name in ('sitecustomize.py','usercustomize.py','sitecustomize','usercustomize'):
    if p.is_symlink()or not p.is_file():raise ValueError('selected startup alias')
    actual[str(p)]={'kind':'file','bytes':p.stat().st_size}
  if actual!=expected:raise ValueError('builder startup selection changed')
 for link in plan['links']:
  p=Path(link['path'])
  if not p.is_symlink()or os.readlink(p)!=link['target']or str(p.resolve())!=link['resolved']:raise ValueError('selected runtime link changed')

def main():
 verify_namespace()
 WORK.mkdir(mode=0o700);(WORK/'tmp').mkdir();ENV['TMPDIR']=str(WORK/'tmp')
 spec=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
 phases=[];source=WORK/'source';inventory=json.loads(Path('/private/tmp/ashlar-evolution-installed-native-source-inventory-n.json').read_bytes());rows={r['path']:r for r in inventory['files']}
 if inventory['revision']!=REV:raise ValueError('source-revision')
 deadline=time.monotonic()+1020
 def run(label,argv,timeout=30,maximum=4*1024*1024,stdin=None,cwd=None):
  remaining=int(deadline-time.monotonic()-90)
  if remaining<1:raise TimeoutError('whole deadline before child')
  timeout=min(timeout,remaining)
  out=WORK/(label+'.stdout');err=WORK/(label+'.stderr');result=capture.capture(argv,str(cwd or WORK),ENV,str(out),str(err),timeout,maximum,str(stdin)if stdin else None)
  record={'phase':label,**result,'stdoutSha256':sha(out.read_bytes()),'stderrSha256':sha(err.read_bytes())};phases.append(record);write(WORK/(label+'.json'),enc(record))
  if result['exitCode']:raise ValueError('phase-refused:'+label)
  return out.read_bytes()
 run('archive',['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','tar.umask=0002','-C',str(REPO),'archive','--format=tar',REV,'src','pyproject.toml','README.md','tools/evolution_stage_observer.py'],maximum=16*1024*1024)
 source.mkdir();seen=set();decoded=0
 with owned(tarfile.open(WORK/'archive.stdout','r:'))as tar:
  members=tar.getmembers()
  if len(members)>512:raise ValueError('source-member-bound')
  names=set()
  for m in members:
   name=m.name.rstrip('/')if m.isdir()else m.name;safe(name)
   if name in names:raise ValueError('source-duplicate')
   names.add(name)
   if m.isdir():
    if not any(p.startswith(name+'/')for p in rows):raise ValueError('source-directory')
    continue
   if not m.isfile()or name not in rows:raise ValueError('source-extra')
   r=rows[name];decoded+=m.size
   if decoded>8*1024*1024 or m.size!=r['bytes']:raise ValueError('source-bound')
   with owned(tar.extractfile(m))as member:raw=member.read(r['bytes']+1)
   if len(raw)!=r['bytes']or sha(raw)!=r['sha256']or m.mode&0o777!=(0o775 if r['gitMode']=='100755'else 0o664):
    # Git archive uses umask-independent 0664/0775 payload permissions.
    raise ValueError('source-custody')
   p=source/name;p.parent.mkdir(parents=True,exist_ok=True);write(p,raw);p.chmod(0o755 if r['gitMode']=='100755'else 0o644);seen.add(name)
 if seen!=set(rows):raise ValueError('source-closure')
 def source_custody():
  for name,r in rows.items():
   p=source/name;b=p.read_bytes()
   if p.is_symlink()or len(b)!=r['bytes']or sha(b)!=r['sha256']:raise ValueError('source-closing-custody')
 source_custody();(WORK/'wheels').mkdir()
 run('wheel',[PRIMARY,'-B','-I','-m','pip','wheel','--no-deps','--no-build-isolation','--no-index','--wheel-dir',str(WORK/'wheels'),str(source)],timeout=60)
 wheels=list((WORK/'wheels').iterdir())
 if len(wheels)!=1 or wheels[0].is_symlink()or wheels[0].suffix!='.whl'or wheels[0].stat().st_size>8*1024*1024:raise ValueError('wheel-selection')
 wheel=wheels[0];expected={name[4:]:r for name,r in rows.items()if name.startswith('src/')and name!='src/ashlar/README.md'};payload={};metadata={};total=0;names=set()
 with owned(zipfile.ZipFile(wheel))as archive:
  infos=archive.infolist()
  if len(infos)>512:raise ValueError('wheel-member-bound')
  for info in infos:
   name=info.filename;safe(name);mode=info.external_attr>>16
   if name in names or info.flag_bits&1 or stat.S_IFMT(mode)not in (0,stat.S_IFREG)or info.is_dir():raise ValueError('wheel-member-shape')
   names.add(name);total+=info.file_size
   if total>16*1024*1024:raise ValueError('wheel-decoded-bound')
   raw=archive.read(info)
   if name in expected:
    r=expected[name]
    if len(raw)!=r['bytes']or sha(raw)!=r['sha256']:raise ValueError('wheel-source')
    payload[name]=raw
   elif name.startswith('ashlar_graph_toolkit-0.1.0.dev0.dist-info/')and name.rsplit('/',1)[1]in ('METADATA','WHEEL','entry_points.txt','top_level.txt','RECORD'):metadata[name]=raw
   else:raise ValueError('wheel-extra')
 if set(payload)!=set(expected)or len(metadata)!=5:raise ValueError('wheel-closure')
 if metadata['ashlar_graph_toolkit-0.1.0.dev0.dist-info/entry_points.txt']!=b'[console_scripts]\nashlar = ashlar.cli:main\n':raise ValueError('wheel-entrypoint')
 write(WORK/'wheel-inventory.json',enc({'wheel':wheel.name,'bytes':wheel.stat().st_size,'sha256':sha(wheel.read_bytes()),'members':[{'path':n,'bytes':len(b),'sha256':sha(b)}for n,b in sorted({**payload,**metadata}.items())]}))
 run('venv',[PY311,'-B','-I','-m','venv','--symlinks','--without-pip',str(WORK/'venv')]);venv=WORK/'venv';python=venv/'bin/python';site=venv/'lib/python3.9/site-packages'
 def interpreter_chain(path):
  result=[];seen=set()
  for _ in range(8):
   path=Path(os.path.abspath(str(path)))
   if str(path) in seen:raise ValueError('interpreter-link-cycle')
   seen.add(str(path));st=path.lstat()
   item={'path':str(path),'dev':st.st_dev,'ino':st.st_ino,'mode':st.st_mode,'mtimeNs':st.st_mtime_ns,'bytes':st.st_size}
   if path.is_symlink():
    target=os.readlink(path);item['target']=target;result.append(item)
    path=Path(target) if os.path.isabs(target) else path.parent/target
   else:
    if not path.is_file():raise ValueError('interpreter-target-shape')
    result.append(item);return result
  raise ValueError('interpreter-link-depth')
 original_chain=interpreter_chain(Path(PY311));generated_chain=interpreter_chain(python)
 selected_target=Path(PY311).resolve(strict=True)
 cfg=(venv/'pyvenv.cfg').read_bytes()
 if not python.is_symlink() or python.resolve(strict=True)!=selected_target or b'include-system-site-packages = false'not in cfg:raise ValueError('isolated-interpreter-selection')
 write(WORK/'interpreter-selection.json',enc({'originalChain':original_chain,'generatedChain':generated_chain,'target':str(selected_target),'pyvenvCfgSha256':sha(cfg),'qualification':'Supported framework symlink venv; selected target reused, not a copied interpreter.'}))
 def interpreter():
  if interpreter_chain(Path(PY311))!=original_chain or interpreter_chain(python)!=generated_chain or (venv/'pyvenv.cfg').read_bytes()!=cfg:raise ValueError('interpreter-current-custody')
 interpreter();run('ensurepip',[str(python),'-I','-B','-m','ensurepip','--default-pip'],timeout=30);interpreter()
 baseline={}
 for path in site.rglob('*'):
  if path.is_symlink():raise ValueError('bundled installer namespace alias')
  if path.is_file():baseline[path.relative_to(site).as_posix()]=path.read_bytes()
 if not baseline:raise ValueError('bundled installer namespace empty')
 for name,version in (('pip','21.2.4'),('setuptools','58.0.4')):
  metadata_name=name+'-'+version+'.dist-info/METADATA'
  raw=baseline.get(metadata_name)
  if raw is None or ('\nName: '+name+'\n').encode()not in raw or ('\nVersion: '+version+'\n').encode()not in raw:raise ValueError('selected bundled installer metadata differs')
 if any(name in baseline for name in payload):raise ValueError('bundled installer shadows product')
 write(WORK/'bundled-installer-inventory.json',enc({'selectedEnsurepipVersion':'21.2.4','files':[{'path':name,'bytes':len(raw),'sha256':sha(raw)}for name,raw in sorted(baseline.items())]}))
 run('pip-install',[str(python),'-I','-B','-m','pip','install','--no-deps','--no-index','--no-compile',str(wheel)],timeout=60);interpreter()
 for name,b in payload.items():
  p=site/name
  if p.is_symlink()or p.read_bytes()!=b:raise ValueError('installed-source-correspondence')
 console=venv/'bin/ashlar'
 console_bytes=console.read_bytes()
 if not console_bytes.startswith(('#!'+str(python)+'\n').encode())or b'from ashlar.cli import main\n'not in console_bytes:raise ValueError('console-entrypoint')
 write(WORK/'installed-console.txt',console_bytes)
 record_path=site/'ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD';record_bytes=record_path.read_bytes()
 if len(record_bytes)>128*1024:raise ValueError('installed-record-bound')
 write(WORK/'installed-RECORD.csv',record_bytes)
 def installed_custody():
  if console.is_symlink()or console.read_bytes()!=console_bytes:raise ValueError('console-closing-custody')
  for name,b in metadata.items():
   if name.endswith('/RECORD'):continue
   if (site/name).is_symlink()or (site/name).read_bytes()!=b:raise ValueError('installed-metadata-correspondence')
  if record_path.read_bytes()!=record_bytes:raise ValueError('installed-record-custody')
  entries=list(csv.reader(io.StringIO(record_bytes.decode('utf-8'))));seen_record=set()
  if len(entries)>512:raise ValueError('installed-record-members')
  for entry in entries:
   if len(entry)!=3 or entry[0]in seen_record:raise ValueError('installed-record-shape')
   name,digest,size=entry;seen_record.add(name);path=site/name
   if name!='../../../bin/ashlar':safe(name)
   if path.is_symlink()or not path.is_file()or os.path.commonpath((str(path.resolve()),str(venv)))!=str(venv):raise ValueError('installed-record-path')
   raw=path.read_bytes()
   if name=='ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD':
    if digest or size:raise ValueError('installed-record-self')
   elif digest!='sha256='+base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).rstrip(b'=').decode()or size!=str(len(raw)):raise ValueError('installed-record-hash')
  if not set(payload).issubset(seen_record)or '../../../bin/ashlar'not in seen_record:raise ValueError('installed-record-closure')
  actual=set()
  for p in site.rglob('*'):
   if p.is_symlink():raise ValueError('installed namespace alias refused')
   if p.is_file():actual.add(p.relative_to(site).as_posix())
  for name,raw in baseline.items():
   if (site/name).is_symlink()or (site/name).read_bytes()!=raw:raise ValueError('bundled installer closing custody')
  if actual!=(seen_record-{'../../../bin/ashlar'})|set(baseline):raise ValueError('complete installed namespace changed')
 installed_custody()
 JAVA='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home'
 (WORK/'typing-site').mkdir()
 typing_source=Path('/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages/typing_extensions.py')
 write(WORK/'typing-site/typing_extensions.py',typing_source.read_bytes())
 ENV.update({'PATH':JAVA+'/bin:/usr/bin:/bin','JAVA_HOME':JAVA,'PYTHONPATH':str(site)+':/private/tmp/ashlar-evolution-selected-pg-site-a:/private/tmp/ashlar-indexed-delta4-python-20261010-a:/private/tmp/ashlar-spark4-python39-bridge:'+str(WORK/'typing-site'),'PYSPARK_PYTHON':str(python),'PYSPARK_DRIVER_PYTHON':str(python),'SPARK_LOCAL_IP':'127.0.0.1','SPARK_LOCAL_HOSTNAME':'localhost'})
 primary=None
 try:
  producer={'source':'/private/tmp/ashlar-umf-evolution-land-6a292','bun':'/opt/homebrew/Cellar/bun/1.4.2/bin/bun','git':'/usr/bin/git','timeout_seconds':30,'maximum_output_bytes':1048576,'maximum_receipt_bytes':4194304}
  configuration={'profile':'ashlar-commerce-evolution-invocation/0.1','mode':'continue','ledger_path':'/private/tmp/ashlar-evolution-installed-native-20261011-f/installation/run.sqlite','receipt_path':str(WORK/'prefix.receipt.json'),'producer':producer,'expected_sha256':'8abac861a6ada92aee0fb4080c1230867d358d776c16c92c5a776538ea657f95','through_ordinal':2}
  path=WORK/'continue-configuration.json';write(path,enc(configuration))
  provider=Path('/private/tmp/ashlar-evolution-continuation-provider-n.py')
  run('continue',[str(WORK/'venv/bin/ashlar'),'continue-commerce-evolution','--configuration',str(path),'--provider',str(provider),'--provider-sha256',sha(provider.read_bytes())],timeout=300,maximum=16*1024*1024)
  prefix=json.loads(bounded_read(WORK/'prefix.receipt.json',4194304))
  if prefix.get('profile')!='ashlar-commerce-evolution-prefix-receipt/0.1' or prefix.get('through_ordinal')!=2 or prefix.get('completed_count')!=3 or prefix.get('total_publications')!=8 or prefix.get('run_complete') is not False or prefix.get('run_sha256')!=configuration['expected_sha256']:raise ValueError('Exact partial prefix receipt required')
 except BaseException as error:primary=error
 for close in (source_custody,interpreter,installed_custody,verify_namespace):
  try:close()
  except BaseException as error:primary=select_failure(primary,error)
 result={'profile':'ashlar-installed-public-evolution-operation/0.1','sourceRevision':REV,'phases':phases,'openingClosingCustody':primary is None,'installedInterpreter':'CPython3.9 explicit symlink venv','nativeScope':'private two ordinary sources; fresh-session ACK reconciliation; one same-original ordinal2 partial-prefix continuation; no full8 or external32bag qualification; prior G faults retained separately; no Truss/production authority','wholeSuccess':primary is None}
 try:write(WORK/'receipt.json',enc(result))
 except BaseException as error:primary=select_failure(primary,error)
 if primary is not None:raise primary

if __name__=='__main__':main()
