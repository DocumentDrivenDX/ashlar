import importlib.util,pathlib,tempfile,hashlib,http.client,threading,unittest,json
from http.server import HTTPServer,BaseHTTPRequestHandler
from unittest.mock import patch
s=importlib.util.spec_from_file_location('proxy','/private/tmp/ashlar-p06-response-loss-proxy-g.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Controls(unittest.TestCase):
 def case(self,fail,short=False,unframed=False,header_fail=False):
  request=b'{"original":"request"}';seen=[]
  class Up(BaseHTTPRequestHandler):
   def log_message(self,*a):pass
   def do_POST(self):
    seen.append(self.rfile.read(int(self.headers['Content-Length'])))
    if fail:self.connection.close();return
    self.send_response(200)
    if not unframed:self.send_header('Content-Length','1048576')
    self.end_headers();self.wfile.write(b'x'*(7 if short or unframed else m.MAXIMUM));self.close_connection=True
  up=HTTPServer(('127.0.0.1',0),Up);t=threading.Thread(target=up.handle_request);t.start()
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d).resolve();p.chmod(0o700)
   proxy=m.make_server(p,port=self.port(),expected_request_sha256=hashlib.sha256(request).hexdigest(),expected_authorization='test-only',upstream_port=up.server_port)
   error=None
   try:
    with m.one_shot(proxy):
     c=http.client.HTTPConnection('127.0.0.1',proxy.server_port,timeout=10)
     try:
      c.request('POST',m.PATH,request,{'Authorization':'test-only'})
      with self.assertRaises(http.client.RemoteDisconnected):c.getresponse()
     finally:c.close()
   except Exception as e:error=e
   self.assertEqual(seen,[request]);self.assertEqual((p/'forwarded-request.bin').read_bytes(),request)
   terminal=json.loads((p/'terminal.json').read_bytes());self.assertFalse(terminal['replyDelivered']);self.assertEqual(terminal['upstreamTerminalRetained'],not fail and not short and not unframed and not header_fail)
   if fail:self.assertIsInstance(error,http.client.RemoteDisconnected);self.assertFalse((p/'upstream-response.bin').exists())
   elif short or unframed:self.assertIsInstance(error,ValueError);self.assertEqual((p/'upstream-response.bin').read_bytes(),b'x'*7)
   else:
    if header_fail:self.assertIsInstance(error,ValueError)
    else:self.assertIsNone(error)
    self.assertEqual((p/'upstream-response.bin').read_bytes(),b'x'*m.MAXIMUM)
  t.join(10);up.server_close();self.assertFalse(t.is_alive())
 def port(self):
  import socket
  with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
 def test_complete_drop(self):self.case(False)
 def test_upstream_failure(self):self.case(True)
 def test_truncated_advertised_body(self):self.case(False,True)
 def test_unframed_reply(self):self.case(False,unframed=True)
 def test_root_replacement(self):
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d).resolve()/'owned';root.mkdir(mode=0o700);e=m.EvidenceDirectory(root)
   original=root.with_name('original');root.rename(original);root.mkdir(mode=0o700);foreign=root/'foreign';foreign.write_bytes(b'foreign')
   try:
    with self.assertRaises(ValueError):m.retain(e,'body',b'original')
    self.assertFalse((root/'body').exists());self.assertEqual(foreign.read_bytes(),b'foreign')
   finally:e.close()
 def test_primary_close(self):
  primary=KeyboardInterrupt('original')
  def close():raise ValueError('closing')
  try:
   with m.owned(None,close):raise primary
  except BaseException as e:self.assertIs(e,primary)
 def test_directory_fsync_close(self):
  primary=KeyboardInterrupt('fsync')
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d).resolve();root.chmod(0o700);e=m.EvidenceDirectory(root)
   original=m.os.close
   def close(fd):original(fd);raise ValueError('close')
   try:
    with patch.object(m.os,'fsync',side_effect=primary),patch.object(m.os,'close',side_effect=close):
     try:m.retain(e,'body',b'x')
     except BaseException as error:self.assertIs(error,primary)
   finally:e.close()
 def test_interrupted_first_join_still_shutdown_reaps(self):
  from types import SimpleNamespace
  primary=KeyboardInterrupt('first join');calls=[]
  class Thread:
   alive=True
   def __init__(self,**kw):pass
   def start(self):calls.append('start')
   def join(self,seconds):
    calls.append(('join',seconds))
    if seconds==45:raise primary
    self.alive=False
   def is_alive(self):return self.alive
  class Timer:
   def __init__(self,*a):pass
   def start(self):pass
   def cancel(self):calls.append('timer-cancel')
   def join(self,*a):pass
   def is_alive(self):return False
  class Socket:
   def shutdown(self,*a):calls.append('shutdown')
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d).resolve();root.chmod(0o700)
   server=m.make_server(root,port=self.port(),expected_request_sha256='0'*64,expected_authorization='test-only',upstream_port=self.port())
   server.active_connection=Socket();server.active_upstream=SimpleNamespace(sock=Socket())
   try:
    with patch.object(m.threading,'Thread',Thread),patch.object(m.threading,'Timer',Timer):
     try:
      with m.one_shot(server):pass
     except BaseException as error:self.assertIs(error,primary)
    self.assertEqual(calls.count('shutdown'),2);self.assertIn(('join',15),calls);self.assertTrue(server.cleanup_complete);self.assertIsNone(server.evidence.fd)
   finally:server.server_close();server.evidence.close()
 def timer_case(self,live):
  primary=KeyboardInterrupt('timer cancel');calls=[]
  class Thread:
   def __init__(self,**kw):pass
   def start(self):pass
   def join(self,*a):pass
   def is_alive(self):return False
  class Timer:
   def __init__(self,*a):pass
   def start(self):pass
   def cancel(self):calls.append('cancel');raise primary
   def join(self,*a):calls.append('join')
   def is_alive(self):return live
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d).resolve();root.chmod(0o700)
   server=m.make_server(root,port=self.port(),expected_request_sha256='0'*64,expected_authorization='test-only',upstream_port=self.port())
   try:
    with patch.object(m.threading,'Thread',Thread),patch.object(m.threading,'Timer',Timer):
     try:
      with m.one_shot(server):pass
     except BaseException as error:self.assertIs(error,primary)
    self.assertEqual(calls,['cancel','join']);self.assertEqual(server.cleanup_complete,not live);self.assertIsNone(server.evidence.fd)
   finally:server.server_close();server.evidence.close()
 def test_timer_cancel_interrupt_still_joins(self):self.timer_case(False)
 def test_live_timer_refuses_complete_cleanup(self):self.timer_case(True)
 def framed_case(self,wire,positive):
  import socket
  request=b'original';up=socket.socket();up.bind(('127.0.0.1',0));up.listen(1)
  def serve():
   c,_=up.accept()
   with c:
    data=b''
    while b'\r\n\r\n' not in data:data+=c.recv(4096)
    c.sendall(wire)
  t=threading.Thread(target=serve);t.start()
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d).resolve();p.chmod(0o700)
   proxy=m.make_server(p,port=self.port(),expected_request_sha256=hashlib.sha256(request).hexdigest(),expected_authorization='test-only',upstream_port=up.getsockname()[1]);error=None
   try:
    with m.one_shot(proxy):
     c=http.client.HTTPConnection('127.0.0.1',proxy.server_port,timeout=10)
     try:
      c.request('POST',m.PATH,request,{'Authorization':'test-only'})
      with self.assertRaises(http.client.RemoteDisconnected):c.getresponse()
     finally:c.close()
   except Exception as e:error=e
   self.assertEqual(error is None,positive)
   self.assertEqual(json.loads((p/'terminal.json').read_bytes())['upstreamTerminalRetained'],positive)
   self.assertTrue((p/'upstream-response-headers.json').exists())
   if positive:
    self.assertEqual((p/'upstream-response.bin').read_bytes(),b'abcde')
    self.assertEqual(json.loads((p/'upstream-response-headers.json').read_bytes())['trailers'],['X-Check: valid'])
  t.join(10);up.close();self.assertFalse(t.is_alive())
 def test_chunked_complete(self):self.framed_case(b'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n3\r\nabc\r\n2\r\nde\r\n0\r\nX-Check: valid\r\n\r\n',True)
 def test_chunked_truncated(self):self.framed_case(b'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n3\r\nab',False)
 def test_chunked_missing_trailer_end(self):self.framed_case(b'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n3\r\nabc\r\n0\r\n',False)
 def test_ambiguous_framing(self):self.framed_case(b'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nContent-Length: 3\r\n\r\n3\r\nabc\r\n0\r\n\r\n',False)
 def test_unknown_encoding(self):self.framed_case(b'HTTP/1.1 200 OK\r\nTransfer-Encoding: gzip\r\n\r\nabc',False)
 def test_invalid_chunk_delimiter(self):self.framed_case(b'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n3\r\nabcXX0\r\n\r\n',False)
 def test_chunk_extensions_refused(self):self.framed_case(b'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n3;bad extension\r\nabc\r\n0\r\n\r\n',False)
 def test_header_retention_failure_keeps_body_metadata(self):
  original=m.retain
  def retain(directory,name,body):
   if name=='upstream-response-headers.json':raise ValueError('header retention')
   return original(directory,name,body)
  # Existing complete-length case verifies the original body but expects success;
  # a dedicated interception checks every independent retention attempt instead.
  calls=[]
  def observed(directory,name,body):
   calls.append((name,body));return retain(directory,name,body)
  with patch.object(m,'retain',side_effect=observed):
   self.case(False,header_fail=True)
  self.assertIn('upstream-response.bin',[x[0]for x in calls])
  metadata=json.loads(next(x[1]for x in calls if x[0]=='upstream-response.json'));self.assertFalse(metadata['complete'])
 def test_encoded_header_bound_keeps_body_metadata(self):
  with patch.object(m.FramedResponse,'getheaders',return_value=[('X-Large','x'*m.MAXIMUM)]):self.case(False,header_fail=True)
if __name__=='__main__':unittest.main()
