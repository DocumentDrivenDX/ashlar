"""Extract actual provider Policy without importing SDK or performing effects."""
import ast,hashlib,json,tempfile,sys
from pathlib import Path
from types import SimpleNamespace
from contextlib import contextmanager
sys.path.insert(0,'/Users/erik/Projects/ashlar/src')
from ashlar_host.puppy_release_cli import original_file
from ashlar_host.lifecycle import finish
source=Path('/private/tmp/ashlar-p06-response-loss-provider-f.py')
tree=ast.parse(source.read_text());owner=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='_open');node=next(n for n in owner.body if isinstance(n,ast.ClassDef)and n.name=='Policy')
code=compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(source),'exec')
checks=[]
with tempfile.TemporaryDirectory(dir='/private/tmp')as directory:
 root=Path(directory).resolve();runtime=root/'native-runtime.json';source_path=root/'source.json';database=root/'db';model=root/'model.json';receipt=root/'receipt.json'
 runtime.write_bytes(b'{"engine":"selected"}');source_path.write_bytes(b'{"original":"whole"}');database.write_bytes(b'original-database');model.write_bytes(b'{"model":"original"}')
 receipt.write_text(json.dumps({'release_sha256':'release','database_sha256':hashlib.sha256(database.read_bytes()).hexdigest(),'model_sha256':hashlib.sha256(model.read_bytes()).hexdigest()}))
 snapshot={p:p.read_bytes()for p in [runtime,source_path,database,model,receipt]}
 def construct():
  calls=[]
  globals_={'Path':Path,'hashlib':hashlib,'decode':json.loads,'contextmanager':contextmanager,'finish':finish,'ROOT':root,'original_file':original_file,'runtime_original':original_file(runtime,1048576),'info':{'release_hashes':['release']},'source_paths':{'release':source_path},'source_originals':{'release':original_file(source_path,16777216)},'prepared_originals':{str(p):original_file(p,33554432)for p in [database,model,receipt]},'prepared':{'release':(str(database),str(model),str(receipt),hashlib.sha256(receipt.read_bytes()).hexdigest())},'runtime':lambda c:calls.append('inert-current-instance-check'),'PuppyReleaseHandle':lambda r:SimpleNamespace(release=r),'release':SimpleNamespace(sha256='release')}
  exec(code,globals_);return globals_['Policy'](),calls
 handle=SimpleNamespace(release=SimpleNamespace(sha256='release'))
 policy,calls=construct();policy.admit(handle,None);checks.append('actual admit positive: runtime/source/prepared')
 for p in snapshot:
  policy,calls=construct();p.write_bytes(snapshot[p]+b' ')
  try:policy.admit(handle,None)
  except ValueError:checks.append('byte drift refused '+p.name)
  else:raise AssertionError('drift accepted')
  p.write_bytes(snapshot[p])
 policy,calls=construct();replacement=root/'replacement';replacement.write_bytes(database.read_bytes());replacement.replace(database)
 try:policy.admit(handle,None)
 except ValueError:checks.append('same bytes replacement inode refused')
 else:raise AssertionError('replacement accepted')
 policy,calls=construct();cancel=KeyboardInterrupt('owned primary')
 try:
  with policy.writer(None):
   runtime.write_bytes(b'changed');raise cancel
 except KeyboardInterrupt as error:assert error is cancel;checks.append('writer cancellation survives closing drift')
 else:raise AssertionError('cancellation lost')
 result={'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'checks':checks,'scope':'Extracted actual Policy with inert current-instance function; real public file snapshots; no SDK imports/network/native operations'}
print(json.dumps(result,sort_keys=True))
