from pathlib import Path
from collections import Counter
import json,hashlib
from ashlar.supply_chain_source import build_transaction
from ashlar.graph_release import validate_release_carrier
from ashlar_host.supply_chain_projection import original_supply_chain_oracle
from ashlar_host.schema_rows import fixture_columns
from ashlar_host.resources import RESOURCE_ROOT
from ashlar_host.supply_chain_request import SOURCE_SYSTEM
from ashlar_host.graphframes_release import validate_common_evidence,validate_projected_carrier_evidence,validate_derived_evidence
ROOT=Path('/Users/erik/Projects/ashlar/out/supply-chain-graphframes-common-20261017');r=ROOT/'r2';sha=lambda raw:hashlib.sha256(raw).hexdigest();report=json.loads((r/'graphframes-query/report.json').read_bytes());request=json.loads((r/'graphframes-query/engine/input.json').read_bytes());result=report['result'];profile=request['profile'];release=request['release'];observations=report['observations'];assert observations==[json.loads(line)for line in (r/'graphframes-query/engine/observations.jsonl').read_bytes().splitlines()]
assert result==json.loads((r/'graphframes-query/engine/result.json').read_bytes())
assert result['common_cases_passed']==7 and result['cases']==[] and result['full_carrier_parity']is True and len(observations)==19
config=json.loads((r/'fresh-publication-configuration.json').read_bytes());model=Path(config['model']).read_bytes();graph=Path(config['graph']).read_bytes();batch,bindings=build_transaction(model,graph,source_system=SOURCE_SYSTEM);expected=original_supply_chain_oracle(model,graph,bindings,batch,fixture_columns(RESOURCE_ROOT))
canon=lambda rows:Counter(json.dumps(row,sort_keys=True,separators=(',',':'),ensure_ascii=False)for row in rows)
for kind,role,table in [('node','nodes','object_current'),('edge','edges','edge_current')]:
 original=[validate_release_carrier(row,kind)for row in expected[table]]
 assert canon(release[role])==canon(original)
 assert canon(result['common']['all-objects'if kind=='node'else'all-edges'])==canon(original)
validate_common_evidence(result,release,profile,observations);validate_projected_carrier_evidence(profile,observations);validate_derived_evidence(result,release,observations,r/'graphframes-query/engine')
selection=json.loads((ROOT/'stage2-selection.json').read_bytes());assert result['original_snapshots']==selection['vector']
assert sha((r/'graphframes-query/public-source-receipt.json').read_bytes())==json.loads((ROOT/'publication/report.json').read_bytes())['source']['public_dataset_receipt_sha256']
transport=json.loads((r/'graphframes-query/engine/transport.json').read_bytes());assert transport['complete']is True and transport['exit']==0
outer=json.loads((r/'graphframes-control/outer-attempt.json').read_bytes());assert outer['status']==0 and outer['cleanup']['groups_absent']is True and outer['cleanup']['session_leader_reaped']is True
value={'profile':'ashlar-supply-chain-graphframes-r2-independent-bags/0.1','mode':'Pure immutable retained source/report/raw record validation only; no engine/source/lease invocation, not a current publication authority grant','result':'PASS','native_common_cases':7,'authored_graphframes_cases':0,'observations':19,'all_nodes':20,'all_edges':23,'common_counts':{k:len(v)if type(v)is list else v for k,v in result['common'].items()},'complete_original_carrier_bags_equal':True,'raw_common_schemas_and_bags_valid':True,'derived_opening_before_closing_v0_uuid_valid':True,'original_four_table_vector_equal':True,'public_dataset_receipt_matches_stage1':True,'report_sha256':sha((r/'graphframes-query/report.json').read_bytes()),'elapsed_seconds':outer['elapsed_seconds'],'actual_cleanup':outer['cleanup']}
(r/'independent-bag-review.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');print(json.dumps(value))
