"""Seven common operations only, after successful new original publication."""
from pathlib import Path
import json,os,sys,hashlib,importlib.util
from ashlar_host.lifecycle import finish,owned_context
ROOT=Path(__file__).resolve().parent;ORIGINAL=ROOT.parent;os.umask(0o077)
selection=json.loads((ROOT/'preparation.json').read_bytes())
def renew():
    for pin in selection['pins']:
        raw=Path(pin['path']).read_bytes()
        if len(raw)!=pin['bytes']or hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise PermissionError('Original preparation changed')
renew()
if not(ROOT/'fresh-publication-command-result.json').is_file():raise PermissionError('Actual successful fresh publication required')
from ashlar_host.supply_chain_native_cli import parse_supply_chain_native_invocation
from ashlar_host.supply_chain_producer import HeldSupplyChainDataset
from ashlar_host.supply_chain_common_read import SupplyChainCommonReadConfig,SupplyChainCommonRuntime,open_supply_chain_common_read
from ashlar_host.evolution_verification_types import VerificationBounds
from ashlar_host.graphframes_release import GraphFramesRuntimeConfig,execute_supply_chain_graphframes_release
native=parse_supply_chain_native_invocation((ROOT/'fresh-publication-configuration.json').read_bytes()).native
work=ROOT/'graphframes-query';work.mkdir(mode=0o700);ephemeral=work/'canonical-runtime';ephemeral.mkdir(mode=0o700)
os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable,SPARK_LOCAL_IP='127.0.0.1')
producer=HeldSupplyChainDataset(native.producer,native.model,native.graph,work/'public-source-receipt.json')
config=SupplyChainCommonReadConfig(producer.original_invocation(),native.output,native.output/'registry.json',native.output/'operations.sqlite',SupplyChainCommonRuntime(Path(sys.executable).resolve(),Path(os.environ['JAVA_HOME']),ephemeral),native.jars,native.pack,native.operation_capacity,VerificationBounds(262144,128,1048576,16777216,1048576,1048576))
spec=importlib.util.spec_from_file_location('selected_runtime_owner',ROOT/'runtime_policy.py');owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)
selected=owner.inventory();worker_digest,sdk_digest=owner.config_values(selected)
jdk=Path(json.loads((ORIGINAL/'jdk-selection.json').read_bytes())['java_home']);python=(ROOT/'worker-env-r2/bin/python').resolve()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
runtime=GraphFramesRuntimeConfig(python,digest(python),jdk,digest(jdk/'bin/java'),selected.worker_revision,worker_digest,sdk_digest,ORIGINAL/'worker-jars',work/'engine',300,1048576,16777216)
policy=owner.RuntimePolicy(runtime);records=[];answer=None;primary=None
try:
    with owned_context(open_supply_chain_common_read(config))as opened:
        answer=execute_supply_chain_graphframes_release(opened,runtime,policy,policy,lambda value:records.append(value))
except BaseException as error:primary=error
finish(primary,[renew])
if answer['common_cases_passed']!=7:raise PermissionError('Complete common result required')
raw=(json.dumps({'result':answer,'observations':records,'qualification':'Actual fresh finite source/publication plus seven common GraphFrames cases, not protectedACK, cloud, production or authoredGraphFrames scenarios'},sort_keys=True,separators=(',',':'))+'\n').encode()
if len(raw)>16777216:raise ValueError('Bounded complete result required')
fd=os.open(work/'report.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);error=None
try:
    if os.write(fd,raw)!=len(raw):raise OSError('Complete report write required')
    os.fsync(fd)
except BaseException as e:error=e
finish(error,[lambda:os.close(fd)])
print(json.dumps({'completed':'supply-chain-seven-common-graphframes','report':str(work/'report.json')}))
