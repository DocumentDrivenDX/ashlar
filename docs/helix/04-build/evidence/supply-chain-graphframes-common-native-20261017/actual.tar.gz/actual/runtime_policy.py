"""Explicit trusted local runtime selection, not source/publication authority."""
from pathlib import Path
import hashlib,json,os
from ashlar_host.graphframes_release import GraphFramesRuntimeFile,GraphFramesRuntimeInventory
ROOT=Path(__file__).resolve().parent;ORIGINAL=ROOT.parent
BASE=Path('/private/tmp/ashlar-publication-query-runtime-20261016-b/lib/python3.11/site-packages')

def files(root):
    root=Path(root)
    return sorted({p.resolve()for p in root.rglob('*')if p.is_file()and '__pycache__'not in p.parts},key=str)

def descriptors(paths):
    result=[]
    for path in paths:
        raw=path.read_bytes()
        result.append(GraphFramesRuntimeFile(path,hashlib.sha256(raw).hexdigest(),len(raw)))
    return tuple(result)

def inventory():
    site=ROOT/'worker-env-r2/lib/python3.11/site-packages';sdk=ORIGINAL/'worker-sdk'
    worker=files(site)
    # The .pth references the explicit sdk root. Include only these selected
    # support packages and metadata, not the parent Spark4 installation.
    support=[]
    for name in ('typing_extensions.py','typing_extensions-4.15.0.dist-info','importlib_metadata','zipp'):
        p=sdk/name
        if p.is_file():support.append(p.resolve())
        elif p.is_dir():support.extend(files(p.resolve()))
    for pattern in ('importlib_metadata-*.dist-info','zipp-*.dist-info'):
        for p in sdk.glob(pattern):support.extend(files(p.resolve()))
    jdk=Path(json.loads((ORIGINAL/'jdk-selection.json').read_bytes())['java_home'])
    support.extend(files(ROOT/'worker-support-r2'));support.extend(files(jdk));support.extend(files(ORIGINAL/'worker-jars'))
    support.append((ROOT/'worker-env-r2/bin/python').resolve())
    support.append((ROOT/'worker-env-r2/pyvenv.cfg').resolve())
    groups=[]
    for distribution,package in [('pyspark','pyspark'),('delta-spark','delta'),('graphframes-py','graphframes')]:
        selected=files(sdk/package)
        stem={'pyspark':'pyspark','delta-spark':'delta_spark','graphframes-py':'graphframes_py'}[distribution]
        for p in sdk.glob(stem+'-*.dist-info'):selected.extend(files(p))
        groups.append((distribution,descriptors(sorted(set(selected),key=str))))
    groups.append(('transitive-imports',descriptors(sorted(set(support),key=str))))
    return GraphFramesRuntimeInventory('33ddfb678fae565c4370591f095ec10fde38578d',descriptors(worker),tuple(groups))

def descriptor_digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def config_values(selected):
    def records(fs):return [{'path':str(f.path),'sha256':f.sha256,'size':f.size}for f in fs]
    return descriptor_digest(records(selected.worker)),descriptor_digest({n:records(fs)for n,fs in selected.sdks})

class RuntimePolicy:
    def __init__(self,runtime):
        self.runtime=runtime;self.selected=inventory();self.names=self.namespace()
        self.selected.verify(runtime)
    def namespace(self):
        roots=[ROOT/'worker-support-r2',ORIGINAL/'worker-sdk',ROOT/'worker-env-r2/lib/python3.11/site-packages',ORIGINAL/'worker-jars',Path(json.loads((ORIGINAL/'jdk-selection.json').read_bytes())['java_home'])]
        roots.extend(Path(link['target'])for link in json.loads((ORIGINAL/'worker-support-selection.json').read_bytes())['links']if Path(link['target']).is_dir())
        return tuple((str(root),tuple((str(p.relative_to(root)),os.readlink(p)if p.is_symlink()else 'directory'if p.is_dir()else 'file')for p in sorted(root.rglob('*'))if '__pycache__'not in p.parts))for root in roots)
    def renew_graphframes_runtime(self,selected,runtime,context):
        if context is not self or selected is not self.selected or runtime is not self.runtime or self.namespace()!=self.names:
            raise PermissionError('Original independent local runtime selection changed')
        selected.verify(runtime)
    def admit_graphframes_runtime(self,runtime,context):
        self.renew_graphframes_runtime(self.selected,runtime,context)
        return self.selected
