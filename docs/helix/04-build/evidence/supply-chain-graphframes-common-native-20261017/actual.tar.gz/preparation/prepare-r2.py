"""Prepare a fresh missing-dependency correction; do not invoke source or engines."""
from pathlib import Path
import json,zipfile,subprocess,hashlib,shutil
ROOT=Path(__file__).resolve().parent;R=ROOT/'r2';R.mkdir(mode=0o700)
CAN=Path('/private/tmp/ashlar-projected-detail-probe-20261017-a');wheel_record=json.loads((CAN/'wheel-preparation.json').read_bytes());wheel=Path(wheel_record['wheel']);assert hashlib.sha256(wheel.read_bytes()).hexdigest()==wheel_record['wheel_sha256']
python=CAN/'runtime/bin/python';env=R/'worker-env-r2';subprocess.run([str(python),'-I','-B','-m','venv','--without-pip','--copies',str(env)],check=True,timeout=30)
site=env/'lib/python3.11/site-packages'
with zipfile.ZipFile(wheel)as z:
 z.extractall(site);installed=[]
 for name in z.namelist():
  if name.endswith('/'):continue
  raw=(site/name).read_bytes();assert raw==z.read(name);installed.append({'path':str(site/name),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
archive=Path('/Users/erik/Library/Caches/pip/http-v2/2/c/6/c/9/2c6c9c16f569bab881b1cbc5c8fa48e9839723f6b5412040d8b82484.body');support=R/'worker-support-r2';support.mkdir(mode=0o700)
with zipfile.ZipFile(archive)as z:
 assert 'numpy-2.4.6.dist-info/METADATA'in z.namelist()
 assert 'Tag: cp311-cp311-macosx_14_0_arm64'in z.read('numpy-2.4.6.dist-info/WHEEL').decode()
 members=z.infolist();assert sum(x.file_size for x in members)<=100000000
 for member in members:
  path=support/member.filename;assert support in path.resolve().parents
 z.extractall(support)
(site/'00-selected-support.pth').write_text(str(support)+'\n');(site/'01-selected-original-sdk.pth').write_text(str(ROOT/'worker-sdk')+'\n')
(R/'installed-r2.json').write_text(json.dumps({'product_revision':wheel_record['commit'],'wheel':str(wheel),'wheel_sha256':wheel_record['wheel_sha256'],'worker_files':installed,'numpy':{'version':'2.4.6','tag':'cp311-cp311-macosx_14_0_arm64','archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'scope':'Compatible explicitly selected cached NumPy build; not assertion of previous NumPy build or scalar operations. Entire extracted package/native.libs included in runtime inventory.'},'original_worker_sdk_reused':str(ROOT/'worker-sdk'),'canonical_python':str(python),'scope':'New dependency/env only; original controls/SDK/environment/publication untouched. No engine or source invoked.'},sort_keys=True,indent=2)+'\n')
shutil.copy2(ROOT/'fresh-publication-configuration.json',R/'fresh-publication-configuration.json')
# Retain the actual first-stage result as correspondence, not a native grant.
shutil.copy2(ROOT/'fresh-publication-command-result.json',R/'fresh-publication-command-result.json')
policy=(ROOT/'runtime_policy.py').read_text().replace("ROOT=Path(__file__).resolve().parent","ROOT=Path(__file__).resolve().parent;ORIGINAL=ROOT.parent")
policy=policy.replace("ROOT/'worker-env", "ROOT/'worker-env-r2").replace("ROOT/'worker-sdk'", "ORIGINAL/'worker-sdk'").replace("ROOT/'worker-jars'", "ORIGINAL/'worker-jars'").replace("ROOT/'jdk-selection.json'", "ORIGINAL/'jdk-selection.json'").replace("ROOT/'worker-support-selection.json'", "ORIGINAL/'worker-support-selection.json'").replace("'4f004106edef5c9987cbf56a3bc3118528030db7'",repr(wheel_record['commit']))
policy=policy.replace("support.extend(files(jdk));", "support.extend(files(ROOT/'worker-support-r2'));support.extend(files(jdk));")
policy=policy.replace("roots=[ORIGINAL/'worker-sdk'", "roots=[ROOT/'worker-support-r2',ORIGINAL/'worker-sdk'")
(R/'runtime_policy.py').write_text(policy)
runner=(ROOT/'run-graphframes.py').read_text().replace("ROOT=Path(__file__).resolve().parent;", "ROOT=Path(__file__).resolve().parent;ORIGINAL=ROOT.parent;").replace("ROOT/'jdk-selection.json'", "ORIGINAL/'jdk-selection.json'").replace("ROOT/'worker-env/bin/python'", "ROOT/'worker-env-r2/bin/python'").replace("ROOT/'worker-jars'", "ORIGINAL/'worker-jars'")
(R/'run-graphframes.py').write_text(runner)
control=R/'graphframes-control';control.mkdir(mode=0o700)
supervisor=(ROOT/'graphframes-control/supervise.py').read_text().replace(str(ROOT/'canonical-env/lib/python3.11/site-packages'),str(CAN/'runtime/lib/python3.11/site-packages')).replace(str(ROOT/'canonical-env/bin/python'),str(python))
(control/'supervise.py').write_text(supervisor)
print('fresh R2 prepared without source/native calls')
