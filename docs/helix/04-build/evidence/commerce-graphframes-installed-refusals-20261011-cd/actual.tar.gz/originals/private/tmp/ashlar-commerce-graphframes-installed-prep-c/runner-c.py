"""Bounded prepared installed original-commerce workflow; no import-side effects."""
import hashlib,importlib.util,json,os,re,stat,time,zipfile,csv,base64,argparse
from pathlib import Path
ROOT=Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-c')
COMMAND=ROOT/'command-c.json'
def select(primary,error):
    return error if primary is None or isinstance(primary,Exception) and not isinstance(error,Exception) else primary

def read(path,maximum=16*1024*1024):
    stream=Path(path).open('rb');primary=None;raw=None
    try:
        raw=stream.read(maximum+1)
        if len(raw)>maximum:raise ValueError('Bounded file required')
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
    return raw

def retain(path,value):
    raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();stream=path.open('xb');primary=None
    try:
        if stream.write(raw)!=len(raw):raise OSError('Short evidence write')
        stream.flush();os.fsync(stream.fileno())
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--command',required=True,type=Path);parser.add_argument('--sha256',required=True);args=parser.parse_args()
    if re.fullmatch('[0-9a-f]{64}',args.sha256) is None:raise ValueError('External command pin required')
    command_path=args.command
    raw=read(command_path,1024*1024)
    if hashlib.sha256(raw).hexdigest()!=args.sha256:raise ValueError('Externally selected command differs')
    command=json.loads(raw);start=time.monotonic();deadline=start+720
    output=Path(command['output']);records=[];primary=None;closing=False;capture=None;installed=[];owned_id=None;whole=None;host_namespaces={}
    def verify():
        if read(command_path,1024*1024)!=raw:raise ValueError('Original command changed')
        for item in command['resources']:
            if time.monotonic()>=deadline-30:raise TimeoutError('Closing budget required')
            p=Path(item['path']);info=p.lstat()
            if not stat.S_ISREG(info.st_mode):raise ValueError('Original regular resource required')
            b=read(p,max(1,item['size']))
            if len(b)!=item['size'] or hashlib.sha256(b).hexdigest()!=item['sha256']:raise ValueError('Resource changed')
        for directory,names in command['jarNamespaces'].items():
            if sorted(p.name for p in Path(directory).iterdir())!=names:raise ValueError('Exact selected JAR namespace required')
        namespace=json.loads(read(Path(command['runtimeNamespaceDescriptor']),4*1024*1024))
        actual=[(str(p),'link'if p.is_symlink()else'file'if p.is_file()else'directory'if p.is_dir()else'refused',os.readlink(p)if p.is_symlink()else None)for p in sorted(Path(namespace['root']).rglob('*'))]
        if actual!=[tuple(x)for x in namespace['members']]:raise ValueError('Original complete selected SDK namespace changed')
        for link in command['dockerLinks']:
            p=Path(link['path']);s=p.lstat()
            if not stat.S_ISLNK(s.st_mode) or os.readlink(p)!=link['target'] or (s.st_dev,s.st_ino)!=(link['device'],link['inode']):raise ValueError('Docker selected link changed')
    def phase(name,argv,cwd,env,seconds):
        remaining=deadline-time.monotonic()-30
        if remaining<1:raise TimeoutError('No phase budget remains')
        result=capture.capture(argv,cwd,env,output/(name+'.stdout'),output/(name+'.stderr'),min(seconds,remaining),4*1024*1024)
        records.append({'phase':name,'argv':argv,'capture':result})
        if result['exitCode']!=0:raise RuntimeError('Required phase refused: '+name)
        return result
    def installed_verify():
        for directory,expected in host_namespaces.items():
            actual=[]
            for p in Path(directory).rglob('*'):
                if p.is_symlink():raise ValueError('Installed host alias introduced')
                if p.is_file():actual.append(str(p.relative_to(directory)))
                elif not p.is_dir():raise ValueError('Unexpected installed host carrier')
            if sorted(actual)!=expected:raise ValueError('Installed host namespace changed')
        for item in installed:
            if hashlib.sha256(read(item['path'],max(1,item['size']))).hexdigest()!=item['sha256']:raise ValueError('Installed host changed')
    try:
        verify()
        if output.exists() or output.is_symlink():raise ValueError('Fresh whole output required')
        output.mkdir(mode=0o700)
        spec=importlib.util.spec_from_file_location('selected_capture',command['captureModule']);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
        base=command['environment'];installer=command['installer'];python=command['python311'];source=str(ROOT/'host-source')
        wheel_dir=output/'wheel';wheel_dir.mkdir(mode=0o700)
        phase('wheel',[installer,'-I','-B','-m','pip','wheel','--no-deps','--no-index','--no-build-isolation','--wheel-dir',str(wheel_dir),source],source,base,60)
        wheels=list(wheel_dir.glob('*.whl'))
        if len(wheels)!=1:raise ValueError('One actual host wheel required')
        wheel=wheels[0];archive=zipfile.ZipFile(wheel);primary_zip=None;members=[]
        try:
            for name in archive.namelist():
                if name.startswith(('ashlar/','ashlar_host/')):
                    original=ROOT/'host-source/src'/name
                    if archive.read(name)!=read(original):raise ValueError('Immutable source/wheel correspondence differs')
                if not name.endswith('/'):members.append((name,archive.read(name)))
        except BaseException as error:primary_zip=error
        try:archive.close()
        except BaseException as error:primary_zip=select(primary_zip,error)
        if primary_zip is not None:raise primary_zip
        for kind in ('canonical','worker'):
            envdir=output/(kind+'-env')
            phase(kind+'-venv',[python,'-I','-B','-m','venv','--copies','--without-pip',str(envdir)],str(output),base,30)
            phase(kind+'-install',[installer,'-I','-B','-m','pip','--python',str(envdir/'bin/python'),'install','--no-deps','--no-index','--no-compile',str(wheel)],str(output),base,30)
            site=Path(command['hostSites'][kind])
            for name,expected in members:
                if name.endswith('/RECORD'):continue
                p=site/name;b=read(p)
                if b!=expected:raise ValueError('Installed wheel payload/metadata differs')
                installed.append({'path':str(p),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
            for package in ('ashlar','ashlar_host'):
                expected=sorted(name[len(package)+1:] for name,data in members if name.startswith(package+'/'))
                host_namespaces[str(site/package)]=expected
            installed_verify()
            records_file=next(site.glob('ashlar_graph_toolkit-*.dist-info/RECORD'))
            record_raw=read(records_file)
            for relative,hashed,size in csv.reader(record_raw.decode().splitlines()):
                actual=(site/relative).resolve()
                if not actual.is_relative_to(envdir.resolve()):raise ValueError('Installed RECORD escapes owned environment')
                if not hashed:
                    if actual!=records_file.resolve():raise ValueError('Unexpected unhashed RECORD entry')
                    continue
                data=read(actual)
                if hashed!='sha256='+base64.urlsafe_b64encode(hashlib.sha256(data).digest()).decode().rstrip('=') or str(len(data))!=size:raise ValueError('Actual installed RECORD differs')
            installed.append({'path':str(records_file),'size':len(record_raw),'sha256':hashlib.sha256(record_raw).hexdigest()})
            console=envdir/'bin/ashlar';b=read(console)
            if b'from ashlar.cli import main' not in b or not b.startswith(('#!'+str(envdir/'bin/python')+'\n').encode()):raise ValueError('Installed public entrypoint differs')
            installed.append({'path':str(console),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
        retain(output/'installed-host.json',{'sourceRevision':command['sourceRevision'],'wheelSha256':hashlib.sha256(read(wheel)).hexdigest(),'files':installed})
        fixture=json.loads(read(Path(command['retainedFixtureInventory']),1024*1024));owned_id=fixture['container_id']
        if owned_id!=command['retainedContainerId'] or fixture['container']!=command['container']:raise ValueError('Retained exact fixture differs')
        worker_site=Path(command['hostSites']['worker'])
        selector=worker_site/'selected-sdk.pth'
        stream=selector.open('xb');write_primary=None
        try:
            value=(command['graphframesSdk']+'\n').encode()
            if stream.write(value)!=len(value):raise OSError('Short selector write')
            stream.flush();os.fsync(stream.fileno())
        except BaseException as error:write_primary=error
        try:stream.close()
        except BaseException as error:write_primary=select(write_primary,error)
        if write_primary is not None:raise write_primary
        phase('worker-import',[str(output/'worker-env/bin/python'),'-I','-B',str(ROOT/'inspect-worker-c.py')],str(ROOT),base,15)
        spec=importlib.util.spec_from_file_location('selected_runtime_plan',command['runtimePlanModule']);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        plan=module.prepare(command['sourceRevision'],worker_site,Path(command['graphframesSdk']),Path(command['stdlib']),output/'worker-env/bin/python',{item['path']:item for item in command['resources']if Path(item['path']).is_relative_to(Path(command['graphframesSdk']))})
        proof_raw=read(output/'worker-import.stdout',1024*1024)
        proof=json.loads(proof_raw)
        if set(proof)!={'format','sdk','worker','executable','prefix','sys_path','jvmStarted'} or proof['format']!='ashlar-graphframes-installed-import/0.1' or proof['jvmStarted'] is not False:raise ValueError('Actual import-only resolution proof required')
        if proof['executable']!=str(output/'worker-env/bin/python') or proof['prefix']!=str(output/'worker-env') or proof['worker']!=str(worker_site/'ashlar_host/graphframes_release.py'):raise ValueError('Actual isolated installed worker correspondence differs')
        expected_versions={'pyspark':'3.5.3','delta-spark':'3.2.1','graphframes-py':'0.12.3'}
        expected_packages={'pyspark':'pyspark','delta-spark':'delta','graphframes-py':'graphframes'}
        if set(proof['sdk'])!=set(expected_versions):raise ValueError('Exact three selected SDK resolutions required')
        for name,version in expected_versions.items():
            if proof['sdk'][name]!={'version':version,'origin':str(Path(command['graphframesSdk'])/expected_packages[name]/'__init__.py'),'metadata':command['graphframesSdk']}:raise ValueError('Actual selected SDK resolution differs')
        plan['resolution']=proof
        plan['selectors'].append({'path':str(output/'worker-import.stdout'),'size':len(proof_raw),'sha256':hashlib.sha256(proof_raw).hexdigest()})
        retain(output/'runtime-plan.json',plan)
        def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':')).encode()
        runtime={'python':str(output/'worker-env/bin/python'),'python_sha256':hashlib.sha256(read(output/'worker-env/bin/python')).hexdigest(),'java_home':command['workerJavaHome'],'java_sha256':command['workerJavaSha256'],'worker_revision':command['sourceRevision'],'worker_inventory_sha256':hashlib.sha256(encoded(plan['worker'])).hexdigest(),'sdk_inventory_sha256':hashlib.sha256(encoded(dict(plan['sdks']))).hexdigest(),'jars':command['graphframesJars'],'timeout_seconds':300,'maximum_stream_bytes':1048576,'maximum_evidence_bytes':16777216}
        invocation={'profile':'ashlar-original-commerce-graphframes-invocation/0.1','mode':'live-publication','pack':command['pack'],'publication':command['publication'],'output':str(output/'query'),'runtime':runtime}
        retain(output/'configuration.json',invocation)
        canonical_python=str(output/'canonical-env/bin/python')
        installed.append({'path':str(selector),'size':len(value),'sha256':hashlib.sha256(value).hexdigest()})
        phase('graphframes',[canonical_python,'-I','-B','-S',str(ROOT/'entry-c.py'),'graphframes','--command',str(command_path),'--sha256',args.sha256],str(ROOT),command['queryEnvironment'],command['graphframesWholeSeconds'])
        report=json.loads(read(output/'query/report.json'))
        whole={'sourceRevision':command['sourceRevision'],'reportSha256':hashlib.sha256(read(output/'query/report.json')).hexdigest(),'qualification':'Installed current original commerce GraphFrames original four scenarios and seven common operations only; independent actual bag review required.','retainedContainerId':owned_id}
    except BaseException as error:primary=error
    finally:
        try:verify();installed_verify();closing=True
        except BaseException as error:primary=select(primary,error)
        if primary is None and whole is not None:
            try:retain(output/'whole-result.json',whole)
            except BaseException as error:primary=select(primary,error)
        if output.is_dir():
            try:retain(output/'outer-receipt.json',{'commandSha256':hashlib.sha256(raw).hexdigest(),'phases':records,'closing':closing,'primary':None if primary is None else type(primary).__name__,'ownedContainerId':owned_id,'cleanup':'Container retained; no outer deletion based on unproven mutable handle. Public setup handles its positively acquired failures.','elapsedSeconds':time.monotonic()-start})
            except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
if __name__=='__main__':main()
