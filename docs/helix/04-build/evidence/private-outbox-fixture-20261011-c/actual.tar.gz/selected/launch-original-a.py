"""Preparation-only launcher: selected setup, retained owned handle, bounded capture."""
import hashlib,importlib.util,json,os,stat,subprocess,time
from pathlib import Path
ROOT=Path('/private/tmp/ashlar-private-outbox-fixture-prep-b')
COMMAND=ROOT/'command-draft.json'
primary=None

def select(primary,error):
    if primary is None:return error
    return error if isinstance(primary,Exception) and not isinstance(error,Exception) else primary

def read(path):
    stream=path.open('rb');error=None;raw=None
    try:raw=stream.read(128*1024*1024+1)
    except BaseException as e:error=e
    try:stream.close()
    except BaseException as e:error=select(error,e)
    if error is not None:raise error
    if len(raw)>128*1024*1024:raise ValueError('Resource capacity')
    return raw

def write(path,value):
    stream=path.open('xb');error=None
    try:
        stream.write(json.dumps(value,sort_keys=True,indent=2).encode()+b'\n');stream.flush();os.fsync(stream.fileno())
    except BaseException as e:error=e
    try:stream.close()
    except BaseException as e:error=select(error,e)
    if error is not None:raise error

command=json.loads(read(COMMAND));start=time.monotonic();deadline=start+command['wholeSeconds']
def verify():
    for item in command['resources']:
        if time.monotonic()>deadline-40:raise TimeoutError('Closing reserve')
        path=Path(item['path']);info=path.lstat()
        if not stat.S_ISREG(info.st_mode):raise ValueError('Exact regular resource required')
        raw=read(path)
        if len(raw)!=item['size'] or hashlib.sha256(raw).hexdigest()!=item['sha256']:raise ValueError('Resource changed')
    socket=command['socket'];info=Path(socket['path']).stat()
    if not stat.S_ISSOCK(info.st_mode) or (info.st_dev,info.st_ino)!=(socket['device'],socket['inode']):raise ValueError('Selected socket changed')

result=None;closing=False;cleanup=None;capture=None
try:
    verify()
    spec=importlib.util.spec_from_file_location('selected_capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py')
    capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
    if (ROOT/'operation/fixture').exists():raise ValueError('Fresh output required')
    result=capture.capture(command['argv'],command['cwd'],command['environment'],ROOT/'setup.stdout',ROOT/'setup.stderr',min(command['childSeconds'],deadline-time.monotonic()-40),command['streamBytes'])
    if result['exitCode']!=0:raise RuntimeError('Setup refused')
except BaseException as error:primary=error
finally:
    try:verify();closing=True
    except BaseException as error:primary=select(primary,error)
    if primary is not None:
        try:
            handle=ROOT/'operation/fixture/created-container.json'
            if handle.exists() and capture is not None:
                value=json.loads(read(handle));argv=value.get('cleanup_argv')
                # Only the tool's exact returned-ID cleanup is admissible.
                expected=json.loads(read(ROOT/'configuration.json'))
                container_id=value.get('container_id')
                import re
                if type(container_id) is not str or not re.fullmatch('[0-9a-f]{64}',container_id):raise ValueError('Safe owned handle required')
                wanted=[expected['docker'],'--host',expected['docker_host'],'rm','--force','--volumes',container_id]
                if argv!=wanted:raise ValueError('Exact owned cleanup argv required')
                if deadline-time.monotonic()<1:raise TimeoutError('Whole cleanup deadline')
                cleanup=capture.capture(wanted,str(ROOT),command['environment'],ROOT/'cleanup.stdout',ROOT/'cleanup.stderr',min(30,deadline-time.monotonic()),1048576)
                if cleanup['exitCode']!=0:raise RuntimeError('Owned cleanup refused')
            else:cleanup={'completed':False,'reason':'No retained ownedID; no name-based cleanup attempted'}
        except BaseException as error:primary=select(primary,error)
    try:write(ROOT/'actual-receipt.json',{'commandSha256':hashlib.sha256(read(COMMAND)).hexdigest(),'result':result,'closing':closing,'cleanup':cleanup,'primary':None if primary is None else type(primary).__name__,'elapsedSeconds':time.monotonic()-start})
    except BaseException as error:primary=select(primary,error)
if primary is not None:raise primary
