"""Selected immutable setup source; no ambient SDK or credentials."""
import importlib.util,runpy,sys
from pathlib import Path
root=Path('/private/tmp/ashlar-private-outbox-fixture-prep-b')
p='/private/tmp/umf-python-port-env/lib/python3.12/site-packages/typing_extensions.py'
s=importlib.util.spec_from_file_location('typing_extensions',p)
m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
sys.path.insert(0,'/private/tmp/ashlar-indexed-psycopg-python39-20261010-b')
import psycopg
if psycopg.__version__!='3.2.13' or psycopg.pq.__impl__!='binary':raise ValueError('Selected SDK required')
sys.path.insert(0,str(root/'source/src'))
sys.argv=[str(root/'source/tools/setup_private_outbox_fixture.py'),'--configuration',str(root/'configuration-c.json')]
runpy.run_path(sys.argv[0],run_name='__main__')
