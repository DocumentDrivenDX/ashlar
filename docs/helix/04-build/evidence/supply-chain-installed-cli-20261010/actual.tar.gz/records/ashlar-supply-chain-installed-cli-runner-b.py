"""Finite fresh immutable wheel/CLI operation. No PG, Spark, network or Weft rebuild."""
import base64,csv,gzip,hashlib,importlib.util,io,json,os,stat,sys,tarfile,zipfile
from pathlib import Path,PurePosixPath
WORK=Path('/private/tmp/ashlar-supply-chain-installed-cli-b');REPO=Path('/Users/erik/Projects/ashlar');REV='b89e9291a88d8536cb9adbb1cfe5638faf4245b8'
PRIMARY='/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
PY311='/Users/erik/.local/share/uv/python/cpython-3.11.17-macos-aarch64-none/bin/python3.11'
INDEX=Path('/private/tmp/ashlar-count-star-fresh-install-e/checkout/distributions/index.json');ID='weft-5ddcebd-count-star-aarch64-apple-darwin-candidate';PACKAGE=INDEX.parent/'realizations'/ID
BASE=Path('/private/tmp/weft-count-star-build-20261010-b')
ENV={'PYTHONPATH':'/private/tmp/truss-python-report-schema-env/lib/python3.11/site-packages','PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','PIP_CONFIG_FILE':'/dev/null','PIP_DISABLE_PIP_VERSION_CHECK':'1','PIP_NO_CACHE_DIR':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_TERMINAL_PROMPT':'0','GIT_ALLOW_PROTOCOL':'file'}
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return json.dumps(v,separators=(',',':'),sort_keys=True).encode()+b'\n'
def write(p,b):
 with p.open('xb')as f:f.write(b)
def safe(name):
 p=PurePosixPath(name)
 if not name or '\\'in name or p.is_absolute()or any(v in ('','..','.')for v in name.split('/')):raise ValueError('member-path')
 return p

def main():
 WORK.mkdir(mode=0o700);(WORK/'tmp').mkdir();ENV['TMPDIR']=str(WORK/'tmp')
 spec=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
 phases=[];source=WORK/'source';inventory=json.loads(Path('/private/tmp/ashlar-supply-chain-installed-source-inventory-a.json').read_bytes());rows={r['path']:r for r in inventory['files']}
 if inventory['revision']!=REV:raise ValueError('source-revision')
 def run(label,argv,timeout=30,maximum=4*1024*1024,stdin=None,cwd=None):
  out=WORK/(label+'.stdout');err=WORK/(label+'.stderr');result=capture.capture(argv,str(cwd or WORK),ENV,str(out),str(err),timeout,maximum,str(stdin)if stdin else None)
  record={'phase':label,**result,'stdoutSha256':sha(out.read_bytes()),'stderrSha256':sha(err.read_bytes())};phases.append(record);write(WORK/(label+'.json'),enc(record))
  if result['exitCode']:raise ValueError('phase-refused:'+label)
  return out.read_bytes()
 run('archive',['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','tar.umask=0002','-C',str(REPO),'archive','--format=tar',REV,'src','pyproject.toml','README.md'],maximum=16*1024*1024)
 source.mkdir();seen=set();decoded=0
 with tarfile.open(WORK/'archive.stdout','r:')as tar:
  members=tar.getmembers()
  if len(members)>512:raise ValueError('source-member-bound')
  names=set()
  for m in members:
   name=m.name.rstrip('/')if m.isdir()else m.name;safe(name)
   if name in names:raise ValueError('source-duplicate')
   names.add(name)
   if m.isdir():
    if not any(p.startswith(name+'/')for p in rows):raise ValueError('source-directory')
    continue
   if not m.isfile()or name not in rows:raise ValueError('source-extra')
   r=rows[name];decoded+=m.size
   if decoded>8*1024*1024 or m.size!=r['bytes']:raise ValueError('source-bound')
   raw=tar.extractfile(m).read(r['bytes']+1)
   if len(raw)!=r['bytes']or sha(raw)!=r['sha256']or m.mode&0o777!=(0o775 if r['gitMode']=='100755'else 0o664):
    # Git archive uses umask-independent 0664/0775 payload permissions.
    raise ValueError('source-custody')
   p=source/name;p.parent.mkdir(parents=True,exist_ok=True);write(p,raw);p.chmod(0o755 if r['gitMode']=='100755'else 0o644);seen.add(name)
 if seen!=set(rows):raise ValueError('source-closure')
 def source_custody():
  for name,r in rows.items():
   p=source/name;b=p.read_bytes()
   if p.is_symlink()or len(b)!=r['bytes']or sha(b)!=r['sha256']:raise ValueError('source-closing-custody')
 source_custody();(WORK/'wheels').mkdir()
 run('wheel',[PRIMARY,'-B','-I','-m','pip','wheel','--no-deps','--no-build-isolation','--no-index','--wheel-dir',str(WORK/'wheels'),str(source)],timeout=60)
 wheels=list((WORK/'wheels').iterdir())
 if len(wheels)!=1 or wheels[0].is_symlink()or wheels[0].suffix!='.whl'or wheels[0].stat().st_size>8*1024*1024:raise ValueError('wheel-selection')
 wheel=wheels[0];expected={name[4:]:r for name,r in rows.items()if name.startswith('src/')and name!='src/ashlar/README.md'};payload={};metadata={};total=0;names=set()
 with zipfile.ZipFile(wheel)as archive:
  infos=archive.infolist()
  if len(infos)>512:raise ValueError('wheel-member-bound')
  for info in infos:
   name=info.filename;safe(name);mode=info.external_attr>>16
   if name in names or info.flag_bits&1 or stat.S_IFMT(mode)not in (0,stat.S_IFREG)or info.is_dir():raise ValueError('wheel-member-shape')
   names.add(name);total+=info.file_size
   if total>16*1024*1024:raise ValueError('wheel-decoded-bound')
   raw=archive.read(info)
   if name in expected:
    r=expected[name]
    if len(raw)!=r['bytes']or sha(raw)!=r['sha256']:raise ValueError('wheel-source')
    payload[name]=raw
   elif name.startswith('ashlar_graph_toolkit-0.1.0.dev0.dist-info/')and name.rsplit('/',1)[1]in ('METADATA','WHEEL','entry_points.txt','top_level.txt','RECORD'):metadata[name]=raw
   else:raise ValueError('wheel-extra')
 if set(payload)!=set(expected)or len(metadata)!=5:raise ValueError('wheel-closure')
 if metadata['ashlar_graph_toolkit-0.1.0.dev0.dist-info/entry_points.txt']!=b'[console_scripts]\nashlar = ashlar.cli:main\n':raise ValueError('wheel-entrypoint')
 write(WORK/'wheel-inventory.json',enc({'wheel':wheel.name,'bytes':wheel.stat().st_size,'sha256':sha(wheel.read_bytes()),'members':[{'path':n,'bytes':len(b),'sha256':sha(b)}for n,b in sorted({**payload,**metadata}.items())]}))
 run('venv',[PY311,'-B','-I','-m','venv','--without-pip',str(WORK/'venv')]);venv=WORK/'venv';python=venv/'bin/python';site=venv/'lib/python3.11/site-packages'
 def interpreter():
  if python.resolve()!=Path(PY311).resolve()or 'include-system-site-packages = false'not in (venv/'pyvenv.cfg').read_text():raise ValueError('venv-selection')
 interpreter();run('pip-install',[PRIMARY,'-B','-I','-m','pip','--python',str(python),'install','--no-deps','--no-index','--no-compile',str(wheel)],timeout=60);interpreter()
 for name,b in payload.items():
  p=site/name
  if p.is_symlink()or p.read_bytes()!=b:raise ValueError('installed-source-correspondence')
 console=venv/'bin/ashlar'
 console_bytes=console.read_bytes()
 if not console_bytes.startswith(('#!'+str(python)+'\n').encode())or b'from ashlar.cli import main\n'not in console_bytes:raise ValueError('console-entrypoint')
 write(WORK/'installed-console.txt',console_bytes)
 record_path=site/'ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD';record_bytes=record_path.read_bytes()
 if len(record_bytes)>128*1024:raise ValueError('installed-record-bound')
 write(WORK/'installed-RECORD.csv',record_bytes)
 def installed_custody():
  if console.is_symlink()or console.read_bytes()!=console_bytes:raise ValueError('console-closing-custody')
  for name,b in metadata.items():
   if name.endswith('/RECORD'):continue
   if (site/name).is_symlink()or (site/name).read_bytes()!=b:raise ValueError('installed-metadata-correspondence')
  if record_path.read_bytes()!=record_bytes:raise ValueError('installed-record-custody')
  entries=list(csv.reader(io.StringIO(record_bytes.decode('utf-8'))));seen_record=set()
  if len(entries)>512:raise ValueError('installed-record-members')
  for entry in entries:
   if len(entry)!=3 or entry[0]in seen_record:raise ValueError('installed-record-shape')
   name,digest,size=entry;seen_record.add(name);path=site/name
   if name!='../../../bin/ashlar':safe(name)
   if path.is_symlink()or not path.is_file()or not path.resolve().is_relative_to(venv):raise ValueError('installed-record-path')
   raw=path.read_bytes()
   if name=='ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD':
    if digest or size:raise ValueError('installed-record-self')
   elif digest!='sha256='+base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).rstrip(b'=').decode()or size!=str(len(raw)):raise ValueError('installed-record-hash')
  if not set(payload).issubset(seen_record)or '../../../bin/ashlar'not in seen_record:raise ValueError('installed-record-closure')
 installed_custody()
 original=REPO/'examples/domain-packs/supply-chain/upstream'
 run('supplychain-compile',[str(console),'compile-supply-chain-count-star','--pack',str(original/'pack.json'),'--model',str(original/'ontology.json'),'--graph',str(original/'graph/fixture.json'),'--metadata','/private/tmp/ashlar-supply-chain-installed-metadata-a.json','--index',str(INDEX),'--installation','/private/tmp/ashlar-count-star-installed-cli-c/weft-installation','--output',str(WORK/'compile-output'),'--maximum-artifact-bytes','1048576'],timeout=45)
 selected=WORK/'compile-output';observations=[json.loads(line)for line in (selected/'observations.jsonl').read_bytes().splitlines()]
 if len(observations)!=10:raise ValueError('five-recompile-count')
 old=Path('/private/tmp/ashlar-supply-chain-041-compile-b');ordered=['split-excursion','excursion','replay','lineage','sensor']
 for ordinal,row in enumerate(observations):
  name=ordered[ordinal//2];iteration=ordinal%2
  if row['id']!=name or row['iteration']!=iteration:raise ValueError('original-order')
  for kind in ('request','response'):
   body=(selected/(name+'-'+str(iteration)+'.'+kind)).read_bytes()
   if body.hex()!=row[kind+'Hex']or body!=(old/(name+'-'+str(iteration)+'.'+kind)).read_bytes():raise ValueError('original-reviewed-correspondence')
  if json.loads(bytes.fromhex(row['responseHex']))['status']!='compiled':raise ValueError('original-five-compiled')
 report=json.loads((selected/'report.json').read_bytes())
 if [r['id']for r in report['cases']]!=ordered:raise ValueError('original-five-report')
 source_custody();interpreter();installed_custody()
 for name,b in payload.items():
  if (site/name).read_bytes()!=b:raise ValueError('installed-closing-correspondence')
 write(WORK/'result.json',enc({'format':'ashlar-installed-supply-chain-cli/0.1','ashlarRevision':REV,'weftIndexRevision':'bd490abc877a1992666c7b45412b14a0ca6c2cac','sourceFiles':len(rows),'wheelSourceFiles':len(payload),'originalCases':5,'actualCompiles':10,'qualification':'Fresh offline immutable Ashlar wheel installation and actual public supplychain console command: all5original requests compiled/recompiled,public041offlineadmission,original complete source bags,exact prior reviewedrawcorrespondence. Existing indexed compiler not rebuilt/reinstalled. No nativeSQL/PG/Spark/protectedACK/sourceauthority. Explicit cachedschema dependencies via pinnedPYTHONPATH; cooperative stdlib/OS/Git objectstore,not hermetic.'}))
if __name__=='__main__':main()
