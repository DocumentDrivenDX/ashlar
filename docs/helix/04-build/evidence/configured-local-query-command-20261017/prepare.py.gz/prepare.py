from pathlib import Path
import subprocess,tempfile,tarfile,io,json,hashlib,os,importlib.metadata
root=Path(tempfile.mkdtemp(prefix='ashlar-configured-query-command-20261017-',dir='/private/tmp'));root.chmod(0o700)
commit='ca836c6494730497b3c18d4d3c0b07d5fd026b8f';source=root/'source';source.mkdir()
raw=subprocess.check_output(['/usr/bin/git','archive',commit,'src','README.md','pyproject.toml'],cwd='/Users/erik/Projects/ashlar')
with tarfile.open(fileobj=io.BytesIO(raw))as archive:archive.extractall(source,filter='data')
builder='/private/tmp/ashlar-weft-validation-wheel-20261016-cdc5wn_8/build-environment/bin/python';runtime='/private/tmp/ashlar-publication-query-runtime-20261016-b/bin/python'
with(root/'build.log').open('wb')as log:subprocess.run([builder,'-c',"import setuptools.build_meta as b;print(b.build_wheel('../dist'))"],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
wheel=next((root/'dist').glob('*.whl'))
with(root/'install.log').open('wb')as log:subprocess.run([builder,'-m','pip','--isolated','--python',runtime,'install','--no-index','--no-deps','--force-reinstall',str(wheel)],stdout=log,stderr=subprocess.STDOUT,check=True)
original=json.loads(Path('/private/tmp/ashlar-configured-local-read-installed-20261016-b8y_psej/current-updated.json').read_bytes());original.pop('selector');original['operation']='query'
for name,ordinal,sql in [('current-count',3,'SELECT COUNT(*) AS n FROM Item i'),('old-projection',1,'SELECT i.label AS first_label,i.label AS second_label FROM Item i')]:
 config={**original,'ordinal':ordinal,'output':str(root/name),'query':{'profile':'ashlar-configured-local-weft/0.1','sql':sql,'compiler':{'index':'/private/tmp/ashlar-count-star-public-install-20261014-a/checkout/distributions/index.json','installation':'/private/tmp/ashlar-count-star-public-install-20261014-a/compiler'},'bounds':{'maximum_artifact_bytes':1048576,'maximum_rows':1000,'maximum_cell_bytes':65536,'maximum_total_cell_bytes':1048576}}}
 (root/(name+'.json')).write_text(json.dumps(config,indent=2)+'\n');os.chmod(root/(name+'.json'),0o600)
(root/'preparation.json').write_text(json.dumps({'commit':commit,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'runtime':runtime,'scope':'Actual installed run-configured-local query commands, no test hook, existing publication/no ingestion'},indent=2)+'\n');print(root)
