from pathlib import Path
import json,hashlib,sqlite3,os,time,sys,traceback,importlib.metadata,platform
from collections import Counter
from ashlar_host.process_capture import capture_process
root=Path(sys.argv[1]);python='/private/tmp/ashlar-publication-query-runtime-20261016-b/bin/python'
installation=Path(json.loads((root/'current-count.json').read_bytes())['installation'])
def write(name,value):
 raw=(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode();path=root/name
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 try:assert os.write(fd,raw)==len(raw)
 finally:os.close(fd)
def state():
 with sqlite3.connect('file:'+str(installation/'operations.sqlite')+'?mode=ro',uri=True)as db:
  rows={table:sorted([list(r)for r in db.execute('SELECT * FROM "'+table+'"')],key=lambda r:json.dumps(r,sort_keys=True))for table in ('local_operation','local_plan','jsonl_consumer_progress')}
 return {'registry_sha256':hashlib.sha256((installation/'installation.json').read_bytes()).hexdigest(),'delta_json_logs':{str(p.relative_to(installation)):hashlib.sha256(p.read_bytes()).hexdigest()for p in installation.glob('*/_delta_log/*.json')},'journal_counts':{k:len(v)for k,v in rows.items()},'journal_sha256':hashlib.sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
environment={'PATH':'/usr/bin:/bin','HOME':'/Users/erik','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','JAVA_HOME':'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home','PYSPARK_PYTHON':python,'PYSPARK_DRIVER_PYTHON':python,'PYTHONDONTWRITEBYTECODE':'1','SPARK_LOCAL_IP':'127.0.0.1'}
write('runtime.json',{'python':platform.python_version(),'packages':{n:importlib.metadata.version(n)for n in ('pyspark','delta-spark','jsonschema','referencing','rpds-py','attrs','jsonschema-specifications','typing-extensions')}})
before=state();write('before.json',before);results=[]
for name,expected in [('current-count',[['1']]),('old-projection',[['first','first'],['second','second']])]:
 config=json.loads((root/(name+'.json')).read_bytes());config['bounds']['whole_seconds']=180
 (root/(name+'.json')).write_text(json.dumps(config,indent=2)+'\n');os.chmod(root/(name+'.json'),0o600)
 started=time.monotonic()
 try:
  out,err=capture_process([python,'-I','-B','-m','ashlar','run-configured-local','--configuration',str(root/(name+'.json'))],cwd=root,environment=environment,timeout_seconds=240,maximum_output_bytes=1048576)
  for suffix,raw in (('stdout',out),('stderr',err)):
   fd=os.open(root/(name+'.'+suffix),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
   try:assert os.write(fd,raw)==len(raw)
   finally:os.close(fd)
  answer=json.loads(out);report=json.loads((root/name/'report.json').read_bytes());internal=json.loads((root/name/'runtime-report.json').read_bytes())
  assert answer==report==internal
  assert Counter(map(tuple,answer['query']['rows']))==Counter(map(tuple,expected))
  assert answer['ordinal']==config['ordinal']and answer['local_checkpoint']=='1828'and answer['completed_batches']==3and answer['protected_ack']is False
  protocol=answer['query']['protocol'];artifact=json.loads(protocol['response']);request=json.loads(protocol['request']);assert protocol['response']==protocol['recompiled']and request['sql']==config['query']['sql']
  assert answer['query']['evidence']['native_result']['rows']==answer['query']['rows']
  assert all(guard['native']['rows']==[['0']]for guard in answer['query']['evidence']['guards'])
  assert state()==before
  result={'name':name,'status':'complete','elapsed_seconds':time.monotonic()-started,'ordinal':answer['ordinal'],'publication_id':answer['manifest']['publication_id'],'rows':answer['query']['rows'],'guard_count':len(answer['query']['evidence']['guards']),'local_checkpoint':answer['local_checkpoint'],'completed_batches':answer['completed_batches']}
  write(name+'-terminal.json',result);results.append(result);print(json.dumps(result),flush=True)
 except BaseException as error:
  write(name+'-terminal.json',{'name':name,'status':'refused','elapsed_seconds':time.monotonic()-started,'error_type':type(error).__name__})
  (root/(name+'-runner-failure.txt')).write_text(traceback.format_exc());raise
write('after.json',state());assert state()==before
write('results.json',{'status':'complete','cases':results,'unchanged_log_registry_and_journal':True,'scope':'Two actual installed CLI invocations through parent/worker and complete source/native/Spark closing. No hook, ingestion, checkpoint advancement, protected ACK or Databricks compute.'})
