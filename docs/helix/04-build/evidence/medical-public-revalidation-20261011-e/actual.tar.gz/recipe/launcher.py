import sys,json,importlib.util
from pathlib import Path
from custody import Context,finish
context=None;primary=None;result=None
try:
 context=Context(sys.argv[1],sys.argv[2]);c=context.config
 spec=importlib.util.spec_from_file_location('capture',c['captureModule']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 result=m.capture([c['python'],'-I','-B','-S',str(Path(sys.argv[1]).parent/'entry-runner.py'),sys.argv[1],sys.argv[2]],'/private/tmp',{'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'},c['output']+'.outer.stdout',c['output']+'.outer.stderr',c['outerSeconds'],c['streamBytes'])
 if result['exitCode']!=0:raise ValueError('bounded-medical-revalidation-refused')
except BaseException as error:primary=error
finish(primary,([context.renew,context.close]if context else []))
