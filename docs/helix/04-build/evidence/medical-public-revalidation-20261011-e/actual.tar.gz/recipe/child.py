import sys,json,hashlib,os
from pathlib import Path
from custody import Context,finish
def execute(context):
 c=context.config;sys.path.insert(0,c['packageRoot'])
 from ashlar_host.config import ProducerConfig
 from ashlar_host.medical_producer import HeldMedicalDataset
 from ashlar_host.original_medical_publication import MedicalAdmission,original_medical_oracle
 from ashlar.medical_source import build_transaction
 from ashlar_host.schema_rows import fixture_columns
 from ashlar_host.resources import RESOURCE_ROOT
 from custody import finish,write,Pinned,Directory
 w=Path(c['output']);owner=None;admission=None;primary=None;released=[];directory=None
 try:
  directory=Directory(w)
  for module in (sys.modules['ashlar_host.medical_producer'],sys.modules['ashlar_host.original_medical_publication']):
   if not Path(module.__file__).is_relative_to(Path(c['packageRoot'])):raise ValueError('copied-owner-import-origin')
  cfg=ProducerConfig(Path(c['umfSource']),Path(c['bun']),Path(c['git']),c['producerSeconds'],c['streamBytes'],c['receiptBytes'])
  paths=tuple(map(Path,c['originalInputs']));owner=HeldMedicalDataset(cfg,*paths,w/'public-result.json')
  batch,bindings=build_transaction(*owner.originals,source_system='isolated-original-medical')
  admission=MedicalAdmission(batch,bindings,*paths,owner);views=admission.evidence();metadata=admission.metadata()
  if len(json.dumps(metadata,ensure_ascii=False).encode())>1048576:raise ValueError('driver-metadata-bound')
  bags=original_medical_oracle(views.model,views.graph,bindings,feed=batch.feed,epoch=batch.epoch,batch_id=batch.batch_id,materialized_at='2026-10-11T00:00:00.123456+00:00',columns=fixture_columns(RESOURCE_ROOT))
  if {k:len(v)for k,v in bags.items()}!={'object_current':51,'edge_current':62,'tombstone':0,'whole_source_history':113}:raise ValueError('complete-original-bags')
  files={role+'.bin':getattr(views,role)for role in ('model','graph','baseline','bindings','revalidation')}
  files['metadata.json']=json.dumps(metadata,ensure_ascii=False,allow_nan=False).encode();files['oracle.json']=json.dumps(bags,ensure_ascii=False,allow_nan=False).encode()
  if sum(map(len,files.values()))>12582912:raise ValueError('aggregate-evidence-bound')
  for name,data in files.items():
   pin=write(w/name,data);pin.read();released.append(pin)
  released.append(Pinned(w/'public-result.json',len(owner.raw),hashlib.sha256(owner.raw).hexdigest()));released[-1].read()
 except BaseException as error:primary=error
 def namespace():
  expected={pin.path.name for pin in released}|{'child.stdout','child.stderr'}
  if released and set(x.name for x in w.iterdir())!=expected:raise ValueError('raw-output-namespace-drift')
 finish(primary,([owner.renew]if owner is not None else [])+([admission.renew]if admission is not None else [])+[pin.read for pin in released]+[namespace]+([directory.renew]if directory else [])+([directory.close]if directory else []))
 return {'scope':c['scope'],'admission':True,'bagCounts':{k:len(v)for k,v in bags.items()},'closing':True}
context=None;primary=None;summary=None
try:
 context=Context(sys.argv[1],sys.argv[2]);summary=execute(context)
except BaseException as error:primary=error
finish(primary,([context.renew,context.close]if context else []))
print(json.dumps(summary,sort_keys=True))
