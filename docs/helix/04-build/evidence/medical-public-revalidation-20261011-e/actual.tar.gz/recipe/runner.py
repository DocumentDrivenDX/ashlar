import sys,json,hashlib,importlib.util
from pathlib import Path
from custody import Context,Directory,Pinned,finish,write
context=None;directory=None;primary=None;result=None;released=[]
try:
 context=Context(sys.argv[1],sys.argv[2]);c=context.config;w=Path(c['output'])
 if w.exists()or w.is_symlink():raise ValueError('fresh-output-required')
 w.mkdir(mode=0o700);directory=Directory(w)
 spec=importlib.util.spec_from_file_location('capture',c['captureModule']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 result=m.capture([c['python'],'-I','-B','-S',str(Path(sys.argv[1]).parent/'entry-child.py'),sys.argv[1],sys.argv[2]],str(w),{'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'},str(w/'child.stdout'),str(w/'child.stderr'),c['childSeconds'],c['streamBytes'])
 if result['exitCode']!=0:raise ValueError('public-revalidation-refused')
 total=0
 for p in sorted(w.iterdir()):
  if not p.is_file()or p.is_symlink():raise ValueError('raw-output-shape')
  total+=p.stat().st_size
  if total>14680064:raise ValueError('raw-output-aggregate')
  pin=Pinned(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest());pin.read();released.append(pin)
except BaseException as error:primary=error
try:
 finish(primary,([context.renew]if context else [])+[p.read for p in released]+([directory.renew]if directory else [])+([context.close]if context else []))
except BaseException as error:
 finish(error,([directory.renew,directory.close]if directory else []))
receipt=None;primary=None
try:
 directory.renew()
 receipt=write(w/'receipt.json',json.dumps({'result':result,'closing':True,'scope':c['scope']},sort_keys=True).encode()+b'\n',dir_fd=directory.fd)
 receipt.read();directory.renew()
except BaseException as error:primary=error
try:
 finish(primary,[directory.renew,directory.close])
except BaseException:
 # Remove only the exact receipt inode under the unchanged owned named directory.
 if receipt is not None and receipt.original is not None:
  try:
   root=w.lstat();original=directory.original;current=(w/'receipt.json').lstat()
   if (root.st_dev,root.st_ino)==(original.st_dev,original.st_ino)and(current.st_dev,current.st_ino)==receipt.original[:2]:
    (w/'receipt.json').unlink()
  except BaseException:pass
 raise
