import os,stat,hashlib,json
from pathlib import Path

def choose(primary,error):return error if primary is None or isinstance(primary,Exception)and not isinstance(error,Exception)else primary
def finish(primary,callbacks):
 for callback in callbacks:
  try:callback()
  except BaseException as error:primary=choose(primary,error)
 if primary is not None:raise primary

def identity(s):return(s.st_dev,s.st_ino,s.st_uid,s.st_mode,s.st_size,s.st_mtime_ns,s.st_nlink)
class Pinned:
 def __init__(self,path,size,digest,links=1):
  self.path=Path(path);self.size=size;self.digest=digest;self.original=None;self.links=links
  if type(links)is not int or (links!=1 and not(self.path==Path('/usr/bin/git')and links==78)):raise ValueError('closed-selected-link-count')
 def read(self):
  fd=None;primary=None;raw=None
  try:
   fd=os.open(self.path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK);s=os.fstat(fd)
   if not stat.S_ISREG(s.st_mode)or s.st_nlink!=self.links or s.st_size!=self.size or (self.links!=1 and(s.st_uid!=0 or not s.st_mode&0o111)):raise ValueError('pinned-file-shape')
   if self.original is not None and identity(s)!=self.original:raise ValueError('pinned-file-replaced')
   blocks=[];total=0
   while True:
    b=os.read(fd,min(65536,self.size-total+1))
    if not b:break
    total+=len(b)
    if total>self.size:raise ValueError('pinned-file-growth')
    blocks.append(b)
   raw=b''.join(blocks)
   if len(raw)!=self.size or hashlib.sha256(raw).hexdigest()!=self.digest or identity(os.fstat(fd))!=identity(s)or identity(self.path.lstat())!=identity(s):raise ValueError('pinned-file-drift')
   if self.original is None:self.original=identity(s)
  except BaseException as error:primary=error
  finish(primary,[lambda:os.close(fd)]if fd is not None else [])
  return raw
class Directory:
 def __init__(self,path):
  self.path=Path(path);self.fd=os.open(self.path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);self.original=os.fstat(self.fd)
 def renew(self):
  a=os.fstat(self.fd);b=self.path.lstat();i=lambda s:(s.st_dev,s.st_ino,s.st_uid,s.st_mode)
  if i(a)!=i(self.original)or i(b)!=i(self.original):raise ValueError('owned-directory-drift')
 def close(self):os.close(self.fd)
class Context:
 def __init__(self,path,digest):
  self.fd=None;self.parent=None;self.config=None;self.pins=[];primary=None
  try:
   self.path=Path(path);self.fd=os.open(self.path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK);s=os.fstat(self.fd)
   if not stat.S_ISREG(s.st_mode)or s.st_nlink!=1 or not 0<s.st_size<=1048576:raise ValueError('config-shape')
   self.original=identity(s);raw=os.read(self.fd,s.st_size+1)
   if len(raw)!=s.st_size or hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('external-config-pin')
   self.raw=raw;self.parent=Directory(self.path.parent);self.renew_config();self.config=json.loads(raw)
   self.pins=[Pinned(r['path'],r['bytes'],r['sha256'],r['links'])for r in self.config['resources']]
   self.renew()
  except BaseException as error:primary=error
  if primary is not None:finish(primary,[self.close])
 def renew_config(self):
  if identity(os.fstat(self.fd))!=self.original or identity(self.path.lstat())!=self.original:raise ValueError('config-custody-drift')
  os.lseek(self.fd,0,os.SEEK_SET)
  if os.read(self.fd,len(self.raw)+1)!=self.raw:raise ValueError('config-byte-drift')
 def namespace(self):
  root=Path(self.config['packageRoot']);expected={Path(r['path'])for r in self.config['resources']if Path(r['path']).is_relative_to(root)};actual={p for p in root.rglob('*')if not p.is_dir()}
  if actual!=expected or any(p.is_symlink()for p in root.rglob('*')):raise ValueError('closed-package-namespace')
 def renew(self):finish(None,[self.renew_config]+([self.parent.renew]if self.parent is not None else [])+[p.read for p in self.pins]+([self.namespace]if self.config is not None else []))
 def close(self):
  callbacks=[self.renew]if self.config is not None else ([self.renew_config]if hasattr(self,'raw')else [])+([self.parent.renew]if self.parent is not None else [])
  if self.parent is not None:callbacks.append(self.parent.close)
  if self.fd is not None:callbacks.append(lambda:os.close(self.fd))
  finish(None,callbacks)
def write(path,data,dir_fd=None):
 fd=None;primary=None
 try:
  fd=os.open(Path(path).name if dir_fd is not None else path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=dir_fd);view=memoryview(data)
  while view:
   n=os.write(fd,view)
   if type(n)is not int or n<=0:raise OSError('complete-write-required')
   view=view[n:]
  os.fsync(fd)
 except BaseException as error:primary=error
 finish(primary,[lambda:os.close(fd)]if fd is not None else [])
 return Pinned(path,len(data),hashlib.sha256(data).hexdigest())
