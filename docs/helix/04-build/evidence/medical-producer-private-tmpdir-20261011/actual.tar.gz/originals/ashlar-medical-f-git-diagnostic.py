from pathlib import Path
import json
from ashlar_host.original_medical_local_configuration import parse_original_medical_local
from ashlar_host.evolution_producer import capture
c=parse_original_medical_local(Path('/private/tmp/ashlar-medical-recovery-installed-prep-f/configuration.json').read_bytes())
env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_TERMINAL_PROMPT':'0'}
rows=[]
for args in (['rev-parse','HEAD'],['status','--porcelain']):
 out,err=capture([str(c.producer.git),'-C',str(c.producer.source),*args],cwd=Path('/private/tmp/ashlar-medical-f-producer-diagnostic-a'),environment=env,timeout_seconds=c.producer.timeout_seconds,maximum_output_bytes=c.producer.maximum_output_bytes)
 rows.append({'command':args,'stdout':out.decode(),'stderr':err.decode()})
p=Path('/private/tmp/ashlar-medical-f-producer-diagnostic-a/git-observation.json');p.write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
