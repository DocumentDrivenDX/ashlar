from pathlib import Path
import os,json,hashlib,subprocess,sys
from ashlar_host.original_medical_local_configuration import parse_original_medical_local
from ashlar_host.original_medical_installation_handoff import validate_original_medical_installation_handoff
from ashlar_host.original_medical_runtime import OriginalMedicalRuntimeCustody
from ashlar_host.medical_producer import MedicalFile
from ashlar_host.resources import RESOURCE_ROOT
p=Path('/private/tmp/ashlar-medical-recovery-installed-prep-f'); c=parse_original_medical_local((p/'configuration.json').read_bytes()); events=[]
def check(name,fn):
 try: fn();events.append({'check':name,'pass':True})
 except Exception as e: events.append({'check':name,'pass':False,'class':type(e).__name__,'message':str(e)[:240]})
def pins():
 for x in (c.installation,c.request):
  raw=MedicalFile(x.path,min(c.bounds.input_bytes,c.bounds.receipt_bytes) if x is c.installation else c.bounds.input_bytes).read();assert len(raw)==x.bytes and hashlib.sha256(raw).hexdigest()==x.sha256
check('selected-original-pins',pins)
check('handoff',lambda:validate_original_medical_installation_handoff(c.installation.path.read_bytes(),c))
def runtime():
 with OriginalMedicalRuntimeCustody.open(c.runtime,c.inputs,c.bounds,c.producer) as owner:
  owner.renew(); assert not any(n in sys.modules for n in ('pyspark','delta'))
check('runtime-filesystem-opening-closing-no-SDK-import',runtime)
def producer_inputs():
 for x in (c.inputs.model,c.inputs.graph,c.inputs.baseline):MedicalFile(x.path,4194304).read()
 MedicalFile(RESOURCE_ROOT/'check_medical_dataset.ts',1048576).read()
 st=c.output.stat();assert st.st_mode&0o777==0o700 and not (c.output/'public-revalidation.json').exists()
check('producer-file-and-parent-preconditions',producer_inputs)
print(json.dumps(events))
