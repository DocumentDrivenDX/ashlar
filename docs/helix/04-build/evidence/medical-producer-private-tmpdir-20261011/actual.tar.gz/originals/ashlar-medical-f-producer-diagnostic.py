from pathlib import Path
import os,json,traceback
from ashlar_host.original_medical_local_configuration import parse_original_medical_local
from ashlar_host.original_medical_runtime import OriginalMedicalRuntimeCustody
from ashlar_host.medical_producer import HeldMedicalDataset
p=Path('/private/tmp/ashlar-medical-recovery-installed-prep-f');c=parse_original_medical_local((p/'configuration.json').read_bytes())
d=Path('/private/tmp/ashlar-medical-f-producer-diagnostic-a');d.mkdir(mode=0o700)
report={'scope':'Packaged producer only; no lease/native/source/ACK/recovery','stage':'producer-opening'}
try:
 with OriginalMedicalRuntimeCustody.open(c.runtime,c.inputs,c.bounds,c.producer) as o:
  env=o.native_environment();os.environ.clear();os.environ.update(env)
  dataset=HeldMedicalDataset(c.producer,c.inputs.model.path,c.inputs.graph.path,c.inputs.baseline.path,d/'public-revalidation.json')
  report.update(success=True,bytes=len(dataset.raw),stage='producer-complete')
except BaseException as e:
 report.update(success=False,error_class=type(e).__name__,message=str(e)[:512])
 (d/'exception.txt').write_text(traceback.format_exc())
(d/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
