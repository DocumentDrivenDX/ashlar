from pathlib import Path
import subprocess,json,hashlib,base64
root=Path('/private/tmp/ashlar-configured-sdk-installed-20261017-dgr8_k7v');env=root/'runtime';site=env/'lib/python3.11/site-packages'
original=Path('/private/tmp/ashlar-publication-query-runtime-20261016-b/lib/python3.11/site-packages')
preparer=Path('/private/tmp/ashlar-configured-sdk-prepare-20261017.py').read_text()
# Reconstruct the exact already-copied SDK dependency inventory, then add two
# RECORD-verified Delta transitive dependencies; preserve failed pip-check.log.
selected=['pydantic','pydantic-core','typing-extensions','typing-inspection','annotated-types'];source_site=Path('/private/tmp/umf-sdk-merged/python311/lib/python3.11/site-packages')
code=preparer.split('code=',1)[1].split('\nmetadata=',1)[0]
code=eval(code)
metadata=json.loads(subprocess.check_output(['/private/tmp/umf-sdk-merged/python311/bin/python','-c',code]));copied=[]
for distribution in metadata:
 for record in distribution['files']:
  relative=Path(record['path'])
  if relative.suffix=='.pyc':continue
  src=(source_site/relative).resolve();dst=(site/relative).resolve();assert source_site in src.parents and site in dst.parents
  raw=src.read_bytes();assert dst.read_bytes()==raw
  if record['hash'] is not None:
   algorithm,wanted=record['hash'];assert algorithm=='sha256'and base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip('=')==wanted
  copied.append({'name':distribution['name'],'version':distribution['version'],'file':str(relative),'sha256':hashlib.sha256(raw).hexdigest()})
code="import importlib.metadata as m,json;print(json.dumps([{ 'name':n,'version':m.version(n),'files':[{'path':str(f),'hash':None if f.hash is None else [f.hash.mode,f.hash.value]}for f in m.distribution(n).files]}for n in ['importlib-metadata','zipp']]))"
metadata=json.loads(subprocess.check_output(['/private/tmp/ashlar-publication-query-runtime-20261016-b/bin/python','-c',code]))
for distribution in metadata:
 for record in distribution['files']:
  relative=Path(record['path'])
  if relative.suffix=='.pyc':continue
  src=(original/relative).resolve();dst=(site/relative).resolve();assert original in src.parents and site in dst.parents
  raw=src.read_bytes()
  if record['hash']is not None:
   algorithm,wanted=record['hash'];assert algorithm=='sha256'and base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip('=')==wanted
  assert not dst.exists();dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);assert src.read_bytes()==raw
  copied.append({'name':distribution['name'],'version':distribution['version'],'file':str(relative),'sha256':hashlib.sha256(raw).hexdigest()})
builder='/private/tmp/ashlar-weft-validation-wheel-20261016-cdc5wn_8/build-environment/bin/python'
with(root/'pip-check-completed.log').open('wb')as log:subprocess.run([builder,'-m','pip','--isolated','--python',str(env/'bin/python'),'check'],stdout=log,stderr=subprocess.STDOUT,check=True)
linked=[str(p.resolve())for p in site.iterdir()if p.is_symlink()]
wheels=[(Path('/private/tmp/sdk-main-consolidation-20261016/sdk-wheels/umf_access-0.1.0.dev0-py3-none-any.whl'),'c2c3794d89277d644ca1198ff63fd076faec059046b6412823dfafda7070b392'),(Path('/private/tmp/weft041-public/weft_sql-0.4.41-cp39-abi3-macosx_11_0_arm64.whl'),'863e6487b513610d25581d8307bf5cea5df6928bc704171ec256f00c68b155dc')]
for p,wanted in wheels:assert hashlib.sha256(p.read_bytes()).hexdigest()==wanted
base=json.loads(Path('/private/tmp/ashlar-typed-graph-installed-20261017-gfothazt/read-original.json').read_bytes());base['python']=str(env/'bin/python');base['bounds']['receipt_bytes']=524288
(root/'base.json').write_text(json.dumps(base,indent=2)+'\n');(root/'dependencies.json').write_text(json.dumps({'copied_record_verified':copied,'linked_native_runtime':linked,'qualification':'Isolated dependencies copied from existing installed RECORDs; selected Spark/Delta links. Not hermetic/public dependency-wheel proof. Initial pip check missing importlib-metadata; completed with RECORD-verified importlib-metadata/zipp.'},indent=2)+'\n')
wheel=next((root/'dist').glob('*.whl'))
(root/'preparation.json').write_text(json.dumps({'commit':'49c0d89646155b811b79c419d1b8b5cb9cd82f79','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'runtime':str(env/'bin/python'),'sdk_wheels':[{'file':str(p),'sha256':h}for p,h in wheels],'scope':'Installed configured-source SDK pages on retained local Delta; no cloud/source/ACK writes.'},indent=2)+'\n');print(root)
