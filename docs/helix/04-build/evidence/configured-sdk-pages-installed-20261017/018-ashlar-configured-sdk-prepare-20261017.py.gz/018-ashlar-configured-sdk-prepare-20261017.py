from pathlib import Path
import subprocess,tempfile,tarfile,io,json,hashlib,sys,shutil,base64
commit=sys.argv[1];root=Path(tempfile.mkdtemp(prefix='ashlar-configured-sdk-installed-20261017-',dir='/private/tmp'));root.chmod(0o700)
python='/private/tmp/ashlar-publication-query-runtime-20261016-b/bin/python';env=root/'runtime'
subprocess.run([python,'-m','venv','--without-pip',str(env)],check=True)
site=env/'lib/python3.11/site-packages';source_site=Path('/private/tmp/umf-sdk-merged/python311/lib/python3.11/site-packages')
selected=['pydantic','pydantic-core','typing-extensions','typing-inspection','annotated-types']
code='import importlib.metadata as m,json;print(json.dumps([{ "name":n,"version":m.version(n),"files":[{"path":str(f),"hash":None if f.hash is None else [f.hash.mode,f.hash.value]}for f in m.distribution(n).files]}for n in '+repr(selected)+']))'
metadata=json.loads(subprocess.check_output(['/private/tmp/umf-sdk-merged/python311/bin/python','-c',code]));copied=[]
for distribution in metadata:
 for record in distribution['files']:
  relative=Path(record['path'])
  if relative.suffix=='.pyc':continue
  src=(source_site/relative).resolve();dst=(site/relative).resolve()
  assert source_site in src.parents and site in dst.parents
  raw=src.read_bytes()
  if record['hash']is not None:
   algorithm,wanted=record['hash'];assert algorithm=='sha256'and base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip('=')==wanted
  dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);assert src.read_bytes()==raw
  copied.append({'name':distribution['name'],'version':distribution['version'],'file':str(relative),'sha256':hashlib.sha256(raw).hexdigest()})
original=Path('/private/tmp/ashlar-publication-query-runtime-20261016-b/lib/python3.11/site-packages');linked=[]
for pattern in ('pyspark','pyspark-*.dist-info','delta','delta_spark-*.dist-info','py4j','py4j-*.dist-info'):
 paths=list(original.glob(pattern));assert len(paths)==1
 src=paths[0];(site/src.name).symlink_to(src,target_is_directory=src.is_dir());linked.append(str(src))
builder='/private/tmp/ashlar-weft-validation-wheel-20261016-cdc5wn_8/build-environment/bin/python'
wheels=[(Path('/private/tmp/sdk-main-consolidation-20261016/sdk-wheels/umf_access-0.1.0.dev0-py3-none-any.whl'),'c2c3794d89277d644ca1198ff63fd076faec059046b6412823dfafda7070b392'),(Path('/private/tmp/weft041-public/weft_sql-0.4.41-cp39-abi3-macosx_11_0_arm64.whl'),'863e6487b513610d25581d8307bf5cea5df6928bc704171ec256f00c68b155dc')]
for p,wanted in wheels:assert hashlib.sha256(p.read_bytes()).hexdigest()==wanted
with(root/'dependency-install.log').open('wb')as log:subprocess.run([builder,'-m','pip','--isolated','--python',str(env/'bin/python'),'install','--no-index','--no-deps',*[str(p)for p,_ in wheels]],stdout=log,stderr=subprocess.STDOUT,check=True)
source=root/'source';source.mkdir();raw=subprocess.check_output(['/usr/bin/git','archive',commit,'src','README.md','pyproject.toml'],cwd='/Users/erik/Projects/ashlar')
with tarfile.open(fileobj=io.BytesIO(raw))as archive:archive.extractall(source,filter='data')
with(root/'build.log').open('wb')as log:subprocess.run([builder,'-c',"import setuptools.build_meta as b;print(b.build_wheel('../dist'))"],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
wheel=next((root/'dist').glob('*.whl'))
with(root/'install.log').open('wb')as log:subprocess.run([builder,'-m','pip','--isolated','--python',str(env/'bin/python'),'install','--no-index','--no-deps',str(wheel)],stdout=log,stderr=subprocess.STDOUT,check=True)
with(root/'pip-check.log').open('wb')as log:subprocess.run([builder,'-m','pip','--isolated','--python',str(env/'bin/python'),'check'],stdout=log,stderr=subprocess.STDOUT,check=True)
base=json.loads(Path('/private/tmp/ashlar-typed-graph-installed-20261017-gfothazt/read-original.json').read_bytes());base['python']=str(env/'bin/python');base['bounds']['receipt_bytes']=524288
(root/'base.json').write_text(json.dumps(base,indent=2)+'\n');(root/'dependencies.json').write_text(json.dumps({'copied_record_verified':copied,'linked_native_runtime':linked,'qualification':'Isolated local SDK dependencies copied from existing installed RECORDs; linked selected Spark/Delta packages. Not a hermetic/public dependency-wheel proof.'},indent=2)+'\n')
(root/'preparation.json').write_text(json.dumps({'commit':commit,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'runtime':str(env/'bin/python'),'sdk_wheels':[{ 'file':str(p),'sha256':h}for p,h in wheels],'scope':'Actual installed configured-source SDK pages on retained local Delta; no cloud or source/ACK writes.'},indent=2)+'\n');print(root)
