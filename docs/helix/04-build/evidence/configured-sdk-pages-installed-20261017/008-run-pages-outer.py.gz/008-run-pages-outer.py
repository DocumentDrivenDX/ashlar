from pathlib import Path
import os,json,subprocess,time,signal
R=Path(__file__).resolve().parent;os.umask(0o077)
base=json.loads((R/'base.json').read_bytes());python=R/'runtime/bin/python'
environment={'PATH':'/usr/bin:/bin','HOME':str(Path.home()),'JAVA_HOME':base['java_home'],'PYSPARK_PYTHON':str(python),'PYTHONDONTWRITEBYTECODE':'1','SPARK_LOCAL_IP':'127.0.0.1','LANG':'C','LC_ALL':'C'}
argv=[str(python),'-I','-B',str(R/'run-pages-native.py')];started=time.monotonic();process=None;primary=None;code=None
try:
 with (R/'pages.stdout').open('xb')as out,(R/'pages.stderr').open('xb')as err:
  process=subprocess.Popen(argv,cwd=R,env=environment,stdout=out,stderr=err,start_new_session=True)
  try:code=process.wait(timeout=230)
  except subprocess.TimeoutExpired:primary='outer-timeout'
finally:
 if process is not None:
  if process.poll()is None:
   try:os.killpg(process.pid,signal.SIGINT)
   except ProcessLookupError:pass
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:pass
  try:os.killpg(process.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  code=process.wait(timeout=5)
 record={'argv':argv,'exit_code':code,'cause':primary,'elapsed_seconds':time.monotonic()-started,'outer_seconds':240}
 (R/'pages-attempt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));raise SystemExit(0 if code==0 and primary is None else 2)
