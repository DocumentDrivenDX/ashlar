"""Run only after successful terminal completion; reads retained outputs only."""
from pathlib import Path
import gzip,hashlib,json,zipfile
R=Path(__file__).resolve().parent
OUT=Path('/Users/erik/Projects/ashlar/docs/helix/04-build/evidence/configured-sdk-pages-installed-20261017')
attempt=json.loads((R/'pages-attempt.json').read_bytes());summary=json.loads((R/'pages-summary.json').read_bytes())
assert attempt['exit_code']==0 and attempt['cause']is None and summary['status']=='passed' and summary['native_contents_unchanged']is True
assert [(v['ordinal'],v['rows'],v['pages'])for v in summary['cases']]==[(1,3,2),(3,1,1)]
assert (R/'pages-before.json').read_bytes()==(R/'pages-after.json').read_bytes()
preparation=json.loads((R/'preparation.json').read_bytes())
assert preparation['commit']=='49c0d89646155b811b79c419d1b8b5cb9cd82f79'
OUT.mkdir()  # Never replace an existing archive.
def pin(path):
 data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
site=next((R/'runtime/lib').glob('python*/site-packages'))
provenance={'profile':'ashlar-configured-sdk-installed-correspondence/0.1','commit':preparation['commit'],'wheels':[],'dependencies':[],
 'scope':'Exact installed selected toolkit/UMF/Weft wheel-file correspondence and dependency metadata only; no whole SDK/OS audit, public release or native authority inferred.'}
for wheel,prefix in [(next((R/'dist').glob('*.whl')),'ashlar/'),*[(Path(v['file']),'umf_access/'if 'umf_access'in v['file']else'weft/')for v in preparation['sdk_wheels']]]:
 info=pin(wheel);checked=[]
 with zipfile.ZipFile(wheel)as archive:
  for name in archive.namelist():
   if name.endswith('/')or not(name.startswith(prefix)or prefix=='ashlar/'and name.startswith('ashlar_host/')):continue
   raw=(site/name).read_bytes();assert raw==archive.read(name)
   checked.append({'file':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 info['installed_files']=checked;provenance['wheels'].append(info)
for metadata in sorted(site.glob('*.dist-info/METADATA')):
 headers=[line for line in metadata.read_text().splitlines()if line.startswith(('Name:','Version:','Requires-Dist:'))]
 provenance['dependencies'].append({'metadata':pin(metadata),'headers':headers})
sources=[(R/name,name)for name in ['preparation.json','dependencies.json','dependency-install.log','pip-check.log','pip-check-completed.log','base.json','pages-runner-preparation.json','run-pages-native.py','run-pages-outer.py','pages-attempt.json','pages.stdout','pages.stderr','pages-before.json','pages-after.json','pages-summary.json','build.log','install.log']]
completion=Path('/private/tmp/ashlar-configured-sdk-complete-20261017.py');sources.append((completion,completion.name))
initial=Path('/private/tmp/ashlar-configured-sdk-prepare-20261017.py');sources.append((initial,initial.name))
sources.append((Path(__file__),Path(__file__).name))
for case in ('old-unfiltered','current-filtered'):
 sources.extend([(R/('pages-'+case+'-result.json'),'pages-'+case+'-result.json'),(R/('pages-'+case)/'runtime-report.json','pages-'+case+'/runtime-report.json')])
entries=[]
def archive_bytes(raw,label,index):
 assert len(raw)<=8388608
 name=f'{index:03d}-'+Path(label).name+'.gz';compressed=gzip.compress(raw,mtime=0);(OUT/name).write_bytes(compressed)
 entries.append({'source':label,'archive':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'gzip_bytes':len(compressed),'gzip_sha256':hashlib.sha256(compressed).hexdigest()})
for index,(path,label)in enumerate(sources):archive_bytes(path.read_bytes(),label,index)
archive_bytes((json.dumps(provenance,indent=2)+'\n').encode(),'installed-sdk-correspondence.json',len(entries))
assert sum(v['bytes']for v in entries)<=16777216
(OUT/'manifest.json').write_text(json.dumps({'profile':'ashlar-local-run-evidence/0.1','files':entries},indent=2)+'\n')
cases=summary['cases'];elapsed=attempt['elapsed_seconds']
(OUT/'README.md').write_text(f'''# Installed typed SDK pages on the retained graph publication\n\nThe exact installed Ashlar commit `{preparation['commit']}` completed two\nsequential calls through the public typed Python `page_configured_local` API and\nexisting `AshlarTarget` / `EngineRead` page executor. This is SDK evidence, not a\npublic CLI page command. The retained graph installation was reused without\nreingest or new publication.\n\nOrdinal 1 returned three original Person key/name rows across two pages at page\nsize 2. Ordinal 3 filtered `person_name = :name` with `name: Ada` and returned one\nrow in one page. The runner checked exact ordered items, terminal continuation\nstate and every emitted guard's actual STRING-zero frame. Both runtime reports\nand complete result programs are retained. These cases do not qualify arbitrary\nqueries, numeric pages, other engines or the full source/query corpus.\n\nBefore/after registry, Delta/data file contents and canonical SQLite inventories\nmatch. Transient SQLite WAL/SHM byte layouts are excluded from that comparison;\nlogical progress contents remain included. The outer runner terminated with\nstatus 0 after {elapsed:.3f} seconds within its selected 240-second envelope.\nThis is whole-workflow duration, not isolated page latency or scale evidence.\n\nThe runtime uses pinned local wheels for UMF access and public Weft 0.4.41.\n`installed-sdk-correspondence.json` retains exact wheel and installed native/shim\nhashes and dependency metadata. Existing SDK/dependency copies and links are\nexplicit development selections, not a whole SDK or OS closure. Initial pip\nchecking found missing `importlib-metadata`; the retained completion script copied\nRECORD-verified `importlib-metadata` 9.0.1 and `zipp` 4.1.1, then pip checking\npassed. Original failed and completed checks are preserved.\n\nPublic compilation, DTO validation and report bytes confer no native or source\nauthority. Actual held source/publication/alias, deadline and closing owners remain\nmandatory. No protected source ACK, PostgreSQL/remote pin, Unity Catalog, production\nwriter or performance qualification is claimed. No paid cloud work was performed.\n\n`manifest.json` binds {len(entries)} exact retained streams with original/gzip\nlengths and SHA256 digests; gzip timestamps are zero. Prior source/publication\ncorpora are not duplicated.\n''')
for item in entries:
 raw=(OUT/item['archive']).read_bytes();decoded=gzip.decompress(raw)
 assert len(raw)==item['gzip_bytes']and hashlib.sha256(raw).hexdigest()==item['gzip_sha256']and len(decoded)==item['bytes']and hashlib.sha256(decoded).hexdigest()==item['sha256']
print(json.dumps({'archive':str(OUT),'streams':len(entries)}))
