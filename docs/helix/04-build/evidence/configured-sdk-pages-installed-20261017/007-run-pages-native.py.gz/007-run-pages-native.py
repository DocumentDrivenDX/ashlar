"""Two sequential installed public typed-page calls; no ingest or cloud actions."""
from pathlib import Path
from contextlib import contextmanager,redirect_stdout
import hashlib,json,os,sqlite3,sys
from pydantic import BaseModel,ConfigDict
import weft
from ashlar_host.configured_local_cli import parse_configured_local
from ashlar_host.configured_local_runtime import page_configured_local
from ashlar_host.configured_sdk_pages import ConfiguredSdkPagesConfig
from ashlar_host.path_capture import PathCaptureConfig
from ashlar_host.lifecycle import finish
R=Path(__file__).resolve().parent
os.umask(0o077)
class Empty(BaseModel):model_config=ConfigDict(strict=True,extra='forbid')
class Filter(BaseModel):
 model_config=ConfigDict(strict=True,extra='forbid')
 name:str
class Person(BaseModel):
 model_config=ConfigDict(strict=True,extra='forbid')
 person_key:str
 person_name:str
@contextmanager
def diagnostics():
 fd=None;primary=None
 try:
  sys.stdout.flush();sys.stderr.flush();fd=os.dup(1);os.dup2(2,1)
  with redirect_stdout(sys.stderr):yield
 except BaseException as e:primary=e
 finish(primary,[sys.stderr.flush]+([]if fd is None else[lambda:os.dup2(fd,1),lambda:os.close(fd)]))
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def retain(name,value):
 raw=canonical(value)+b'\n';assert len(raw)<=8388608
 fd=os.open(R/name,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
 with os.fdopen(fd,'wb')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
def fingerprint(root):
 files=[];databases=[];total=0
 for path in sorted(root.rglob('*')):
  if path.is_symlink():raise ValueError('Original native symlink refused')
  if not path.is_file():continue
  relative=str(path.relative_to(root))
  if path.suffix in ('.sqlite','.db'):
   before=path.stat();connection=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True)
   try:
    tables=[]
    for name,sql in connection.execute("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name"):
     escaped=name.replace('"','""');rows=connection.execute('SELECT * FROM "'+escaped+'"').fetchall()
     def atom(value):return {'blob':value.hex()}if type(value)is bytes else value
     ordered=sorted(([atom(v)for v in row]for row in rows),key=lambda v:canonical(v));tables.append([name,sql,ordered])
    raw=canonical(tables);assert len(raw)<=134217728;databases.append({'path':relative,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
   finally:connection.close()
   after=path.stat();assert (before.st_dev,before.st_ino)==(after.st_dev,after.st_ino)
   continue
  if path.name.endswith(('-shm','-wal')):continue
  raw=path.read_bytes();total+=len(raw);assert len(files)<4096 and total<=134217728
  files.append({'path':relative,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 return {'files':files,'databases':databases,'scope':'Original owned registry/Delta/data files and canonical SQLite contents; excludes transient SQLite WAL/SHM bytes.'}
base_raw=(R/'base.json').read_bytes();base=json.loads(base_raw)
assert Path(base['installation'])==Path('/private/tmp/ashlar-typed-graph-installed-20261017-gfothazt/native')
before=fingerprint(Path(base['installation']));retain('pages-before.json',before)
results=[];primary=None
try:
 for name,ordinal,sql,parameters_type,parameters,wanted,page_count in [
  ('old-unfiltered',1,'SELECT p.person_key,p.person_name FROM Person p',Empty,Empty(),[{'person_key':'person-1','person_name':'Ada'},{'person_key':'person-2','person_name':'Ben'},{'person_key':'person-3','person_name':'雪'}],2),
  ('current-filtered',3,'SELECT p.person_key,p.person_name FROM Person p WHERE p.person_name = :name',Filter,Filter(name='Ada'),[{'person_key':'person-1','person_name':'Ada'}],1)]:
  selected=dict(base,operation='read',ordinal=ordinal,output=str(R/('pages-'+name)),selector={'type_id':17,'entity_id':1})
  invocation=parse_configured_local(canonical(selected));query=ConfiguredSdkPagesConfig(weft,sql,parameters_type,Person,parameters,2,10,120,PathCaptureConfig(1000,65536,1048576))
  with diagnostics():answer=page_configured_local(invocation.runtime,ordinal=ordinal,query=query)
  result=answer['query'];assert result['items']==wanted and len(result['pages'])==page_count and result['has_more']is False
  guard_count=0
  for observation in result['evidence']:
   artifact=observation['program']['artifact'];guard_hashes={hashlib.sha256(check['sql'].encode()).hexdigest()for obligation in artifact['obligations']for check in obligation['parameters'].get('checks',[])}
   frames=observation['frames'];seen=[]
   for frame in frames:
    if frame['sql_sha256']in guard_hashes:
     assert len(frame['schema'])==1 and frame['schema'][0][1]=='STRING' and frame['rows']==[['0']];seen.append(frame['sql_sha256']);guard_count+=1
   assert set(seen)==guard_hashes
  assert guard_count>0 and (R/'base.json').read_bytes()==base_raw
  retain('pages-'+name+'-result.json',answer);results.append({'case':name,'ordinal':ordinal,'rows':len(wanted),'pages':page_count,'zero_guard_frames':guard_count})
except BaseException as e:primary=e
def closing():
 after=fingerprint(Path(base['installation']));retain('pages-after.json',after);assert before==after and (R/'base.json').read_bytes()==base_raw
finish(primary,[closing])
retain('pages-summary.json',{'status':'passed','cases':results,'native_contents_unchanged':True,'scope':'Two original configured graph required STRING SDK page cases only; no writes, reingest, cloud, protected ACK or performance claim.'})
print(json.dumps({'status':'passed','cases':results},separators=(',',':')))
