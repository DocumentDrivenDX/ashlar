import json,os,pathlib,subprocess,time,signal,socket,sys,hashlib,importlib.metadata as m
import ashlar,ashlar_host.puppy_export_cli as code,duckdb,neo4j
root=pathlib.Path(__file__).parent;c=json.loads((root/'configuration.json').read_bytes());start=time.monotonic()
metadata={'python':sys.version,'interpreter':sys.executable,'duckdb':m.version('duckdb'),'neo4j':m.version('neo4j'),'ashlar':m.version('ashlar-graph-toolkit'),'ashlar_file':ashlar.__file__,'public_command_file':code.__file__,'wheel_sha256':hashlib.sha256(next((root/'dist').glob('*.whl')).read_bytes()).hexdigest()}
(root/'runtime-selection.json').write_text(json.dumps(metadata,indent=2)+'\n')
for port in (c['http_port'],c['bolt_port']):
 s=socket.socket();s.bind(('127.0.0.1',port));s.close()
env={k:v for k,v in os.environ.items()if k not in ('PYTHONPATH','PYTHONHOME')};env['PYTHONDONTWRITEBYTECODE']='1'
command=[str(root/'venv/bin/ashlar'),'query-puppy-immutable-export','--configuration',str(root/'configuration.json')]
with (root/'stdout.log').open('wb')as out,(root/'stderr.log').open('wb')as err:
 p=subprocess.Popen(command,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True)
 (root/'live.json').write_text(json.dumps({'pid':p.pid,'command':command,'bound_seconds':180})+'\n')
 deadline=False
 try:exitcode=p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  deadline=True;os.killpg(p.pid,signal.SIGKILL);exitcode=p.wait(timeout=5)
result={'outcome':'deadline'if deadline else'completed','exit_code':exitcode,'duration_seconds':round(time.monotonic()-start,3),'command':command}
# Read-only verify final runtime state; cleanup fallback only for deadline, no restart.
env['DOCKER_HOST']=c['docker_host'];inspect=subprocess.run([c['docker'],'inspect',c['name']],env=env,capture_output=True,timeout=15)
if inspect.returncode==0:
 rows=json.loads(inspect.stdout);r=rows[0]
 if deadline and r['Name']=='/'+c['name']and r['Image']==c['image']and r['HostConfig']['Memory']==3*1024**3 and r['HostConfig']['NanoCpus']==2000000000:
  result['deadline_owned_cleanup']=[subprocess.run([c['docker'],*args,r['Id']],env=env,capture_output=True,timeout=20).returncode for args in (['stop','--time','5'],['rm'])]
 else:result['unexpected_remaining_container']=r['Id']
else:result['owned_container_absent_after_command']=True
(root/'supervisor-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(exitcode if exitcode>=0 else 124)
