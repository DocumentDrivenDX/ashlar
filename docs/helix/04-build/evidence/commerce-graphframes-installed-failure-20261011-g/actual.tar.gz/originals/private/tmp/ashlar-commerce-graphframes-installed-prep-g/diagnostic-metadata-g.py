"""Bounded fixed source metadata only; no exception text, locals or payloads."""
from pathlib import Path
import json,re

def exception_event(error,site,provider,approved):
    if not isinstance(error,BaseException)or type(approved)is not dict:raise ValueError('Original exception and closed guard map required')
    name=type(error).__name__
    if name not in approved['exception_types']:name='UnlistedExceptionType'
    frames=[];trace=error.__traceback__;count=0
    while trace is not None:
        count+=1
        if count>128:raise ValueError('Bounded original traceback metadata required')
        code=trace.tb_frame.f_code;filename=Path(code.co_filename)
        if filename==provider:relative='provider'
        elif filename.is_relative_to(site):
            relative=str(filename.relative_to(site))
            if not relative.startswith(('ashlar/','ashlar_host/')):relative=None
        else:relative=None
        if relative is not None and relative not in approved['functions']:relative=None
        if relative is not None:
            function=code.co_name
            if function not in approved['functions'].get(relative,[]):function='unlisted_function'
            key=relative+':'+str(trace.tb_lineno)
            frames.append({'file':relative,'function':function,'line':trace.tb_lineno,'guard_id':approved['guards'].get(key)})
        trace=trace.tb_next
    value={'format':'ashlar-owned-exception-metadata/0.1','exception_type':name,'frames':frames,'scope':'Owner source metadata only; no messages, locals, SQL, rows or credentials. No admission grant.'}
    raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
    if len(raw)>16384:raise ValueError('Bounded exception event required')
    return raw
