"""Prepared isolated import-only correspondence; does not start Spark/JVM."""
import sys,json,importlib.util,importlib.metadata
from pathlib import Path
if sys.flags.isolated!=1 or sys.flags.dont_write_bytecode!=1:raise ValueError('Actual isolated no-bytecode worker required')
expected=Path('/private/tmp/ashlar-commerce-graphframes-installed-20261011-g/worker-env')
sdk=Path('/private/tmp/ashlar-original-commerce-publication-sdk-20261011-a/lib/python3.11/site-packages')
if Path(sys.executable)!=expected/'bin/python' or Path(sys.prefix)!=expected:raise ValueError('Actual separate installed worker required')
observed={}
for name,package,version in [('pyspark','pyspark','3.5.3'),('delta-spark','delta','3.2.1'),('graphframes-py','graphframes','0.12.3')]:
    distribution=importlib.metadata.distribution(name);spec=importlib.util.find_spec(package)
    if distribution.version!=version or Path(distribution.locate_file('')).resolve()!=sdk or spec is None or Path(spec.origin).resolve()!=sdk/package/'__init__.py':raise ValueError('Selected SDK resolution/version differs')
    observed[name]={'version':version,'origin':spec.origin,'metadata':str(distribution.locate_file(''))}
    __import__(package)
worker=importlib.util.find_spec('ashlar_host.graphframes_release')
if worker is None or Path(worker.origin)!=expected/'lib/python3.11/site-packages/ashlar_host/graphframes_release.py':raise ValueError('Actual installed worker resolution differs')
for name in ('sitecustomize','usercustomize'):
    if importlib.util.find_spec(name)is not None:raise ValueError('Unexpected startup hook')
print(json.dumps({'format':'ashlar-graphframes-installed-import/0.1','sdk':observed,'worker':worker.origin,'executable':sys.executable,'prefix':sys.prefix,'sys_path':sys.path,'jvmStarted':False},sort_keys=True,separators=(',',':')))
