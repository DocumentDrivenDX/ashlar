"""Ordinary source and protected-ACK readback only; no native/publication grant."""
from pathlib import Path
import os,json,hashlib,importlib.util,signal
from ashlar_host.existing_outbox_authority import ordinary,privileges,one
from ashlar_host.postgres import Session
from ashlar_host.ack import receipt_bytes
from ashlar.outbox import PostgresOutbox
from ashlar_host.lifecycle import finish
R=Path(__file__).resolve().parent;os.umask(0o077)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def timeout(*args):raise TimeoutError('Bounded ordinary observation deadline')
def cancel(*args):raise KeyboardInterrupt()
signal.signal(signal.SIGALRM,timeout);signal.signal(signal.SIGTERM,cancel);signal.alarm(30)
selection=json.loads((R/'preparation.json').read_bytes())
if selection.get('ready')is not True:raise PermissionError('Completed A2 original byte selection pending')
def renew():
 for pin in selection['pins']:
  raw=Path(pin['path']).read_bytes()
  if len(raw)!=pin['bytes']or sha(raw)!=pin['sha256']:raise PermissionError('Original selected observer input changed')
renew();os.environ.update(json.loads((R/'operator-environment.json').read_bytes()));os.environ['PGCONNECT_TIMEOUT']='3'
spec=importlib.util.spec_from_file_location('original_readback_provider',R/'provider.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def retain_diagnostic(name,value):
 raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
 if len(raw)>4096:raise ValueError('Bounded private observation diagnostic required')
 fd=os.open(R/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);primary=None
 try:
  if os.write(fd,raw)!=len(raw):raise OSError('Exact diagnostic write required')
  os.fsync(fd)
 except BaseException as error:primary=error
 finish(primary,[lambda:os.close(fd)])
def read_source(session,selected):
 schema=selected.source.source_schema
 head=one(session,'SELECT position::text AS position FROM "'+schema+'".head WHERE id=1',{},('position',))['position']
 transactions=PostgresOutbox(session,feed=selected.source.scope.feed,epoch=selected.source.scope.epoch,schema=schema).read('0',limit=4)
 if head!='4'or len(transactions)!=4 or [(t.previous,t.position)for t in transactions]!=[(str(i),str(i+1))for i in range(4)]:raise PermissionError('Exact complete four-group source required')
 return {'head':head,'transactions':[{'previous':t.previous,'position':t.position,'batch_id':t.batch.batch_id,'payload_digest':t.payload_digest}for t in transactions]}
expected_completed=json.loads((R/'expected-completed.json').read_bytes())
operator=module.existing_operator();records=[];context=object();primary=None
try:
 for label,selected in zip(('A','B'),operator.registrations):
  connection=selected.source.connection_factory(context);error=None;source=None
  try:
   connection.execute('SET TRANSACTION ISOLATION LEVEL READ COMMITTED READ ONLY')
   connection.execute("SET LOCAL statement_timeout='3000ms'");connection.execute("SET LOCAL lock_timeout='1000ms'")
   session=Session(connection);ordinary(session,selected.source_role,selected.database);privileges(session,selected,ack=False)
   source=read_source(session,selected)
   if read_source(session,selected)!=source:raise PermissionError('Closing complete source changed')
   ordinary(session,selected.source_role,selected.database);privileges(session,selected,ack=False)
  except BaseException as e:error=e
  finish(error,[connection.rollback,connection.close])
  connection=selected.metadata_factory(context);error=None;observed=None;binding=None;ack_diagnostic=None
  try:
   connection.execute('SET TRANSACTION ISOLATION LEVEL READ COMMITTED READ WRITE')
   connection.execute("SET LOCAL statement_timeout='3000ms'");connection.execute("SET LOCAL lock_timeout='1000ms'")
   session=Session(connection);ordinary(session,selected.ack_role,selected.database);privileges(session,selected,ack=True)
   scope=selected.source.scope;expected=selected.source.metadata()['scope'];expected.pop('service_schema');expected.update(source_schema=selected.source.source_schema,source_signature_sha256=selected.source.source_signature_sha256)
   binding=one(session,'SELECT "'+scope.service_schema+'".scope_binding(CAST(:scope AS uuid)) AS binding',{'scope':scope.scope_id},('binding',))['binding']
   if binding!=expected:raise PermissionError('Original scope binding differs')
   current=one(session,'SELECT * FROM "'+scope.service_schema+'".observe(CAST(:scope AS uuid),CAST(:position AS bigint))',{'scope':scope.scope_id,'position':'0'},('position','request_hex','manifest_hex','receipt_hex'))
   position=current['position']
   if position!=({'A':'2','B':'1'}[label]):raise PermissionError('Exact completed A2/B1 readback required')
   if type(position)is not str or not position.isdecimal()or str(int(position))!=position or not 0<=int(position)<=4:raise PermissionError('Bounded canonical actual ACK position required')
   wanted=int(position);expected_slot=expected_completed[label].get(position);matched=False
   observed=one(session,'SELECT * FROM "'+scope.service_schema+'".observe(CAST(:scope AS uuid),CAST(:position AS bigint))',{'scope':scope.scope_id,'position':str(wanted)},('position','request_hex','manifest_hex','receipt_hex'))
   if observed['position']!=str(wanted):raise PermissionError('Observed ACK position differs from selected readback')
   if wanted==0:
    if any(observed[n]is not None for n in ('request_hex','manifest_hex','receipt_hex')):raise PermissionError('Zero-position receipt must be absent')
   else:
    values=[]
    for name in ('request_hex','manifest_hex','receipt_hex'):
     value=observed[name]
     if type(value)is not str or len(value)>8388608 or len(value)%2:raise PermissionError('Bounded original protected bytes required')
     raw=bytes.fromhex(value)
     if raw.hex()!=value:raise PermissionError('Exact lowercase protected bytes required')
     values.append(raw)
    ack_diagnostic={'label':label,'actual_position':position,'observed':{name:{'bytes':len(raw),'sha256':sha(raw)}for name,raw in zip(('request','manifest','receipt'),values)},'receipt_codec_valid':False,'completed_slot_match':None,'scope':'Bounded byte observation only; final report/closing required, no ACK or publication completion claim'}
    _,_,checkpoint,calculated=receipt_bytes(scope,values[0],values[1])
    if calculated!=values[2]:raise PermissionError('Exact protected byte correspondence differs')
    ack_diagnostic['receipt_codec_valid']=True
    source_group=source['transactions'][wanted-1]
    if any(checkpoint[k]!=source_group[k]for k in ('previous','position','batch_id','payload_digest')):raise PermissionError('Protected ACK differs from complete original source group')
    if expected_slot is not None:
     expected_request=Path(expected_slot['request']['path']).read_bytes();expected_manifest=Path(expected_slot['manifest']['path']).read_bytes()
     ack_diagnostic['expected']={'request':{'bytes':len(expected_request),'sha256':sha(expected_request)},'manifest':{'bytes':len(expected_manifest),'sha256':sha(expected_manifest)}}
     ack_diagnostic['completed_slot_match']=values[0]==expected_request and values[1]==expected_manifest
     if not ack_diagnostic['completed_slot_match']:raise PermissionError('Protected request/descriptor differs from completed original slot')
     matched=True
   ordinary(session,selected.ack_role,selected.database);privileges(session,selected,ack=True)
  except BaseException as e:error=e
  finish(error,[connection.rollback,connection.close]+([]if ack_diagnostic is None else[lambda:retain_diagnostic('ack-'+label+'-byte-observation.json',ack_diagnostic)]))
  records.append({'label':label,'scope_binding':binding,'source':source,'ack':observed,'transaction_closing_completed':True,'source_opening_closing_equal':True,'completed_slot_bytes_match':matched,'selected_completed_slot':None if expected_slot is None else expected_slot['ordinal'],'completed_slot_correspondence':'matched'if matched else'not-available-at-observed-position'})
except BaseException as e:primary=e
finish(primary,[renew])
result={'profile':'ashlar-ordinary-source-ack-observation/0.1','records':records,'all_closing_completed':True,'qualification':'Ordinary native role/privilege/scope, complete four-group source bracket and protected receipt readback; Actual ACK positions are observed without assuming A2; exact request/descriptor matching is asserted only when a completed slot exists. A receipt at a later retained-only slot does not establish publication completion. No writer/native lease, publication validity, replay/submit or ACK mutation authority.'}
raw=(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n').encode()
if len(raw)>4194304:raise ValueError('Bounded observation report required')
fd=os.open(R/'observation.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);error=None
try:
 if os.write(fd,raw)!=len(raw):raise OSError('Exact observation write required')
 os.fsync(fd)
except BaseException as e:error=e
finish(error,[lambda:os.close(fd)]);signal.alarm(0)
print(json.dumps({'status':'observed','positions':[r['ack']['position']for r in records],'all_closing_completed':True}))
