import os,sys,tempfile,time,json,base64,hashlib,importlib.metadata
from pathlib import Path
import psycopg,psycopg.pq,jsonschema,referencing
root=Path(__file__).parent;(root/'ipc').mkdir();os.environ['TMPDIR']=str(root/'ipc');tempfile.tempdir=None
os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
for p in reversed(json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical']):sys.path.insert(0,p)
sys.path.insert(0,'/Users/erik/Projects/ashlar/src');sys.path.insert(0,'/private/tmp/ashlar-truss15-parallel-example-20261013-a/truss-target')
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context
from ashlar_host.truss_example import private_file
from ashlar_host.truss_example_reader import run_configure_truss_example_reader_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_two_hop_count_cli import run_query_truss_two_hop_count_command
from ashlar_host.truss_two_hop_target_count_cli import run_query_truss_two_hop_target_count_command
start=time.monotonic();result=None
try:
 example=Path('/private/tmp/ashlar-truss15-parallel-example-20261013-a/example')
 with owned_context(LocalPostgres(example/'data'))as runtime:
  live=private_file(root/'live.json',{'profile':'ashlar-local-truss-connection/0.1','data_directory':str(example/'data'),'connection_uri':runtime.info.connection_uri})
  reader=root/'reader.json';run_configure_truss_example_reader_command(example,live,reader,reader_configuration=example/'reader-configuration.json')
  config=json.loads(reader.read_bytes())
  def connection():return psycopg.connect(config['connection_uri'],autocommit=False,connect_timeout=5)
  before=read_page(connection,'example-related-delta',maximum_bytes=2097152).prior.content
  private_file(root/'checkpoint-before.json',{'cursor_base64':base64.b64encode(before).decode()})
  original=json.loads((example/'result.json').read_bytes());edges=[json.loads((example/f'created-edge-{i}.json').read_bytes())['edge']for i in (1,2)]
  if len({e['identity']['id']for e in edges})!=2 or any(e['source']!=e['target']for e in edges):raise ValueError('Actual distinct original self-edge occurrences required')
  values=[]
  for name,port,sql,key,expected in (('paths',run_query_truss_two_hop_count_command,'SELECT COUNT(*) AS paths FROM TypedRecord a CROSS JOIN EXPAND_PATHS(a.related,related) AS p','paths',4),('targets',run_query_truss_two_hop_target_count_command,'SELECT COUNT_DISTINCT_PATH_TARGETS(p) AS targets FROM TypedRecord a CROSS JOIN EXPAND_PATHS(a.related,related) AS p','targets',1)):
   value=port(reader,root/(name+'-query.json'),index='/private/tmp/weft-042-integration-b/distributions/index.json',installation='/private/tmp/ashlar-042-installed-cli-actual-b/qualification/installation',sql=sql,revision='1',document_id='typed-related-record',maximum_rows=1)
   if value['rows']!=[{key:expected}]or value['publication_id']!=original['publication_id']:raise ValueError('Exact original parallel path/target count differs')
   values.append({'case':name,'rows':value['rows'],'integrity':value['integrity'],'publication_id':value['publication_id']})
  after=read_page(connection,'example-related-delta',maximum_bytes=2097152).prior.content;private_file(root/'checkpoint-after.json',{'cursor_base64':base64.b64encode(after).decode()})
  if before!=after:raise ValueError('Read-only counts changed source checkpoint')
 result={'outcome':'passed','duration_seconds':round(time.monotonic()-start,3),'truss_version':importlib.metadata.version('truss-toolkit'),'source_edge_ids':[e['identity']['id']for e in edges],'queries':values,'source_checkpoint_unchanged':True,'qualification':'Actual public indexed0.4.2 two-hop pathCOUNT4 and originalterminal-key DISTINCTCOUNT1 under complete original Truss15 acceptedmodel/source/publication/nativeguards and independentlyderived fulledge-occurrence oracle. No source mutation, ACK, ingest, oldsourceupgrade or externalengine qualification.'}
except BaseException as error:result={'outcome':'failed','duration_seconds':round(time.monotonic()-start,3),'error_type':type(error).__name__};raise
finally:private_file(root/'run-result.json',result);print(json.dumps(result),flush=True)
