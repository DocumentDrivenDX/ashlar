import unittest,tempfile,pathlib,os,hashlib,sys
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import replacement as m
class Tests(unittest.TestCase):
 def fixture(self,root):
  parent=root/'parent'; parent.mkdir(); cache=parent/'cache'; cache.mkdir(); staging=root/'staging'; staging.mkdir(); rows=[]
  for name in ('one.pyc','two.pyc'):
   old=cache/name; old.write_bytes(b'unknown'); new=staging/name; new.write_bytes(b'controlled')
   def pin(p):
    s=p.stat(); return {'bytes':s.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'identity':[s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_mtime_ns,s.st_ctime_ns]}
   rows.append({'name':name,'original':pin(old),'generated':pin(new)})
  return cache,staging,rows,m.ancestors(cache),m.ancestors(staging)
 def test_success(self):
  with tempfile.TemporaryDirectory() as t:
   c,s,r,cc,sc=self.fixture(pathlib.Path(t).resolve()); self.assertEqual(m.replace_selected(c,cc,s,sc,r,result=pathlib.Path(t)/'result'),['one.pyc','two.pyc']); self.assertEqual((c/'one.pyc').read_bytes(),b'controlled')
 def test_parent_alias(self):
  with tempfile.TemporaryDirectory() as t:
   c,s,r,cc,sc=self.fixture(pathlib.Path(t).resolve()); moved=c.parent.with_name('moved'); c.parent.rename(moved); c.parent.symlink_to(moved)
   with self.assertRaises(ValueError):m.replace_selected(c,cc,s,sc,r)
   self.assertEqual((moved/'cache/one.pyc').read_bytes(),b'unknown')
 def test_directory_replacement(self):
  with tempfile.TemporaryDirectory() as t:
   c,s,r,cc,sc=self.fixture(pathlib.Path(t).resolve()); old=c.with_name('old'); c.rename(old); c.mkdir()
   with self.assertRaises(ValueError):m.replace_selected(c,cc,s,sc,r)
   self.assertEqual((old/'one.pyc').read_bytes(),b'unknown')
 def test_partial_cancel_primary_and_closing(self):
  with tempfile.TemporaryDirectory() as t:
   c,s,r,cc,sc=self.fixture(pathlib.Path(t).resolve()); primary=KeyboardInterrupt(); calls=[]; close=os.close; cancelled=[]
   def cancel(i):
    if i==1:cancelled.append(True); raise primary
   def closing(fd):
    calls.append(fd); close(fd)
    if cancelled:raise OSError('secondary')
   with patch.object(m.os,'close',closing):
    with self.assertRaises(KeyboardInterrupt) as caught:m.replace_selected(c,cc,s,sc,r,before_replace=cancel,result=pathlib.Path(t)/'result')
   self.assertIs(caught.exception,primary); self.assertGreaterEqual(len(calls),2); self.assertFalse((pathlib.Path(t)/'result').exists())
 def test_partial_replace_failure_unqualified(self):
  with tempfile.TemporaryDirectory() as t:
   c,s,r,cc,sc=self.fixture(pathlib.Path(t).resolve()); replace=os.replace; count=[]
   def fail(*a,**kw):
    count.append(1)
    if len(count)==2:raise OSError('partial replacement')
    return replace(*a,**kw)
   with patch.object(m.os,'replace',fail):
    with self.assertRaises(OSError):m.replace_selected(c,cc,s,sc,r,result=pathlib.Path(t)/'result')
   self.assertEqual((c/'one.pyc').read_bytes(),b'controlled'); self.assertEqual((c/'two.pyc').read_bytes(),b'unknown'); self.assertFalse((pathlib.Path(t)/'result').exists())
 def test_general_selected_links_exact(self):
  import ast
  tree=ast.parse((pathlib.Path(__file__).parent/'repair.py').read_bytes()); node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='verify'); env={'pathlib':pathlib,'os':os,'stat':__import__('stat'),'hashlib':hashlib}; exec(compile(ast.Module(body=[node],type_ignores=[]),'verify','exec'),env)
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t).resolve()/'file';p.write_bytes(b'original'); link=p.with_name('link');os.link(p,link); st=p.stat();row={'path':str(p),'bytes':8,'sha256':hashlib.sha256(b'original').hexdigest(),'identity':[st.st_dev,st.st_ino,st.st_mode,2]};env['verify'](row,extended=False)
   with self.assertRaises(AssertionError):env['verify'](row)
   link.unlink()
   with self.assertRaises(AssertionError):env['verify'](row,extended=False)
if __name__=='__main__':unittest.main()
