import pathlib,json,hashlib,os,stat,subprocess,ast
P=pathlib.Path('/private/tmp/ashlar-supply-chain-native-03-cache-repair-c'); R=pathlib.Path('/private/tmp/ashlar-supply-chain-native-03-prep-a')
# Reuse frozen bounded streaming file owner verbatim, without running its module.
owner=R/'run-native.py'; raw=owner.read_bytes(); assert len(raw)<=65536 and hashlib.sha256(raw).hexdigest()=='302b91b602cb7ee58d7309348a891169b7321f6bf9f653d14af8dfd2e671f30b'; tree=ast.parse(raw)
namespace={'os':os,'stat':stat,'hashlib':hashlib}
def finish(primary,callbacks):
 errors=[]
 for callback in callbacks:
  try:callback()
  except BaseException as error:errors.append(error)
 if primary is not None:raise primary
 if errors:raise errors[0]
namespace['finish']=finish
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name=='bounded_read':exec(compile(ast.Module(body=[node],type_ignores=[]),str(owner),'exec'),namespace)
read=namespace['bounded_read']
X=json.loads(read(P/'inventory.json',65536)); assert hashlib.sha256(read(P/'inventory.json',65536)).hexdigest()=='b7f9cc6ea6e379550cbd95598fe5032ebde6ce8f28b1c624a6f51e3726b97078'
C=json.loads(read(R/'custody.json',8388608)); assert hashlib.sha256(read(R/'custody.json',8388608)).hexdigest()==X['custody']['sha256']
for row in C['selectedFiles']:read(pathlib.Path(row['path']),row['bytes'],selected=row,collect=False)
def observed(root,links=False):
 answer={}
 for p in sorted(root.rglob('*')):
  s=p.lstat()
  if p.is_symlink():
   if not links:raise ValueError('Unexpected SDK alias')
   answer[str(p)]={'kind':'symlink','target':os.readlink(p),'resolved':str(p.resolve())}
  elif p.is_dir():answer[str(p)]={'kind':'directory','identity':[s.st_dev,s.st_ino,s.st_mode]}
  elif p.is_file():answer[str(p)]={'kind':'file','bytes':s.st_size,'metadata':[s.st_dev,s.st_ino,s.st_mode,s.st_mtime_ns,s.st_nlink]}
  else:raise ValueError('Unexpected namespace kind')
 return answer
extras={X['cache_directory']['path']}|{r['unknown']['path'] for r in X['files']}
a=observed(R/'venv'); assert set(a)-set(C['environmentNamespace'])==extras; assert {k:v for k,v in a.items() if k not in extras}==C['environmentNamespace']
for row in X['cache_ancestors']:
 s=pathlib.Path(row['path']).lstat(); assert [s.st_dev,s.st_ino,s.st_mode]==row['identity'] and stat.S_ISDIR(s.st_mode)
for row in X['files']:
 pin=row['unknown']; p=pathlib.Path(pin['path']); s=p.lstat(); assert [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_mtime_ns,s.st_ctime_ns]==pin['identity']; read(p,pin['bytes'],selected={**pin,'identity':pin['identity'][:4]},collect=False)
for root,expected in C['externalNamespace'].items():assert observed(pathlib.Path(root),True)==expected
scopes=('/private/tmp/ashlar-supply-chain-native-03-prep-a/venv','/private/tmp/ashlar-supply-chain-native-02-prep-b','/private/tmp/ashlar-medical-')
# No command lines are retained or printed; only bounded matching PID census.
result=subprocess.run(['/bin/ps','-axo','pid=,command='],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,check=True)
if len(result.stdout)>1048576 or result.stderr:raise ValueError('Process census refused')
matches=[]
for line in result.stdout.decode('utf-8',errors='strict').splitlines():
 parts=line.strip().split(None,1)
 if len(parts)==2 and int(parts[0])!=os.getpid() and any(scope in parts[1] for scope in scopes):matches.append(int(parts[0]))
if matches:raise ValueError('Selected process scopes occupied')
print(json.dumps({'originalResources':len(C['selectedFiles']),'SDKNamespaceOriginal':len(C['environmentNamespace']),'permittedExtras':len(extras),'JDKNamespaceComplete':True,'selectedProcessCount':0,'scope':'read-only pre-repair; no native authority'},sort_keys=True))
