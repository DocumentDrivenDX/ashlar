import os, pathlib, stat, json, hashlib

def identity(s): return [s.st_dev,s.st_ino,s.st_mode]
def ancestors(path):
 return [{'path':str(p),'identity':identity(p.lstat())} for p in [*reversed(path.parents),path]]
def renew(path, chain, fd):
 if path.resolve()!=path: raise ValueError('Canonical directory changed')
 for row in chain:
  p=pathlib.Path(row['path']); s=p.lstat()
  if not stat.S_ISDIR(s.st_mode) or identity(s)!=row['identity']: raise ValueError('Directory identity changed')
 if identity(os.fstat(fd))!=chain[-1]['identity']: raise ValueError('Held directory changed')
def finish(primary, callbacks):
 errors=[]
 for callback in callbacks:
  try: callback()
  except BaseException as error: errors.append(error)
 if primary is not None: raise primary
 if errors: raise errors[0]
def read_at(fd,name,expected,*,moved=False):
 owned=None; primary=None; answer=None
 try:
  owned=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd); s=os.fstat(owned)
  if not stat.S_ISREG(s.st_mode) or s.st_nlink!=1 or s.st_size!=expected['bytes']: raise ValueError('Exact bounded file required')
  if [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_mtime_ns,s.st_ctime_ns][:5 if moved else 6]!=expected['identity'][:5 if moved else 6]: raise ValueError('File identity changed')
  h=hashlib.sha256(); n=0
  while True:
   b=os.read(owned,min(65536,expected['bytes']-n+1))
   if not b: break
   n+=len(b)
   if n>expected['bytes']: raise ValueError('File grew')
   h.update(b)
  if n!=expected['bytes'] or h.hexdigest()!=expected['sha256'] or os.fstat(owned)!=s or os.stat(name,dir_fd=fd,follow_symlinks=False)!=s: raise ValueError('File bytes changed')
  answer=True
 except BaseException as error: primary=error
 finish(primary,[lambda:os.close(owned)] if owned is not None else[]); return answer

def replace_selected(cache,chain,staging,stage_chain,rows,*,before_replace=lambda i:None,result=None):
 cache=pathlib.Path(cache); staging=pathlib.Path(staging); cf=sf=rf=None; primary=None; completed=[]
 try:
  cf=os.open(cache,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW); renew(cache,chain,cf)
  sf=os.open(staging,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW); renew(staging,stage_chain,sf)
  for i,row in enumerate(rows):
   before_replace(i); renew(cache,chain,cf); renew(staging,stage_chain,sf)
   name=row['name']
   if pathlib.Path(name).name!=name or name in ('.','..'): raise ValueError('Closed relative name required')
   read_at(cf,name,row['original']); read_at(sf,name,row['generated'])
   os.replace(name,name,src_dir_fd=sf,dst_dir_fd=cf)
   renew(cache,chain,cf); renew(staging,stage_chain,sf)
   read_at(cf,name,row['generated'],moved=True); completed.append(name)
  if result is not None:
   raw=(json.dumps({'qualified':True,'replaced':completed},separators=(',',':'))+'\n').encode()
   if len(raw)>65536: raise ValueError('Bounded result required')
   rf=os.open(result,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
   offset=0
   while offset<len(raw):
    n=os.write(rf,raw[offset:])
    if n<=0: raise OSError('Incomplete result write')
    offset+=n
   os.fsync(rf)
 except BaseException as error: primary=error
 finish(primary,[lambda fd=fd:os.close(fd) for fd in (rf,sf,cf) if fd is not None])
 return completed
