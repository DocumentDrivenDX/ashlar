"""Review-only executable; running this script mutates only the thirteen captured caches."""
import pathlib,os,json,hashlib,stat,py_compile,tempfile
P=pathlib.Path('/private/tmp/ashlar-supply-chain-native-03-cache-repair-c'); R=pathlib.Path('/private/tmp/ashlar-supply-chain-native-03-prep-a')
def verify(row,extended=True):
 p=pathlib.Path(row['path']); s=p.lstat(); assert p.resolve()==p and stat.S_ISREG(s.st_mode) and s.st_nlink==(1 if extended else row['identity'][3]) and s.st_size==row['bytes']
 facts=[s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_mtime_ns,s.st_ctime_ns]; assert facts[:len(row['identity'])]==row['identity']
 h=hashlib.sha256(); count=0
 with p.open('rb') as f:
  assert os.fstat(f.fileno())==s
  while b:=f.read(min(65536,row['bytes']-count+1)):
   count+=len(b); assert count<=row['bytes']; h.update(b)
 assert count==row['bytes'] and h.hexdigest()==row['sha256'] and p.lstat()==s and p.resolve()==p
x=json.loads((P/'inventory.json').read_bytes()); assert hashlib.sha256((P/'inventory.json').read_bytes()).hexdigest()=='b7f9cc6ea6e379550cbd95598fe5032ebde6ce8f28b1c624a6f51e3726b97078'
verify(x['custody']); verify(x['wheel']); verify(x['python']); assert pathlib.Path(os.sys.executable).resolve()==pathlib.Path(x['python']['path'])
c=json.loads((R/'custody.json').read_bytes())
for row in c['selectedFiles']:verify(row,extended=False)
extras={x['cache_directory']['path']}|{r['unknown']['path'] for r in x['files']}
actual={}
for p in (R/'venv').rglob('*'):
 assert not p.is_symlink(); s=p.lstat()
 actual[str(p)]={'kind':'directory','identity':[s.st_dev,s.st_ino,s.st_mode]} if p.is_dir() else {'kind':'file','bytes':s.st_size,'metadata':[s.st_dev,s.st_ino,s.st_mode,s.st_mtime_ns,s.st_nlink]}
assert set(actual)-set(c['environmentNamespace'])==extras
assert {k:v for k,v in actual.items() if k not in extras}==c['environmentNamespace']
for row in x['files']:
 for kind in ('unknown','preserved','source'):verify(row[kind])
# No site imports; CHECKED_HASH and explicit dfile/optimization define derivation.
staging=pathlib.Path(tempfile.mkdtemp(prefix='controlled-',dir=P)); generated=[]
for row in x['files']:
 source=row['source']['path']; dest=staging/pathlib.Path(row['unknown']['path']).name
 py_compile.compile(source,cfile=str(dest),dfile=source,doraise=True,optimize=0,invalidation_mode=py_compile.PycInvalidationMode.CHECKED_HASH)
 os.chmod(dest,0o600); generated.append((row,dest))
# Review release also requires immediate selected-process absence; never execute pyc.
for row in c['selectedFiles']:verify(row,extended=False)
import importlib.util
spec=importlib.util.spec_from_file_location('controlled_replacement',P/'replacement.py'); helper=importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
rows=[]
for row,dest in generated:
 s=dest.stat(); rows.append({'name':dest.name,'original':row['unknown'],'generated':{'bytes':s.st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'identity':[s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_mtime_ns,s.st_ctime_ns]}})
helper.replace_selected(pathlib.Path(x['cache_directory']['path']),x['cache_ancestors'],staging,helper.ancestors(staging),rows,result=P/'controlled-result.json')
# The result is qualified only with terminal command success, all FD closing, and independent B custody renewal.
