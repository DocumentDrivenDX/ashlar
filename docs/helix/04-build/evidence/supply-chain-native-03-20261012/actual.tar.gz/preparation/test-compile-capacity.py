import importlib.util,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
R=Path(__file__).parent;s=importlib.util.spec_from_file_location('recipe',R/'compile-capacity.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Controls(unittest.TestCase):
 def test_actual_original_20_request_comparisons_no_compiler_call(self):
  with patch.object(m,'compile_paths_distribution')as compiler:
   original,prepared,requests=m.derive(m.pins())
  compiler.assert_not_called();self.assertEqual(len(original),30);self.assertEqual(len(requests),12)
  self.assertEqual(prepared['queries'][10]['relationships'],['shipment_items.shipment_id','shipments.facility_id'])
  self.assertEqual(prepared['queries'][11]['relationships'],['shipment_items.item_id','items.lot_id'])
 def test_original_byte_pin_drift_refuses_before_compile(self):
  selected=m.pins();selected['audit']={**selected['audit'],'sha256':'0'*64}
  with patch.object(m,'compile_paths_distribution')as compiler,self.assertRaises(ValueError):m.derive(selected)
  compiler.assert_not_called()
 def test_receipt_cancellation_keeps_identity_and_attempts_owned_close(self):
  primary=KeyboardInterrupt();events=[]
  def write(raw):events.append('write');raise primary
  def close():events.append('close');raise OSError('secondary')
  with patch.object(Path,'open',return_value=SimpleNamespace(write=write,close=close)),self.assertRaises(KeyboardInterrupt)as caught:m.write_receipt({'scope':'inert'})
  self.assertIs(caught.exception,primary);self.assertEqual(events,['write','close'])
if __name__=='__main__':unittest.main()
