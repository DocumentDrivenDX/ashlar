"""Four public compiler calls and exact original binary capacity proof only.

No producer, SDK/session/native SQL or publication authority is constructed.
"""
from pathlib import Path
import importlib.util
import hashlib
import json
import os
import sys
from ashlar.supply_chain_source import build_transaction
from ashlar.weft_paths_distribution import installed_paths_schema_bundle, compile_paths_distribution
from ashlar_host.supply_chain_native_cli import parse_supply_chain_native_invocation
from ashlar_host.supply_chain_common_requests import prepare_supply_chain_two_hop
from ashlar_host.supply_chain_request import SOURCE_SYSTEM
from ashlar_host.supply_chain_binary_evidence import SupplyChainBinaryEvidence, INVENTORY
from ashlar_host.path_admission import PathAdmissionConfig, admit_path_artifact
from ashlar_host.path_schema import make_offline_path_schema_validation
from ashlar_host.delta_custody import encoded
from ashlar_host.lifecycle import finish
R = Path(__file__).parent
s = importlib.util.spec_from_file_location('capture_guards', R / 'run-native.py')
guard = importlib.util.module_from_spec(s); s.loader.exec_module(guard)
SCRIPT_OPENING = {}
PINS_SHA = 'c42cd15cde81dea3740d9dc7692a912bb5c8587b9eb61d8bfa2904e467e308c2'

def pins():
    raw = guard.bounded_read(R / 'compile-inputs.json', 65536)
    if hashlib.sha256(raw).hexdigest() != PINS_SHA:
        raise ValueError('Exact original compilation selection required')
    return json.loads(raw)

def read(item):
    return guard.bounded_read(Path(item['path']), item['bytes'], selected=item)

def renewal(selected):
    guard.renew()
    for path, digest in SCRIPT_OPENING.items():
        if hashlib.sha256(guard.bounded_read(Path(path), 65536)).hexdigest() != digest:
            raise ValueError('Original compiler-only recipe bytes changed')
    for item in selected.values():
        guard.bounded_read(Path(item['path']), item['bytes'], selected=item, collect=False)

def derive(selected):
    protocol = [json.loads(line) for line in read(selected['protocol']).splitlines()]
    if len(protocol) != 30 or [(r['id'], r['iteration']) for r in protocol] != list(INVENTORY[:30]):
        raise ValueError('Exact thirty retained original protocol records required')
    originals = []
    for row in protocol:
        if set(row) != {'id', 'iteration', 'requestHex', 'responseHex'} or type(row['iteration']) is not int:
            raise ValueError('Closed original protocol record required')
        if any(type(row[k]) is not str or len(row[k]) > 2097152 for k in ('requestHex', 'responseHex')):
            raise ValueError('Bounded original byte views required')
        originals.append((row['id'], row['iteration'], bytes.fromhex(row['requestHex']), bytes.fromhex(row['responseHex'])))
    report = json.loads(read(selected['audit']))
    manifest = report['manifest']  # Exact actual audit field; no reconstruction.
    registry = json.loads(read(selected['registry']))
    model, graph, pack = (read(selected[k]) for k in ('model', 'graph', 'pack'))
    _, bindings = build_transaction(model, graph, source_system=SOURCE_SYSTEM)
    first = json.loads(originals[10][2]); binding = json.loads(first['target']['bindingJson'])
    aliases = {}
    for native in json.loads(manifest['table_versions_json']):
        tables = [t for t in binding['publication']['tables'] if t['name'][-1] == native.split('.')[-1]]
        if len(tables) != 1: raise ValueError('Exact original publication alias correspondence required')
        aliases[native] = '.'.join(tables[0]['name'])
    prepared = prepare_supply_chain_two_hop(pack, model, graph, bindings, manifest, registry['targets'], aliases)
    requests = [(encoded(q['request']) + '\n').encode() for q in prepared['queries']]
    for ordinal in range(10):
        for iteration in (0, 1):
            if originals[10 + 2*ordinal + iteration][2] != requests[ordinal]:
                raise ValueError('Original retained request differs from public pure preparation')
    return originals, prepared, requests

def write_receipt(value):
    raw = (json.dumps(value, indent=2) + '\n').encode()
    if len(raw) > 65536: raise ValueError('Bounded capacity receipt required')
    stream = None; primary = None
    try:
        stream = (R / 'compile-capacity-result.json').open('xb')
        if stream.write(raw) != len(raw): raise ValueError('Complete capacity receipt required')
        stream.flush(); os.fsync(stream.fileno())
    except BaseException as error: primary = error
    finish(primary, [stream.close] if stream is not None else [])

def main():
    for path in (Path(__file__), R/'run-native.py', R/'compile-inputs.json'):
        SCRIPT_OPENING[str(path)] = hashlib.sha256(guard.bounded_read(path, 65536)).hexdigest()
    selected = pins(); originals, prepared, requests = derive(selected)
    config = parse_supply_chain_native_invocation(read(selected['configuration'])).native
    paths = config.two_hop.distribution
    if Path(sys.executable).resolve() != R/'venv/bin/python':
        raise ValueError('Exact fresh installed interpreter required')
    for module in ('ashlar', 'ashlar_host.supply_chain_common_requests', 'ashlar_host.supply_chain_binary_evidence'):
        path = Path(sys.modules[module].__file__)
        if path.resolve() != path or not path.is_relative_to(R/'venv/lib/python3.11/site-packages'):
            raise ValueError('Actual isolated installed package origin required')
    output = R / 'compile-capacity-output'
    output.mkdir(mode=0o700)
    sink = None; bundle = None; primary = None; result = None
    try:
        renewal(selected)
        bundle = dict(installed_paths_schema_bundle(paths))
        schema = make_offline_path_schema_validation({k: bundle[k] for k in
            ('compile-request-v0.4.schema.json', 'compile-response-v0.4.schema.json', 'logical-plan-v0.4.schema.json')})
        sink = SupplyChainBinaryEvidence(output)
        for name, iteration, request, response in originals:
            sink.retain(name, iteration, request, response)
        calls = []
        for ordinal in (10, 11):
            responses = []
            for iteration in (0, 1):
                renewal(selected)
                response = compile_paths_distribution(paths, requests[ordinal])
                if type(response) is not bytes or len(response) > 1048576:
                    raise ValueError('Original response exceeds selected one MiB bound')
                sink.retain('two-hop-'+str(ordinal), iteration, requests[ordinal], response)
                responses.append(response); calls.append([ordinal, iteration])
            if responses[0] != responses[1]: raise ValueError('Independent original recompilation differs')
            admit_path_artifact(prepared['queries'][ordinal]['request'], json.loads(responses[0]),
                json.loads(responses[1]), config=PathAdmissionConfig(1048576, schema, 'paths'))
        result = {'scope': 'Actual public installed Paths530 compilation/metadata admission and binary retention capacity only; no native/source/publication authority or query execution',
            'sourceRevision': '93de7cc617ae31e6206597503ac3dfd32d872c01',
            'reusedOriginalRecords': 30, 'actualCompileCalls': calls,
            'originalRequestComparisons': 20, 'missingQueryRelationships': [prepared['queries'][i]['relationships'] for i in (10, 11)],
            'binaryInventory': sink.reference(), 'auditManifestField': '/manifest',
            'auditSourceSha256': selected['audit']['sha256']}
    except BaseException as error: primary = error
    def close_bundle():
        if bundle is not None and dict(installed_paths_schema_bundle(paths)) != bundle:
            raise ValueError('Original installed compiler schema bundle changed')
    callbacks = [close_bundle, lambda: renewal(selected)]
    if sink is not None: callbacks.append(sink.close)
    finish(primary, callbacks)
    if any(m in sys.modules for m in ('pyspark', 'delta')):
        raise ValueError('No SDK or native query owner may be opened')
    result['allClosingPassed'] = True
    write_receipt(result)
    print('Actual34 binary payload/index capacity and four public compiler calls PASS', result['binaryInventory']['aggregate_bytes'])

if __name__ == '__main__': main()
