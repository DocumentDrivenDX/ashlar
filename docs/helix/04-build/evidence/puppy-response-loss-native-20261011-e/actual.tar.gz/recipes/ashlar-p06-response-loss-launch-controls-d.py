import ast,sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/erik/Projects/ashlar/src')
from ashlar_host.lifecycle import owned_context,finish
probe=Path('/private/tmp/ashlar-p06-response-loss-native-probe-d.py');tree=ast.parse(probe.read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='main');body=next(n for n in main.body if isinstance(n,ast.Try)).body
start=next(i for i,n in enumerate(body)if isinstance(n,ast.With)and 'launched-id.txt' in ast.unparse(n));statements=body[start:start+5]
assert isinstance(statements[0],ast.With)and 'finish' in ast.unparse(statements[-1])
class Stream:
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
 def write(self,value):pass
 def flush(self):pass
 def fileno(self):return 7
 def close(self):self.closed=True;raise RuntimeError('close error')
class Root:
 def __truediv__(self,name):return self
 def open(self,mode):return stream
class OS:
 O_RDONLY=0
 def open(self,*args):return 8
 def fsync(self,fd):
  if fd==selected:raise primary
 def close(self,fd):closed.append(fd);raise RuntimeError('fd close error')
checks=[]
for selected in [7,8]:
 stream=Stream();stream.closed=False;closed=[];primary=KeyboardInterrupt('primary')
 # File cancellation requires only file statement; directory cancellation uses its exact actual four statements.
 chosen=statements[:1]if selected==7 else statements[1:]
 env={'ROOT':Root(),'container':'a'*64,'owned_context':owned_context,'finish':finish,'os':OS()}
 # Actual file block's import os must use inert object, so drop solely that import from extracted block.
 chosen=ast.parse('\n'.join(ast.unparse(n)for n in chosen)).body
 for n in ast.walk(ast.Module(body=chosen,type_ignores=[])):
  if isinstance(n,ast.With):n.body=[x for x in n.body if not isinstance(x,ast.Import)]
 try:exec(compile(ast.fix_missing_locations(ast.Module(body=chosen,type_ignores=[])),'actual-launch','exec'),env)
 except KeyboardInterrupt as error:assert error is primary
 else:raise AssertionError('primary identity lost')
 assert stream.closed if selected==7 else closed==[8]
 checks.append('actual launch '+('file'if selected==7 else 'directory')+' cancellation preserved; close attempted')
print(json.dumps({'probe_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'checks':checks,'scope':'Actual extracted launch persistence blocks with inert file/fd effects; no native/SDK'}))
