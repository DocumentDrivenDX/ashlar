"""Offline wheel/install and bounded tiny actual CLI response-loss experiment. Review required."""
from contextlib import contextmanager
import base64
import csv
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile
import time
import zipfile

WORK = Path('/private/tmp/ashlar-p06-response-loss-20261011-e')
REPO = Path('/Users/erik/Projects/ashlar')
REVISION = '730a53dad8ce23849558aa89250c56a2ae1c3c59'
INVENTORY = Path('/private/tmp/ashlar-p06-response-loss-source-inventory-e.json')
CLOSURE = Path('/private/tmp/ashlar-p06-response-loss-closure-e.json')
CLOSURE_SHA = '0a6fe975910b9671beb8ad14255b9ca3a466a95ed4f8609368bfa169b579b71c'
BUILD_PYTHON = '/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
BASE_PYTHON = '/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
SDK = Path('/private/tmp/ashlar-duckdb-sdk-20261010-c')
ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC',
    'PYTHONDONTWRITEBYTECODE': '1', 'PIP_CONFIG_FILE': '/dev/null',
    'PIP_DISABLE_PIP_VERSION_CHECK': '1', 'PIP_NO_CACHE_DIR': '1',
    'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_SYSTEM': '/dev/null',
    'GIT_TERMINAL_PROMPT': '0', 'GIT_ALLOW_PROTOCOL': 'file'}


def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
def select(primary, closing):
    if primary is None or isinstance(primary, Exception) and not isinstance(closing, Exception): return closing
    return primary


@contextmanager
def owned(manager):
    primary = None
    try:
        with manager as value:
            try: yield value
            except BaseException as error: primary = error; raise
    except BaseException as error:
        raise select(primary, error)
    if primary is not None: raise primary


def write(path, raw):
    with owned(path.open('xb')) as stream:
        if stream.write(raw) != len(raw): raise ValueError('Incomplete owned retention')
        stream.flush(); os.fsync(stream.fileno())


def read(path, maximum):
    if path.is_symlink() or not path.is_file() or path.stat().st_size > maximum: raise ValueError('Selected regular file bound')
    with owned(path.open('rb')) as stream: raw = stream.read(maximum + 1)
    if len(raw) > maximum: raise ValueError('Selected file bound')
    return raw


def safe(name):
    path = PurePosixPath(name)
    if not name or path.is_absolute() or '\\' in name or any(p in ('', '.', '..') for p in name.split('/')): raise ValueError('Closed member path')


def verify():
    phase_deadline=min(WHOLE_DEADLINE,time.monotonic()+45)
    raw = read(CLOSURE, 16777216)
    if sha(raw) != CLOSURE_SHA: raise ValueError('Selected existing closure changed')
    plan = json.loads(raw)
    for path in plan['absent_startup_paths']:
        if Path(path).exists() or Path(path).is_symlink(): raise ValueError('Startup selection changed')
    actual_links = [{'path': str(p), 'target': os.readlink(p), 'resolved': str(p.resolve())}
        for root in plan['roots'] for p in sorted(Path(root).rglob('*')) if p.is_symlink()]
    external = Path('/usr/local/bin/docker')
    if not external.is_symlink():raise ValueError('Explicit Docker alias disappeared')
    actual_links.append({'path':str(external),'target':os.readlink(external),'resolved':str(external.resolve(strict=True))})
    if len({row['path']for row in actual_links})!=13 or sorted(actual_links,key=lambda row:row['path']) != sorted(plan['symlinks'],key=lambda row:row['path']):raise ValueError('Whole selected namespace links changed')
    for root in plan['roots']:
        actual = {str(p.resolve()) for p in Path(root).rglob('*') if p.is_file()}
        expected = set(plan['root_files'][root])
        if actual != expected: raise ValueError('Whole selected dependency membership changed')
    if len(plan['files']) != 13006 or sum(r['bytes'] for r in plan['files'].values()) > 838860800: raise ValueError('Closed preparation custody bounds')
    for path, pin in plan['files'].items():
        if time.monotonic()>phase_deadline:raise TimeoutError('Finite closure phase')
        p = Path(path)
        if p.is_symlink() or not p.is_file() or p.stat().st_size != pin['bytes']: raise ValueError('Original custody shape changed')
        digest = hashlib.sha256()
        with owned(p.open('rb')) as stream:
            count=0
            for block in iter(lambda: stream.read(262144), b''):
                count+=len(block)
                if count>pin['bytes']or time.monotonic()>phase_deadline:raise TimeoutError('Finite closure bytes/time')
                digest.update(block)
            if count!=pin['bytes']:raise ValueError('Complete selected closure required')
        if digest.hexdigest() != pin['sha256']: raise ValueError('Original selected byte custody changed')


def main():
    started=time.monotonic()
    verify()
    if WORK.exists() or WORK.is_symlink(): raise ValueError('Fresh exclusive preparation required')
    WORK.mkdir(mode=0o700); (WORK / 'tmp').mkdir(mode=0o700); ENV['TMPDIR'] = str(WORK / 'tmp')
    spec = importlib.util.spec_from_file_location('owned_capture', '/private/tmp/ashlar-count-star-installed-cli-capture-a.py')
    capture = importlib.util.module_from_spec(spec); spec.loader.exec_module(capture)
    deadline = WHOLE_DEADLINE; phases = []
    def run(label, argv, limit=60, maximum=4194304):
        remaining = deadline - time.monotonic() - 45
        if remaining < 1: raise ValueError('Preparation deadline')
        stdout = WORK / (label + '.stdout'); stderr = WORK / (label + '.stderr')
        result = capture.capture(argv, str(WORK), ENV, str(stdout), str(stderr), min(limit, int(remaining)), maximum, None)
        record = {'phase': label, **result, 'stdoutSha256': sha(read(stdout, maximum)), 'stderrSha256': sha(read(stderr, maximum))}
        phases.append(record); write(WORK / (label + '.json'), encoded(record))
        if result['exitCode'] != 0: raise ValueError('Owned preparation phase refused: ' + label)
        return read(stdout, maximum)
    inventory = json.loads(read(INVENTORY, 1048576)); rows = {r['path']: r for r in inventory['files']}
    if inventory['revision'] != REVISION: raise ValueError('Exact immutable source revision required')
    run('archive', ['/usr/bin/git', '-c', 'core.hooksPath=/dev/null', '-c', 'tar.umask=0002', '-C', str(REPO), 'archive', '--format=tar', REVISION, 'src', 'pyproject.toml', 'README.md'], maximum=4194304)
    source = WORK / 'source'; source.mkdir(); seen = set(); decoded = 0
    with owned(tarfile.open(WORK / 'archive.stdout', 'r:')) as archive:
        members = archive.getmembers()
        if len(members) > 512: raise ValueError('Bounded source inventory required')
        names = set()
        for member in members:
            name = member.name.rstrip('/') if member.isdir() else member.name; safe(name)
            if name in names: raise ValueError('Duplicate source member')
            names.add(name)
            if member.isdir():
                if not any(p.startswith(name + '/') for p in rows): raise ValueError('Unselected source directory')
                continue
            if not member.isfile() or name not in rows: raise ValueError('Unselected source member')
            pin = rows[name]; decoded += member.size
            if decoded > 8388608 or member.size != pin['bytes']: raise ValueError('Bounded source decoded bytes')
            with owned(archive.extractfile(member)) as stream: raw = stream.read(member.size + 1)
            if len(raw) != pin['bytes'] or sha(raw) != pin['sha256'] or member.mode & 0o777 != (0o775 if pin['gitMode'] == '100755' else 0o664): raise ValueError('Immutable source byte/mode mismatch')
            target = source / name; target.parent.mkdir(parents=True, exist_ok=True); write(target, raw)
            target.chmod(0o755 if pin['gitMode'] == '100755' else 0o644); seen.add(name)
    if seen != set(rows): raise ValueError('Whole immutable source required')
    (WORK / 'wheels').mkdir()
    run('wheel', [BUILD_PYTHON, '-B', '-I', '-m', 'pip', 'wheel', '--no-deps', '--no-build-isolation', '--no-index', '--wheel-dir', str(WORK / 'wheels'), str(source)])
    wheels = list((WORK / 'wheels').iterdir())
    if len(wheels) != 1 or wheels[0].suffix != '.whl': raise ValueError('Exactly one fresh wheel required')
    wheel = wheels[0]; read(wheel, 8388608)
    expected = {name[4:]: pin for name, pin in rows.items() if name.startswith('src/') and name != 'src/ashlar/README.md'}
    payload = {}; metadata = {}; total = 0
    with owned(zipfile.ZipFile(wheel)) as archive:
        infos = archive.infolist()
        if len(infos) > 512: raise ValueError('Wheel member bound')
        for info in infos:
            name = info.filename; safe(name); mode = info.external_attr >> 16; total += info.file_size
            if name in payload or name in metadata or info.flag_bits & 1 or info.is_dir() or stat.S_IFMT(mode) not in (0, stat.S_IFREG) or total > 16777216: raise ValueError('Closed bounded wheel shape')
            raw = archive.read(info)
            if name in expected:
                pin = expected[name]
                if len(raw) != pin['bytes'] or sha(raw) != pin['sha256']: raise ValueError('Wheel original source correspondence')
                payload[name] = raw
            elif name.startswith('ashlar_graph_toolkit-0.1.0.dev0.dist-info/') and name.rsplit('/', 1)[1] in ('METADATA', 'WHEEL', 'entry_points.txt', 'top_level.txt', 'RECORD'): metadata[name] = raw
            else: raise ValueError('Unselected wheel member')
    if set(payload) != set(expected) or len(metadata) != 5 or metadata['ashlar_graph_toolkit-0.1.0.dev0.dist-info/entry_points.txt'] != b'[console_scripts]\nashlar = ashlar.cli:main\n': raise ValueError('Complete actual installed entrypoint required')
    write(WORK / 'wheel-inventory.json', encoded({'wheel': wheel.name, 'bytes': wheel.stat().st_size, 'sha256': sha(read(wheel, 8388608)), 'members': [{'path': name, 'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted({**payload, **metadata}.items())]}))
    run('venv', [BASE_PYTHON, '-B', '-I', '-m', 'venv', '--copies', '--without-pip', str(WORK / 'venv')], limit=30)
    venv = WORK / 'venv'; python = venv / 'bin/python'; site = venv / 'lib/python3.12/site-packages'
    for name in ('python', 'python3', 'python3.12'):
        if sha(read(venv / 'bin' / name, 67108864)) != sha(read(Path(BASE_PYTHON), 67108864)): raise ValueError('Exact copied interpreter required')
    if 'include-system-site-packages = false' not in read(venv / 'pyvenv.cfg', 16384).decode(): raise ValueError('Separate runtime required')
    run('install', [BUILD_PYTHON, '-B', '-I', '-m', 'pip', '--python', str(python), 'install', '--no-deps', '--no-index', '--no-compile', str(wheel)])
    write(site / 'selected-sdk.pth', (str(SDK) + '\n').encode())
    console = read(venv / 'bin/ashlar', 65536)
    if not console.startswith(('#!' + str(python) + '\n').encode()) or b'from ashlar.cli import main\n' not in console: raise ValueError('Actual installed console required')
    write(WORK / 'installed-console.txt', console)
    records = read(site / 'ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD', 131072); write(WORK / 'installed-RECORD.csv', records)
    entries = list(csv.reader(io.StringIO(records.decode()))); names = set()
    if len(entries) > 512: raise ValueError('Installed RECORD bound')
    for entry in entries:
        if len(entry) != 3 or entry[0] in names: raise ValueError('Closed RECORD shape')
        name, digest, size = entry; names.add(name)
        if name != '../../../bin/ashlar': safe(name)
        path = site / name
        if not path.resolve().is_relative_to(venv): raise ValueError('RECORD path escapes selected installation')
        raw = read(path, 8388608)
        if name.endswith('.dist-info/RECORD'):
            if digest or size: raise ValueError('Closed self RECORD')
        elif digest != 'sha256=' + base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).rstrip(b'=').decode() or size != str(len(raw)): raise ValueError('Complete installed RECORD bytes required')
    if not set(payload).issubset(names) or '../../../bin/ashlar' not in names: raise ValueError('Whole installed payload/console required')
    for name, raw in payload.items():
        if read(site / name, 8388608) != raw: raise ValueError('Installed source differs from immutable Git bytes')
    for name, raw in metadata.items():
        if not name.endswith('/RECORD') and read(site / name, 8388608) != raw: raise ValueError('Installed metadata differs')
    def generated():
        result = {}; total = 0
        for root in (source, WORK / 'wheels', venv):
            for path in sorted(root.rglob('*')):
                if path.is_symlink() or path.suffix == '.pyc' or '__pycache__' in path.parts: raise ValueError('Fresh generated namespace must contain no links/cache')
                if path.is_file():
                    raw = read(path, 67108864); total += len(raw)
                    if total > 134217728 or len(result) > 1024: raise ValueError('Generated closure bound')
                    result[str(path)] = {'bytes': len(raw), 'sha256': sha(raw)}
        return result
    before = generated(); write(WORK / 'generated-custody.json', encoded(before))
    primary=None;native_env=dict(ENV)
    native_env.update({'PATH':'/usr/local/bin:/usr/bin:/bin','PYTHONPATH':str(site)+':/private/tmp/ashlar-p06-neo4j-private-a/site:/private/tmp/ashlar-gremlin-python','DOCKER_HOST':'unix:///Users/erik/.orbstack/run/docker.sock'})
    try:
        remaining=int(deadline-time.monotonic()-45)
        if remaining<1:raise TimeoutError('Whole deadline before native child')
        outcome=capture.capture([str(python),'-B','-S','/private/tmp/ashlar-p06-response-loss-native-probe-e.py'],str(WORK),native_env,str(WORK/'native.stdout'),str(WORK/'native.stderr'),min(180,remaining),4194304,None)
        write(WORK/'native-process.json',encoded(outcome))
        if outcome['exitCode']:raise ValueError('Actual installed response-loss workflow refused')
    except BaseException as error:primary=error
    def collect(callback):
        nonlocal primary
        try:callback()
        except BaseException as error:primary=select(primary,error)
    def installed_closing():
        if generated()!=before:raise ValueError('Generated source/wheel/installation changed')
        for name,pin in rows.items():
            if sha(read(source/name,8388608))!=pin['sha256']:raise ValueError('Closing immutable source correspondence')
        if read(site/'ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD',131072)!=records or read(venv/'bin/ashlar',65536)!=console:raise ValueError('Closing installed RECORD/console changed')
    def cleanup():
        launch=WORK/'native/launched-id.txt'
        if not launch.exists():return
        cid=read(launch,128).decode().strip()
        if len(cid)!=64 or any(c not in '0123456789abcdef'for c in cid):raise ValueError('Exact positive owned launch required')
        def docker(label,argv):
            result=capture.capture(['/usr/local/bin/docker',*argv],str(WORK),native_env,str(WORK/(label+'.stdout')),str(WORK/(label+'.stderr')),15,1048576,None)
            if result['exitCode']:raise ValueError('Cleanup refused:'+label)
            return read(WORK/(label+'.stdout'),1048576)
        if docker('cleanup-list',['ps','-aq','--filter','id='+cid]).strip():
            found=json.loads(docker('cleanup-inspect',['inspect','--format','[{{json .Id}},{{json .Name}},{{json .Image}},{{json (index .Config.Labels "ashlar.refresh.fixture")}}]',cid]))
            if found!=[cid,'/ashlar-p06-response-loss-20261011-e','sha256:6d016d5a7e3eab0a57bd4d23c4e218467d00c7661fcda215ea2a429941a68cee','20261011-response-loss-e']:raise ValueError('Foreign cleanup refused')
            docker('cleanup-remove',['rm','-f',cid])
    collect(cleanup);collect(installed_closing)
    if primary is not None:raise primary
    summary=json.loads(read(WORK/'native/summary.json',4194304))
    if summary['freshProcessRecovery']is not True or summary['recoveryPOSTs']!=0 or summary['replayPOSTs']!=0 or summary['oldR1StableAfterR2']is not True:raise ValueError('Whole exact recovery required')
    write(WORK/'preparation.json',encoded({'revision':REVISION,'phases':phases,'summary':summary,'scope':'Fresh installed tiny R1/R2 complete-POST reply-loss/recovery; private fixture only, no production switching/native-generation/ACK claims.'}))


WHOLE_DEADLINE=time.monotonic()+300
primary = None; closing = False
try: main()
except BaseException as error: primary = error
try: verify(); closing = True
except BaseException as error: primary = select(primary, error)
def launched_evidence():
    path=WORK/'native/launched-id.txt'
    if not path.exists():return False
    value=read(path,128).decode().strip()
    if len(value)!=64 or any(c not in '0123456789abcdef'for c in value):raise ValueError('Malformed retained positive launch record')
    return True

launched=False
try:launched=launched_evidence()
except BaseException as error:primary=select(primary,error)
receipt = {'format': 'ashlar-public-puppy-response-loss/0.1', 'revision': REVISION,
    'failureType': type(primary).__name__ if primary is not None else None, 'openingClosingCustody': closing,
    'producerReexecuted': False, 'graphEngineExecuted': launched, 'executionEvidence': 'Exact positive returned launch ID retained' if launched else 'No positive launch record retained'}
try: write(WORK/'runner-receipt.json', encoded(receipt))
except BaseException as error: primary = select(primary, error)
if primary is not None: raise primary
