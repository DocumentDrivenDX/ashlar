"""Preparation-only one-shot loopback transport; bytes do not grant authority."""
import hashlib,json,os,socket,http.client,threading,sys,time
from pathlib import Path
from http.server import BaseHTTPRequestHandler,HTTPServer
from contextlib import contextmanager
MAXIMUM=1024*1024
PATH='/schema?postUploadBehavior=none'
def select(primary,closing):
    if primary is None or isinstance(primary,Exception) and not isinstance(closing,Exception):return closing
    return primary
@contextmanager
def owned(value,close):
    primary=None
    try:yield value
    except BaseException as e:primary=e
    try:close()
    except BaseException as e:primary=select(primary,e)
    if primary is not None:raise primary

class EvidenceDirectory:
    def __init__(self,path):
        if type(path)is not type(Path('/'))or not path.is_absolute()or path.resolve()!=path:raise ValueError('Canonical private evidence directory')
        self.path=path;self.parent_identity=self.identity(path.parent.stat())
        self.fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        try:
            st=os.fstat(self.fd)
            if st.st_mode&0o777!=0o700 or st.st_uid!=os.getuid():raise ValueError('Private evidence directory')
            self.root_identity=self.identity(st);self.renew()
        except BaseException as primary:
            fd=self.fd;self.fd=None
            try:os.close(fd)
            except BaseException as e:primary=select(primary,e)
            raise primary
    @staticmethod
    def identity(st):return (st.st_dev,st.st_ino)
    def renew(self):
        if self.fd is None or self.path.resolve()!=self.path or self.identity(self.path.parent.stat())!=self.parent_identity:raise ValueError('Evidence parent drift')
        st=self.path.lstat();held=os.fstat(self.fd)
        if self.identity(st)!=self.root_identity or self.identity(held)!=self.root_identity or st.st_mode&0o777!=0o700 or st.st_uid!=os.getuid():raise ValueError('Evidence root drift')
    def close(self):
        fd=self.fd;self.fd=None
        if fd is not None:os.close(fd)

def retain(directory,name,body):
    if type(directory)is not EvidenceDirectory:raise ValueError('Owned evidence directory required')
    if type(body)is not bytes or len(body)>MAXIMUM:raise ValueError('Bounded original bytes required')
    if type(name)is not str or '/'in name or name in ('','.', '..'):raise ValueError('Closed evidence filename')
    directory.renew()
    fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=directory.fd)
    with owned(fd,lambda:os.close(fd)):
        offset=0
        while offset<len(body):
            n=os.write(fd,body[offset:])
            if n<=0:raise ValueError('Complete retention required')
            offset+=n
        os.fsync(fd)
    os.fsync(directory.fd);directory.renew()

def make_server(directory,*,port,expected_request_sha256,expected_authorization,upstream_port):
    if type(directory)is not type(Path('/'))or not directory.is_absolute()or directory.is_symlink():raise ValueError('Explicit private directory')
    st=directory.stat()
    if not directory.is_dir()or st.st_mode&0o777!=0o700 or st.st_uid!=os.getuid():raise ValueError('Private evidence directory')
    if any(type(p)is not int or not 1024<=p<=65535 for p in (port,upstream_port)):raise ValueError('Explicit loopback ports')
    if type(expected_request_sha256)is not str or len(expected_request_sha256)!=64 or any(c not in '0123456789abcdef'for c in expected_request_sha256):raise ValueError('Exact selected request')
    if type(expected_authorization)is not str or not expected_authorization or len(expected_authorization)>4096 or any(c in expected_authorization for c in '\r\n'):raise ValueError('Explicit authorization')
    class Server(HTTPServer):
        def get_request(self):
            connection,address=super().get_request();connection.settimeout(15);self.active_connection=connection;return connection,address
        def handle_error(self,request,client_address):self.failure=select(self.failure,sys.exception() if hasattr(sys,'exception') else sys.exc_info()[1])
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_POST(self):
            primary=None;terminal={'requestRetained':False,'upstreamTerminalRetained':False,'replyDelivered':False}
            try:
                if self.server.used:raise ValueError('One attempt only')
                self.server.used=True;self.connection.settimeout(15)
                if self.path!=PATH or self.headers.get_all('Authorization')!=[expected_authorization]:raise ValueError('Original route/auth only')
                lengths=self.headers.get_all('Content-Length')
                if lengths is None or len(lengths)!=1:raise ValueError('Single length required')
                length=lengths[0]
                if len(length)>7 or not length.isascii()or not length.isdecimal()or not 0<int(length)<=MAXIMUM or self.headers.get('Transfer-Encoding')is not None:raise ValueError('Bounded body')
                parts=[];remaining=int(length);deadline=time.monotonic()+15
                while remaining:
                    left=deadline-time.monotonic()
                    if left<=0:raise TimeoutError('Request deadline')
                    self.connection.settimeout(left)
                    part=self.rfile.read1(min(remaining,65536))
                    if not part:break
                    parts.append(part);remaining-=len(part)
                body=b''.join(parts)
                if len(body)!=int(length)or hashlib.sha256(body).hexdigest()!=expected_request_sha256:raise ValueError('Original request changed')
                retain(evidence,'forwarded-request.bin',body);terminal['requestRetained']=True
                upstream=http.client.HTTPConnection('127.0.0.1',upstream_port,timeout=15);self.server.active_upstream=upstream
                with owned(upstream,upstream.close):
                    upstream.request('POST',PATH,body,{'Authorization':expected_authorization,'Content-Type':'application/json'})
                    response=upstream.getresponse()
                    with owned(response,response.close):
                        lengths=response.headers.get_all('Content-Length')
                        framed=lengths is not None and len(lengths)==1 and len(lengths[0])<=7 and lengths[0].isascii() and lengths[0].isdecimal() and int(lengths[0])<=MAXIMUM and response.headers.get('Transfer-Encoding')is None
                        expected=int(lengths[0]) if framed else None
                        parts=[];count=0;deadline=time.monotonic()+15;response_primary=None
                        try:
                            while True:
                                if time.monotonic()>=deadline:raise TimeoutError('Response deadline')
                                part=response.read1(min(65536,MAXIMUM+1-count))
                                if not part:break
                                parts.append(part);count+=len(part)
                                if count>MAXIMUM:raise ValueError('Upstream response bound')
                            if not framed or count!=expected:raise ValueError('Complete single-length response required')
                        except BaseException as e:response_primary=e
                        raw=b''.join(parts)[:MAXIMUM]
                        try:
                            retain(evidence,'upstream-response.bin',raw)
                            retain(evidence,'upstream-response.json',json.dumps({'status':response.status,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'requestSha256':expected_request_sha256,'expectedBytes':expected,'complete':response_primary is None},separators=(',',':')).encode())
                        except BaseException as e:response_primary=select(response_primary,e)
                        if response_primary is not None:raise response_primary
                        terminal['upstreamTerminalRetained']=True
            except BaseException as e:primary=e;terminal['failureType']=type(e).__name__
            finally:
                self.close_connection=True
                try:self.connection.shutdown(socket.SHUT_RDWR)
                except OSError:pass
                except BaseException as e:primary=select(primary,e)
                try:self.connection.close()
                except BaseException as e:primary=select(primary,e)
                try:retain(evidence,'terminal.json',json.dumps(terminal,separators=(',',':')).encode())
                except BaseException as e:primary=select(primary,e)
            if primary is not None:
                self.server.failure=select(self.server.failure,primary);raise primary
    evidence=EvidenceDirectory(directory)
    try:server=Server(('127.0.0.1',port),Handler)
    except BaseException as primary:
        try:evidence.close()
        except BaseException as e:primary=select(primary,e)
        raise primary
    server.evidence=evidence;server.used=False;server.failure=None;server.active_connection=None;server.active_upstream=None;server.timeout=15
    return server

@contextmanager
def one_shot(server):
    if not isinstance(server,HTTPServer):raise ValueError('Owned HTTP server required')
    def run():
        try:server.handle_request()
        except BaseException as e:server.failure=select(server.failure,e)
    thread=threading.Thread(target=run,name='owned-response-loss',daemon=False);primary=None
    def expire():
        server.failure=select(server.failure,TimeoutError('One-shot wall deadline'))
        sockets=[server.active_connection]
        if server.active_upstream is not None:sockets.append(server.active_upstream.sock)
        for connection in sockets:
            if connection is not None:
                try:connection.shutdown(socket.SHUT_RDWR)
                except OSError:pass
    timer=threading.Timer(45,expire)
    try:timer.start();thread.start();yield server
    except BaseException as e:primary=e
    finally:
        # Cleanup attempts are independent: interruption of the first wait cannot
        # leave a live writer holding a descriptor that we then close beneath it.
        try:thread.join(45)
        except BaseException as e:primary=select(primary,e)
        if thread.is_alive():
            for connection in [server.active_connection,server.active_upstream.sock if server.active_upstream is not None else None]:
                if connection is not None:
                    try:connection.shutdown(socket.SHUT_RDWR)
                    except OSError:pass
                    except BaseException as e:primary=select(primary,e)
        try:thread.join(15)
        except BaseException as e:primary=select(primary,e)
        try:timer.cancel()
        except BaseException as e:primary=select(primary,e)
        try:timer.join(1)
        except BaseException as e:primary=select(primary,e)
        try:server.server_close()
        except BaseException as e:primary=select(primary,e)
        if timer.is_alive():primary=select(primary,TimeoutError('Owned watchdog remains live'))
        if server.failure is not None:primary=select(primary,server.failure)
        if thread.is_alive():
            server.cleanup_complete=False
            primary=select(primary,TimeoutError('Owned handler remains live; evidence descriptor retained'))
        else:
            server.cleanup_complete=not timer.is_alive()
            try:server.evidence.renew()
            except BaseException as e:primary=select(primary,e)
            try:server.evidence.close()
            except BaseException as e:primary=select(primary,e)
    if primary is not None:raise primary
