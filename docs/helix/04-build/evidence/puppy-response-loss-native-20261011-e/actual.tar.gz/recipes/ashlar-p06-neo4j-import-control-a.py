from pathlib import Path
import sys,json,hashlib,importlib.metadata
site=Path('/private/tmp/ashlar-p06-neo4j-private-a/site')
sys.path[:0]=[str(site),'/private/tmp/ashlar-gremlin-python']
from neo4j import GraphDatabase,Query
from gremlin_python.driver import client,serializer
from gremlin_python import statics
import neo4j,pytz
assert neo4j.__version__=='5.28.2'and neo4j.__file__==str(site/'neo4j/__init__.py')
assert importlib.metadata.version('neo4j')=='5.28.2'
assert callable(GraphDatabase.driver)and Query('RETURN 1',timeout=1).text=='RETURN 1'
assert statics.long(9007199254740993)==9007199254740993
imports={}
for name,module in sorted(sys.modules.items()):
 path=getattr(module,'__file__',None)
 if path and Path(path).is_file():
  p=Path(path);raw=p.read_bytes();imports[name]={'path':str(p),'resolved':str(p.resolve()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
record={'neo4j':neo4j.__version__,'pytz':pytz.__version__,'gremlinpython':importlib.metadata.version('gremlinpython'),'python':sys.version,'sys_executable':sys.executable,'sys_path':sys.path,'imports':imports,'scope':'Actual import and pure constructor/type check only; no driver/client instance, network, engine or shared modification'}
root=site.parent;(root/'import-control.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps({'versions':[record[x]for x in ['neo4j','pytz','gremlinpython']],'importedFiles':len(imports)}))
