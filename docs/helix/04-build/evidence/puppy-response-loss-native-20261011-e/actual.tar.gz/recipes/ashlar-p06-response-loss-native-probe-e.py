"""Bounded real local PuppyGraph refresh; invoked only after recipe review."""
import base64, hashlib, json, subprocess, time, urllib.request, urllib.error
from pathlib import Path
from contextlib import contextmanager
from neo4j import GraphDatabase, Query
from gremlin_python.driver import client as gremlin_client, serializer
from ashlar_host.puppy_gremlin import GremlinReleaseProjection
from ashlar.graph_release import GraphRelease
from ashlar_host.lifecycle import finish, owned_context
from ashlar_host.puppy_release import PuppyReleaseHandle, PuppyReleaseOwner
from ashlar_host.puppy_native import PuppyNativeReleaseAdapter, encoded, decode, original_model, admit_original_subset

ROOT = Path('/private/tmp/ashlar-p06-response-loss-20261011-e/native')
INSTALLED=ROOT.parent
WORK=ROOT.parent
REPO = Path('/Users/erik/Projects/ashlar')
PROXY_PATH='/private/tmp/ashlar-p06-response-loss-proxy-e.py'
CARRIERS = Path('/private/var/folders/z0/kv_wlyps77b_txh08w55z99w0000gn/T/ashlar-puppy-carrier-short-i82hlx9p')
NAME = 'ashlar-p06-response-loss-20261011-e'
IMAGE = 'sha256:6d016d5a7e3eab0a57bd4d23c4e218467d00c7661fcda215ea2a429941a68cee'
DIGESTS = ['ca4b40f78b1a27e3d6df50eb17816ec49e30f0f70d6ff7dabc195307c07642e7', 'a6a4cb268f6bb3f8d193b35289d5b593ad08e33d8fc561e29487919fd1502e3a']
# Deliberately supplied credentials for this new isolated local fixture only.
VERSION_EVIDENCE=Path('/private/tmp/ashlar-p06-response-loss-qualified-version-e.json')
VERSION_EVIDENCE_SHA='130c0d5d2af7d3da0f26d318881db74e7800db93deeb71017576916727867f17'
def selected_version():
    body=VERSION_EVIDENCE.read_bytes()
    if hashlib.sha256(body).hexdigest()!=VERSION_EVIDENCE_SHA:raise ValueError('Selected qualified version evidence changed')
    evidence=json.loads(body)
    if evidence['image']!='sha256:6d016d5a7e3eab0a57bd4d23c4e218467d00c7661fcda215ea2a429941a68cee' or evidence['version']!='1.13.0':raise ValueError('Selected version correspondence')
    return evidence['version']
USER, PASSWORD = 'ashlarfixture', 'ashlar-local-refresh-fixture'
def docker(*args):
    return subprocess.check_output(['/usr/local/bin/docker', *args], timeout=20).decode().strip()
def main():
    ROOT.mkdir(mode=0o700, exist_ok=False)
    body_deadline=time.monotonic()+160
    prepared, handles = {}, []
    for digest in DIGESTS:
        directory = CARRIERS / digest
        receipt = directory / 'receipt.json'
        info = json.loads(receipt.read_bytes())
        prepared[digest] = (str(directory/info['database_name']), str(directory/'model.json'), str(receipt), hashlib.sha256(receipt.read_bytes()).hexdigest())
        raw = (REPO/'docs/helix/04-build/evidence/puppygraph-releases-20261009'/ (digest+'.graph.json')).read_bytes()
        handles.append(PuppyReleaseHandle(GraphRelease(raw, digest)))
    records, mode, posts = [], None, []
    rejected = ValueError("Actual native rejected control")
    interrupted = KeyboardInterrupt("Controlled cancellation after actual partial native POST")
    def raw_http(path, data):
        headers = {'Authorization':'Basic '+base64.b64encode((USER+':'+PASSWORD).encode()).decode()}
        if data is not None: headers['Content-Type'] = 'application/json'
        request = urllib.request.Request('http://127.0.0.1:18883'+path, data=data, headers=headers)
        try:
            with owned_context(urllib.request.urlopen(request, timeout=15)) as response:
                status, raw = response.status, response.read(1024*1024+1)
        except urllib.error.HTTPError as error:
            with owned_context(error): status, raw = error.code, error.read(1024*1024+1)
        except BaseException as error:
            records.append({'path':path,'request':None if data is None else data.decode(),'requestSHA256':None if data is None else hashlib.sha256(data).hexdigest(),'status':'unknown','response':None,'exception':type(error).__name__+':'+str(error)})
            raise
        if len(raw)>1024*1024: raise ValueError('HTTP response cap')
        records.append({'path':path,'request':None if data is None else data.decode(),'status':status,'response':raw.decode()})
        return status, raw
    def runtime(context):
        actual = docker('inspect','--format','{{.Id}} {{.Image}} {{.State.Running}}', NAME)
        if actual != container+' '+IMAGE+' true': raise ValueError('Native instance changed')
        return container, selected_version()
    container = ''
    client = None
    remote = None
    primary = None
    try:
        if docker('ps','-aq','--filter','name=^/'+NAME+'$'): raise ValueError('Owned name already exists')
        args = ['run','-d','--pull=never','--name',NAME,'--label','ashlar.refresh.fixture=20261011-response-loss-e','--cpus','2','--memory','3g','-p','127.0.0.1:18883:8081','-p','127.0.0.1:17690:7687','-p','127.0.0.1:18182:8182','-e','PUPPYGRAPH_USERNAME='+USER,'-e','PUPPYGRAPH_PASSWORD='+PASSWORD]
        for digest, files in prepared.items(): args += ['--mount','type=bind,source='+files[0]+',target=/tmp/'+Path(files[0]).name+',readonly']
        container = docker(*args, IMAGE)
        if len(container)!=64 or any(c not in '0123456789abcdef'for c in container):raise ValueError('Positive exact owned launch ID required')
        with owned_context((ROOT/'launched-id.txt').open('x')) as target:
            target.write(container+'\n');target.flush()
            import os
            os.fsync(target.fileno())
        fd=os.open(ROOT,os.O_RDONLY);directory_primary=None
        try:os.fsync(fd)
        except BaseException as error:directory_primary=error
        finish(directory_primary,[lambda:os.close(fd)])
        start=time.monotonic()
        http_attempts=0
        while True:
            http_attempts+=1
            if http_attempts>76:raise TimeoutError('Finite HTTP readiness attempts')
            try:
                status, initial = raw_http('/schemajson',None)
                if status==200: break
            except (OSError, urllib.error.URLError): pass
            if time.monotonic()-start>75: raise TimeoutError('Native readiness')
            time.sleep(1)
        initial_value=decode(initial)
        if initial_value != {} and initial_value != {'catalog': [], 'node': [], 'edge': []} and initial_value != {'node': [], 'edge': []}: raise ValueError('Fresh native unconfigured/empty shape unknown')
        client=GraphDatabase.driver('bolt://127.0.0.1:17690', auth=(USER,PASSWORD), connection_timeout=5, connection_acquisition_timeout=5, max_connection_pool_size=1)
        startup=[];protocol_attempts=0
        while True:
            protocol_attempts+=1
            if protocol_attempts>76:raise TimeoutError('Finite protocol readiness attempts')
            if time.monotonic()-start>75: raise TimeoutError('Native protocol readiness budget')
            try:
                with owned_context(client.session()) as ready_session:
                    ready=ready_session.run(Query('RETURN 1 AS ready',timeout=5)).data()
                startup.append({'query':'RETURN 1 AS ready','result':ready})
                (ROOT/'native-readiness.json').write_bytes(encoded(startup))
                if time.monotonic()-start>75: raise TimeoutError('Native protocol readiness budget')
                if ready != [{'ready':1}]: raise ValueError('Unexpected native readiness marker')
                break
            except Exception as error:
                startup.append({'query':'RETURN 1 AS ready','exception':type(error).__name__+':'+str(error)})
                (ROOT/'native-readiness.json').write_bytes(encoded(startup))
                if time.monotonic()-start>75: raise TimeoutError('Native protocol readiness budget') from error
                time.sleep(1)
        remote=gremlin_client.Client('ws://127.0.0.1:18182/gremlin','g',username=USER,password=PASSWORD,message_serializer=serializer.GraphSONSerializersV3d0())
        def submit(query,context):
            runtime(context)
            return remote.submit(query).all().result(timeout=15)
        if time.monotonic()-start>75:raise TimeoutError('Protocol readiness budget before Gremlin')
        marker=submit("g.inject('ashlar-ready')",None)
        (ROOT/'gremlin-readiness.json').write_bytes(encoded({'query':"g.inject('ashlar-ready')",'rows':marker}))
        if time.monotonic()-start>75:raise TimeoutError('Protocol readiness budget after Gremlin')
        if marker != ['ashlar-ready'] or type(marker[0]) is not str: raise ValueError('Native Gremlin protocol marker differs')
        client.close();client=None;remote.close();remote=None
        import importlib.util,os
        spec=importlib.util.spec_from_file_location('bounded_capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py')
        capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
        provider=Path('/private/tmp/ashlar-p06-response-loss-provider-e.py')
        provider_sha=hashlib.sha256(provider.read_bytes()).hexdigest()
        console=INSTALLED/'venv/bin/ashlar';results=[];prior={'catalog':[],'node':[],'edge':[]}
        def invoke(label,digest,language,selected=None,*,fault=False,resume=None,allow_failure=False):
            info={'engine':container,'image':IMAGE,'name':NAME,'prepared':prepared,'release_hashes':DIGESTS,'prior_model':prior,'language':language,'fault':fault}
            (WORK/'native-runtime.json').write_bytes(encoded(info))
            (ROOT/(label+'-operator-original.json')).write_bytes(encoded(info))
            config={'profile':'ashlar-puppy-invocation/0.1','release_path':str(REPO/'docs/helix/04-build/evidence/puppygraph-releases-20261009'/(digest+'.graph.json')),'release_sha256':digest,'output_directory':str(WORK/label)}
            command='activate-puppy-release'
            if selected is not None:
                command='read-puppy-release';config['activation_path']=selected['activation_path'];config['activation_sha256']=selected['activation_sha256']
            configuration=ROOT/(label+'-configuration.json')
            if resume is None:configuration.write_bytes(encoded(config))
            else:configuration=resume[0];command='resume-puppy-release'
            argv=[str(console),command,'--configuration',str(configuration),'--provider',str(provider),'--provider-sha256',provider_sha]
            if resume is not None:argv+=['--original-intent',str(resume[1]),'--original-intent-sha256',resume[2],'--attempt-directory',str(resume[3])]
            env={key:value for key,value in os.environ.items() if key in {'PATH','PYTHONDONTWRITEBYTECODE','PYTHONPATH','DOCKER_HOST','TMPDIR','LC_ALL','LANG'}}
            stdout=ROOT/(label+'.stdout');stderr=ROOT/(label+'.stderr')
            remaining=int(body_deadline-time.monotonic())
            if remaining<1:raise TimeoutError('Native body deadline before CLI')
            outcome=capture.capture(argv,str(WORK),env,str(stdout),str(stderr),min(75,remaining),4*1024*1024)
            (ROOT/(label+'-process.json')).write_bytes(encoded({'argv':argv,**outcome}))
            if allow_failure:
                if outcome['exitCode']!=2 or stdout.read_bytes() or stderr.read_bytes()!=b'ashlar selected PuppyGraph release refused\n':raise ValueError('Exact unknown-outcome CLI refusal required')
                return configuration,WORK/label
            if outcome['exitCode'] or stderr.read_bytes(): raise ValueError('Installed CLI failed: '+label)
            result=decode(stdout.read_bytes());raw=Path(result['activation_path']).read_bytes()
            if hashlib.sha256(raw).hexdigest()!=result['activation_sha256']:raise ValueError('Exact selected receipt output')
            observation=Path(result['observation_path']).read_bytes();results.append({'label':label,'language':language,'result':result,'observation':decode(observation)})
            return result,observation
        first,first_bytes=invoke('r1-activate-cypher',DIGESTS[0],'Cypher')
        prior=original_model(prior,decode(Path(prepared[DIGESTS[0]][1]).read_bytes()))
        _,first_gremlin=invoke('r1-read-gremlin',DIGESTS[0],'Gremlin',first)
        if first_gremlin!=first_bytes:raise ValueError('Separate process R1 language parity')
        # Independently derived exact original merged request; no native response feeds it.
        addition=decode(Path(prepared[DIGESTS[1]][1]).read_bytes())
        request=encoded(original_model(prior,addition))
        proxy_directory=ROOT/'proxy';proxy_directory.mkdir(mode=0o700)
        spec=importlib.util.spec_from_file_location('owned_proxy',PROXY_PATH)
        proxy=importlib.util.module_from_spec(spec);spec.loader.exec_module(proxy)
        authorization='Basic '+base64.b64encode((USER+':'+PASSWORD).encode()).decode()
        server=proxy.make_server(proxy_directory,port=18884,expected_request_sha256=hashlib.sha256(request).hexdigest(),expected_authorization=authorization,upstream_port=18883)
        with proxy.one_shot(server):
            original_configuration,original_output=invoke('r2-lost-reply',DIGESTS[1],'Cypher',fault=True,allow_failure=True)
        if getattr(server,'cleanup_complete',False)is not True:raise ValueError('Owned proxy handler/watchdog cleanup incomplete')
        terminal=decode((proxy_directory/'terminal.json').read_bytes())
        metadata=decode((proxy_directory/'upstream-response.json').read_bytes())
        upstream=decode((proxy_directory/'upstream-response.bin').read_bytes())
        if (terminal.get('replyDelivered')is not False or terminal.get('upstreamTerminalRetained')is not True
            or metadata['status']!=200 or metadata['complete']is not True or upstream.get('ok')is not True
            or (proxy_directory/'forwarded-request.bin').read_bytes()!=request):raise ValueError('Actual complete upstream terminal and reply loss required')
        intent=original_output/'original-intent.json';intent_bytes=intent.read_bytes()
        configuration_bytes=original_configuration.read_bytes()
        runtime_bytes=(WORK/'native-runtime.json').read_bytes()
        second,second_bytes=invoke('r2-resume',DIGESTS[1],'Cypher',fault=True,
            resume=(original_configuration,intent,hashlib.sha256(intent_bytes).hexdigest(),original_output/'attempts/attempt-00'))
        if intent.read_bytes()!=intent_bytes or original_configuration.read_bytes()!=configuration_bytes or (WORK/'native-runtime.json').read_bytes()!=runtime_bytes:raise ValueError('Original recovery inputs changed')
        resume_http=decode((original_output/'attempts/attempt-00/native-http-records.json').read_bytes())
        if any(row['request']is not None for row in resume_http):raise ValueError('Complete state recovery sent POST')
        prior=original_model(prior,addition)
        _,second_gremlin=invoke('r2-read-gremlin',DIGESTS[1],'Gremlin',second)
        _,old_cypher=invoke('r1-read-after-r2-cypher',DIGESTS[0],'Cypher',first)
        _,old_gremlin=invoke('r1-read-after-r2-gremlin',DIGESTS[0],'Gremlin',first)
        replay,replay_bytes=invoke('r2-replay-cypher',DIGESTS[1],'Cypher')
        replay_http=decode((WORK/'r2-replay-cypher/native-http-records.json').read_bytes())
        if any(row['request']is not None for row in replay_http):raise ValueError('Completed original replay sent POST')
        _,replay_gremlin=invoke('r2-replay-gremlin',DIGESTS[1],'Gremlin')
        if any(row['request']is not None for row in decode((WORK/'r2-replay-gremlin/native-http-records.json').read_bytes())):raise ValueError('Gremlin completed replay sent POST')
        if replay_gremlin!=second_bytes or second_gremlin!=second_bytes or replay_bytes!=second_bytes or old_cypher!=first_bytes or old_gremlin!=first_bytes:raise ValueError('Full original R1/R2 both-language value/identity parity')
        (ROOT/'summary.json').write_bytes(encoded({'engine':container,'image':IMAGE,'version':selected_version(),'versionQualification':'Prior qualified log bound to exact same selected image; current engine log separately retained','processes':results,
            'completeUpstreamTerminal':terminal,'freshProcessRecovery':True,'recoveryPOSTs':0,'replayPOSTs':0,
            'oldR1StableAfterR2':True,'sourceRevision':'730a53dad8ce23849558aa89250c56a2ae1c3c59',
            'scope':'Tiny explicit current retained fixture only; complete POST reply-loss/recovery/full exact native identities/endpoints; no durable latest/generation/production atomic switching/source ACK claim'}))
    except BaseException as error: primary=error
    def retain_native_logs():
        if container:
            process=subprocess.Popen(['/usr/local/bin/docker','logs','--tail','500',container],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            primary=None
            try:
                raw=process.stdout.read(1024*1024+1)
                if len(raw)>1024*1024:raise ValueError('Native log1MiB cap')
                process.wait(timeout=10)
                (ROOT/'native-engine.log').write_bytes(raw)
            except BaseException as error:primary=error
            finish(primary,[lambda:process.kill()if process.poll()is None else None,
                lambda:process.wait(timeout=5),process.stdout.close])
    def cleanup_container():
        if container:
            actual=docker('inspect','--format','{{.Id}} {{.Image}}',NAME)
            if actual != container+' '+IMAGE: raise ValueError('Refuse cleanup of changed native instance')
            docker('rm','-f',container)
    finish(primary, [lambda: client.close() if client is not None else None,
        lambda: remote.close() if remote is not None else None,lambda:(ROOT/'http-records.json').write_bytes(encoded(records)),retain_native_logs,cleanup_container])
if __name__=='__main__': main()
