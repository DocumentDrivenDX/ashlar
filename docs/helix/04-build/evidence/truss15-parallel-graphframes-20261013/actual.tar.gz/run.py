import sys,json,time,tempfile,os,hashlib
from pathlib import Path
from collections import Counter
root=Path(__file__).parent;(root/'ipc').mkdir();os.environ['TMPDIR']=str(root/'ipc');tempfile.tempdir=None
sys.path.insert(0,'/Users/erik/Projects/ashlar/src')
from ashlar_host.graphframes_export import run_graphframes_export_command
from ashlar_host.graphframes_export_setup import run_configure_graphframes_export_command
start=time.monotonic();result=None
try:
 source=Path('/private/tmp/ashlar-truss15-parallel-export-20261013-a');report=source/'export.json'
 jars=tuple('/private/tmp/ashlar-graphframes-installed-20261010-c/jars/'+name for name in ('io.graphframes_graphframes-spark3_2.12-0.12.3.jar','io.graphframes_graphframes-graphx-spark3_2.12-0.12.3.jar'))
 config=root/'graphframes.json';run_configure_graphframes_export_command(str(report),hashlib.sha256(report.read_bytes()).hexdigest(),config,jars=jars,java_home='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home')
 graph=json.loads((source/'export.json-release.json').read_bytes());edges=graph['edges'];nodes=graph['nodes'];active=edges[0]['src'];isolate=next(n['graph_id']for n in nodes if n['graph_id']!=active)
 expected=[{'src':a['src'],'edge1':a['graph_id'],'middle':a['dst'],'edge2':b['graph_id'],'dst':b['dst']}for a in edges for b in edges if a['dst']==b['src']]
 value=run_graphframes_export_command(config,root/'graphframes-result.json',maximum_hops=2)
 if (value['nodes'],value['edges'],len(value['one_hop']),len(value['two_hop']))!=(2,2,2,4):raise ValueError('Exact parallel GraphFrames occurrence counts differ')
 canonical=lambda row:json.dumps(row,sort_keys=True,separators=(',',':'))
 if Counter(map(canonical,value['two_hop']))!=Counter(map(canonical,expected)):raise ValueError('Complete original four edge-ID pair bag differs')
 degrees={r['id']:r['out_degree']for r in value['out_degrees']};counts={r['id']:(r['path_count'],r['distinct_destinations'])for r in value['two_hop_counts']}
 if degrees!={active:2,isolate:0}or counts!={active:(4,1),isolate:(0,0)}:raise ValueError('Parallel path/distinct/isolate counts differ')
 result={'outcome':'passed','duration_seconds':round(time.monotonic()-start,3),'publication_id':value['publication_id'],'nodes':2,'edges':2,'one_hop_occurrences':2,'two_hop_occurrences':4,'two_hop_distinct_destinations':1,'isolate_zero_degree_and_paths':True,'runtime':value['runtime'],'release_sha256':value['release_sha256'],'custody_sha256':value['custody_sha256'],'qualification':'Actual public GraphFrames canonical node/edge bag admission and exact two-parallel-self-edge four ordered edge-ID pair paths, onedistinctdestination and isolatedR2zero counts over immutable releasedTruss15 export. Original numericprops JSON retained as opaque STRING, no numeric filtering. No sourceaccess/mutations/ACK/ingest.'}
except BaseException as error:result={'outcome':'failed','duration_seconds':round(time.monotonic()-start,3),'error_type':type(error).__name__};raise
finally:(root/'run-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
