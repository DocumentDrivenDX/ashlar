import os,selectors,subprocess,sys,time,json,signal
from pathlib import Path
SITE='/Users/erik/Projects/ashlar/out/combined-source-current-20261017/held-singleton-32m-lru-control/runtime/lib/python3.11/site-packages'
sys.path.insert(0,SITE)
from ashlar_host.lifecycle import finish
from ashlar_host.puppy_scenario_processes import terminate_scenario_processes
LEADER="""import os,signal,subprocess,sys
fd=int(sys.argv[1])
signal.signal(signal.SIGTERM,signal.SIG_IGN)
p=subprocess.Popen(sys.argv[2:],stdin=subprocess.DEVNULL,close_fds=True)
status=p.wait()
os.close(1);os.close(2)
os.write(fd,(str(status)+'\\n').encode('ascii'));os.close(fd)
while True: signal.pause()
"""
ENV={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1'}
def capture(argv,seconds=600,cap=1048576,observer=None,ownership_observer=None,cleanup_observer=None):
    process=None;selector=None;streams=[];rd=wr=None;primary=None
    outputs=[bytearray(),bytearray(),bytearray()];cleanup=None
    try:
        rd,wr=os.pipe()
        process=subprocess.Popen([sys.executable,'-I','-B','-c',LEADER,str(wr),*argv],env=ENV,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,pass_fds=(wr,))
        streams=[process.stdout,process.stderr]
        if ownership_observer is not None:ownership_observer(process.pid)
        os.close(wr);wr=None
        control=os.fdopen(rd,'rb',buffering=0);rd=None;streams.append(control)
        selector=selectors.DefaultSelector()
        for i,s in enumerate(streams):
            os.set_blocking(s.fileno(),False);selector.register(s,selectors.EVENT_READ,i)
        end=time.monotonic()+seconds
        while selector.get_map():
            left=end-time.monotonic()
            if left<=0:raise TimeoutError('combined-source-deadline')
            for key,_ in selector.select(min(left,.1)):
                i=key.data;limit=cap if i<2 else 16
                raw=os.read(key.fileobj.fileno(),min(65536,limit-len(outputs[i])+1))
                if not raw:selector.unregister(key.fileobj);continue
                if len(outputs[i])+len(raw)>limit:raise ValueError('combined-source-capture-cap')
                outputs[i].extend(raw)
        status=bytes(outputs[2])
        if not status.endswith(b'\n') or status.count(b'\n')!=1:raise ValueError('combined-source-terminal')
        token=status[:-1]
        if not token or (token.startswith(b'-') and not token[1:].isdigit()) or (not token.startswith(b'-') and not token.isdigit()):raise ValueError('combined-source-terminal')
        result={'status':int(token),'stdout':bytes(outputs[0]),'stderr':bytes(outputs[1])}
    except BaseException as error:primary=error
    def terminate():
        nonlocal cleanup
        if process is not None:
            def grace():
                try:os.killpg(process.pid,signal.SIGTERM)
                except ProcessLookupError:return
                end=time.monotonic()+5
                while time.monotonic()<end:
                    if len(streams)<3:break
                    try:raw=os.read(streams[2].fileno(),16)
                    except BlockingIOError:time.sleep(.02);continue
                    if not raw or raw.endswith(b'\n'):break
            def force():
                nonlocal cleanup
                cleanup=terminate_scenario_processes(process,failure_observer=cleanup_observer)
            finish(None,[grace,force])
    actions=[terminate]
    if selector is not None:actions.append(selector.close)
    actions.extend(s.close for s in streams)
    for fd in (rd,wr):
        if fd is not None:actions.append(lambda fd=fd:os.close(fd))
    cleanup_errors=[]
    def tracked(action):
        def invoke():
            try:return action()
            except BaseException as error:
                cleanup_errors.append(error)
                raise
        return invoke
    actions=[tracked(action) for action in actions]
    if observer is not None:
        def observed():
            status=None
            token=bytes(outputs[2])
            if token.endswith(b'\n') and token.count(b'\n')==1:
                value=token[:-1]
                if value.isdigit() or value.startswith(b'-') and value[1:].isdigit():status=int(value)
            observer(bytes(outputs[0]),bytes(outputs[1]),{'status':status,'error_class':type(primary).__name__ if primary is not None else (type(cleanup_errors[0]).__name__ if cleanup_errors else None),'cleanup_confirmed':cleanup is not None,'cleanup_failed':bool(cleanup_errors),'complete':primary is None and not cleanup_errors and cleanup is not None})
        actions.append(observed)
    finish(primary,actions)
    result['cleanup']=cleanup
    return result
def retain(root,stdout,stderr,terminal):
    def write(name,raw):
        fd=os.open(root/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        primary=None
        try:
            offset=0
            while offset<len(raw):
                count=os.write(fd,raw[offset:])
                if type(count)is not int or count<=0:raise OSError('combined-source-capture-write')
                offset+=count
        except BaseException as error:primary=error
        finish(primary,[lambda:os.close(fd)])
    records=[('resume.stdout',stdout),('resume.stderr',stderr),('resume-terminal.json',(json.dumps(terminal,sort_keys=True)+'\n').encode())]
    finish(None,[lambda name=name,raw=raw:write(name,raw) for name,raw in records])
def write_record(path,value):
    raw=(json.dumps(value,sort_keys=True)+'\n').encode()
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    primary=None
    try:
        if os.write(fd,raw)!=len(raw):raise OSError('Bounded diagnostic write refused')
    except BaseException as error:primary=error
    finish(primary,[lambda:os.close(fd)])
if __name__=='__main__':
    os.umask(0o077)
    root=Path(__file__).parent;started=time.monotonic()
    value=capture(['/Users/erik/Projects/ashlar/out/combined-source-current-20261017/held-singleton-32m-lru-control/runtime/bin/python','-I','-B',str(root/'run-installed.py')],observer=lambda stdout,stderr,terminal:retain(root,stdout,stderr,terminal),ownership_observer=lambda pid:write_record(root/'owned-session.json',{'session_leader_pid':pid}),cleanup_observer=lambda record:write_record(root/'cleanup-failure.json',dict(record)))
    record={'status':value['status'],'cleanup':value['cleanup'],'elapsed_seconds':time.monotonic()-started}
    write_record(root/'outer-attempt.json',record);print(json.dumps(record));raise SystemExit(0 if value['status']==0 else 2)
