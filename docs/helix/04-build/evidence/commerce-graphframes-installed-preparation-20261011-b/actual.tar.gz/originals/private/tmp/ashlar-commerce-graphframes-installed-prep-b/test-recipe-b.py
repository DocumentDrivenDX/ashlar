"""Inert recipe wiring controls; no SDK imports, subprocess or native access."""
import unittest,importlib.util,sys,json,hashlib,tempfile,ast
from pathlib import Path
from unittest import mock
ROOT=Path(__file__).parent

def load(name):
 spec=importlib.util.spec_from_file_location(name.replace('-','_'),ROOT/name);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
class Tests(unittest.TestCase):
 def test_external_command_refuses_before_import(self):
  module=load('entry-b.py')
  with tempfile.TemporaryDirectory()as d:
   p=Path(d)/'command';p.write_text('{}')
   with mock.patch.object(sys,'argv',['entry','graphframes','--command',str(p),'--sha256','0'*64]),mock.patch.object(module.json,'loads',side_effect=AssertionError('parse before pin')):
    with self.assertRaises(ValueError):module.main()
 def test_exact_installed_dispatch_and_closing_drift(self):
  module=load('entry-b.py');cancel=KeyboardInterrupt('primary');seen=[]
  with tempfile.TemporaryDirectory()as d:
   p=Path(d)/'command';command={'hostSites':{'canonical':d},'sdkRoots':{'canonical':[]},'graphframesArgv':['installed','query-graphframes']};p.write_text(json.dumps(command));pin=hashlib.sha256(p.read_bytes()).hexdigest()
   import types
   fake=types.ModuleType('ashlar.cli')
   def main():seen.append(sys.argv[:]);p.write_text('{}');raise cancel
   fake.main=main
   original_path=sys.path[:]
   try:
    with mock.patch.dict(sys.modules,{'ashlar.cli':fake}),mock.patch.object(sys,'argv',['entry','graphframes','--command',str(p),'--sha256',pin]):
     with self.assertRaises(KeyboardInterrupt)as raised:module.main()
    self.assertIs(raised.exception,cancel);self.assertEqual(seen,[command['graphframesArgv']])
   finally:sys.path[:]=original_path
 def test_distinct_java_and_immutable_publication_only(self):
  c=json.loads((ROOT/'command-b.json').read_text());settings=json.loads((ROOT/'settings-b.json').read_text())
  self.assertEqual(c['queryEnvironment']['JAVA_HOME'],settings['canonical_java_home']);self.assertNotEqual(c['queryEnvironment']['JAVA_HOME'],c['workerJavaHome'])
  self.assertEqual(c['publication'],'/private/tmp/ashlar-original-commerce-native-20261011-e/publication');self.assertEqual(c['workerSeconds'],300);self.assertEqual(c['driverMiB'],512)
  tree=ast.parse((ROOT/'runner-b.py').read_text());literal=[n.value for n in ast.walk(tree)if isinstance(n,ast.Constant)and isinstance(n.value,str)]
  self.assertFalse(any(x in literal for x in ['publish-original-commerce','setup','append','docker']))
  self.assertEqual(c['graphframesArgv'][1],'query-graphframes')
 def test_primary_close_cancellation_identity(self):
  module=load('runtime-plan-b.py');cancel=KeyboardInterrupt('read')
  class Stream:
   def read(self,n):raise cancel
   def close(self):raise OSError('close')
  path=mock.Mock();path.open.return_value=Stream()
  with self.assertRaises(KeyboardInterrupt)as raised:module.read(path,10)
  self.assertIs(raised.exception,cancel)
 def test_import_proof_precedes_inventory_and_jvm(self):
  source=(ROOT/'runner-b.py').read_text();self.assertLess(source.index("phase('worker-import'"),source.index("plan=module.prepare"));self.assertLess(source.index("plan['resolution']=proof"),source.index("phase('graphframes'"))
  helper=(ROOT/'inspect-worker-b.py').read_text();self.assertIn("sys.flags.dont_write_bytecode!=1",helper);self.assertNotIn('getOrCreate',helper)
if __name__=='__main__':unittest.main()
