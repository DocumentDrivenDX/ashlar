"""Build explicit selected inventory from installed RECORDs, not a second SDK scan.

Execution is a prepared phase only. Existing hashed RECORD members keep their
original expected digests; generated/unhashed bytecode, RECORDs and stdlib are
selected separately. Runtime owner will verify all actual bytes before engine use.
"""
import base64,csv,hashlib,json,os,stat
from pathlib import Path

def select(primary,error):
    return error if primary is None or isinstance(primary,Exception) and not isinstance(error,Exception) else primary

def read(path,maximum):
    stream=path.open('rb');primary=None;raw=None
    try:
        raw=stream.read(maximum+1)
        if len(raw)>maximum:raise ValueError('Bounded original member required')
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
    return raw

def owned_file(path):
    info=path.lstat()
    if not stat.S_ISREG(info.st_mode):raise ValueError('Exact regular inventory member required')
    raw=read(path,134217728)
    return {'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw)}

def namespace(root):
    return [(str(p),'link'if p.is_symlink()else'file'if p.is_file()else'directory'if p.is_dir()else'refused',os.readlink(p)if p.is_symlink()else None)for p in sorted(root.rglob('*'))]

def prepare(revision,host_site,sdk,stdlib,python):
    groups={'pyspark':{},'delta-spark':{},'graphframes-py':{},'transitive-imports':{}}
    owners={};selectors=[]
    for record in sorted(sdk.glob('*.dist-info/RECORD')):
        name=record.parent.name
        group='pyspark'if name.startswith('pyspark-')else'delta-spark'if name.startswith('delta_spark-')else'graphframes-py'if name.startswith('graphframes_py-')else'transitive-imports'
        selectors.append(owned_file(record))
        for relative,hashed,size in csv.reader(read(record,4*1024*1024).decode().splitlines()):
            path=(sdk/relative).resolve()
            if not path.is_relative_to(sdk):continue # console scripts are not on child PATH
            if path in owners and owners[path]!=group:raise ValueError('Ambiguous SDK ownership')
            owners[path]=group
            if hashed:
                if not hashed.startswith('sha256=')or not size.isdecimal():raise ValueError('Exact recorded SHA256/size required')
                digest=base64.urlsafe_b64decode(hashed[7:]+'='*(-len(hashed[7:])%4)).hex()
                if len(digest)!=64:raise ValueError('Exact recorded digest required')
                groups[group][str(path)]={'path':str(path),'sha256':digest,'size':int(size)}
            else:
                if path!=record:raise ValueError('Unexpected unhashed selected SDK member')
                groups[group][str(path)]=owned_file(path)
    # Every currently visible file is covered, including existing bytecode and
    # unlisted importable artifacts. None are deleted or silently excluded.
    for path in sorted(sdk.rglob('*')):
        if path.is_file():
            resolved=path.resolve()
            if not resolved.is_relative_to(sdk):raise ValueError('SDK alias escapes selected root')
            if str(resolved)not in groups[owners.get(resolved,'transitive-imports')]:
                groups[owners.get(resolved,'transitive-imports')][str(resolved)]=owned_file(resolved)
        elif not path.is_dir():raise ValueError('Unsupported SDK namespace carrier')
    python_lib=stdlib.parent
    for path in sorted(python_lib.rglob('*')):
        if path.is_relative_to(stdlib/'site-packages'):continue
        if path.is_file():
            resolved=path.resolve()
            if not resolved.is_relative_to(python_lib):raise ValueError('Python runtime library alias escapes selected root')
            groups['transitive-imports'][str(resolved)]=owned_file(resolved)
        elif not path.is_dir():raise ValueError('Unsupported standard library carrier')
    worker={}
    for root in [host_site/'ashlar',host_site/'ashlar_host',*host_site.glob('ashlar_graph_toolkit-*.dist-info')]:
        for path in sorted(root.rglob('*')):
            if path.is_symlink():raise ValueError('Installed worker alias refused')
            if path.is_file():worker[str(path)]=owned_file(path)
    selectors.extend(owned_file(p)for p in (host_site/'selected-sdk.pth',python.parent.parent/'pyvenv.cfg',python))
    plan={'revision':revision,'python':str(python),'worker':sorted(worker.values(),key=lambda x:x['path']),'sdks':[(name,sorted(rows.values(),key=lambda x:x['path']))for name,rows in groups.items()],
          'selectors':selectors,'namespaces':{str(root):namespace(root)for root in (host_site,sdk,python_lib)}}
    files=plan['worker']+[f for _,rows in plan['sdks']for f in rows]
    if len(files)>8192 or sum(f['size']for f in files)>1073741824:raise ValueError('Owning complete runtime inventory capacity exceeded')
    return plan
