import pathlib,json,hashlib
r=pathlib.Path(__file__).parent
status=json.loads((r/'initialize-attempt.json').read_bytes());assert status['state']=='terminal'and status['exit_code']==0
raw=(r/'initialize.stdout').read_bytes();handoff=json.loads(raw);config=json.loads((r/'initialize.json').read_bytes())
assert handoff['installation_id']==config['installation_id']and len(handoff['targets'])==6
(r/'installation.json').write_bytes(raw)
config['profile']='ashlar-original-medical-local-publication/0.1';config['output']=str(r/'publication-output');config.pop('schemas')
config['installation']={'path':str(r/'installation.json'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
config['journal']=handoff['journal'];config['targets']=[{**t,'table':t['table'].split('.')[-1]}for t in handoff['targets']]
(r/'publish.json').write_text(json.dumps(config,indent=2)+'\n')
