import pathlib,json,subprocess,sys,uuid,hashlib
sys.path.insert(0,'/Users/erik/Projects/ashlar/tools')
from setup_private_outbox_fixture import Source,ddl,ordinary_identity,connection_operation
from ashlar_host.ack import AckScope
import psycopg
r=pathlib.Path(__file__).parent
selected=json.loads(subprocess.run(['/Users/erik/.orbstack/bin/docker','inspect','ashlar-private-outbox-medical16a'],capture_output=True,check=True,timeout=10).stdout)[0]
assert selected['Id']=='f862d55b64c078ffc4c2369ec64022b784b7a620385c9d74d75e2f99d4b73d91'and selected['State']['Running']is True
assert selected['Config']['Image']=='postgres@sha256:2a0d0fe14825b0939f78a8cad5cd4e6aa68bf94d0e5dd96e24b6d23af4315545'
assert selected['HostConfig']['Memory']==536870912 and selected['NetworkSettings']['Ports']['5432/tcp']==[{'HostIp':'127.0.0.1','HostPort':'25446'}]
facts={'container_id':selected['Id'],'image':selected['Image'],'configured_image':selected['Config']['Image'],'database':'medical16b','port':25446,'existing_container_reused':True}
(r/'source-intent.json').write_text(json.dumps(facts,indent=2)+'\n')
source=Source(AckScope('ashlar_ack_medical16b',str(uuid.uuid4()),str(uuid.uuid4()),'original-medical16b','private-original-medical-fixture','original-medical-v1'),'ashlar_medical16b_source','medical16b_writer','medical16b_reader','medical16b_ack')
def connect(role,db,autocommit=False):
 return psycopg.connect(host='127.0.0.1',hostaddr='127.0.0.1',port=25446,dbname=db,user=role,password='',passfile='/dev/null',sslmode='disable',gssencmode='disable',options='-c statement_timeout=5000 -c lock_timeout=1000',connect_timeout=2,autocommit=autocommit)
with connect('postgres','medical16a',True)as c:
 assert c.execute('SELECT current_user,current_database()').fetchone()==('postgres','medical16a')
 assert c.execute("SELECT current_setting('server_version')").fetchone()[0].startswith('17.9')
 assert c.execute('SELECT count(*) FROM pg_catalog.pg_database WHERE datname=%s',('medical16b',)).fetchone()==(0,)
 assert c.execute('SELECT count(*) FROM pg_catalog.pg_roles WHERE rolname=ANY(%s)',([source.writer,source.reader,source.ack],)).fetchone()==(0,)
 c.execute('CREATE DATABASE medical16b')
with connect('postgres','medical16b')as c:
 assert c.execute("SELECT count(*) FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname !~ '^pg_' AND n.nspname<>'information_schema'").fetchone()==(0,)
 ddls=ddl(source)
 for statement in ddls:c.execute(statement)
 scope=source.scope;prefix=scope.service_schema
 c.execute('SELECT '+prefix+'.register_source(%s::uuid,%s::name)',(scope.installation_id,source.schema))
 c.execute('SELECT '+prefix+'.register_consumer(%s::uuid,%s::uuid,%s,%s,%s)',(scope.scope_id,scope.installation_id,scope.consumer,scope.feed,scope.epoch));c.commit()
identities=[]
for role in [source.writer,source.reader,source.ack]:
 identities.append(connection_operation(connect(role,'medical16b'),lambda c:ordinary_identity(c,role,'medical16b')))
with connect(source.ack,'medical16b')as c:
 binding=c.execute('SELECT '+prefix+'.scope_binding(%s::uuid)',(scope.scope_id,)).fetchone()[0];c.rollback()
from dataclasses import asdict
result={**facts,'scope':asdict(scope),'binding':binding,'identities':identities,'ddl_sha256':[hashlib.sha256(x.encode()).hexdigest()for x in ddls],'source_schema':source.schema,'writer_role':source.writer,'reader_role':source.reader,'ack_role':source.ack,'qualification':'Fresh empty isolated development source only; no native publication or ACK progress'}
(r/'source.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'database':'medical16b','source_schema':source.schema,'installation_id':scope.installation_id}))
