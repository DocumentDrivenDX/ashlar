import ast,copy,json,hashlib
from pathlib import Path
from types import SimpleNamespace
import unittest
import sys
sys.path.insert(0,'/Users/erik/Projects/ashlar/src')
from ashlar_host.lifecycle import finish
D=Path('/private/tmp/ashlar-verification-guard-native-prep-a')
class Tests(unittest.TestCase):
 def test_fixed_observer_preserves_cancel_and_closes_iterator(self):
  tree=ast.parse((D/'probe-c.py').read_bytes());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='observed')
  primary=KeyboardInterrupt('body');events=[]
  class Cursor:
   def __iter__(self):return self
   def __next__(self):raise primary
   def close(self):events.append('close');raise OSError('closing')
  frame=SimpleNamespace(_jdf=SimpleNamespace(queryExecution=lambda:SimpleNamespace(executedPlan=lambda:SimpleNamespace(toString=lambda:'Project Filter Window'))))
  scope={'active':{'plans':[],'transferred':[]},'original':lambda *a,**k:Cursor(),'finish':finish}
  exec(compile(ast.Module(body=[node],type_ignores=[]),'<actual fixed observer>','exec'),scope)
  with self.assertRaises(KeyboardInterrupt)as caught:list(scope['observed'](frame))
  self.assertIs(caught.exception,primary);self.assertEqual(events,['close'])
 def test_actual_cleanup_restores_method_and_preserves_body_cancel(self):
  tree=ast.parse((D/'probe-c.py').read_bytes());node=copy.deepcopy(next(n for n in tree.body if isinstance(n,ast.Try)))
  node.body=[ast.Raise(exc=ast.Name(id='cancel',ctx=ast.Load()),cause=None)];ast.fix_missing_locations(node)
  primary=GeneratorExit('body');events=[];original=object();owner=SimpleNamespace(toLocalIterator='wrapper')
  def stop():events.append('stop');raise OSError('closing')
  scope={'DataFrame':owner,'original':original,'spark':SimpleNamespace(stop=stop),'primary':None,'cancel':primary,'finish':finish}
  with self.assertRaises(GeneratorExit)as caught:exec(compile(ast.Module(body=[node],type_ignores=[]),'<actual cleanup>','exec'),scope)
  self.assertIs(caught.exception,primary);self.assertIs(owner.toLocalIterator,original);self.assertEqual(events,['stop'])
 def test_actual_runner_receipt_failure_preserves_capture_cancel(self):
  tree=ast.parse((D/'runner-c.py').read_bytes());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='main')
  node=copy.deepcopy(next(n for n in main.body if isinstance(n,ast.Try)))
  node.body=[ast.Raise(exc=ast.Name(id='cancel',ctx=ast.Load()),cause=None)];ast.fix_missing_locations(node)
  primary=KeyboardInterrupt('capture');events=[]
  def renew():events.append('source')
  def namespace():events.append('runtime')
  def retain(*args):events.append('receipt');raise OSError('receipt write')
  def select(primary,closing):return primary if primary is not None else closing
  known=SimpleNamespace(verify_namespace=namespace,write=retain,enc=lambda v:b'bounded',select_failure=select)
  scope={'primary':None,'cancel':primary,'renew':renew,'known':known,'WORK':D,'result':None,'started':0,'time':SimpleNamespace(monotonic=lambda:1)}
  exec(compile(ast.Module(body=[node],type_ignores=[]),'<actual runner closing>','exec'),scope)
  self.assertIs(scope['primary'],primary);self.assertEqual(events,['source','runtime','receipt'])

 def test_actual_origin_assertions_accept_qualified_symlink_only(self):
  alias=Path('/private/tmp/ashlar-spark4-python39-bridge/pyspark/__init__.py')
  self.assertTrue(alias.parent.is_symlink());self.assertNotEqual(alias,alias.resolve())
  tree=ast.parse((D/'probe-c.py').read_bytes())
  nodes=[node for node in tree.body if isinstance(node,ast.Assert)and any(isinstance(item,ast.Name)and item.id=='pyspark'for item in ast.walk(node))]
  self.assertEqual(len(nodes),2)
  code=compile(ast.Module(body=nodes,type_ignores=[]),'<actual origin gates>','exec')
  scope={'Path':Path,'pyspark':SimpleNamespace(__version__='4.0.1',__file__=str(alias))}
  exec(code,scope)
  scope['pyspark'].__file__=str(alias.resolve())
  with self.assertRaises(AssertionError):exec(code,scope)
  scope['pyspark'].__file__=str(alias);scope['pyspark'].__version__='4.0.0'
  with self.assertRaises(AssertionError):exec(code,scope)

 def test_native_budget_and_closed_cases(self):
  tree=ast.parse((D/'runner-c.py').read_bytes());calls=[n for n in ast.walk(tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='capture']
  self.assertEqual(len(calls),1);self.assertEqual(calls[0].args[-2].value,300);self.assertEqual(calls[0].args[-1].value,1048576)
  plan=json.loads((D/'command-c.json').read_bytes());self.assertEqual(plan['wholeDeadlineSeconds'],540);self.assertEqual(plan['commands'][0]['timeoutSeconds'],510)
  probe=ast.parse((D/'probe-c.py').read_bytes());cases=[n for n in ast.walk(probe)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='run']
  self.assertEqual(len(cases),11)
  for path in D.glob('*.py'):compile(path.read_bytes(),str(path),'exec')
if __name__=='__main__':unittest.main()
