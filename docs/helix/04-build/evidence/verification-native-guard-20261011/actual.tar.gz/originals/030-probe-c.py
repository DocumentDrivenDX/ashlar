"""Tiny synthetic owning guard qualification; no Delta/PG/original-run access."""
import sys,os,json,hashlib
from pathlib import Path
from datetime import datetime
from decimal import Decimal
ROOT=Path('/private/tmp/ashlar-verification-guard-native-prep-a/source')
sys.path[:0]=[str(ROOT/'src'),'/private/tmp/ashlar-spark4-python39-bridge']
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.classic.dataframe import DataFrame
from pyspark.sql.types import StructType,StructField,StringType,LongType,TimestampType,DecimalType,MapType,ArrayType
from ashlar_host.delta_custody import LocalDeltaTransport,LocalDeltaError,DeltaTarget
from ashlar_host.evolution_verification_types import VerificationBounds
from ashlar_host.lifecycle import finish
assert sys.version_info[:2]==(3,9)
assert os.environ['JAVA_HOME']=='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home'
assert pyspark.__version__=='4.0.1' and Path(pyspark.__file__)==Path('/private/tmp/ashlar-spark4-python39-bridge/pyspark/__init__.py')
assert Path(pyspark.__file__).resolve()==Path('/private/tmp/ashlar-spark4-python39-bridge/pyspark/__init__.py').resolve()
assert Path(sys.modules['ashlar_host.delta_custody'].__file__).resolve()==ROOT/'src/ashlar_host/delta_custody.py'
OUT=Path('/private/tmp/ashlar-verification-guard-native-c');OUT.mkdir(mode=0o700)
events=[];active=None;original=DataFrame.toLocalIterator;spark=None;primary=None
# Fixed one owner method, bounded synthetic observations; never callback authority.
def observed(frame,*args,**kwargs):
 global active
 assert active is not None
 text=frame._jdf.queryExecution().executedPlan().toString()
 if len(text.encode())>65536:raise ValueError('bounded executed plan')
 active['plans'].append(text)
 iterator=original(frame,*args,**kwargs)
 def capture():
  error=None
  try:
   for row in iterator:
    if len(active['transferred'])>=11:raise ValueError('tiny transfer row bound')
    active['transferred'].append(row.asDict())
    yield row
  except BaseException as e:error=e
  finally:finish(error,[iterator.close])
 return capture()
DataFrame.toLocalIterator=observed
try:
 spark=(SparkSession.builder.master('local[1]').appName('ashlar-tiny-verification-guard')
  .config('spark.driver.memory','512m').config('spark.sql.shuffle.partitions','1')
  .config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true')
  .config('spark.ui.enabled','false').config('spark.executorEnv.PYTHONDONTWRITEBYTECODE','1').getOrCreate())
 owner=LocalDeltaTransport.__new__(LocalDeltaTransport);owner.spark=spark
 base=VerificationBounds(65536,10,1024,65536,65536,65536)
 def run(name,rows,schema,bounds=base,refuse=False,lexical=False):
  global active
  active={'case':name,'plans':[],'transferred':[]};frame=spark.createDataFrame(rows,schema)
  error=None;answer=None
  try:
   with owner.bounded_observations(bounds):
    if lexical:
     real=owner.spark;owner.spark=type('LexicalPort',(),{'range':lambda self,n:real.range(n),'read':type('ReadPort',(),{'format':lambda self,x:self,'option':lambda self,*args:self,'load':lambda self,path:frame})()})()
     owner._detail=lambda target:None
     try:answer=owner.bounded_snapshot(DeltaTarget('tiny.synthetic.items',OUT,'synthetic'),0)[0]['rows']
     finally:owner.spark=real
    else:answer=owner._bounded_native_rows(frame)
  except LocalDeltaError as e:error=type(e).__name__
  assert (error is not None)==refuse,(name,error)
  assert len(active['plans'])==1,(name,'one iterator action')
  assert 'Window' in active['plans'][0] and 'Filter' in active['plans'][0] and active['plans'][0].index('Filter')<active['plans'][0].index('Window'),name
  transferred=active['transferred'];sentinels=[r for r in transferred if r['_ashlar_verification_real']==0]
  assert len(sentinels)==1
  assert all(sentinels[0][field.name] is None for field in schema.fields)
  if refuse:
   assert len(transferred)==1 and sentinels[0]['_ashlar_verification_valid'] is False
  elif not lexical:
   expected=[dict(zip(schema.fieldNames(),row))for row in rows]
   def key(row):return json.dumps(row,sort_keys=True,default=lambda value:{type(value).__name__:str(value)})
   assert sorted(answer,key=key)==sorted(expected,key=key),(name,'exact native carrier bags')
   assert sentinels[0]['_ashlar_verification_valid'] is True
  active['outcome']='refused'if refuse else'accepted';active['answer']=answer
  events.append(active);active=None
 simple=StructType([StructField('id',StringType(),True),StructField('text',StringType(),True)])
 run('empty',[],simple);run('duplicates',[('x',None),('x',None)],simple)
 run('all-null',[(None,None)],simple);run('utf8-escapes',[('雪','\n"\\')],simple)
 native=StructType([StructField('stamp',TimestampType(),True),StructField('amount',DecimalType(20,4),True),StructField('map',MapType(StringType(),StringType(),True),True),StructField('array',ArrayType(StringType(),True),True)])
 run('native-carriers',[(datetime(2026,10,11,1,2,3,456789),Decimal('123456789.0123'),{'key':None,'snow':'雪'},['x',None,'x'])],native)
 run('row-overflow',[('x',None)]*3,simple,VerificationBounds(65536,2,1024,65536,65536,65536),True)
 run('cell-overflow',[('x'*100,None)],simple,VerificationBounds(65536,10,16,65536,65536,65536),True)
 run('total-overflow',[('x'*400,'y'*400)]*3,simple,VerificationBounds(65536,10,1024,5000,65536,65536),True)
 run('repeated-metric-overflow',[(None,None)]*10,simple,VerificationBounds(65536,10,1024,5000,65536,65536),True)
 long=StructType([StructField('key_'+('k'*895),StringType(),True),StructField('text',StringType(),True)])
 run('null-long-key-overflow',[(None,None)]*10,long,VerificationBounds(65536,10,1024,40000,65536,65536),True)
 lexical=StructType([StructField('id',LongType(),True),StructField('text',StringType(),True),StructField('stamp',TimestampType(),True),StructField('amount',DecimalType(20,4),True)])
 run('lexical',[(9007199254740993,'雪',datetime(2026,10,11,1,2,3,456789),Decimal('123456789.0123'))],lexical,lexical=True)
 assert events[-1]['answer']==[{'id':'9007199254740993','text':'雪','stamp':'1791680523456789','amount':'123456789.0123'}]
except BaseException as e:primary=e
finally:
 DataFrame.toLocalIterator=original
 finish(primary,[spark.stop]if spark is not None else[])
# Serialization is bounded independently; synthetic carrier encoding retains types.
def default(value):
 if isinstance(value,datetime):return {'datetime':value.isoformat()}
 if isinstance(value,Decimal):return {'decimal':str(value)}
 raise TypeError('closed synthetic carrier')
record={'profile':'tiny-owning-native-guard/0.1','qualification':'synthetic Spark4 guard only; no Delta/source/ACK/full evolution authority or speed/heap claim','cases':events,'sparkStopped':True}
raw=bytearray()
for chunk in json.JSONEncoder(sort_keys=True,default=default).iterencode(record):
 part=chunk.encode()
 if len(raw)+len(part)>1048576:raise ValueError('bounded synthetic result capture')
 raw.extend(part)
(OUT/'result.json').write_bytes(raw)
