"""Bounded source/native guard microprobe runner; no business sources."""
import json,sys,time,hashlib,importlib.util
from pathlib import Path
PREP=Path('/private/tmp/ashlar-verification-guard-native-prep-a')
WORK=Path('/private/tmp/ashlar-verification-guard-native-c-runner')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
 spec=importlib.util.spec_from_file_location('known_runner','/private/tmp/ashlar-evolution-installed-verification-runner-b.py');known=importlib.util.module_from_spec(spec);spec.loader.exec_module(known)
 known.verify_namespace()
 WORK.mkdir(mode=0o700);(WORK/'tmp').mkdir()
 spec=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
 inventory=json.loads((PREP/'source-inventory-a.json').read_bytes())
 def renew():
  for row in inventory['files']:
   p=Path(row['path']);raw=p.read_bytes()
   if p.is_symlink() or len(raw)!=row['bytes'] or sha(raw)!=row['sha256']:raise ValueError('source-custody')
  actual={str(p)for p in (PREP/'source').rglob('*')if p.is_file()}
  if actual!={r['path']for r in inventory['files']}:raise ValueError('source-namespace')
 renew()
 env={'PATH':'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home/bin:/usr/bin:/bin','JAVA_HOME':'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','SPARK_LOCAL_IP':'127.0.0.1','SPARK_LOCAL_HOSTNAME':'localhost','TMPDIR':str(WORK/'tmp'),'PYSPARK_PYTHON':'/private/tmp/ashlar-db-client/bin/python','PYSPARK_DRIVER_PYTHON':'/private/tmp/ashlar-db-client/bin/python'}
 primary=None;result=None;started=time.monotonic()
 try:
  result=capture.capture(['/private/tmp/ashlar-db-client/bin/python','-B','-S',str(PREP/'probe-c.py')],str(WORK),env,str(WORK/'native.stdout'),str(WORK/'native.stderr'),300,1048576)
 except BaseException as e:primary=e
 finally:
  for close in (renew,known.verify_namespace):
   try:close()
   except BaseException as e:primary=known.select_failure(primary,e)
  try:
   known.write(WORK/'receipt.json',known.enc({'profile':'tiny-native-guard-runner/0.1','result':result,'wholeSuccess':primary is None and result is not None and result['exitCode']==0,'sourceRuntimeClosing':primary is None,'elapsedSeconds':time.monotonic()-started,'qualification':'synthetic source-native guard only, no original F/Delta/PG/authority or performance qualification'}))
  except BaseException as error:primary=known.select_failure(primary,error)
 if primary is not None:raise primary
 if result['exitCode']:raise SystemExit(result['exitCode'])
if __name__=='__main__':main()
