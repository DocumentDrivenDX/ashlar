"""Pure retained-source/pair verification; never starts native/producer services."""
from pathlib import Path
from collections import Counter
import json,hashlib
from ashlar.typed_graph_source_config import load_typed_graph_jsonl_configuration
from ashlar.source import jsonl_batches
from ashlar.graph_release import validate_release_carrier,decode_graph_key
from ashlar_host.managed_source_oracle import configured_prefix_carrier_rows
from ashlar_host.managed_carriers import load_managed_carriers
from ashlar_host.private_graph_custody import load_private_graph_release
from ashlar_host.delta_custody import encoded
root=Path('/private/tmp/ashlar-configured-graph-export-installed-20261017-hxv54ut0');results=[]
for ordinal in (1,3):
 c=root/('ordinal-'+str(ordinal));out=c/'output';invocation=json.loads((c/'configuration.json').read_bytes());report=json.loads((out/'report.json').read_bytes())
 receipt=(out/'admission/graph-1.json').read_bytes();config=load_typed_graph_jsonl_configuration(Path(invocation['source_configuration']),receipt=receipt)
 batches=tuple(jsonl_batches(config.source.read_bytes().splitlines(keepends=True),feed=config.feed,epoch=config.epoch))
 expected=configured_prefix_carrier_rows(config,batches[:ordinal],materialization_clock_us=invocation['materialization_clock_us'],carriers=load_managed_carriers()).rows()
 release=(out/'release.graph.json').read_bytes();custody=(out/'custody.json').read_bytes();graph=load_private_graph_release(release,report['release_sha256'],custody,report['custody_sha256'])
 assert graph['publication']==report['manifest']and report==json.loads((out/'runtime-report.json').read_bytes())==json.loads((c/'export.stdout').read_bytes())
 assert report['ordinal']==ordinal and report['completed_batches']==3 and report['local_checkpoint']=='5724'and report['protected_ack']is False
 for kind,role,key in [('node','object_current','nodes'),('edge','edge_current','edges')]:
  assert Counter(map(encoded,graph[key]))==Counter(encoded(validate_release_carrier(dict(row),kind))for row in expected[role])
 assert json.loads(graph['publication']['validation_report_json'])['source_oracle_sha256']==hashlib.sha256(encoded(expected).encode()).hexdigest()
 snapshots=graph['snapshots'];assert {t:s['version']for t,s in snapshots.items()}==json.loads(report['manifest']['table_versions_json'])
 nodes=graph['nodes'];edges=graph['edges'];endpoints={e[k]for e in edges for k in ('src','dst')};pairs=Counter((e['src'],e['dst'])for e in edges)
 for row in nodes:assert decode_graph_key(row['graph_id'])==('node',row['source_system'],row['type_id'],row['id'])
 for row in edges:assert decode_graph_key(row['graph_id'])==('edge',row['source_system'],row['rel_type_id'],row['id'])
 assert json.loads((c/'export-terminal.json').read_bytes())=={'cleanup_confirmed':True,'cleanup_failed':False,'complete':True,'error_class':None,'status':0}
 outer=json.loads((c/'outer-attempt.json').read_bytes());assert outer['status']==0 and outer['cleanup']['groups_absent']is True and outer['cleanup']['session_leader_reaped']is True
 old=json.loads((c/'reviewed-pending.json').read_bytes());operative=json.loads((c/'preparation.json').read_bytes());assert old['ready']is False and operative['ready']is True
 assert {k:v for k,v in old.items()if k!='ready'}=={k:v for k,v in operative.items()if k!='ready'}
 for pin in operative['pins']:
  b=Path(pin['path']).read_bytes();assert len(b)==pin['bytes']and hashlib.sha256(b).hexdigest()==pin['sha256']
 results.append({'ordinal':ordinal,'nodes':len(nodes),'edges':len(edges),'isolates':sum(n['graph_id']not in endpoints for n in nodes),'self_loops':sum(e['src']==e['dst']for e in edges),'parallel_endpoint_occurrences':sum(v for v in pairs.values()if v>1),'full_independent_source_carriers_equal':True,'strict_saved_pair_loader':True,'snapshot_vector':snapshots,'release_sha256':report['release_sha256'],'custody_sha256':report['custody_sha256'],'report_sha256':hashlib.sha256((out/'report.json').read_bytes()).hexdigest(),'elapsed_seconds':outer['elapsed_seconds'],'cleanup':outer['cleanup'],'public_source_receipt_sha256':hashlib.sha256(receipt).hexdigest()})
assert [(r['nodes'],r['edges'])for r in results]==[(4,4),(3,1)]
raw=(json.dumps({'profile':'ashlar-configured-graph-export-retained-review/0.1','result':'PASS','qualification':'Pure exact retained input/receipt/source-prefix/carrier/pair correspondence only; no engine/producer/native/source/ACK calls or new authority.','ordinals':results},indent=2)+'\n').encode();(root/'independent-pair-review.json').write_bytes(raw);print(raw.decode())
