import os,sys,json,hashlib,runpy,signal
from pathlib import Path
R=Path(__file__).resolve().parent
raw=(R/'preparation.json').read_bytes();selected=json.loads(raw)
def renew():
 if(R/'preparation.json').read_bytes()!=raw:raise PermissionError('Frozen export preparation changed')
 for pin in selected['pins']:
  b=Path(pin['path']).read_bytes()
  if len(b)!=pin['bytes']or hashlib.sha256(b).hexdigest()!=pin['sha256']:raise PermissionError('Frozen export input changed')
renew()
def stop(*args):raise KeyboardInterrupt()
signal.signal(signal.SIGTERM,stop)
sys.argv=['ashlar','run-configured-local','--configuration',str(R/'configuration.json')]
from ashlar_host.lifecycle import finish
primary=None
try:runpy.run_module('ashlar',run_name='__main__')
except BaseException as error:primary=error
finish(primary,[renew])
