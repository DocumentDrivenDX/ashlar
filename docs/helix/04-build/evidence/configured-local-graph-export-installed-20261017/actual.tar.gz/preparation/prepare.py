from pathlib import Path
import subprocess,tempfile,tarfile,io,json,hashlib,os,gzip,shutil,zipfile
os.umask(0o077)
root=Path(tempfile.mkdtemp(prefix='ashlar-configured-graph-export-installed-20261017-',dir='/private/tmp'));root.chmod(0o700)
commit='0bca82232a0bc923ef83eaf879a0e96595b515b5';repo=Path('/Users/erik/Projects/ashlar');source=root/'source';source.mkdir()
raw=subprocess.check_output(['/usr/bin/git','archive',commit,'src','README.md','pyproject.toml'],cwd=repo);(root/'source.tar').write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(raw))as t:t.extractall(source,filter='data')
builder='/private/tmp/ashlar-weft-validation-wheel-20261016-cdc5wn_8/build-environment/bin/python';base='/private/tmp/ashlar-publication-query-runtime-20261016-b/bin/python';env=root/'runtime'
with(root/'build.log').open('wb')as log:subprocess.run([builder,'-c',"import setuptools.build_meta as b;print(b.build_wheel('../dist'))"],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([base,'-I','-B','-m','venv','--without-pip',str(env)],check=True,stdout=subprocess.DEVNULL)
python=env/'bin/ashlar-python3.11';shutil.copy2((env/'bin/python').resolve(),python);python.chmod(0o700)
site=env/'lib/python3.11/site-packages'
wheel=next((root/'dist').glob('*.whl'))
with(root/'install.log').open('wb')as log:subprocess.run([builder,'-m','pip','--isolated','--python',str(python),'install','--no-index','--no-deps','--no-compile',str(wheel)],check=True,stdout=log,stderr=subprocess.STDOUT)
(site/'owned-dependencies.pth').write_text('/private/tmp/ashlar-publication-query-runtime-20261016-b/lib/python3.11/site-packages\n')
count=0
with zipfile.ZipFile(wheel)as z:
 for name in z.namelist():
  if name.startswith(('ashlar/','ashlar_host/'))and not name.endswith('/'):
   assert(site/name).read_bytes()==z.read(name);count+=1
old=Path('/private/tmp/ashlar-typed-graph-installed-20261017-gfothazt');evidence=repo/'docs/helix/04-build/evidence/configured-typed-graph-installed-20261017'
baseconfig=json.loads(gzip.decompress((evidence/'base.json.gz').read_bytes()));initialize=json.loads(gzip.decompress((evidence/'initialize/report.json.gz').read_bytes()));registry=old/'native/installation.json';assert hashlib.sha256(registry.read_bytes()).hexdigest()==initialize['installation_sha256']
prep={'profile':'ashlar-configured-graph-export-preparation/0.1','ready':False,'commit':commit,'wheel':str(wheel),'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'archive_sha256':hashlib.sha256(raw).hexdigest(),'installed_package_members_byte_equal':count,'runtime':str(python),'original_installation':str(old/'native'),'trusted_installation_sha256':initialize['installation_sha256'],'original_evidence_manifest_sha256':hashlib.sha256((evidence/'manifest.json').read_bytes()).hexdigest(),'scope':'Prepare only two read-only exports of original selected ordinals1 and3. No native/source/producer/engine calls or journal recreation. Actual current custody must be admitted by public command.','commands':[]}
commonpins=[]
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
originals=[registry,Path(baseconfig['source_configuration'])]
doc=json.loads(Path(baseconfig['source_configuration']).read_bytes())
for key in ('source','schema','bindings'):originals.append(Path(baseconfig['source_configuration']).parent/doc[key]['path'])
for p in originals:commonpins.append(pin(p))
for n in ('configured_local_graph_release.py','configured_graph_custody.py','private_graph_custody.py','configured_local_runtime.py','configured_local_cli.py','process_capture.py','puppy_scenario_processes.py','lifecycle.py'):commonpins.append(pin(site/'ashlar_host'/n))
for p in Path(baseconfig['jars']).glob('*.jar'):commonpins.append(pin(p))
commonpins.extend([pin(python),pin(site/'owned-dependencies.pth'),pin(Path(baseconfig['producer']['bun'])),pin(Path(baseconfig['producer']['git']))])
# Reuse the previously reviewed retained-leader capture mechanics unchanged except selected paths/names.
supervisor=Path('/private/tmp/ashlar-projected-detail-probe-20261017-a/supervise.py').read_text()
runner='''import os,sys,json,hashlib,runpy,signal\nfrom pathlib import Path\nR=Path(__file__).resolve().parent\nraw=(R/'preparation.json').read_bytes();selected=json.loads(raw)\ndef renew():\n if(R/'preparation.json').read_bytes()!=raw:raise PermissionError('Frozen export preparation changed')\n for pin in selected['pins']:\n  b=Path(pin['path']).read_bytes()\n  if len(b)!=pin['bytes']or hashlib.sha256(b).hexdigest()!=pin['sha256']:raise PermissionError('Frozen export input changed')\nrenew()\ndef stop(*args):raise KeyboardInterrupt()\nsignal.signal(signal.SIGTERM,stop)\nsys.argv=['ashlar','run-configured-local','--configuration',str(R/'configuration.json')]\nfrom ashlar_host.lifecycle import finish\nprimary=None\ntry:runpy.run_module('ashlar',run_name='__main__')\nexcept BaseException as error:primary=error\nfinish(primary,[renew])\n'''
for ordinal in (1,3):
 control=root/('ordinal-'+str(ordinal));control.mkdir(mode=0o700)
 cfg=dict(baseconfig,operation='export',ordinal=ordinal,python=str(python),installation_sha256=initialize['installation_sha256'],output=str(control/'output'));cfg['bounds']=dict(cfg['bounds'],whole_seconds=180)
 (control/'configuration.json').write_text(json.dumps(cfg,indent=2)+'\n');(control/'configuration.json').chmod(0o600)
 (control/'run-export.py').write_text(runner)
 sup=supervisor.replace("str(Path(__file__).parent/'runtime/lib/python3.11/site-packages')",repr(str(site))).replace("str(root/'probe.py')","str(root/'run-export.py')").replace('seconds=60','seconds=210').replace("'work_seconds':60","'work_seconds':210").replace('probe.stdout','export.stdout').replace('probe.stderr','export.stderr').replace('probe-terminal.json','export-terminal.json')
 (control/'supervise.py').write_text(sup)
 pins=commonpins+[pin(control/'configuration.json'),pin(control/'run-export.py'),pin(control/'supervise.py')]
 selection={'ready':False,'profile':'ashlar-configured-local-export-control/0.1','ordinal':ordinal,'pins':pins,'bounds':{'public_cli_whole_seconds':180,'outer_work_seconds':210,'grace_seconds':5,'stream_bytes':1048576},'scope':'Read original selected publication only; no publication, source append, progress/ACK or native-r2 access.'}
 (control/'preparation.json').write_text(json.dumps(selection,indent=2)+'\n')
 prep['commands'].append({'ordinal':ordinal,'control':str(control),'preparation_sha256':hashlib.sha256((control/'preparation.json').read_bytes()).hexdigest(),'argv':[str(python),'-I','-B',str(control/'supervise.py')],'public_argv':[str(python),'-I','-B','-m','ashlar','run-configured-local','--configuration',str(control/'configuration.json')]})
(root/'preparation.json').write_text(json.dumps(prep,indent=2)+'\n')
print(root)
