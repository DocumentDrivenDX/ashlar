import sys,json,time,os,hashlib
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;s=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a');e=Path('/private/tmp/ashlar-truss22-commerce-evolution-20261013-a');o=r/'query';o.mkdir(mode=0o700)
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical'];sys.path[:0]=['/private/tmp/ashlar-truss22-commerce-indexed-settlement-20261013-a/ashlar-target','/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from contextlib import nullcontext
from types import SimpleNamespace
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_resume_setup import run_configure_truss_resume_command
from ashlar_host.truss_indexed_commerce_cli import run_query_truss_commerce_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_example import private_file
intent=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a/native/publication/publication-intent-ce9a7e185f33f545e6cd30bdda650ed240bfb4db4fa86d4165c654e370d4567f.json');publication=json.loads(intent.read_bytes())
previous={k:os.environ.get(k)for k in ('JAVA_HOME','PYSPARK_PYTHON','PYSPARK_DRIVER_PYTHON')};primary=None;answer=None;t=time.monotonic()
def mark(stage):
 print(json.dumps({'stage':stage,'elapsed_seconds':time.monotonic()-t}),flush=True)
def restore():
 for k,v in previous.items():
  if v is None:os.environ.pop(k,None)
  else:os.environ[k]=v
try:
 os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
 mark('query_child_start')
 with nullcontext(SimpleNamespace(info=SimpleNamespace(connection_uri=json.loads((r/'runtime-info.json').read_bytes())['connection_uri'])))as runtime:
  mark('supervisor_owned_source_ready')
  params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);administrator=psycopg.conninfo.make_conninfo(**params);params['user']=json.loads((s/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
  def conn():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
  pending=read_page(conn,'commerce22-full-native',maximum_bytes=2097152);private_file(o/'checkpoint-before.bin',pending.prior.content)
  selection=json.loads((s/'native/publish.json').read_bytes());selection.update(connection_uri=ordinary,administrator_uri=administrator);selection['archived_acceptance_files']=[{'path':str(e/'evolution.json'),'sha256':hashlib.sha256((e/'evolution.json').read_bytes()).hexdigest()}];reader=o/'reader.json';run_configure_truss_resume_command(private_file(o/'publisher-selection.json',selection),intent,reader)
  mark('query_start')
  query=run_query_truss_commerce_command(reader,o/'refund.json',index='/private/tmp/weft-042-integration-b/distributions/index.json',installation='/private/tmp/ashlar-042-installed-cli-actual-b/qualification/installation',pack_path='/Users/erik/Projects/ashlar/examples/domain-packs/commerce/upstream/pack.json',case_id='refund',revision='1',document_id='urn:umf:domain:commerce',maximum_rows=10)
  mark('query_closed')
  after=read_page(conn,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(o/'checkpoint-after.bin',after);assert after==pending.prior.content
  assert query['publication_id']==publication['publication_id']
  assert query['rows']==[['[42,0,"RF1"]']]
  answer={'outcome':'passed','case':'refund','publication_id':query['publication_id'],'rows':query['rows'],'query_checkpoint_unchanged':True,'scope':'One unchanged authored refund SQL on retained original UMF0.8 Truss22 publication; historical read while current source remains evolved, installed public indexed compiler and pinned installed Ashlar wheel. Local Spark/Delta only; no production or UC qualification.'}
except BaseException as error:primary=error
finish(primary,[restore]);mark('query_child_environment_closed');answer['duration_seconds']=time.monotonic()-t;private_file(o/'result.json',answer);print(json.dumps(answer),flush=True)
