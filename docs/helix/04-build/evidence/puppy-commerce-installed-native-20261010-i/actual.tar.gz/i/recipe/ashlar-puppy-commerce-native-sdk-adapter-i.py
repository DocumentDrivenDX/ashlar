"""Recipe-owned exact GremlinPython3.7.3 GraphSON boundary; not a public grant."""
import os,threading
from pathlib import Path
from gremlin_python.statics import long as SDKLong
from gremlin_python.driver.serializer import GraphSONSerializersV3d0
from ashlar_host.puppy_commerce_projection import commerce_snapshot
from ashlar_host.lifecycle import owned_context


def passive_sdk_rows(value,maximum_bytes=1048576):
    nodes=0;active=set();census={'sdkLong':0,'plainInteger':0,'strings':0,'nulls':0,'booleans':0}
    def copy(item,depth):
        nonlocal nodes
        nodes+=1
        if depth>64 or nodes>250000:raise ValueError('Bounded SDK carrier structure')
        if type(item)is SDKLong:
            result=int.__int__(item)
            if not -(2**63)<=result<2**63:raise ValueError('Exact SDK signed64 only')
            census['sdkLong']+=1;return result
        if type(item)is int:census['plainInteger']+=1;return item
        if type(item)is str:census['strings']+=1;return item
        if item is None:census['nulls']+=1;return None
        if type(item)is bool:census['booleans']+=1;return item
        if type(item)not in (list,dict):raise ValueError('Unknown SDK passive carrier refused')
        if id(item)in active:raise ValueError('Cyclic SDK carrier')
        active.add(id(item))
        try:
            if type(item)is list:return[copy(x,depth+1)for x in item]
            result={}
            for key,entry in item.items():
                if type(key)is not str:raise ValueError('Exact SDK member name')
                result[key]=copy(entry,depth+1)
            return result
        finally:active.remove(id(item))
    return commerce_snapshot(copy(value,0),maximum_bytes),census


class RetainedGraphSONSerializer(GraphSONSerializersV3d0):
    def __init__(self,directory,*,maximum_frame_bytes=1048576,maximum_total_bytes=16777216):
        super().__init__();self.directory=Path(directory);self.lock=threading.Lock();self.count=0;self.total=0
        self.maximum_frame_bytes=maximum_frame_bytes;self.maximum_total_bytes=maximum_total_bytes
    def deserialize_message(self,message):
        if type(message)is str:
            if len(message)>self.maximum_frame_bytes:raise ValueError('Bounded raw GraphSON text')
            raw=message.encode('utf-8')
        elif type(message)is bytes:raw=message
        else:raise ValueError('Exact raw GraphSON bytes/text')
        if len(raw)>self.maximum_frame_bytes:raise ValueError('Bounded raw GraphSON frame')
        with owned_context(self.lock):
            if self.count>=128 or self.total+len(raw)>self.maximum_total_bytes:raise ValueError('Bounded whole raw GraphSON capture')
            self.count+=1;path=self.directory/('gremlin-wire-'+str(self.count)+'.json')
            # Retain exact wire bytes before the SDK can transform or refuse them.
            with owned_context(path.open('xb'))as stream:
                if stream.write(raw)!=len(raw):raise ValueError('Complete raw GraphSON retention')
                stream.flush();os.fsync(stream.fileno())
            self.total+=len(raw)
        return super().deserialize_message(message)
