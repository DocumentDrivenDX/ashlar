import sys,importlib.util,tempfile,json
from pathlib import Path
sys.path[:]=['/private/tmp/ashlar-gremlin-python','/private/tmp/ashlar-puppy-commerce-installed-20261010-b/venv/lib/python3.12/site-packages']+[p for p in sys.path if p not in ('','/private/tmp')]
spec=importlib.util.spec_from_file_location('sdk_adapter','/private/tmp/ashlar-puppy-commerce-native-sdk-adapter-i.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from gremlin_python.structure.io.graphsonV3d0 import GraphSONReader
from gremlin_python.statics import long
reader=GraphSONReader();values=[-(2**63),-9007199254740993,9007199254740993,2**63-1]
for value in values:
 native=reader.to_object({'@type':'g:Int64','@value':value});assert type(native)is long
 out,c=m.passive_sdk_rows([{'number':native,'identity':'[42,0,"ST1"]','nullable':None}]);assert type(out[0]['number'])is int and out[0]['number']==value and c['sdkLong']==1 and out[0]['identity']=='[42,0,"ST1"]'
class Forged(int):
 def __int__(self):raise AssertionError('Executable integer dispatched')
for value in [Forged(3),long(2**63),1.0,{'x':object()}]:
 try:m.passive_sdk_rows(value)
 except ValueError:pass
 else:raise AssertionError('Unknown or lossy scalar accepted')
with tempfile.TemporaryDirectory()as tmp:
 s=m.RetainedGraphSONSerializer(tmp)
 raw=b'{"requestId":"fixture","status":{"code":200,"attributes":{},"message":""},"result":{"data":[{"@type":"g:Int64","@value":9007199254740993}],"meta":{}}}'
 result=s.deserialize_message(raw);assert type(result['result']['data'][0])is long;assert(Path(tmp)/'gremlin-wire-1.json').read_bytes()==raw
 bad=b'not JSON'
 try:s.deserialize_message(bad)
 except json.JSONDecodeError:pass
 else:raise AssertionError('Malformed wire accepted')
 assert(Path(tmp)/'gremlin-wire-2.json').read_bytes()==bad
 s.maximum_frame_bytes=1
 try:s.deserialize_message(b'{}')
 except ValueError:pass
 else:raise AssertionError('Oversized wire accepted')
 assert not(Path(tmp)/'gremlin-wire-3.json').exists()
 cancellation=KeyboardInterrupt('original retention cancellation');original=m.os.fsync
 def fail(_):raise cancellation
 m.os.fsync=fail
 try:
  s.maximum_frame_bytes=1048576
  try:s.deserialize_message(b'{}')
  except KeyboardInterrupt as e:assert e is cancellation
  else:raise AssertionError('Cancellation suppressed')
 finally:m.os.fsync=original
 assert(Path(tmp)/'gremlin-wire-3.json').read_bytes()==b'{}'
print('Pure selected Gremlin3.7.3 GraphSON controls PASS: exact64bit values, nested cells, identity/nulls, forged/float/range refusal, raw-before-parse/bounds/cancellation. No network or engine.')
