"""Prepare-only five-case campaign, guarded by reviewed exact runtime selection."""
from pathlib import Path
import hashlib,json,os,sqlite3,runpy,sys,time
R=Path(__file__).resolve().parent;os.umask(0o077)
def put(path,value):
 raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
 if len(raw)>1048576:raise ValueError('Finite campaign report required')
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  if os.write(fd,raw)!=len(raw):raise OSError('Exact owned report required')
  os.fsync(fd)
 finally:os.close(fd)
def fingerprint():
 native=R/'native';files={};total=0
 for p in sorted(native.rglob('*')):
  if not p.is_file()or p.name.endswith(('-wal','-shm','.lock'))or p.suffix not in ('.json','.parquet'):continue
  if p.is_symlink()or p.stat().st_size>1048576:raise ValueError('Tiny original native file inventory required')
  raw=p.read_bytes();total+=len(raw)
  if len(files)>=256 or total>8*1048576:raise ValueError('Finite native file inventory required')
  files[str(p.relative_to(native))]=hashlib.sha256(raw).hexdigest()
 db=sqlite3.connect('file:'+str(native/'operations.sqlite')+'?mode=ro',uri=True)
 try:
  db.execute('PRAGMA query_only=ON');tables=[r[0]for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")];facts={}
  for table in tables:
   if not table.replace('_','').isalnum():raise ValueError('Closed SQLite table identifier required')
   rows=[];size=0
   for row in db.execute('SELECT * FROM "'+table+'" LIMIT 1001'):
    raw=json.dumps(row,sort_keys=True,separators=(',',':')).encode();size+=len(raw)
    if len(rows)>=1000 or len(raw)>1048576 or size>4*1048576:raise ValueError('Tiny original journal inventory required')
    rows.append(raw.decode())
   facts[table]={'rows':len(rows),'sha256':hashlib.sha256(json.dumps(sorted(rows),separators=(',',':')).encode()).hexdigest()}
 finally:db.close()
 return {'files':files,'journal_tables':facts}
def main():
 selection=json.loads((R/'preparation.json').read_bytes())
 if selection.get('ready')is not True:raise PermissionError('Exact reviewed installed campaign required')
 base=json.loads((R/'base.json').read_bytes());python=base['python']
 if Path(sys.executable)!=Path(python):raise PermissionError('Explicit immutable campaign runtime required')
 if(R/'native').exists():raise PermissionError('Fresh isolated campaign required')
 expected_positions=[int(item['position'])for item in selection['expected_source_checkpoints']]
 if len(expected_positions)!=2 or not 0<expected_positions[0]<expected_positions[1]:raise ValueError('Exact source byte positions required')
 cases=[];registry_sha=None;first_manifest=None
 for name,ordinal in (('initialize',0),('baseline1',1),('fault2',2),('resume2',2),('replay2',2)):
  case=R/name;case.mkdir(mode=0o700);config={**base,'operation':'initialize'if ordinal==0 else'publish','ordinal':ordinal,'output':str(case/'output'),'installation_sha256':registry_sha}
  put(case/'configuration.json',config);before=fingerprint()if name=='replay2'else None
  start=time.monotonic()
  # The subordinate retained-leader supervisor independently owns all native
  # descendants and finite capture; it releases its result only after cleanup.
  previous_argv=sys.argv;code=0
  try:
   sys.argv=[str(R/'supervise.py'),name]
   try:runpy.run_path(str(R/'supervise.py'),run_name='__main__')
   except SystemExit as ending:
    if type(ending.code)is not int:raise
    code=ending.code
  finally:sys.argv=previous_argv
  terminal=json.loads((case/'attempt-terminal.json').read_bytes())
  if code!=0 or terminal.get('status')!=0 or not terminal.get('complete')or not terminal.get('cleanup_confirmed')or terminal.get('cleanup_failed'):raise AssertionError('Owned exact case incomplete')
  witness=json.loads((case/'witness.json').read_bytes())
  if name=='initialize':registry_sha=witness['result']['installation_sha256']
  elif name=='fault2':
   if witness['status']!='expected-original-response-loss'or witness['injections']!=1 or witness['phase_names']!=['applying','prepared']:raise AssertionError('Exact interrupted applying witness required')
  else:
   result=witness['result']
   if name=='resume2':first_manifest=result['manifest']
   if name=='replay2':
    if not result['replayed']or result['manifest']!=first_manifest:raise AssertionError('Original descriptor replay differs')
    after=fingerprint();put(case/'before.json',before);put(case/'after.json',after)
    if before!=after:raise AssertionError('Replay mutated original files or durable journal')
  cases.append({'case':name,'elapsed_seconds':time.monotonic()-start,'terminal':terminal,'witness_sha256':hashlib.sha256((case/'witness.json').read_bytes()).hexdigest()})
 # Exact original native commit occurs once and its submitted operation now has
 # the normal owner's durable committed receipt; no reconstruction or DML here.
 fault=json.loads((R/'fault2/postcommit-fault.json').read_bytes());db=sqlite3.connect('file:'+str(R/'native/operations.sqlite')+'?mode=ro',uri=True)
 try:
  db.execute('PRAGMA query_only=ON');row=db.execute('SELECT intent,intent_sha,before_version,state,receipt FROM local_operation WHERE operation=?',(fault['operation'],)).fetchone();positions=db.execute('SELECT position FROM jsonl_consumer_progress ORDER BY position').fetchall()
 finally:db.close()
 if row is None or json.loads(row[0])!=fault['intent']or row[1]!=fault['intent_sha256']or row[2]!=fault['before_version']or row[3]!='committed'or row[4]is None or positions!=[(position,)for position in expected_positions]:raise AssertionError('Normal original operation recovery/progress missing')
 commits=[]
 for p in (R/'native').glob('*/_delta_log/*.json'):
  for line in p.read_bytes().splitlines():
   action=json.loads(line)
   if action.get('commitInfo',{}).get('userMetadata')==fault['metadata']:commits.append(str(p.relative_to(R/'native')))
 if len(commits)!=1:raise AssertionError('Original named Delta effect commit duplicated or missing')
 put(R/'campaign-result.json',{'status':'passed','cases':cases,'original_effect_commit_files':commits,'original_operation_recovered_with_receipt':True,'local_progress_positions':expected_positions,'replay_native_and_journal_unchanged':True,'scope':'One interrupted actual typed Delta effect, ordinary public recovery and replay on fresh private immutable-file fixture. Empty tombstones are verified, not delete behavior. No protected source ACK, production authority or throughput qualification.'})
 print(json.dumps({'status':'passed','cases':len(cases)}))
if __name__=='__main__':main()
