from pathlib import Path
import json,sys,inspect
from ashlar_host.configured_local_cli import parse_configured_local
from ashlar_host.delta_custody import LocalDeltaTransport
from ashlar.source import jsonl_batches
from ashlar.source_checkpoint import jsonl_checkpoint
r=Path(sys.argv[1]);base=json.loads((r/'base.json').read_bytes());inv=parse_configured_local(json.dumps(base).encode());assert inv.python==Path(sys.executable)
selection=json.loads((r/'preparation.json').read_bytes());cfg=json.loads(Path(base['source_configuration']).read_bytes());raw=(r/'fixture/typed-named-source.jsonl').read_bytes();batches=tuple(jsonl_batches(raw.splitlines(keepends=True),feed=cfg['feed'],epoch=cfg['epoch']));assert[json.loads(jsonl_checkpoint(b))for b in batches[:2]]==selection['expected_source_checkpoints'];assert[len(raw),[int(c['position'])for c in selection['expected_source_checkpoints']]]==[2051,[931,1493]]
assert Path(inspect.getsourcefile(LocalDeltaTransport)).is_relative_to(r/'runtime')
for key in ('bun','git','source'):assert Path(base['producer'][key]).exists()
assert Path(base['jars']).is_dir()and Path(base['java_home']).is_dir()
print(json.dumps({'python':sys.executable,'transport':inspect.getsourcefile(LocalDeltaTransport),'configuration_parsed':True,'source_checkpoint_positions':[931,1493],'producer_paths_exist_only':True,'native_execution':False,'producer_execution':False}))
