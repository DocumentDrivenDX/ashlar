"""Private one-shot postcommit fault; no product callback or journal repair."""
from pathlib import Path
import hashlib,json,os,sys,signal,sqlite3,time,datetime
R=Path(__file__).resolve().parent;CASE=R/sys.argv[1];os.umask(0o077)
class OriginalEffectResponseLost(OSError):pass
primary_fault=OriginalEffectResponseLost()
def retain(path,value):
 def native(value):
  if type(value)is datetime.datetime:return {'native_datetime_iso':value.isoformat(timespec='microseconds')}
  raise TypeError('Unsupported exact witness carrier')
 raw=(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False,default=native)+'\n').encode()
 if len(raw)>1048576:raise ValueError('Bounded original witness required')
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  offset=0
  while offset<len(raw):
   count=os.write(fd,raw[offset:])
   if count<=0:raise OSError('Witness write refused')
   offset+=count
  os.fsync(fd)
 finally:os.close(fd)
def stop(*args):raise KeyboardInterrupt()
signal.signal(signal.SIGTERM,stop)
def main():
 from ashlar_host.configured_local_cli import parse_configured_local
 from ashlar_host.configured_local_runtime import initialize_configured_local,publish_configured_local
 from ashlar_host.delta_custody import LocalDeltaTransport,LocalDeltaEffects
 from ashlar_host.managed_source_oracle import configured_prefix_carrier_rows
 from ashlar_host.managed_carriers import load_managed_carriers
 from ashlar.effect_validation import validate_effect_snapshot
 from ashlar_host.lifecycle import finish
 from ashlar_host.configured_source_local import open_configured_local_source,ConfiguredLocalSource
 selection_raw=(R/'preparation.json').read_bytes();selection=json.loads(selection_raw)
 if selection.get('ready')is not True:raise PermissionError('Reviewed installed selection required')
 def renew():
  if(R/'preparation.json').read_bytes()!=selection_raw:raise PermissionError('Original selection changed')
  for pin in selection['pins']+selection['fixture_pins']:
   raw=Path(pin['path']).read_bytes()
   if len(raw)!=pin['bytes']or hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise PermissionError('Original selected bytes changed')
 renew();invocation=parse_configured_local((CASE/'configuration.json').read_bytes());config=invocation.runtime
 if Path(sys.executable)!=invocation.python or sys.gettrace()is not None:raise PermissionError('Exact untraced installed runtime required')
 import inspect
 transport_file=Path(inspect.getsourcefile(LocalDeltaTransport))
 if hashlib.sha256(transport_file.read_bytes()).hexdigest()!=selection['transport_sha256']:raise PermissionError('Exact fault point source required')
 # Revalidate exact executable breakpoint against the selected installed AST.
 import ast
 tree=ast.parse(transport_file.read_bytes());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='LocalDeltaTransport');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name=='_execute')
 points=[n.lineno for n in ast.walk(method)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='history'for t in n.targets)and isinstance(n.value,ast.Call)and isinstance(n.value.func,ast.Attribute)and n.value.func.attr=='original_history']
 if points!=[selection['postcollect_line']]:raise PermissionError('Exact postcollect point differs')
 expected_checkpoints=selection['expected_source_checkpoints'];expected_positions=[int(item['position'])for item in expected_checkpoints]
 if len(expected_positions)!=2 or not 0<expected_positions[0]<expected_positions[1]:raise ValueError('Exact original byte checkpoints required')
 admitted_checkpoints={};snapshots={};captured_bytes=0;effects_depth=0;injected=False;fault_witness=None
 def observe(frame,event,arg):
  nonlocal effects_depth,injected,captured_bytes,fault_witness
  if frame.f_code is ConfiguredLocalSource.spec.__code__ and event=='return'and arg is not None:
   ordinal=frame.f_locals['ordinal']
   if ordinal in (1,2):
    checkpoint=json.loads(arg.request()['source_checkpoint_json'])
    if checkpoint!=expected_checkpoints[ordinal-1]:raise AssertionError('Admitted original byte checkpoint differs')
    admitted_checkpoints[ordinal]=checkpoint
  if frame.f_code is LocalDeltaEffects._execute.__code__:
   if event=='call':effects_depth+=1
   elif event=='return':effects_depth-=1
  if frame.f_code is validate_effect_snapshot.__code__ and event=='return'and type(arg)is dict:
   table=frame.f_locals['table'];version=frame.f_locals['version'];columns=frame.f_locals['columns'];actual=frame.f_locals['actual']
   if set(arg)!={'table','uuid','version','rows','columns'}or arg['table']!=table or arg['version']!=version:raise ValueError('Exact successful effect witness required')
   if not table.rsplit('.',1)[-1]in ('object_current','edge_current','tombstone','whole_source_history'):raise ValueError('Closed original role required')
   value={'schema':[[name,family.lower()]for name,family in columns],'rows':sorted(actual,key=lambda row:json.dumps(row,sort_keys=True,separators=(',',':')))}
   raw=json.dumps(value,sort_keys=True,separators=(',',':')).encode();key=(table,version);old=snapshots.get(key)
   size=len(raw)-(0 if old is None else len(json.dumps(old,sort_keys=True,separators=(',',':')).encode()))
   if len(raw)>1048576 or captured_bytes+size>4*1048576:raise ValueError('Finite original effect witness bound exceeded')
   snapshots[key]=json.loads(raw);captured_bytes+=size
  if frame.f_code is LocalDeltaTransport._snapshot.__code__ and event=='return'and arg is not None:
   target=frame.f_locals['target'];version=frame.f_locals['version'];key=(target.table,version)
   raw=json.dumps(arg,sort_keys=True,separators=(',',':')).encode()
   old=snapshots.get(key);size=len(raw)-(0 if old is None else len(json.dumps(old,sort_keys=True,separators=(',',':')).encode()))
   if len(raw)>1048576 or captured_bytes+size>4*1048576:raise ValueError('Finite full-bag witness bound exceeded')
   snapshots[key]=json.loads(raw);captured_bytes+=size
  if (CASE.name=='fault2'and not injected and effects_depth>0 and event=='line'
      and frame.f_code is LocalDeltaTransport._execute.__code__ and frame.f_lineno==points[0]):
   injected=True;owner=frame.f_locals['self'];operation=frame.f_locals['operation'];metadata=frame.f_locals['metadata'];target=frame.f_locals['target'];before=frame.f_locals['before']
   row=owner.db.execute('SELECT intent,intent_sha,before_version,state,receipt FROM local_operation WHERE operation=?',(operation,)).fetchone()
   if row is None or row[2:]!=(before,'submitted',None):raise AssertionError('Original submitted/null-receipt intent missing')
   native=owner.original_history(target);matches=[x for x in native if x.get('userMetadata')==metadata]
   if len(matches)!=1 or matches[0]['version']!=before+1:raise AssertionError('Original exact native effect commit missing')
   fault_witness={'operation':operation,'intent':json.loads(row[0]),'intent_sha256':row[1],'before_version':before,'journal_state':'submitted','receipt':None,'native_history':native,'target':target.table,'uuid':target.uuid,'metadata':metadata}
   retain(CASE/'postcommit-fault.json',fault_witness)
   raise primary_fault
  return observe
 result=None;primary=None;expected=None
 try:
  sys.settrace(observe)
  try:result=initialize_configured_local(config)if invocation.operation=='initialize'else publish_configured_local(config,ordinal=invocation.ordinal)
  except OriginalEffectResponseLost as error:
   if CASE.name!='fault2'or error is not primary_fault:raise
  finally:sys.settrace(None)
  if CASE.name=='fault2':
   if not injected or fault_witness is None or result is not None:raise AssertionError('Exact one-shot interruption not observed')
   db=sqlite3.connect('file:'+str(config.installation/'operations.sqlite')+'?mode=ro',uri=True)
   try:
    db.execute('PRAGMA query_only=ON')
    rows=db.execute('SELECT operation,intent,state,receipt FROM local_operation WHERE operation=?',(fault_witness['operation'],)).fetchall()
    progress=db.execute('SELECT position FROM jsonl_consumer_progress ORDER BY position').fetchall()
   finally:db.close()
   if len(rows)!=1 or rows[0][2:]!=('submitted',None)or progress!=[(expected_positions[0],)]or set(admitted_checkpoints)!={1,2}:raise AssertionError('Postfault original custody/progress changed')
   request_digest=fault_witness['intent']['request_digest']
   phase_snapshots=[v for (table,version),v in snapshots.items()if table.endswith('.attempts')]
   phase_rows=[row for value in phase_snapshots for row in value['rows']if row.get('request_digest')==request_digest]
   phases={row['phase']for row in phase_rows}
   if phases!={'prepared','applying'}:raise AssertionError('Original interrupted applying phases not fully captured')
   retain(CASE/'witness.json',{'status':'expected-original-response-loss','injections':1,'progress_positions':[expected_positions[0]],'admitted_source_checkpoints':admitted_checkpoints,'phase_names':sorted(phases),'postfault_journal_state':rows[0][2],'postfault_receipt':None,'native_original_commit_observed':True,'snapshots':{table+'@'+str(version):value for (table,version),value in snapshots.items()}})
  elif invocation.operation!='initialize':
   if result is None or result['ordinal']!=invocation.ordinal or result['completed_batches']!=invocation.ordinal or result['protected_ack']is not False:raise AssertionError('Public completion differs')
   # Independent original-source oracle, opened only after public runtime closes.
   # Admission output is fresh and separate; never reuses runtime admission files.
   from dataclasses import replace
   admission=replace(config.admission,output=CASE/'oracle-admission')
   with open_configured_local_source(admission,stream=config.stream,context=object())as source:
    for ordinal in range(1,invocation.ordinal+1):
     if json.loads(source.spec(ordinal,source.context).request()['source_checkpoint_json'])!=expected_checkpoints[ordinal-1]:raise AssertionError('Admitted exact original checkpoint differs')
    expected=configured_prefix_carrier_rows(source.configuration,source.batches[:invocation.ordinal],materialization_clock_us=config.materialization_clock_us,carriers=load_managed_carriers(),maximum_rows=1000).rows()
   versions=json.loads(result['manifest']['table_versions_json']);bags={}
   for role,wanted in expected.items():
    table=next(t for t in versions if t.endswith('.'+role));value=snapshots.get((table,versions[table]))
    if value is None or value['rows']!=sorted(wanted,key=lambda row:json.dumps(row,sort_keys=True,separators=(',',':'))):raise AssertionError('Complete original bag witness missing or differs')
    bags[role]=value
   if bags['tombstone']['rows']!=[]:raise AssertionError('Expected original empty tombstone differs')
   retain(CASE/'witness.json',{'status':'public-completed','result':result,'bags':bags,'original_source_oracle_match':True,'protected_ack':False})
  else:retain(CASE/'witness.json',{'status':'public-initialized','result':result})
 except BaseException as error:primary=error
 finish(primary,[lambda:sys.settrace(None),renew])
 print(json.dumps({'status':'completed','case':CASE.name,'fault_injections':int(injected)}))
if __name__=='__main__':main()
