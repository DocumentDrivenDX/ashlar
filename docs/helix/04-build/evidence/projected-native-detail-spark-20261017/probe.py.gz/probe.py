"""Six paired fresh native identity observations only; no business/source/publication authority."""
from pathlib import Path
import os,json,hashlib,time,datetime,decimal,signal,sys
from ashlar_host.delta_custody import LocalDeltaTransport,LocalDeltaError
from ashlar_host.evolution_verification_types import VerificationBounds
from ashlar_host.lifecycle import finish
R=Path(__file__).resolve().parent;os.umask(0o077)
def encode(value):
 from pyspark.sql import Row
 if value is None or type(value)in(str,int,bool):return value
 if type(value)is datetime.datetime:return {'native_type':'datetime','iso':value.isoformat(timespec='microseconds'),'timezone':'naive'if value.tzinfo is None else str(value.tzinfo)}
 if type(value)is datetime.date:return {'native_type':'date','iso':value.isoformat()}
 if type(value)is decimal.Decimal:return {'native_type':'decimal','token':str(value)}
 if type(value)is bytes:return {'native_type':'bytes','hex':value.hex()}
 if type(value)is Row:return {'native_type':'struct','fields':[[k,encode(v)]for k,v in value.asDict().items()]}
 if type(value)is dict:return {k:encode(v)for k,v in value.items()}
 if type(value)in(list,tuple):return [encode(v)for v in value]
 raise TypeError('Unsupported actual probe carrier')
def retain(name,value):
 raw=(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
 if len(raw)>1048576:raise ValueError('Bounded probe report required')
 fd=os.open(R/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);primary=None
 try:
  if os.write(fd,raw)!=len(raw):raise OSError('Exact probe write required')
  os.fsync(fd)
 except BaseException as e:primary=e
 finish(primary,[lambda:os.close(fd)])
def stop(*args):raise KeyboardInterrupt()
signal.signal(signal.SIGTERM,stop)
def main():
 from pyspark.sql import SparkSession
 selection_raw=(R/'preparation.json').read_bytes();selection=json.loads(selection_raw)
 if selection.get('ready')is not True:raise PermissionError('Reviewed exact installed runtime not selected')
 def renew():
  if (R/'preparation.json').read_bytes()!=selection_raw:raise PermissionError('Original probe selection changed')
  for pin in selection['pins']:
   raw=Path(pin['path']).read_bytes()
   if len(raw)!=pin['bytes']or hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise PermissionError('Original probe pin changed')
 renew();cfg=json.loads((R/'configuration.json').read_bytes())
 if Path(sys.executable)!=Path(cfg['python'])or SparkSession.getActiveSession()is not None:raise PermissionError('Exact fresh installed runtime required')
 target=R/'probe-delta'
 if target.exists()or target.is_symlink():raise PermissionError('Fresh exclusive table required')
 spark=None;primary=None;cases=[];before=None;after=None;startup=time.monotonic()
 keys=('ashlar.local.installation.id','ashlar.local.registry.sha256','ashlar.local.journal.sha256')
 properties=dict(zip(keys,('synthetic-installation','synthetic-registry','synthetic-journal')))
 properties['ashlar.local.probe.unknown']='must-remain-in-full-detail'
 try:
  spark=(SparkSession.builder.master('local[1]').appName('ashlar-projected-detail-probe').config('spark.driver.memory','512m').config('spark.executor.memory','512m').config('spark.ui.enabled','false').config('spark.jars',','.join(cfg['jars'])).config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension').config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog').config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true').config('spark.sql.shuffle.partitions','1').config('spark.databricks.delta.snapshotPartitions','1').getOrCreate())
  startup_seconds=time.monotonic()-startup
  props=','.join("'"+k+"'='"+v+"'"for k,v in properties.items())
  spark.sql('CREATE TABLE delta.`'+str(target)+'` (`id` BIGINT NOT NULL) USING DELTA TBLPROPERTIES ('+props+')')
  def table_facts():
   files=sorted((target/'_delta_log').glob('*.json'))
   if [p.name for p in files]!=['00000000000000000000.json']:raise PermissionError('Exact empty initial history required')
   raw=files[0].read_bytes();actions=[json.loads(line)for line in raw.splitlines()];metadata=[a['metaData']for a in actions if 'metaData'in a];commits=[a['commitInfo']for a in actions if 'commitInfo'in a]
   if len(metadata)!=1 or len(commits)!=1 or any('add'in a or 'remove'in a for a in actions)or commits[0]['operation']!='CREATE TABLE':raise PermissionError('Fresh zero-business-row metadata required')
   schema={'type':'struct','fields':[{'name':'id','type':'long','nullable':False,'metadata':{}}]}
   if json.loads(metadata[0]['schemaString'])!=schema or metadata[0]['configuration']!=properties:raise PermissionError('Original schema/properties differ')
   return {'uuid':metadata[0]['id'],'version':0,'schema':schema,'properties':properties,'log_json_sha256':hashlib.sha256(raw).hexdigest(),'data_add_actions':0}
  before=table_facts();retain('before.json',before)
  from types import SimpleNamespace
  capture=object.__new__(LocalDeltaTransport);capture.spark=spark;capture._registered=False
  capture.observation_bounds=VerificationBounds(262144,2,65536,1048576,1048576,1048576)
  selected=SimpleNamespace(path=target,uuid=before['uuid'])
  # No journal, registry, reservation, source, NativeDriver, policy or authority.
  # Synthetic properties are compared explicitly; no registration grant claimed.
  for pair,order in enumerate(((True,False),(False,True),(True,False))):
   results={}
   for full in order:
    start=time.monotonic();detail=capture._detail(selected,full=full);elapsed=time.monotonic()-start
    if detail['id']!=before['uuid']or any(detail['properties'].get(k)!=properties[k]for k in keys):raise AssertionError('Original identity values differ')
    if full and (detail['properties'].get('ashlar.local.probe.unknown')!=properties['ashlar.local.probe.unknown']or not detail.get('location')):raise AssertionError('Complete original detail lost')
    results[full]={'id':detail['id'],'properties':{k:detail['properties'][k]for k in keys}}
    cases.append({'pair':pair,'mode':'full'if full else'projected','elapsed_seconds':elapsed,'identity_values_equal_expected':True,'full_detail_fields':len(detail)if full else None})
   if results[True]!=results[False]:raise AssertionError('Paired original identity differs')
  after=table_facts();retain('after.json',after)
  if before!=after or len(cases)!=6:raise AssertionError('Original native bytes changed or incomplete observations')
 except BaseException as error:primary=error
 finish(primary,([]if spark is None else[spark.stop])+[renew])
 retain('result.json',{'profile':'ashlar-projected-native-detail-probe/0.1','status':'passed','spark_startup_seconds':startup_seconds,'fresh_detail_calls':6,'cases':cases,'native_metadata_unchanged':before==after,'spark_closing_completed':True,'qualification':'Three alternating full/projected fresh DESCRIBE pairs on one fresh empty synthetic-property table. Native capture bounds unchanged. No warmup, percentiles, cache-control guarantee or workflow speed claim. No journal, installation reservation/authority, publication, source or ACK.'})
 print(json.dumps({'status':'passed','fresh_detail_calls':6,'spark_closing_completed':True}))
if __name__=='__main__':main()
