import time,sys,json
from pathlib import Path
r=Path(__file__).parent;t=time.monotonic();events=[]
def mark(stage):
 event={'stage':stage,'elapsed_seconds':time.monotonic()-t};events.append(event);print(json.dumps(event),flush=True)
mark('builtin_ready')
import psycopg
mark('psycopg_ready')
import jsonschema,referencing
mark('schema_dependencies_ready')
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical'];sys.path[:0]=['/private/tmp/ashlar-truss22-commerce-indexed-settlement-20261013-a/ashlar-target','/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres
mark('truss_ready')
from ashlar_host.truss_indexed_commerce_cli import run_query_truss_commerce_command
mark('commerce_command_ready')
mark('source_open_start')
with LocalPostgres('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a/data') as source:
 mark('source_ready')
mark('source_closed')
(r/'source-result.json').write_text(json.dumps({'outcome':'completed','events':events,'scope':'Existing owned PostgreSQL lifecycle timing only; no mutation, feed ACK, publication, Spark or query.'},indent=2)+'\n')
