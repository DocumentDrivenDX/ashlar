"""Actual corrected byte gate/launcher config, pure no SDK/build/native."""
from pathlib import Path
import json,hashlib,ast,sys,importlib.util,tempfile,types
from unittest.mock import patch
P=Path('/private/tmp');W=P/'ashlar-graphframes-installed-20261010-c'
post=(P/'ashlar-graphframes-installed-postflight-d.py').read_text();prefix=post[:post.index("result={'profile'")];ns={};exec(compile(prefix,'<original-pure-current-postflight>','exec'),ns)
assert (W/'runtime-plan.json').read_bytes()==ns['enc'](ns['original_memory'])
metadata=json.loads((P/'ashlar-graphframes-installed-metadata-e.json').read_bytes());command=P/'ashlar-graphframes-installed-command-e.json';plan=json.loads(command.read_bytes())
for path in metadata['freshOutputs']:assert not Path(path).exists()
for pin in plan['resources']:
 p=Path(pin['path']);raw=p.read_bytes();assert len(raw)==pin['bytes']and hashlib.sha256(raw).hexdigest()==pin['sha256']
approval=json.loads((P/'ashlar-graphframes-installed-continuation-approval-e.json').read_bytes())
for pin in approval['pins']:
 p=Path(pin['path']);raw=p.read_bytes();assert len(raw)==pin['bytes']and hashlib.sha256(raw).hexdigest()==pin['sha256']
runner=ast.parse((P/'ashlar-graphframes-installed-runner-e.py').read_text());main=next(n for n in runner.body if isinstance(n,ast.FunctionDef)and n.name=='main');renew=next(n for n in main.body if isinstance(n,ast.FunctionDef)and n.name=='renew_runtime_plan')
for node in ast.walk(renew):
 if isinstance(node,ast.Compare)and isinstance(node.left,ast.Call)and isinstance(node.left.func,ast.Attribute)and node.left.func.attr=='read_bytes':
  assert isinstance(node.comparators[0],ast.Call)and isinstance(node.comparators[0].func,ast.Name)and node.comparators[0].func.id=='enc'
  # Evaluate actual corrected guard on retained original plan; no file effects.
  assert eval(compile(ast.Expression(node),'<actual-corrected-byte-gate>','eval'),{'plan_path':W/'runtime-plan.json','enc':ns['enc'],'runtime_plan':ns['original_memory']})is False
spec=importlib.util.spec_from_file_location('reviewed_H_E_control',P/'ashlar-supply-chain-native-read-launcher-h.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
seen=[]
def inert(*args):
 c=plan['commands'][0];assert args==(c['argv'],c['cwd'],plan['environment'],c['stdout'],c['stderr'],c['timeoutSeconds'],16*1024*1024);seen.append(True);return {'exitCode':0,'stdoutBytes':0,'stderrBytes':0}
with tempfile.TemporaryDirectory(prefix='ashlar-gf-E-launcher-control-',dir='/private/tmp')as directory:
 with patch.object(sys,'argv',['launcher','--command',str(command),'--sha256',hashlib.sha256(command.read_bytes()).hexdigest(),'--phase','ecology','--receipt',str(Path(directory)/'receipt.json')]),patch.object(module.importlib.util,'spec_from_file_location',return_value=types.SimpleNamespace(loader=types.SimpleNamespace(exec_module=lambda obj:None))),patch.object(module.importlib.util,'module_from_spec',return_value=types.SimpleNamespace(capture=inert)):module.main()
assert seen==[True]
print('PASS exact runtime-plan byte gate/whole original current postflight/continuation pins/fresh ecology/actual H dispatch; no SDK/build/native')
