"""Installed GraphFrames original retained export operation. No PG/network/canonical writes."""
import base64,csv,gzip,hashlib,importlib.util,io,json,os,stat,sys,tarfile,zipfile
from pathlib import Path,PurePosixPath
NAME=sys.argv[1] if len(sys.argv)==2 and sys.argv[1] == 'ecology' else None
if NAME is None:raise ValueError('Closed original query pack required')
WORK=Path('/private/tmp/ashlar-graphframes-installed-20261010-c');REPO=Path('/Users/erik/Projects/ashlar');REV='6ced38ec82b893e4f79e8412687f09adb7178906'
PRIMARY='/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
PY311='/Users/erik/.local/share/uv/python/cpython-3.11.17-macos-aarch64-none/bin/python3.11'
INDEX=Path('/private/tmp/ashlar-count-star-fresh-install-e/checkout/distributions/index.json');ID='weft-5ddcebd-count-star-aarch64-apple-darwin-candidate';PACKAGE=INDEX.parent/'realizations'/ID
BASE=Path('/private/tmp/weft-count-star-build-20261010-b')
ENV={'PYTHONPATH':'/private/tmp/truss-python-report-schema-env/lib/python3.11/site-packages','PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','PIP_CONFIG_FILE':'/dev/null','PIP_DISABLE_PIP_VERSION_CHECK':'1','PIP_NO_CACHE_DIR':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_TERMINAL_PROMPT':'0','GIT_ALLOW_PROTOCOL':'file'}
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return json.dumps(v,separators=(',',':'),sort_keys=True).encode()+b'\n'
def select_failure(primary,closing):
 if primary is None:return closing
 if isinstance(primary,Exception)and not isinstance(closing,Exception):return closing
 return primary

def write(p,b):
 stream=None;primary=None
 try:
  stream=p.open('xb')
  if stream.write(b)!=len(b):raise ValueError('write-refused')
 except BaseException as error:primary=error
 finally:
  if stream is not None:
   try:stream.close()
   except BaseException as error:primary=select_failure(primary,error)
 if primary is not None:raise primary

def bounded_read(p,maximum):
 if p.is_symlink()or not p.is_file()or p.stat().st_size>maximum:raise ValueError('selected-file-bound')
 with p.open('rb')as stream:raw=stream.read(maximum+1)
 if len(raw)>maximum:raise ValueError('selected-file-bound')
 return raw
def safe(name):
 p=PurePosixPath(name)
 if not name or '\\'in name or p.is_absolute()or any(v in ('','..','.')for v in name.split('/')):raise ValueError('member-path')
 return p

CLOSING=[]
def main():
 verify()
 if NAME=='archaeology':WORK.mkdir(mode=0o700);(WORK/'tmp').mkdir()
 else:
  approval=json.loads(Path('/private/tmp/ashlar-graphframes-installed-continuation-approval-e.json').read_bytes())
  for pin in approval['pins']:
   p=Path(pin['path']);raw=p.read_bytes()
   if p.is_symlink()or len(raw)!=pin['bytes']or sha(raw)!=pin['sha256']:raise ValueError('Original reviewed continuation custody changed')
  prior=json.loads(Path('/private/tmp/ashlar-graphframes-installed-20261010-c-archaeology.receipt.json').read_bytes())
  if prior['failureType']!='ValueError'or prior['openingClosingCustody']is not False:raise ValueError('Original failed runner receipt must remain unchanged')
  component=json.loads((WORK/'archaeology-query.json').read_bytes())
  if component['exitCode']!=0:raise ValueError('Original successful installed component required')
 ENV['TMPDIR']=str(WORK/'tmp')
 spec=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
 phases=[];source=WORK/'source';inventory=json.loads(Path('/private/tmp/ashlar-graphframes-installed-source-inventory-c.json').read_bytes());rows={r['path']:r for r in inventory['files']}
 if inventory['revision']!=REV:raise ValueError('source-revision')
 def run(label,argv,timeout=30,maximum=4*1024*1024,stdin=None,cwd=None):
  out=WORK/(label+'.stdout');err=WORK/(label+'.stderr');result=capture.capture(argv,str(cwd or WORK),ENV,str(out),str(err),timeout,maximum,str(stdin)if stdin else None)
  record={'phase':label,**result,'stdoutSha256':sha(out.read_bytes()),'stderrSha256':sha(err.read_bytes())};phases.append(record);write(WORK/(label+'.json'),enc(record))
  if result['exitCode']:raise ValueError('phase-refused:'+label)
  return out.read_bytes()
 if NAME=='archaeology':run('archive',['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','tar.umask=0002','-C',str(REPO),'archive','--format=tar',REV,'src','pyproject.toml','README.md'],maximum=16*1024*1024)
 if NAME=='archaeology':source.mkdir()
 seen=set();decoded=0
 with tarfile.open(WORK/'archive.stdout','r:')as tar:
  members=tar.getmembers()
  if len(members)>512:raise ValueError('source-member-bound')
  names=set()
  for m in members:
   name=m.name.rstrip('/')if m.isdir()else m.name;safe(name)
   if name in names:raise ValueError('source-duplicate')
   names.add(name)
   if m.isdir():
    if not any(p.startswith(name+'/')for p in rows):raise ValueError('source-directory')
    continue
   if not m.isfile()or name not in rows:raise ValueError('source-extra')
   r=rows[name];decoded+=m.size
   if decoded>8*1024*1024 or m.size!=r['bytes']:raise ValueError('source-bound')
   raw=tar.extractfile(m).read(r['bytes']+1)
   if len(raw)!=r['bytes']or sha(raw)!=r['sha256']or m.mode&0o777!=(0o775 if r['gitMode']=='100755'else 0o664):
    # Git archive uses umask-independent 0664/0775 payload permissions.
    raise ValueError('source-custody')
   p=source/name;p.parent.mkdir(parents=True,exist_ok=True)
   if NAME=='archaeology':write(p,raw);p.chmod(0o755 if r['gitMode']=='100755'else 0o644)
   elif p.is_symlink()or p.read_bytes()!=raw:raise ValueError('Existing serial source changed')
   seen.add(name)
 if seen!=set(rows):raise ValueError('source-closure')
 def source_custody():
  for name,r in rows.items():
   p=source/name;b=p.read_bytes()
   if p.is_symlink()or len(b)!=r['bytes']or sha(b)!=r['sha256']:raise ValueError('source-closing-custody')
 CLOSING.append(source_custody)
 source_custody()
 if NAME=='archaeology':(WORK/'wheels').mkdir()
 if NAME=='archaeology':run('wheel',[PRIMARY,'-B','-I','-m','pip','wheel','--no-deps','--no-build-isolation','--no-index','--wheel-dir',str(WORK/'wheels'),str(source)],timeout=60)
 wheels=list((WORK/'wheels').iterdir())
 if len(wheels)!=1 or wheels[0].is_symlink()or wheels[0].suffix!='.whl'or wheels[0].stat().st_size>8*1024*1024:raise ValueError('wheel-selection')
 wheel=wheels[0];expected={name[4:]:r for name,r in rows.items()if name.startswith('src/')and name!='src/ashlar/README.md'};payload={};metadata={};total=0;names=set()
 with zipfile.ZipFile(wheel)as archive:
  infos=archive.infolist()
  if len(infos)>512:raise ValueError('wheel-member-bound')
  for info in infos:
   name=info.filename;safe(name);mode=info.external_attr>>16
   if name in names or info.flag_bits&1 or stat.S_IFMT(mode)not in (0,stat.S_IFREG)or info.is_dir():raise ValueError('wheel-member-shape')
   names.add(name);total+=info.file_size
   if total>16*1024*1024:raise ValueError('wheel-decoded-bound')
   raw=archive.read(info)
   if name in expected:
    r=expected[name]
    if len(raw)!=r['bytes']or sha(raw)!=r['sha256']:raise ValueError('wheel-source')
    payload[name]=raw
   elif name.startswith('ashlar_graph_toolkit-0.1.0.dev0.dist-info/')and name.rsplit('/',1)[1]in ('METADATA','WHEEL','entry_points.txt','top_level.txt','RECORD'):metadata[name]=raw
   else:raise ValueError('wheel-extra')
 if set(payload)!=set(expected)or len(metadata)!=5:raise ValueError('wheel-closure')
 if metadata['ashlar_graph_toolkit-0.1.0.dev0.dist-info/entry_points.txt']!=b'[console_scripts]\nashlar = ashlar.cli:main\n':raise ValueError('wheel-entrypoint')
 if NAME=='archaeology':write(WORK/'wheel-inventory.json',enc({'wheel':wheel.name,'bytes':wheel.stat().st_size,'sha256':sha(wheel.read_bytes()),'members':[{'path':n,'bytes':len(b),'sha256':sha(b)}for n,b in sorted({**payload,**metadata}.items())]}))
 if NAME=='archaeology':run('venv',[PY311,'-B','-I','-m','venv','--copies','--without-pip',str(WORK/'venv')])
 venv=WORK/'venv';python=venv/'bin/python';site=venv/'lib/python3.11/site-packages'
 def interpreter():
  if any((venv/'bin'/name).is_symlink()or sha((venv/'bin'/name).read_bytes())!=sha(Path(PY311).read_bytes())for name in ('python','python3','python3.11'))or 'include-system-site-packages = false'not in (venv/'pyvenv.cfg').read_text():raise ValueError('venv-selection')
 CLOSING.append(interpreter)
 interpreter()
 if NAME=='archaeology':run('pip-install',[PRIMARY,'-B','-I','-m','pip','--python',str(python),'install','--no-deps','--no-index','--no-compile',str(wheel)],timeout=60)
 interpreter()
 for name,b in payload.items():
  p=site/name
  if p.is_symlink()or p.read_bytes()!=b:raise ValueError('installed-source-correspondence')
 console=venv/'bin/ashlar'
 console_bytes=console.read_bytes()
 if not console_bytes.startswith(('#!'+str(python)+'\n').encode())or b'from ashlar.cli import main\n'not in console_bytes:raise ValueError('console-entrypoint')
 if NAME=='archaeology':write(WORK/'installed-console.txt',console_bytes)
 record_path=site/'ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD';record_bytes=record_path.read_bytes()
 if len(record_bytes)>128*1024:raise ValueError('installed-record-bound')
 if NAME=='archaeology':write(WORK/'installed-RECORD.csv',record_bytes)
 def installed_custody():
  if console.is_symlink()or console.read_bytes()!=console_bytes:raise ValueError('console-closing-custody')
  for name,b in metadata.items():
   if name.endswith('/RECORD'):continue
   if (site/name).is_symlink()or (site/name).read_bytes()!=b:raise ValueError('installed-metadata-correspondence')
  if record_path.read_bytes()!=record_bytes:raise ValueError('installed-record-custody')
  entries=list(csv.reader(io.StringIO(record_bytes.decode('utf-8'))));seen_record=set()
  if len(entries)>512:raise ValueError('installed-record-members')
  for entry in entries:
   if len(entry)!=3 or entry[0]in seen_record:raise ValueError('installed-record-shape')
   name,digest,size=entry;seen_record.add(name);path=site/name
   if name!='../../../bin/ashlar':safe(name)
   if path.is_symlink()or not path.is_file()or not path.resolve().is_relative_to(venv):raise ValueError('installed-record-path')
   raw=path.read_bytes()
   if name=='ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD':
    if digest or size:raise ValueError('installed-record-self')
   elif digest!='sha256='+base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).rstrip(b'=').decode()or size!=str(len(raw)):raise ValueError('installed-record-hash')
  if not set(payload).issubset(seen_record)or '../../../bin/ashlar'not in seen_record:raise ValueError('installed-record-closure')
 CLOSING.append(installed_custody)
 installed_custody()
 def generated_inventory():
  result={};total=0
  for selected in (source,WORK/'wheels',venv):
   for path in selected.rglob('*'):
    if path.is_symlink():
     # The private venv has explicit interpreter links, checked independently.
     if path.parent!=venv/'bin' or path.name not in ('python','python3','python3.11'):raise ValueError('Unexpected generated link')
     continue
    if path.parent==venv/'bin'and path.name in ('python','python3','python3.11'):continue # separately exact all-copy interpreter custody
    if '__pycache__'in path.parts or path.suffix=='.pyc':raise ValueError('Generated package cache namespace must remain absent')
    if path.is_file():
     raw=bounded_read(path,8*1024*1024);total+=len(raw)
     if total>16*1024*1024 or len(result)>=1024:raise ValueError('Generated package custody bound')
     result[str(path)]={'bytes':len(raw),'sha256':sha(raw)}
  return result
 if NAME=='archaeology':write(site/'selected-sdk.pth',b'/private/tmp/ashlar-spark311/lib/python3.11/site-packages\n')
 generated=generated_inventory();seal=WORK/'generated-custody.json'
 if NAME=='archaeology':write(seal,enc(generated))
 elif json.loads(bounded_read(seal,1048576))!=generated:raise ValueError('Original serial installed package changed')
 def renew_generated():
  if generated_inventory()!=generated or json.loads(bounded_read(seal,1048576))!=generated:raise ValueError('Installed closing generated custody changed')
 CLOSING.append(renew_generated)

 JAVA='/private/tmp/ashlar-db-client/lib/python3.9/site-packages/jdk4py/java-runtime'
 SDK=Path('/private/tmp/ashlar-spark311/lib/python3.11/site-packages');BASEPY=Path(PY311).resolve().parent.parent
 ENV.pop('PYTHONPATH',None)
 ENV.update({'PATH':JAVA+'/bin:/usr/bin:/bin','JAVA_HOME':JAVA,'PYSPARK_PYTHON':str(python),'PYSPARK_DRIVER_PYTHON':str(python),'SPARK_LOCAL_IP':'127.0.0.1','SPARK_LOCAL_HOSTNAME':'localhost'})
 # Existing four selected cached JARs only; no repository/download.
 jar_dir=WORK/'jars'
 jar_names=['io.delta_delta-spark_2.12-3.2.1.jar','io.delta_delta-storage-3.2.1.jar','io.graphframes_graphframes-graphx-spark3_2.12-0.12.3.jar','io.graphframes_graphframes-spark3_2.12-0.12.3.jar']
 if NAME=='archaeology':
  jar_dir.mkdir()
  for name in jar_names:write(jar_dir/name,Path('/private/tmp/ashlar-scale-ivy/jars',name).read_bytes());(jar_dir/name).chmod(0o400)
 def descriptors(root):
  result={}
  for p in sorted(root.rglob('*')):
   if p.is_file():
    q=p.resolve();result[str(q)]={'path':str(q),'sha256':sha(q.read_bytes()),'size':q.stat().st_size}
  return [result[k]for k in sorted(result)]
 sdk_parts={}
 for name,dirs in [('pyspark',['pyspark','pyspark-3.5.3.dist-info']),('delta-spark',['delta','delta_spark-3.2.1.dist-info']),('graphframes-py',['graphframes','graphframes_py-0.12.3.dist-info'])]:
  sdk_parts[name]=sorted([row for d in dirs for row in descriptors(SDK/d)],key=lambda row:row['path'])
 named={row['path']for rows in sdk_parts.values()for row in rows}
 transitive={row['path']:row for row in descriptors(BASEPY)+descriptors(SDK)if row['path']not in named}
 for p in [venv/'pyvenv.cfg',*sorted((venv/'bin').iterdir())]:
  if p.is_file():transitive[str(p.resolve())]={'path':str(p.resolve()),'sha256':sha(p.read_bytes()),'size':p.stat().st_size}
 sdk_parts['transitive-imports']=[transitive[k]for k in sorted(transitive)]
 worker=descriptors(site)
 roots={str(p):descriptors(p)for p in (site,SDK,BASEPY)}
 def namespace(root):
  return [{'path':str(p),'kind':'link'if p.is_symlink()else 'file'if p.is_file()else 'directory'if p.is_dir()else 'refused',**({'target':os.readlink(p),'resolved':str(p.resolve())}if p.is_symlink()else {})}for p in sorted(root.rglob('*'))]
 namespaces={str(p):namespace(p)for p in (site,SDK,BASEPY)}
 links=[{'path':str(p),'target':os.readlink(p),'resolved':str(p.resolve())}for root in (site,SDK,BASEPY)for p in sorted(root.rglob('*'))if p.is_symlink()]
 runtime_plan={'worker':worker,'sdks':list(sdk_parts.items()),'roots':roots,'namespaces':namespaces,'symlinks':links,'sys_path':[str(BASEPY/'lib/python311.zip'),str(BASEPY/'lib/python3.11'),str(BASEPY/'lib/python3.11/lib-dynload'),str(site),str(SDK)]}
 plan_path=WORK/'runtime-plan.json'
 if NAME=='archaeology':write(plan_path,enc(runtime_plan))
 elif plan_path.read_bytes()!=enc(runtime_plan):raise ValueError('Original complete serial runtime inventory changed')
 def renew_runtime_plan():
  for root,records in namespaces.items():
   if namespace(Path(root))!=records:raise ValueError('Complete import namespace changed')
  for root,records in roots.items():
   if descriptors(Path(root))!=records:raise ValueError('Complete selected startup/runtime closure changed')
  if plan_path.read_bytes()!=enc(runtime_plan):raise ValueError('Runtime plan changed')
 CLOSING.append(renew_runtime_plan)
 provider_original=Path('/private/tmp/ashlar-graphframes-installed-provider-c.py').read_bytes()
 provider=WORK/'provider.py'
 if NAME=='archaeology':write(provider,provider_original)
 elif provider.read_bytes()!=provider_original:raise ValueError('Original operator code changed')
 trusted=json.loads(Path('/private/tmp/ashlar-graphframes-installed-export-plan-c.json').read_bytes())
 if NAME=='archaeology':write(WORK/'operator-plan.json',enc(trusted))
 elif json.loads((WORK/'operator-plan.json').read_bytes())!=trusted:raise ValueError('Original operator scopes changed')
 original=REPO/'examples/domain-packs'/NAME/'upstream';selected=trusted['packs'][NAME]
 custody=WORK/(NAME+'-custody.json')
 if NAME=='archaeology':
  for pack,selection in trusted['packs'].items():
   compressed=Path(selection['compressed_custody']).read_bytes();raw=gzip.decompress(compressed)
   if len(raw)!=selection['custody_bytes']or sha(raw)!=selection['custody_sha256']:raise ValueError('Original whole custody decompression differs')
   write(WORK/(pack+'-custody.json'),raw)
 output=WORK/(NAME+'-output')
 runtime={'python':str(python),'python_sha256':sha(python.read_bytes()),'java_home':JAVA,'java_sha256':sha(Path(JAVA,'bin/java').read_bytes()),'worker_revision':REV,'worker_inventory_sha256':sha(json.dumps(worker,sort_keys=True,separators=(',',':')).encode()),'sdk_inventory_sha256':sha(json.dumps(sdk_parts,sort_keys=True,separators=(',',':')).encode()),'jars':str(jar_dir),'timeout_seconds':300,'maximum_stream_bytes':1048576,'maximum_evidence_bytes':16777216}
 config={'profile':'ashlar-graphframes-invocation/0.1','mode':'protected-ack-export','pack':str(original/'pack.json'),'release':selected['release'],'release_sha256':selected['release_sha256'],'custody':str(custody),'custody_sha256':selected['custody_sha256'],'output':str(output),'runtime':runtime}
 write(WORK/(NAME+'-invocation.json'),enc(config))
 # Actual isolated installed console and operator interface; no semantic monkeypatch.
 run(NAME+'-query',[str(python),'-I','-B',str(console),'query-graphframes','--configuration',str(WORK/(NAME+'-invocation.json')),'--provider',str(provider),'--provider-sha256',sha(provider_original)],timeout=360,maximum=16*1024*1024)
 report=json.loads(bounded_read(output/'report.json',16777216));result=report['result']
 expected=[{'id':case['id'],'sql':case['sql']}for case in json.loads((original/'pack.json').read_bytes())['scenario_checks']]
 if [r['original_scenario']for r in result['cases']]!=expected or result['all_original_cases_passed']!=len(expected):raise ValueError('Complete unchanged original scenario report required')
 if len(list(output.glob('observation-*.json')))!=report['observations']:raise ValueError('Complete raw observation inventory required')
 for action in CLOSING:action()
 write(WORK/(NAME+'-result.json'),enc({'pack':NAME,'revision':REV,'originalCases':len(expected),'scope':'Actual installed GraphFrames over independently admitted retained protected ACK export; full original cases/common carriers/derived Delta0 evidence. No canonical current availability, PG, cloud or republication claim.'}))
CLOSURE=Path('/private/tmp/ashlar-graphframes-installed-closure-e.json')
CLOSURE_SHA='4db0107a31674df3a5ed8489a6f9a56eb32d0899ff8bf08f35e73973c1cbe733'
def verify():
 raw=CLOSURE.read_bytes()
 if sha(raw)!=CLOSURE_SHA:raise ValueError('Closed selected custody inventory pin')
 plan=json.loads(raw)
 for absent in plan['absent_startup_paths']:
  if Path(absent).exists():raise ValueError('Selected startup path changed')
 actual_links=[{'path':str(p),'target':os.readlink(p),'resolved':str(p.resolve())}for root in plan['roots']for p in sorted(Path(root).rglob('*'))if p.is_symlink()]
 if actual_links!=plan['symlinks']:raise ValueError('Complete selected dependency link namespace changed')
 for link in plan['symlinks']:
  p=Path(link['path'])
  if not p.is_symlink()or os.readlink(p)!=link['target']or str(p.resolve())!=link['resolved']:raise ValueError('Selected dependency link changed')
 for root in plan['roots']:
  actual={str(p.resolve())for p in Path(root).rglob('*')if p.is_file()}
  expected={p for p in plan['files']if p.startswith(str(Path(root).resolve())+'/')}
  if actual!=expected:raise ValueError('Complete selected inventory changed')
 if len(plan['files'])>12000 or sum(v['bytes']for v in plan['files'].values())>800*1024*1024:raise ValueError('Selected custody bound')
 for name,pin in plan['files'].items():
  p=Path(name)
  if p.is_symlink()or not p.is_file()or p.stat().st_size!=pin['bytes']:raise ValueError('Selected file shape changed')
  h=hashlib.sha256()
  with p.open('rb')as stream:
   for block in iter(lambda:stream.read(262144),b''):h.update(block)
  if h.hexdigest()!=pin['sha256']:raise ValueError('Selected custody changed')
def guarded():
 primary=None;closing=True
 try:main()
 except BaseException as error:primary=error
 for action in [*CLOSING,verify]:
  try:action()
  except BaseException as error:closing=False;primary=select_failure(primary,error)
 outcome=Path('/private/tmp/ashlar-graphframes-installed-20261010-c-'+NAME+'.receipt.json')
 try:write(outcome,enc({'pack':NAME,'openingClosingCustody':closing,'failureType':None if primary is None else type(primary).__name__,'sourceRevision':REV}))
 except BaseException as error:primary=select_failure(primary,error)
 if primary is not None:raise primary
if __name__=='__main__':guarded()
