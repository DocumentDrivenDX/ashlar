"""Pinned operator diagnostics around the unchanged public verification CLI."""
import os,sys,json,signal,faulthandler,hashlib,runpy,importlib.util
from pathlib import Path
from ashlar_host.lifecycle import finish,owned_context
R=Path(__file__).resolve().parent
original=(R/'preparation.json').read_bytes();selection=json.loads(original)
def renew():
 if (R/'preparation.json').read_bytes()!=original:raise PermissionError('Original operator selection changed')
 for pin in selection['pins']:
  raw=Path(pin['path']).read_bytes()
  if len(raw)!=pin['bytes']or hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise PermissionError('Original operator input changed')
renew();os.environ.update(json.loads((R/'operator-environment.json').read_bytes()))
boot=json.loads((R.parent/'native-bootstrap-control-r2/bootstrap-selection.json').read_bytes())
os.environ['JAVA_HOME']=boot['java_home'];os.environ['PYSPARK_PYTHON']=sys.executable;os.environ['PYSPARK_DRIVER_PYTHON']=sys.executable;os.environ['SPARK_LOCAL_IP']='127.0.0.1'
helper_path=R/'trace_native_verification.py';spec=importlib.util.spec_from_file_location('pinned_native_verification_trace',helper_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
owner=helper.NativeVerificationTrace(R/'trace.json')
def native_files():
 metadata=json.loads((R.parent/'native-bootstrap-control-r2/native-installation.json').read_bytes());result={}
 for target in metadata['targets']:
  directory=Path(target['path'])
  if directory.is_symlink()or not directory.is_dir():raise PermissionError('Actual original table directory required')
  entries={}
  for path in sorted(directory.rglob('*')):
   if path.is_symlink():raise PermissionError('Native table symlink refused')
   if not path.is_file():continue
   before=path.stat();digest=hashlib.sha256()
   with path.open('rb')as stream:
    for block in iter(lambda:stream.read(65536),b''):digest.update(block)
   after=path.stat()
   if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):raise PermissionError('Native file changed while observed')
   entries[str(path.relative_to(directory))]={'bytes':after.st_size,'sha256':digest.hexdigest()}
  result[target['table']]={'uuid':target['uuid'],'path':str(directory),'files':entries}
 return result
def write_record(name,value):
 raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
 if len(raw)>1048576:raise ValueError('Bounded operator observation required')
 fd=os.open(R/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);error=None
 try:
  if os.write(fd,raw)!=len(raw):raise OSError('Exact operator observation write required')
  os.fsync(fd)
 except BaseException as failure:error=failure
 finish(error,[lambda:os.close(fd)])
before_native=native_files();write_record('native-before.json',before_native)
# Keep native/JVM fd1 output on bounded stderr; Python CLI JSON retains its
# independently duplicated original stdout pipe. No separate unbounded log file.
original_stdout=sys.stdout;public_stdout=os.fdopen(os.dup(1),'w',encoding='utf-8',buffering=1)
os.dup2(2,1);sys.stdout=public_stdout
sys.argv=['ashlar','read-commerce-evolution-singletons','--configuration',str(R/'configuration.json'),'--provider',str(R/'provider.py'),'--provider-sha256',hashlib.sha256((R/'provider.py').read_bytes()).hexdigest(),'--kind','object','--type-id','16','--entity-id','3']
def terminate(signum,frame):raise KeyboardInterrupt()
signal.signal(signal.SIGTERM,terminate)
primary=None;returned=False;closing_pins=False
try:
 with owned_context((R/'private-stack.txt').open('x'))as stream:
  faulthandler.enable(file=stream);faulthandler.dump_traceback_later(240,file=stream,repeat=False)
  body=None
  try:
   with owner:runpy.run_module('ashlar',run_name='__main__')
   returned=True
  except BaseException as error:body=error
  finish(body,[faulthandler.cancel_dump_traceback_later])
 if returned:
  answer=json.loads((R/'singleton-receipt.json').read_bytes())
  assert answer['profile']=='ashlar-original-two-source-singleton/0.1'and answer['ordinal']==2
  assert (answer['kind'],answer['type_id'],answer['entity_id'])==('object',16,3)
  assert answer['original_sha256']=='6e466770c8973b3c3104b48924c2e3e4c954745e63c054e0a14817299bc674ed'
  expected=json.loads((R/'expected-rows.json').read_bytes())
  assert [record['source_system']for record in answer['records']]==['A','B']
  assert [record['row']for record in answer['records']]==expected
  assert expected[0]['source_system']!=expected[1]['source_system']and expected[0]['props_json']!=expected[1]['props_json']and expected[0]['entity_version']!=expected[1]['entity_version']

except BaseException as error:primary=error
def close_pins():
 global closing_pins
 renew();closing_pins=True
def close_native():
 after=native_files();write_record('native-after.json',after)
 if before_native!=after:raise PermissionError('Persistent original native table bytes changed')
def restore_stdout():
 os.dup2(public_stdout.fileno(),1);sys.stdout=original_stdout
def retain_diagnostic():
 # Observer/report errors never discharge guards or replace an ordinary CLI
 # outcome. Cancellation remains BaseException-transparent through finish.
 fd=None;error=None
 try:
  raw=(json.dumps({'profile':'ashlar-operator-trace-runner-result/0.1','diagnostic_failed':owner.diagnostic_failed,'public_cli_returned':returned,'primary_error_class':None if primary is None else type(primary).__name__,'closing_pins_completed':closing_pins},sort_keys=True)+'\n').encode()
  if len(raw)>4096:raise ValueError('Bounded diagnostic result required')
  fd=os.open(R/'runner-result.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  if os.write(fd,raw)!=len(raw):raise OSError('Exact diagnostic write required')
  os.fsync(fd)
 except BaseException as failure:error=failure
 try:finish(error,[]if fd is None else[lambda:os.close(fd)])
 except Exception:pass
finish(primary,[close_native,close_pins,retain_diagnostic,public_stdout.flush,restore_stdout,public_stdout.close])
