"""Prepare controls only from actual completed source seed/native bootstrap receipts."""
from pathlib import Path
import json,hashlib,os
R=Path(__file__).parent;ROOT=R.parent
BOOT=ROOT/'native-bootstrap-control-r2'
def main():
 os.umask(0o077)
 seed=json.loads((ROOT/'seed-attempt/result.json').read_bytes());assert seed['seeded_original_batches']==8
 native=json.loads((BOOT/'native-installation.json').read_bytes());assert native['all_closing_completed']is True and native['installation_id']=='combined-source-current-20261017-r2'
 env=json.loads((BOOT/'native-environment.json').read_bytes());inventory=json.loads((ROOT/'postgres-inventory/inventory.json').read_bytes());bootstrap=json.loads((BOOT/'bootstrap-selection.json').read_bytes())
 assert len(native['targets'])==6
 env['ASHLAR_DELTA_JARS']=','.join(bootstrap['jars'])
 for source in inventory['sources']:
  label=source['scope']['feed'];prefix='ASHLAR_'+label+'_';scope=source['scope'];endpoint=inventory['endpoint']
  env.update({prefix+k:v for k,v in {'SERVICE_SCHEMA':scope['service_schema'],'SCOPE_ID':scope['scope_id'],'ACK_INSTALLATION_ID':scope['installation_id'],'CONSUMER':scope['consumer'],'FEED':label,'EPOCH':scope['epoch'],'SOURCE_SCHEMA':source['schema'],'SOURCE_SIGNATURE_SHA256':source['binding']['source_signature_sha256'],'SOURCE_ROLE':source['reader_role'],'ACK_ROLE':source['ack_role'],'DATABASE':endpoint['database'],'SOURCE_DSN':'host=127.0.0.1 port=25436 dbname=ashlar_current user='+source['reader_role']+' passfile=/dev/null sslmode=disable gssencmode=disable connect_timeout=3','ACK_DSN':'host=127.0.0.1 port=25436 dbname=ashlar_current user='+source['ack_role']+' passfile=/dev/null sslmode=disable gssencmode=disable connect_timeout=3'}.items()})
 clocks=[['2026-10-17T12:00:0'+str(i)+'+00:00'for i in range(4)],['2026-10-17T12:00:1'+str(i)+'+00:00'for i in range(4)]]
 request={'source_order':['A','B'],'stream':'combined-source-current-20261017-r2','predecessor':'empty-combined-source-current-20261017-r2','clocks':clocks,'publication_ids':['combined-source-current-20261017-r2-'+str(i)for i in range(1,9)],'recorded_at':[str(1792238400000000+i)for i in range(8)]}
 config={'profile':'ashlar-commerce-evolution-invocation/0.1','mode':'fresh','through_ordinal':2,'ledger_path':str(ROOT/'native-r2/run.sqlite'),'receipt_path':str(R/'prefix-receipt.json'),'producer':{'source':'/private/tmp/ashlar-combined-evolution-e44-20261014-mo9wk6_y/producer','bun':'/private/tmp/ashlar-bun-1.4.2-original-20261017/bun','git':'/usr/bin/git','timeout_seconds':60,'maximum_output_bytes':1048576,'maximum_receipt_bytes':4194304},'request':request}
 for name,value in [('operator-environment.json',env),('configuration.json',config)]:
  with (R/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
 pins=[]
 for p in [BOOT/'native-installation.json',BOOT/'native-environment.json',ROOT/'seed-attempt/result.json',ROOT/'source-admission-r2/capture-inventory.json',R/'configuration.json',R/'operator-environment.json',R/'provider.py',R/'run-installed.py',R/'supervise.py']:
  b=p.read_bytes();pins.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 with (R/'preparation.json').open('x')as f:json.dump({'prepared_only':True,'commit':'cf3e9028a0252b8504475763d1d757238e626a2e','pins':pins,'command':[bootstrap['python'],'-I','-B',str(R/'supervise.py')],'bound_seconds':180,'complete_original_schedule':8,'publication_prefix':3},f,indent=2)
if __name__=='__main__':main()
