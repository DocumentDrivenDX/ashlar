"""Pinned command custody around normal installed public CLI dispatch."""
import argparse,hashlib,json,sys
from pathlib import Path

def read(path,expected):
    stream=path.open('rb');primary=None;raw=None
    try:
        raw=stream.read(1048577)
        if len(raw)>1048576 or hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('Externally selected command required')
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:
        if primary is None or isinstance(primary,Exception)and not isinstance(error,Exception):primary=error
    if primary is not None:raise primary
    return raw

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--command',required=True,type=Path);parser.add_argument('--sha256',required=True);args=parser.parse_args();raw=read(args.command,args.sha256);command=json.loads(raw);primary=None
    try:
        sys.argv=command['queryArgv']
        from ashlar.cli import main
        main()
    except BaseException as error:primary=error
    try:
        if read(args.command,args.sha256)!=raw:raise ValueError('Selected command changed')
    except BaseException as error:
        if primary is None or isinstance(primary,Exception)and not isinstance(error,Exception):primary=error
    if primary is not None:raise primary
if __name__=='__main__':main()
