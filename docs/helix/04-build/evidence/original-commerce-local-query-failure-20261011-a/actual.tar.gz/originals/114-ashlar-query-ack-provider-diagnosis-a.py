import hashlib,importlib.util,json,sys
from pathlib import Path
from unittest import mock
sys.path.insert(0,'/Users/erik/Projects/ashlar/src')
p=Path('/private/tmp/ashlar-original-commerce-local-query-prep-a/test-preparation-a.py')
spec=importlib.util.spec_from_file_location('inert_query_controls',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
config=m.Tests().config();ports=m.provider.selected(config);calls=[];sentinel=object()
from dataclasses import replace
registration=replace(ports.registration,metadata_factory=lambda context:(calls.append(context),sentinel)[1])
ports=replace(ports,registration=registration)
with mock.patch.object(m.provider,'selected',return_value=ports):
    factory=m.provider.ordinary_query_connection_factory(config)
    try:factory.open(registration.ack_role)
    except AttributeError as error:
        assert calls==[]
        result={'stage':'valid-selected-ack-callback','exceptionType':type(error).__name__,'metadataFactoryCalls':0,'registrationHasConnectionFactory':hasattr(registration,'connection_factory'),'registrationHasMetadataFactory':hasattr(registration,'metadata_factory'),'providerSha256':hashlib.sha256(Path('/private/tmp/ashlar-original-commerce-local-query-prep-a/provider-a.py').read_bytes()).hexdigest(),'nativeOrPostgresEffects':False}
    else:raise AssertionError('Original defect not reproduced')
print(json.dumps(result,sort_keys=True))
