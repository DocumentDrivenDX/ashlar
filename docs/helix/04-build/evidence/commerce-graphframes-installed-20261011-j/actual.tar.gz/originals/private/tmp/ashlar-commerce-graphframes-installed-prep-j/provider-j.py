"""Explicit selected original-fixture ports; no setup, discovery or environment."""
import json
from pathlib import Path
from ashlar_host.ack import AckScope
from ashlar_host.lifecycle import owned_context
from ashlar_host.source_sessions import OutboxSourceRegistration
from ashlar_host.existing_outbox_authority import OutboxAuthorityRegistration
from ashlar_host.commerce_publication_sources import OriginalCommerceSourcePorts,FEED,EPOCH
from ashlar_host.commerce_query_sources import CommerceQuerySourceFactory
from ashlar_host.ordinary_query_connection import OrdinaryQueryConnectionFactory
SETTINGS=Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/settings-j.json')

def selected():
    def load(path):
        with owned_context(path.open('rb')) as stream:raw=stream.read(1024*1024+1)
        if len(raw)>1024*1024:raise ValueError('Bounded explicit metadata required')
        def pairs(items):
            value={}
            for key,item in items:
                if key in value:raise ValueError('Duplicate metadata key')
                value[key]=item
            return value
        return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda value:(_ for _ in ()).throw(ValueError('Nonfinite metadata')))
    settings=load(SETTINGS)
    inventory=load(Path(settings['fixture_inventory']))
    if inventory['format']!='ashlar-private-outbox-fixture/0.1' or inventory['authentication']!='isolated-loopback-trust':raise ValueError('Explicit development fixture required')
    if len(inventory['sources'])!=2:raise ValueError('Closed two-scope fixture required')
    selected=[item for item in inventory['sources'] if item['scope']['feed']==FEED and item['scope']['epoch']==EPOCH]
    if len(selected)!=1:raise ValueError('One exact original source required')
    source=selected[0];scope=AckScope(**source['scope'])
    if scope.feed!=FEED or scope.epoch!=EPOCH:raise ValueError('Original feed/epoch required')
    endpoint=inventory['endpoint']
    if endpoint!={'host':'127.0.0.1','port':settings['postgres_port'],'database':'truss_e2e'}:raise ValueError('Selected original endpoint differs')
    return settings,inventory,source,scope

def open_role(role):
    settings,inventory,source,scope=selected()
    if type(role) is not str or role not in (source['writer_role'],source['reader_role'],source['ack_role']):raise ValueError('Closed original ordinary role required')
    import psycopg
    return psycopg.connect(host='127.0.0.1',port=settings['postgres_port'],dbname='truss_e2e',user=role,password='',passfile='/dev/null',sslmode='disable',gssencmode='disable',options='-c statement_timeout=15000 -c lock_timeout=5000',connect_timeout=5,autocommit=False)

def registration():
    settings,inventory,s,scope=selected()
    source=OutboxSourceRegistration(scope,s['schema'],s['binding']['source_signature_sha256'],lambda context:open_role(s['reader_role']))
    return OutboxAuthorityRegistration(source,s['reader_role'],s['ack_role'],'truss_e2e',lambda context:open_role(s['ack_role']))

def publication_ports():
    settings,inventory,s,scope=selected()
    return OriginalCommerceSourcePorts(registration(),s['writer_role'],lambda context:open_role(s['writer_role']))

def ordinary_query_connection_factory(config):
    settings,inventory,s,scope=selected()
    endpoint=config.postgres
    if (endpoint.container,endpoint.host,endpoint.port,endpoint.database)!=(inventory['container'],'127.0.0.1',settings['postgres_port'],'truss_e2e'):raise ValueError('Explicit query endpoint correspondence required')
    return OrdinaryQueryConnectionFactory(open_role)

def commerce_query_source_factory(config):
    ordinary_query_connection_factory(config)
    return CommerceQuerySourceFactory(registration())

from contextlib import contextmanager
from ashlar_host.graphframes_release import GraphFramesRuntimeInventory,GraphFramesRuntimeFile
from ashlar_host.commerce_graphframes_release import CommerceGraphFramesSession
from ashlar_host.publication_reader import open_commerce_reader,ReaderCleanupState
from ashlar_host.lifecycle import finish
import hashlib,os,stat,importlib.util
from ashlar_host.puppy_release_cli import directory_identity,retain
PLAN=Path('/private/tmp/ashlar-commerce-graphframes-installed-20261011-j/runtime-plan.json')
def namespace(root):
    return [(str(p), 'link' if p.is_symlink() else 'file' if p.is_file() else 'directory', os.readlink(p) if p.is_symlink() else None) for p in sorted(root.rglob('*'))]
class RuntimePolicy:
    def __init__(self):
        with owned_context(PLAN.open('rb')) as stream:self.raw=stream.read(4*1024*1024+1)
        if len(self.raw)>4*1024*1024:raise ValueError('Bounded selected runtime plan required')
        self.plan=json.loads(self.raw)
        resolution=self.plan['resolution']
        if resolution['executable']!=self.plan['python'] or resolution['prefix']!=str(Path(self.plan['python']).parent.parent) or resolution['jvmStarted'] is not False:raise PermissionError('Actual separate installed worker resolution required')
        if resolution['worker'] not in {f['path']for f in self.plan['worker']}:raise PermissionError('Resolved worker absent from complete owned inventory')
        expected={'pyspark':'3.5.3','delta-spark':'3.2.1','graphframes-py':'0.12.3'}
        if set(resolution['sdk'])!=set(expected):raise PermissionError('Exact actual SDK resolution required')
        for name,version in expected.items():
            if resolution['sdk'][name]['version']!=version or resolution['sdk'][name]['origin'] not in {f['path']for group,rows in self.plan['sdks']if group==name for f in rows}:raise PermissionError('Actual SDK resolution not bound to owned inventory')

        self.inventory=GraphFramesRuntimeInventory(self.plan['revision'],tuple(GraphFramesRuntimeFile(Path(f['path']),f['sha256'],f['size']) for f in self.plan['worker']),tuple((name,tuple(GraphFramesRuntimeFile(Path(f['path']),f['sha256'],f['size']) for f in rows)) for name,rows in self.plan['sdks']))
    def renew(self,config,context):
        if context is not self or config.python!=Path(self.plan['python']):raise PermissionError('Selected isolated installed worker required')
        with owned_context(PLAN.open('rb')) as stream:raw=stream.read(4*1024*1024+1)
        if raw!=self.raw:raise PermissionError('Selected runtime plan changed')
        for root,expected in self.plan['namespaces'].items():
            if namespace(Path(root))!=[tuple(row) for row in expected]:raise PermissionError('Selected complete import namespace changed')
        for record in self.plan['selectors']:
            path=Path(record['path'])
            with owned_context(path.open('rb')) as stream:value=stream.read(record['size']+1)
            if len(value)!=record['size'] or hashlib.sha256(value).hexdigest()!=record['sha256']:raise PermissionError('Selected installed lookup changed')
        # RuntimeInventory owns the substantive byte verification. This policy
        # independently owns installed resolution, namespace and current plan.
    def admit_graphframes_runtime(self,config,context):self.renew(config,context);return self.inventory
    def renew_graphframes_runtime(self,inventory,config,context):
        if inventory is not self.inventory:raise PermissionError('Original complete inventory required')
        self.renew(config,context)
def retain_exception_event(error,invocation,identity):
    helper=Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/diagnostic-metadata-j.py')
    spec=importlib.util.spec_from_file_location('owned_diagnostic_metadata',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    approved_path=helper.with_name('approved-guard-ids-j.json')
    with owned_context(approved_path.open('rb'))as stream:raw=stream.read(4*1024*1024+1)
    if len(raw)>4*1024*1024:raise ValueError('Bounded fixed guard IDs required')
    approved=json.loads(raw)
    site=Path('/private/tmp/ashlar-commerce-graphframes-installed-20261011-j/canonical-env/lib/python3.11/site-packages')
    event=module.exception_event(error,site,Path(__file__),approved)
    retain(invocation.output,'provider-exception-event.json',event,identity)

@contextmanager
def open_graphframes(invocation,release,custody):
    if release is not None or custody is not None:raise PermissionError('Live original publication only')
    settings,inventory,source,scope=selected()
    if invocation.publication!=Path(settings['publication_output']):raise PermissionError('Exact retained original publication required')
    from pyspark.sql import SparkSession
    jars=Path(settings['query_jars'])
    spark=None;primary=None;cleanup=ReaderCleanupState();identity=directory_identity(invocation.output);policy=RuntimePolicy()
    try:
        spark=SparkSession.builder.master('local[1]').appName('Installed original commerce GraphFrames canonical reader').config('spark.driver.memory','512m').config('spark.ui.enabled','false').config('spark.sql.shuffle.partitions','1').config('spark.databricks.delta.snapshotPartitions','1').config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true').config('spark.sql.decimalOperations.allowPrecisionLoss','false').config('spark.jars',','.join(str(p) for p in sorted(jars.iterdir()))).config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension').config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog').config('spark.sql.warehouse.dir',str(invocation.output/'canonical-warehouse')).getOrCreate()
        if spark.version!='4.0.1':raise PermissionError('Selected canonical Spark4 required')
        with owned_context(open_commerce_reader(spark,invocation.publication,cleanup_state=cleanup,ordinary_session=OrdinaryQueryConnectionFactory(open_role),source_factory=CommerceQuerySourceFactory(registration()))) as opened:
            yield CommerceGraphFramesSession(opened,policy,policy)
    except BaseException as error:primary=error
    callbacks=([spark.stop]if spark is not None else[])+([lambda:retain_exception_event(primary,invocation,identity)]if primary is not None else[])
    finish(primary,callbacks)
