import sys,json,time,tempfile,os,hashlib
from pathlib import Path
import psycopg,psycopg.pq,jsonschema,referencing
root=Path(__file__).parent;(root/'ipc').mkdir();os.environ['TMPDIR']=str(root/'ipc');tempfile.tempdir=None
for p in reversed(json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical']):sys.path.insert(0,p)
sys.path.insert(0,'/private/tmp/ashlar-supply-chain-held-read-20261013-d/source/src')
from ashlar_host.supply_chain_common_cli import run_supply_chain_common_command,parse_common_configuration
start=time.monotonic();result=None
try:
 old=Path('/private/tmp/ashlar-supply-chain-native-03-prep-a');original=json.loads((old/'configuration.json').read_bytes());publication=old/'publication'
 def native_heads():
  return {str(p.relative_to(publication)):hashlib.sha256(p.read_bytes()).hexdigest()for p in publication.glob('*/_delta_log/*.json')}
 before=native_heads();original_report=(publication/'report.json').read_bytes();original_request=(publication/'request.json').read_bytes()
 baseline={'delta_json_files':before,'registry_sha256':hashlib.sha256((publication/'registry.json').read_bytes()).hexdigest(),'report_sha256':hashlib.sha256(original_report).hexdigest(),'request_sha256':hashlib.sha256(original_request).hexdigest()}
 (root/'before.json').write_text(json.dumps(baseline,indent=2)+'\n')
 config={'profile':'ashlar-supply-chain-common-query/0.1','publication_directory':str(publication),'python':str(Path(sys.executable).resolve()),'java_home':'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',**{k:original[k]for k in ('jars','pack','model','graph','producer','compiler')},'operation_capacity':json.loads((publication/'registry.json').read_bytes())['operation_capacity']}
 configuration=root/'configuration.json';configuration.write_text(json.dumps(config,indent=2)+'\n');parse_common_configuration(configuration.read_bytes())
 answer=run_supply_chain_common_command(configuration,root/'observations',selected_case_ids=('singleton',))
 if native_heads()!=before or hashlib.sha256((publication/'registry.json').read_bytes()).hexdigest()!=baseline['registry_sha256']or (publication/'report.json').read_bytes()!=original_report or (publication/'request.json').read_bytes()!=original_request:raise ValueError('Original native publication/cursor custody changed')
 value=json.loads(Path(answer['output']).read_bytes())
 result={'outcome':'passed','duration_seconds':round(time.monotonic()-start,3),'selected_case_ids':answer['selected_case_ids'],'report_path':answer['output'],'native_heads_unchanged':True,'native_head_files':len(before),'original_report_sha256':hashlib.sha256(original_report).hexdigest(),'original_request_sha256':hashlib.sha256(original_request).hexdigest(),'result_keys':list(value),'qualification':'One actual required singleton common query over existing original supply-chain publication, complete opening/closing graph/source/native custody required by public owner. No ingestion, source mutations or ACK. Original native Delta JSON commit inventory and source request/report remained unchanged.'}
except BaseException as error:result={'outcome':'failed','duration_seconds':round(time.monotonic()-start,3),'error_type':type(error).__name__};raise
finally:(root/'run-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
