"""Ordinary source and protected-ACK readback only; no native/publication grant."""
from pathlib import Path
import os,json,hashlib,importlib.util,signal
from ashlar_host.existing_outbox_authority import ordinary,privileges,one
from ashlar_host.postgres import Session
from ashlar_host.ack import receipt_bytes
from ashlar.outbox import PostgresOutbox
from ashlar_host.lifecycle import finish
R=Path(__file__).resolve().parent;os.umask(0o077)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def timeout(*args):raise TimeoutError('Bounded ordinary observation deadline')
def cancel(*args):raise KeyboardInterrupt()
signal.signal(signal.SIGALRM,timeout);signal.signal(signal.SIGTERM,cancel);signal.alarm(30)
selection=json.loads((R/'preparation.json').read_bytes())
def renew():
 for pin in selection['pins']:
  raw=Path(pin['path']).read_bytes()
  if len(raw)!=pin['bytes']or sha(raw)!=pin['sha256']:raise PermissionError('Original selected observer input changed')
renew();os.environ.update(json.loads((R/'operator-environment.json').read_bytes()));os.environ['PGCONNECT_TIMEOUT']='3'
spec=importlib.util.spec_from_file_location('original_readback_provider',R/'provider.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def read_source(session,selected):
 schema=selected.source.source_schema
 head=one(session,'SELECT position::text AS position FROM "'+schema+'".head WHERE id=1',{},('position',))['position']
 transactions=PostgresOutbox(session,feed=selected.source.scope.feed,epoch=selected.source.scope.epoch,schema=schema).read('0',limit=4)
 if head!='4'or len(transactions)!=4 or [(t.previous,t.position)for t in transactions]!=[(str(i),str(i+1))for i in range(4)]:raise PermissionError('Exact complete four-group source required')
 return {'head':head,'transactions':[{'previous':t.previous,'position':t.position,'batch_id':t.batch.batch_id,'payload_digest':t.payload_digest}for t in transactions]}
operator=module.existing_operator();records=[];context=object();primary=None
try:
 for label,selected,wanted in zip(('A','B'),operator.registrations,(1,1)):
  connection=selected.source.connection_factory(context);error=None;source=None
  try:
   connection.execute('SET TRANSACTION ISOLATION LEVEL READ COMMITTED READ ONLY')
   connection.execute("SET LOCAL statement_timeout='3000ms'");connection.execute("SET LOCAL lock_timeout='1000ms'")
   session=Session(connection);ordinary(session,selected.source_role,selected.database);privileges(session,selected,ack=False)
   source=read_source(session,selected)
   if read_source(session,selected)!=source:raise PermissionError('Closing complete source changed')
   ordinary(session,selected.source_role,selected.database);privileges(session,selected,ack=False)
  except BaseException as e:error=e
  finish(error,[connection.rollback,connection.close])
  connection=selected.metadata_factory(context);error=None;observed=None;binding=None
  try:
   connection.execute('SET TRANSACTION ISOLATION LEVEL READ COMMITTED READ WRITE')
   connection.execute("SET LOCAL statement_timeout='3000ms'");connection.execute("SET LOCAL lock_timeout='1000ms'")
   session=Session(connection);ordinary(session,selected.ack_role,selected.database);privileges(session,selected,ack=True)
   scope=selected.source.scope;expected=selected.source.metadata()['scope'];expected.pop('service_schema');expected.update(source_schema=selected.source.source_schema,source_signature_sha256=selected.source.source_signature_sha256)
   binding=one(session,'SELECT "'+scope.service_schema+'".scope_binding(CAST(:scope AS uuid)) AS binding',{'scope':scope.scope_id},('binding',))['binding']
   if binding!=expected:raise PermissionError('Original scope binding differs')
   observed=one(session,'SELECT * FROM "'+scope.service_schema+'".observe(CAST(:scope AS uuid),CAST(:position AS bigint))',{'scope':scope.scope_id,'position':str(wanted)},('position','request_hex','manifest_hex','receipt_hex'))
   if observed['position']!=str(wanted):raise PermissionError('Observed ACK position differs from selected readback')
   if wanted==0:
    if any(observed[n]is not None for n in ('request_hex','manifest_hex','receipt_hex')):raise PermissionError('Zero-position receipt must be absent')
   else:
    values=[]
    for name in ('request_hex','manifest_hex','receipt_hex'):
     value=observed[name]
     if type(value)is not str or len(value)>8388608 or len(value)%2:raise PermissionError('Bounded original protected bytes required')
     raw=bytes.fromhex(value)
     if raw.hex()!=value:raise PermissionError('Exact lowercase protected bytes required')
     values.append(raw)
    if values[0]!=(R/('expected-'+label+'-request.json')).read_bytes()or values[1]!=(R/('expected-'+label+'-manifest.json')).read_bytes():raise PermissionError('Protected request/descriptor differs from selected completed original slot')
    if receipt_bytes(scope,values[0],values[1])[3]!=values[2]:raise PermissionError('Exact protected byte correspondence differs')
   ordinary(session,selected.ack_role,selected.database);privileges(session,selected,ack=True)
  except BaseException as e:error=e
  finish(error,[connection.rollback,connection.close])
  records.append({'label':label,'scope_binding':binding,'source':source,'ack':observed,'transaction_closing_completed':True,'source_opening_closing_equal':True,'selected_completed_slot_bytes_match':True,'selected_slot':0 if label=='A'else 1})
except BaseException as e:primary=e
finish(primary,[renew])
result={'profile':'ashlar-ordinary-source-ack-observation/0.1','records':records,'all_closing_completed':True,'qualification':'Ordinary native role/privilege/scope, complete four-group source bracket and protected receipt readback; A1 and B1 request/descriptor bytes each match their pinned retained completed slot0/slot1. No writer/native lease, publication validity, replay/submit or ACK mutation authority.'}
raw=(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n').encode()
if len(raw)>4194304:raise ValueError('Bounded observation report required')
fd=os.open(R/'observation.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);error=None
try:
 if os.write(fd,raw)!=len(raw):raise OSError('Exact observation write required')
 os.fsync(fd)
except BaseException as e:error=e
finish(error,[lambda:os.close(fd)]);signal.alarm(0)
print(json.dumps({'status':'observed','positions':[r['ack']['position']for r in records],'all_closing_completed':True}))
