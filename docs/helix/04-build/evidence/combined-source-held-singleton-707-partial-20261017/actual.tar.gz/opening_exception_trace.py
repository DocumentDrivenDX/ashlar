"""Bounded operator diagnostics only: no authority, messages, locals or SQL."""
import hashlib, json, os, stat, sys, threading
from pathlib import Path
from types import CodeType
from ashlar_host.lifecycle import finish

LABELS=frozenset(('held-scope','opening-validate','held-init','held-require','native-hold'))
MAX_RECORDS=16
MAX_BYTES=4096
EXPECTED_DRIVER_SHA256='8896bac0f9bf162428fb14caacddc9e9f44dfe557095ec5c154b59d7d2b1be3b'


def installed_bindings():
    """Exact original native function code objects, never caller-selected frames."""
    from ashlar_host import driver as owner
    if hashlib.sha256(Path(owner.__file__).read_bytes()).hexdigest()!=EXPECTED_DRIVER_SHA256:
        raise ValueError('Exact original selected diagnostic code required')
    NativeDriver=owner.NativeDriver;HeldEvolutionPublication=owner.HeldEvolutionPublication
    scope=NativeDriver.hold_evolution_publication.__wrapped__.__code__
    validate=[code for code in scope.co_consts if type(code)is CodeType and code.co_name=='validate']
    if len(validate)!=1:raise ValueError('Exact owned opening validation required')
    return {'held-scope':scope,'opening-validate':validate[0],
        'held-init':HeldEvolutionPublication.__init__.__code__,
        'held-require':HeldEvolutionPublication.require.__code__,
        'native-hold':NativeDriver._hold.__wrapped__.__code__}


class OpeningExceptionTrace:
    """Observe only this thread's allowlisted exception events, before cleanup.

    Existing tracing, another thread, or ordinary observer failure disables this
    diagnostic without granting or changing application authority. Cancellation
    stays transparent. Every owned descriptor closes and original trace state is
    restored; an independently replaced foreign trace is left untouched.
    """
    def __init__(self,path):
        self.path=Path(path);self.fd=None;self.records=[];self.dropped=0
        self.diagnostic_failed=False;self.previous=None;self.codes={};self.installed=False
        self.callback=self._trace
    def _write(self):
        raw=(json.dumps({'profile':'ashlar-operator-opening-exceptions/0.1',
            'records':self.records,'dropped':self.dropped,'diagnostic_failed':self.diagnostic_failed},
            sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode()
        if len(raw)>MAX_BYTES:raise ValueError('Bounded exception diagnostic required')
        os.lseek(self.fd,0,os.SEEK_SET);offset=0
        while offset<len(raw):
            count=os.write(self.fd,raw[offset:])
            if type(count)is not int or count<=0:raise OSError('Exact diagnostic write required')
            offset+=count
        os.ftruncate(self.fd,len(raw))
    def _restore(self):
        current=sys.gettrace()
        if self.installed and current is self.callback:sys.settrace(self.previous)
        elif self.installed and current is not self.previous:self.diagnostic_failed=True
        self.installed=False
    def __enter__(self):
        self.previous=sys.gettrace()
        if threading.current_thread()is not threading.main_thread()or self.previous is not None:
            self.diagnostic_failed=True;return self
        try:
            bindings=installed_bindings()
            if (type(bindings)is not dict or not bindings or not set(bindings)<=LABELS
                    or any(type(code)is not CodeType for code in bindings.values())
                    or len(set(bindings.values()))!=len(bindings)):
                raise ValueError('Fixed owned exception code bindings required')
            self.codes={code:label for label,code in bindings.items()}
            parent=self.path.parent.lstat()
            if not stat.S_ISDIR(parent.st_mode)or parent.st_uid!=os.getuid()or parent.st_mode&0o077:
                raise PermissionError('Private owned diagnostic parent required')
            self.fd=os.open(self.path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
            self._write();sys.settrace(self.callback);self.installed=True
        except Exception:
            self.diagnostic_failed=True;self._restore()
        except BaseException as error:
            finish(error,[self._restore,self._close])
        return self
    def _trace(self,frame,event,arg):
        if event=='call':
            if frame.f_code not in self.codes:return None
            frame.f_trace_lines=False;frame.f_trace_opcodes=False
            return self.callback
        if frame.f_code not in self.codes:return None
        if event!='exception':return self.callback
        try:
            if len(self.records)>=MAX_RECORDS:
                self.dropped=min(self.dropped+1,2**63-1)
            else:
                name=type(arg[1]).__name__;line=frame.f_lineno-frame.f_code.co_firstlineno
                if type(name)is not str or len(name.encode('utf-8'))>128 or type(line)is not int or not 0<=line<=100000:
                    raise ValueError('Bounded exception type/location required')
                self.records.append({'label':self.codes[frame.f_code],'relative_line':line,'exception_type':name})
            self._write()
        except Exception:
            self.diagnostic_failed=True;self._restore()
        return self.callback
    def _close(self):
        if self.fd is not None:
            fd=self.fd;self.fd=None;os.close(fd)
    def __exit__(self,kind,value,traceback):
        def report():
            if self.fd is not None:self._write();os.fsync(self.fd)
        def diagnostic(callback):
            try:callback()
            except Exception:self.diagnostic_failed=True
        finish(value,[self._restore,lambda:diagnostic(report),lambda:diagnostic(self._close)])
        return False
