from pathlib import Path
import json,sqlite3,hashlib,os
from ashlar_host.local_receipt_codec import original_receipt_chunks
from ashlar_host.delta_custody import encoded
from ashlar_host.lifecycle import finish
os.umask(0o077)
b=Path('/Users/erik/Projects/ashlar/out/combined-source-current-20261017');r=b/'held-singleton-32m-control';r.mkdir(mode=0o700,exist_ok=True)
installation=json.loads((b/'native-bootstrap-control-r2/native-installation.json').read_bytes());db=Path(installation['journal']);targets={x['table']:x for x in installation['targets']};original_limit=20*1024*1024;results=[];primary=None;c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True,timeout=1)
def digest(raw):return hashlib.sha256(raw).hexdigest()
try:
 c.execute('PRAGMA query_only=ON');c.execute('BEGIN');cursor=c.execute("SELECT operation,receipt,intent_sha FROM local_operation WHERE state='committed' ORDER BY operation")
 while True:
  item=cursor.fetchone()
  if item is None:break
  operation,stored,intent_sha=item
  if type(stored)is not str or len(stored.encode())>original_limit:raise ValueError('Finite selected original receipt required')
  data=bytearray();h=hashlib.sha256()
  for chunk in original_receipt_chunks(stored):
   if len(data)+len(chunk)>original_limit:raise ValueError('Selected 20MiB original expansion refused')
   data.extend(chunk);h.update(chunk)
  receipt=json.loads(data);original_length=len(data);data.clear()
  assert receipt['operation']==operation and receipt['operation_sha256']==intent_sha
  target=targets[receipt['table']];assert receipt['uuid']==target['uuid']
  role=receipt['table'].split('.')[-1];snapshot=receipt['snapshot'];rows=snapshot['rows'];columns=snapshot['schema'];schema_json=installation['opening'][role]['schema_json'];physical=json.loads(schema_json)
  assert [x[0]for x in columns]==[x['name']for x in physical['fields']]
  assert len(columns)<=128 and all(type(x)is dict and set(x)=={name for name,_ in columns}for x in rows)
  assert all(value is None or type(value)is str for row in rows for value in row.values())
  rowhash=digest(encoded(rows).encode());assert rowhash==snapshot['row_sha256']
  sizes=[0 if value is None else len(value.encode())for row in rows for value in row.values()]
  count=len(rows);cell=max(sizes,default=0);total=sum(sizes);n=len(columns)
  row_constant=2+n+sum(len(json.dumps(name).encode())+1 for name,_ in columns)+6*n+1
  envelope=512+128*(n+5);base=256+len(schema_json.encode())+2
  required=base+count*row_constant+6*total+(count+1)*envelope
  storage=json.loads(stored)
  results.append({'operation_sha256':digest(operation.encode()),'table':receipt['table'],'version':receipt['version'],'before_version':receipt['before_version'],'codec_profile':storage.get('profile'),'stored_bytes':len(stored.encode()),'stored_sha256':digest(stored.encode()),'verified_original_bytes':original_length,'verified_original_sha256':h.hexdigest(),'snapshot_rows_sha256':rowhash,'columns':n,'rows':count,'maximum_cell_utf8_bytes':cell,'total_cell_utf8_bytes':total,'schema_json_utf8_bytes':len(schema_json.encode()),'base':base,'row_constant':row_constant,'envelope':envelope,'required_total_bytes':required,'fits_16MiB':required<=16777216,'fits_32MiB':required<=33554432,'cell_fits_1MiB':cell<=1048576,'fields_fit_128':n<=128,'rows_fit_10000':count<=10000})
  del receipt,rows,snapshot,sizes,storage
except BaseException as e:primary=e
finish(primary,[c.rollback,c.close])
assert results and all(x['fits_32MiB']and x['cell_fits_1MiB']and x['fields_fit_128']and x['rows_fit_10000']for x in results)
report={'profile':'ashlar-original-receipt-native-bound-diagnosis/0.1','scope':'One SQLite mode=ro/query_only read transaction over all retained COMMITTED original receipts; expansion via actual public original_receipt_chunks, one receipt at a time, explicit20MiB original limit; rollback+close. No Spark/native/source/ACK calls, no source authority claim.','original_expansion_limit_bytes':original_limit,'native_guard_formula':'base + count*row_constant + 6*total_cell_utf8_bytes + (count+1)*envelope','schema_basis':'Exact original bootstrap opening StructType.json for each unchanged native role; retained snapshot column correspondence checked. This is static bound correspondence, not current native observation.','receipts':results,'count':len(results),'maximum_required_total_bytes':max(x['required_total_bytes']for x in results),'maximum_cell_utf8_bytes':max(x['maximum_cell_utf8_bytes']for x in results),'maximum_fields':max(x['columns']for x in results),'all_fit_32MiB':True,'all_fit_other_unchanged_bounds':True}
raw=(json.dumps(report,indent=2)+'\n').encode();assert len(raw)<=262144
fd=os.open(r/'receipt-bound-diagnosis.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
try:assert os.write(fd,raw)==len(raw);os.fsync(fd)
finally:os.close(fd)
print('receipts',len(results),'max',report['maximum_required_total_bytes'],'cell',report['maximum_cell_utf8_bytes'],'fields',report['maximum_fields'],'SHA',digest(raw))
print('attempt15/16',[(x['version'],x['required_total_bytes'])for x in results if x['table'].endswith('.attempts')and x['version']in(15,16)])
