"""Actual public installation and original four compiler calls; no engine/source grant."""
import sys,json,pathlib,hashlib,os
command_path,expected=sys.argv[1:];raw=pathlib.Path(command_path).read_bytes()
assert hashlib.sha256(raw).hexdigest()==expected
C=json.loads(raw)
def verify():
 for r in C['resources']:
  p=pathlib.Path(r['path']);b=p.read_bytes();assert not p.is_symlink() and len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
 for root,names in C['namespaces'].items():
  assert sorted(str(p.relative_to(root)) for p in pathlib.Path(root).rglob('*') if p.is_file() or p.is_symlink())==names
verify();sys.path[:0]=[C['sourceRoot'],C['schemaSite']]
from ashlar.weft_implicit_arithmetic_distribution import ImplicitArithmeticDistributionPaths,install_implicit_arithmetic_distribution,open_implicit_arithmetic_distribution,compile_implicit_arithmetic_distribution,installed_implicit_arithmetic_schema_bundle
from ashlar_host.implicit_arithmetic_request import commerce_implicit_arithmetic_request
from ashlar_host.commerce_original_scenarios import commerce_original_cases,original_commerce_scenario_oracle
from ashlar_host.source_identity import build_transaction
from ashlar_host.implicit_arithmetic_profile import PROFILE,ImplicitArithmeticAdmissionConfig
from ashlar_host.count_star_admission import admit_implicit_arithmetic_artifact
from ashlar_host.count_star_schema import make_offline_implicit_arithmetic_schema_validation
from ashlar_host.lifecycle import finish,owned_context
import ashlar.weft_implicit_arithmetic_distribution as selected
assert pathlib.Path(selected.__file__).is_relative_to(C['sourceRoot'])
W=pathlib.Path(C['work']);W.mkdir(mode=0o700);O=W/'observations';O.mkdir(mode=0o700)
paths=ImplicitArithmeticDistributionPaths(pathlib.Path(C['index']),W/'installation',pathlib.Path(C['package']))
rows=[];total=0;primary=None;installed=None

def put(path,body):
 if type(body)is not bytes or len(body)>1048576:raise ValueError('Bounded complete output required')
 with owned_context(path.open('xb'))as stream:
  if stream.write(body)!=len(body):raise ValueError('Complete output write refused')
  stream.flush();os.fsync(stream.fileno())
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'))+'\n').encode()
try:
 installed=install_implicit_arithmetic_distribution(paths)
 if installed.cleanup_pending:raise ValueError('Installation cleanup incomplete')
 whole=dict(installed_implicit_arithmetic_schema_bundle(paths));port=make_offline_implicit_arithmetic_schema_validation({name:whole[name]for name,_ in PROFILE.schemas});config=ImplicitArithmeticAdmissionConfig(1048576,port)
 model=pathlib.Path(C['model']).read_bytes();graph=pathlib.Path(C['graph']).read_bytes();pack=pathlib.Path(C['pack']).read_bytes()
 _,bindings=build_transaction(model,graph,source_system='private-original-commerce-fixture',binding_profile='ashlar-commerce-development-bindings/0.2')
 metadata=json.loads(pathlib.Path(C['publicationMetadata']).read_bytes());manifest=metadata['native_manifest'];registry=metadata['table_registry'];aliases={t:t.replace('local.','spark_catalog.',1)for t in json.loads(manifest['table_versions_json'])}
 for name,sql in commerce_original_cases(pack):
  request=commerce_implicit_arithmetic_request(sql,model,bindings,manifest,registry,aliases,pack_bytes=pack);body=enc(request);responses=[]
  for iteration in range(2):
   response=compile_implicit_arithmetic_distribution(paths,body)
   put(O/f'{name}-{iteration}.request',body);put(O/f'{name}-{iteration}.response',response)
   total+=len(body)+len(response)
   if total>16777216:raise ValueError('Complete eight-call output bound exceeded')
   responses.append(response)
  row={'case':name,'requestSha256':hashlib.sha256(body).hexdigest(),'responseSha256':[hashlib.sha256(b).hexdigest()for b in responses],'sourceOracle':original_commerce_scenario_oracle(model,graph,request)};rows.append(row)
  if responses[0]!=responses[1]:raise ValueError('Original fresh recompile differs')
  artifacts=[json.loads(b)for b in responses];row['status']=artifacts[0].get('status')
  admit_implicit_arithmetic_artifact(request,*artifacts,config=config)
  row['offlineAdmitted']=True;row['requiredCapabilities']=artifacts[0]['logicalPlan']['requiredCapabilities']
except BaseException as error:primary=error

def close_installation():
 if installed is not None and open_implicit_arithmetic_distribution(paths).ready_bytes!=installed.ready_bytes:raise ValueError('Closing installation changed')
def retain():
 put(W/'qualification.json',enc({'cases':rows,'failureType':None if primary is None else type(primary).__name__,'scope':'Actual public fixed042 installation and unchanged original commerce compiler requests/offline admission only. Retained publication metadata is a compiler binding fixture, not current source/ACK/native authority.'}))
try:finish(primary,[close_installation,verify])
except BaseException as error:primary=error
finish(primary,[retain])
assert len(rows)==4 and all(r['offlineAdmitted']for r in rows)
print(json.dumps({'originalCases':4,'actualCompiles':8,'offlineAdmitted':True,'closingInstallation':True}))
