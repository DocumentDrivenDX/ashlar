"""Bounded source-only public API qualification; no wheel rebuild or engine."""
import pathlib,json,hashlib,sys,importlib.util
p,expected=sys.argv[1:];raw=pathlib.Path(p).read_bytes();assert hashlib.sha256(raw).hexdigest()==expected;C=json.loads(raw)
def verify():
 for r in C['resources']:
  q=pathlib.Path(r['path']);b=q.read_bytes();assert not q.is_symlink()and len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256']
 for root,names in C['namespaces'].items():assert sorted(str(q.relative_to(root))for q in pathlib.Path(root).rglob('*')if q.is_file()or q.is_symlink())==names
verify()
for n in ['work','stdout','stderr','receipt']:assert not pathlib.Path(C[n]).exists()and not pathlib.Path(C[n]).is_symlink()
spec=importlib.util.spec_from_file_location('capture',C['capture']);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
primary=None;outcome=None;stream=None
try:outcome=capture.capture([C['python'],'-I','-B','-S',C['probe'],p,expected],C['cwd'],{'PATH':'/usr/bin:/bin','LANG':'en_US.UTF-8'},pathlib.Path(C['stdout']),pathlib.Path(C['stderr']),90,4194304)
except BaseException as error:primary=error
try:verify()
except BaseException as error:primary=capture.select_failure(primary,error)
try:
 stream=pathlib.Path(C['receipt']).open('x');json.dump({'outcome':outcome,'openingClosingCustody':primary is None,'failureType':None if primary is None else type(primary).__name__,'scope':C['scope']},stream,indent=2);stream.write('\n')
except BaseException as error:primary=capture.select_failure(primary,error)
finally:
 if stream is not None:
  try:stream.close()
  except BaseException as error:primary=capture.select_failure(primary,error)
if primary is not None:raise primary
if outcome['exitCode']:raise SystemExit(outcome['exitCode'])
