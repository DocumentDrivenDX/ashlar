import pathlib,json,sqlite3,hashlib,time
from contextlib import closing
from ashlar_host.medical_installation import OriginalMedicalInstallationSelection,OriginalMedicalInstallationLease
from ashlar_host.delta_custody import DeltaTarget
from ashlar_host.local_receipt_codec import original_receipt_chunks
r=pathlib.Path(__file__).parent;c=json.loads((r/'publish.json').read_bytes());handoff=json.loads((r/'installation.json').read_bytes());selection=OriginalMedicalInstallationSelection(handoff['installation_id'],pathlib.Path(handoff['journal']),tuple(DeltaTarget(t['table'],pathlib.Path(t['path']),t['uuid'])for t in handoff['targets']),handoff['capacity']);ctx=object();records=[];plans=[];sources=[];logs={};started=time.monotonic()
with OriginalMedicalInstallationLease.open(selection,ctx,journal_bytes=c['bounds']['journal_bytes'])as owner:
 with closing(sqlite3.connect(selection.journal.as_uri()+'?mode=ro',uri=True,timeout=1))as db:
  db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
  for op,intent,digest,before,state,receipt in db.execute('SELECT operation,intent,intent_sha,before_version,state,receipt FROM local_operation ORDER BY operation'):
   assert hashlib.sha256(intent.encode()).hexdigest()==digest
   value=json.loads(intent);assert value['installation_id']==selection.installation_id
   proof=None if receipt is None else json.loads(b''.join(original_receipt_chunks(receipt)))
   records.append({'operation':op,'table':value['table'],'state':state,'before_version':before,'intent_sha256':digest,'receipt_version':None if proof is None else proof['version'],'receipt_sha256':None if receipt is None else hashlib.sha256(receipt.encode()).hexdigest()})
  for op,original,digest in db.execute('SELECT operation,original,digest FROM local_plan'):
   assert hashlib.sha256(original.encode()).hexdigest()==digest
   plans.append({'operation':op,'bytes':len(original.encode()),'sha256':digest})
  for request,original in db.execute('SELECT request_digest,original FROM local_source_plan'):sources.append({'request_digest':request,'bytes':len(original.encode()),'sha256':hashlib.sha256(original.encode()).hexdigest()})
  artifacts=db.execute('SELECT count(*) FROM local_publication_artifact').fetchone()[0];db.rollback()
 for target in selection.targets:
  entries=[];identity=None
  for p in sorted((target.path/'_delta_log').glob('*.json')):
   raw=p.read_bytes();rows=[json.loads(x)for x in raw.splitlines()]
   for row in rows:
    if 'metaData'in row:identity=row['metaData']['id']
   commits=[x['commitInfo']for x in rows if 'commitInfo'in x]
   entries.append({'version':int(p.stem),'sha256':hashlib.sha256(raw).hexdigest(),'commits':[{'operation':x.get('operation'),'userMetadata':x.get('userMetadata')}for x in commits]})
  assert identity==target.uuid;logs[target.table]={'uuid':identity,'versions':entries}
 owner.renew(ctx)
result={'installation_id':selection.installation_id,'operations':records,'effect_plans':plans,'source_plans':sources,'publication_artifacts':artifacts,'native_logs':logs,'elapsed_seconds':time.monotonic()-started,'scope':'Read-only leased SQLite logical snapshot and exact native commit-log metadata only; no full logical Delta row read, source/ACK or recovery authority'}
(r/'journal-post-recovery.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'states':[(x['table'],x['state'],x['receipt_version'])for x in records],'effect_plans':len(plans),'source_plans':len(sources),'native_latest':{k:max(x['version']for x in v['versions'])for k,v in logs.items()}}))
