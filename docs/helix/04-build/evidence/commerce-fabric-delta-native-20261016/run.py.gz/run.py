from pathlib import Path
import subprocess,os,signal,time,json
r=Path(__file__).parent;started=time.monotonic();argv=[str(r/'environment/bin/python3'),'-I','-B',str(r/'materialize.py')]
# Explicit child environment, no ambient Spark/PostgreSQL selection.
env={'PATH':'/usr/bin:/bin','JAVA_HOME':'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home','PYTHONDONTWRITEBYTECODE':'1','SPARK_LOCAL_IP':'127.0.0.1','LANG':'C','LC_ALL':'C','TZ':'UTC','PYSPARK_PYTHON':str(r/'environment/bin/python3'),'PYSPARK_DRIVER_PYTHON':str(r/'environment/bin/python3')}
with(r/'stdout.log').open('xb')as out,(r/'stderr.log').open('xb')as err:
 p=subprocess.Popen(argv,cwd=r,env=env,stdout=out,stderr=err,start_new_session=True)
 try:code=p.wait(timeout=240);state='terminal'
 except subprocess.TimeoutExpired:
  state='outer-timeout';os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=10)
(r/'status.json').write_text(json.dumps({'state':state,'exit_code':code,'elapsed_seconds':time.monotonic()-started,'argv':argv,'outer_seconds':240},indent=2)+'\n');print((r/'status.json').read_text())
