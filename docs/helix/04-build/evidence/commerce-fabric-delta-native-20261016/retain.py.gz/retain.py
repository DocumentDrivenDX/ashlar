from pathlib import Path
import json,gzip,hashlib
r=Path(__file__).parent;o=Path('/Users/erik/Projects/ashlar/docs/helix/04-build/evidence/commerce-fabric-delta-native-20261016');o.mkdir()
files=[(p,p.name)for p in sorted(r.iterdir())if p.is_file()]
for role in ('nodes','edges'):
 for p in sorted((r/role).rglob('*')):
  if p.is_file()and(p.suffix=='.parquet'or p.parent.name=='_delta_log'and p.suffix=='.json'):files.append((p,role+'--'+str(p.relative_to(r/role)).replace('/','--')))
m={}
for p,n in files:
 raw=p.read_bytes();z=gzip.compress(raw,mtime=0);n += '.gz';(o/n).write_bytes(z);m[n]={'sha256':hashlib.sha256(raw).hexdigest(),'gzip_sha256':hashlib.sha256(z).hexdigest(),'bytes':len(raw)}
(o/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(len(m),o)
