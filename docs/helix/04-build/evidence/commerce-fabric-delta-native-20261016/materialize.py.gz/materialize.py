from pathlib import Path
import json,time,hashlib,sys,sqlite3
from ashlar.native import quote_table_identifier
from ashlar_host.commerce_export_cli import parse_commerce_export_configuration,open_commerce_export_spark
from ashlar_host.original_commerce_local_setup import original_commerce_local_source_ports
from ashlar_host.ordinary_query_connection import OrdinaryQueryConnectionFactory
from ashlar_host.commerce_query_sources import CommerceQuerySourceFactory
from ashlar_host.publication_reader import open_commerce_reader
from ashlar_host.commerce_fabric_delta import materialize_commerce_fabric_delta
from ashlar_host.evolution_cli import InvocationFile
from ashlar_host.lifecycle import owned_context
r=Path(__file__).parent;started=time.monotonic();captured=InvocationFile.read(r/'selection.json',262144);config=parse_commerce_export_configuration(captured.raw)
jars=[Path('/private/tmp/ashlar-current-commerce-preparation-20261015-9pn8k_h7/query-jars')/n for n in ('delta-spark_2.13-4.0.0.jar','delta-storage-4.0.0.jar')]
expected=('538511702aae0ef6973a6a70af3d4543c9009f8edbed786a00737e2d3cd7f04e','9bdb9fb450f1e119eba53feb427f331b0d09072d26485b8273883ad72c9a2e1d')
for p,h in zip(jars,expected):assert hashlib.sha256(p.read_bytes()).hexdigest()==h
ports=original_commerce_local_source_ports(config.source);registration=ports.registration
# Only ordinary reader/metadata roles are reachable. No writer or ACK submission.
def connection(role):
 if role==registration.source_role:return registration.source.connection_factory(None)
 if role==registration.ack_role:return registration.metadata_factory(None)
 raise PermissionError('Unselected ordinary query role')
ordinary=OrdinaryQueryConnectionFactory(connection);factory=CommerceQuerySourceFactory(registration)
with owned_context(open_commerce_export_spark(jars,r/'warehouse'))as spark:
 assert spark.version=='4.0.1';runtime={'python':sys.version.split()[0],'sqlite':sqlite3.sqlite_version,'spark':spark.version,'master':spark.sparkContext.master,'driver_memory':spark.conf.get('spark.driver.memory')}
 with owned_context(open_commerce_reader(spark,config.publication,ordinary_session=ordinary,source_factory=factory))as opened:
  before=opened.native_files()
  with owned_context(opened.provider.interval(opened.context)):
   for table,alias in opened.aliases.items():
    target=opened.driver.transport.targets[table]
    spark.sql('CREATE DATABASE IF NOT EXISTS '+quote_table_identifier(alias).split('.')[-2]).collect()
    spark.sql('CREATE TABLE '+quote_table_identifier(alias)+" USING DELTA LOCATION '"+str(target.path).replace("'","''")+"'").collect()
  result=materialize_commerce_fabric_delta(spark,opened,node_path=str(r/'nodes'),edge_path=str(r/'edges'))
  ack=opened.provider.closed_interval_custody(opened.context);after=opened.native_files();assert before==after
captured.renew(262144)
# Successful report is exposed only after the reader and Spark close.
result.update(runtime=runtime,source_ack_interval=ack,original_native_files_unchanged=before,elapsed_seconds=time.monotonic()-started,qualification='Actual existing private original-commerce publication/source/ACK hold and fresh native local Spark4/Delta4 canonical STRING projection only; not Fabric upload/load/GQL/managed authorization.')
with(r/'report.json').open('x')as f:json.dump(result,f,indent=2)
print(json.dumps({'success':True,'nodes':result['targets']['nodes']['rows'],'edges':result['targets']['edges']['rows'],'elapsed_seconds':result['elapsed_seconds']}))
