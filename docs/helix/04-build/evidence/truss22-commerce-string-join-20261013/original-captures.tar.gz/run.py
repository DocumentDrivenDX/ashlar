import sys,json,time,os
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;s=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a');l=Path('/private/tmp/ashlar-truss22-commerce-lifecycle-20261013-a')
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical'];sys.path[:0]=[str(r/'ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_resume_setup import run_configure_truss_resume_command
from ashlar_host.truss_scalar_join_query_cli import run_query_truss_scalar_join_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_example import private_file
previous={k:os.environ.get(k)for k in ('JAVA_HOME','PYSPARK_PYTHON','PYSPARK_DRIVER_PYTHON')};primary=None;answer=None;t=time.monotonic()
def restore():
 for k,v in previous.items():
  if v is None:os.environ.pop(k,None)
  else:os.environ[k]=v
try:
 os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
 with owned_context(LocalPostgres(s/'data'))as runtime:
  params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);administrator=psycopg.conninfo.make_conninfo(**params);params['user']=json.loads((s/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
  def conn():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
  before=read_page(conn,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(r/'checkpoint-before.bin',before);assert before==(l/'verified/checkpoint-after.bin').read_bytes()
  item=json.loads((l/'continued/continuation.json').read_bytes())['publications'][-1];selection=json.loads((s/'native/publish.json').read_bytes());selection.update(connection_uri=ordinary,administrator_uri=administrator);reader=r/'reader.json';run_configure_truss_resume_command(private_file(r/'publisher-selection.json',selection),item['publication_intent']['path'],reader)
  started=time.monotonic();query=run_query_truss_scalar_join_command(reader,r/'query.json',compiler='/private/tmp/ashlar-compatible-weft-compile-20261013-a/weft-runtime',sql='SELECT p.sku AS product_sku,s.name AS supplier_name FROM products p JOIN suppliers s ON p.supplier_id=s.id',revision='1',document_id='urn:umf:domain:commerce',physical_revisions=('1',),maximum_rows=10);duration=time.monotonic()-started
  group=json.loads((s/'native/group-result.json').read_bytes());product=dict(next(x for x in group['objects']if x['record_id']=='products')['values']);supplier=dict(next(x for x in group['objects']if x['record_id']=='suppliers')['values']);assert product['supplier_id']==supplier['id']
  assert query['rows']==[{'product_sku':product['sku'],'supplier_name':supplier['name']}] and query['publication_id']==item['manifest']['publication_id']
  after=read_page(conn,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(r/'checkpoint-after.bin',after);assert before==after
  answer={'outcome':'passed','query_seconds':duration,'rows':query['rows'],'publication_id':query['publication_id'],'source_checkpoint_unchanged':True,'scope':'One exact original-commerce required STRING foreign-key equality INNER JOIN through installed compatible scalar-join adapter on lifecycle final publication, full original source-derived pair oracle. No authored-edge join, mathematical integer, aggregate, optional or cloud support claim.'}
except BaseException as error:primary=error
finish(primary,[restore]);answer['duration_seconds']=time.monotonic()-t;private_file(r/'result.json',answer);print(json.dumps(answer),flush=True)
