import importlib.util,json,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('selected','/private/tmp/ashlar-supply-chain-installed-native-runner-c.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class Controls(unittest.TestCase):
 def test_resource_closing_preserves_body_cancellation(self):
  for primary,closing,select_closing in ((KeyboardInterrupt(),ValueError('close'),False),(SystemExit(),ValueError('close'),False),(ValueError('body'),KeyboardInterrupt(),True)):
   class Resource:
    def close(self):raise closing
   try:
    with module.owned(Resource()):raise primary
   except BaseException as error:self.assertIs(error,closing if select_closing else primary)
   else:self.fail('lost original failure')
 def test_complete_existing_bytecode_and_added_alias_refuse(self):
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp).resolve();selected=root/'runtime';selected.mkdir();bytecode=selected/'existing.pyc';bytecode.write_bytes(b'existing')
   descriptor=root/'namespace.json';descriptor.write_text(json.dumps({'roots':{str(selected):{str(bytecode):{'kind':'file','bytes':8}}},'links':[]}));prior=module.NAMESPACE;module.NAMESPACE=descriptor
   try:
    module.verify_namespace();(selected/'extra.pyc').write_bytes(b'x')
    with self.assertRaises(ValueError):module.verify_namespace()
    (selected/'extra.pyc').unlink();(selected/'alias').symlink_to(bytecode)
    with self.assertRaises(ValueError):module.verify_namespace()
   finally:module.NAMESPACE=prior
 def test_launcher_resource_closing_preserves_original_cancellation(self):
  spec=importlib.util.spec_from_file_location('launcher','/private/tmp/ashlar-supply-chain-installed-native-launch-c.py');launcher=importlib.util.module_from_spec(spec);spec.loader.exec_module(launcher)
  for primary,closing,select_closing in ((KeyboardInterrupt(),ValueError('close'),False),(SystemExit(),ValueError('close'),False),(ValueError('body'),KeyboardInterrupt(),True)):
   class Resource:
    def close(self):raise closing
   try:
    with launcher.owned(Resource()):raise primary
   except BaseException as error:self.assertIs(error,closing if select_closing else primary)
   else:self.fail('lost original launcher failure')
if __name__=='__main__':unittest.main()
