import json,hashlib
from pathlib import Path
from collections import Counter
from ashlar_host.supply_chain_oracle import supply_chain_result_oracle,original_graph_oracle
from ashlar_host.supply_chain_request import supply_chain_cases
root=Path('/private/tmp/ashlar-supply-chain-installed-native-c');freeze=Path('/private/tmp/ashlar-supply-chain-installed-native-actual-freeze-c.json');f=json.loads(freeze.read_bytes())
assert hashlib.sha256(freeze.read_bytes()).hexdigest()=='7a962da52912f03b16462e9cbb50af31a396ec752f4a8436be669eb4caa7bef0'
for pin in f['actualFiles']+f['resources']:
 raw=Path(pin['path']).read_bytes();assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
base=Path('/Users/erik/Projects/ashlar/examples/domain-packs/supply-chain/upstream');model=(base/'ontology.json').read_bytes();graph=(base/'graph/fixture.json').read_bytes();pack=(base/'pack.json').read_bytes();cases=supply_chain_cases(pack,model,graph);original=original_graph_oracle(model,graph);assert (len(original['objects']),len(original['edges']))==(20,23)
r=json.loads((root/'publication/report.json').read_bytes());native=[json.loads(x) for x in (root/'publication/native-observations.jsonl').read_text().splitlines()];compiler=[json.loads(x) for x in (root/'publication/compiler-observations.jsonl').read_text().splitlines()]
assert len(native)==5 and len(compiler)==10
bag=lambda rows:Counter(json.dumps(row,sort_keys=True,separators=(',',':')) for row in rows)
for (ident,sql),n,c in zip(cases,native,r['cases']):
 assert n['id']==c['id']==ident
 expected=supply_chain_result_oracle(ident,model,graph);assert bag(n['captured']['rows'])==bag(expected['rows']);assert c['evidence']['native_result']==n['captured'];assert c['evidence']['oracle']==expected
 pairs=[x for x in compiler if x['id']==ident];assert len(pairs)==2 and pairs[0]['requestHex']==pairs[1]['requestHex'] and pairs[0]['responseHex']==pairs[1]['responseHex']
 request=json.loads(bytes.fromhex(pairs[0]['requestHex']));response=json.loads(bytes.fromhex(pairs[0]['responseHex']));assert request['sql']==sql and request['modules'][0]['documentJson'].encode()==model;assert response['status']=='compiled'
 binding=json.loads(request['target']['bindingJson']);vector={'.'.join(t['name']).replace('spark_catalog.','local.',1):t['version'] for t in binding['publication']['tables']};assert vector==json.loads(r['manifest']['table_versions_json'])
 assert c['evidence']['opening_native_files']==c['evidence']['closing_native_files'];assert c['evidence']['interval']['source']==r['source']
 for rawrow,decoded in zip(n['captured']['rows'],c['evidence']['decoded']):
  assert len(rawrow)==len(decoded)
  for rawcell,cell in zip(rawrow,decoded):
   if 'original' in cell:assert cell['original']==rawcell
   else:
    presence=json.loads(rawcell);assert cell['state']==presence['state']
    if cell['state']=='value':assert cell['value']['original']==presence['value']
assert r['exact_replay_unchanged'] is True and r['reader_reopened_from_committed_phases'] is True
outer=json.loads((root.parent/(root.name+'.receipt.json')).read_bytes());closing=json.loads((root/'installed-closing.json').read_bytes());print('outer',outer);print('installed',closing);print('PASS:37pins original20/23 five unchangedSQL deterministicpairs completebags typed-originals vectors replay reopen')
