"""One bounded read-only ordinary ACK component observation."""
import argparse,hashlib,importlib.util,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--command',type=Path,required=True);p.add_argument('--sha256',required=True);a=p.parse_args()
raw=a.command.read_bytes()
if len(raw)>8192 or hashlib.sha256(raw).hexdigest()!=a.sha256:raise ValueError('command selection')
v=json.loads(raw)
def verify():
 for r in v['resources']:
  path=Path(r['path'])
  if path.is_symlink()or path.stat().st_size!=r['bytes']or hashlib.sha256(path.read_bytes()).hexdigest()!=r['sha256']:raise ValueError('selected resource changed')
verify()
spec=importlib.util.spec_from_file_location('owned_capture',v['captureModule']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
primary=None;result=None
try:result=m.capture(v['argv'],'/private/tmp',{'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1'},v['stdout'],v['stderr'],v['timeoutSeconds'],v['maximumOutputBytes'])
except BaseException as error:primary=error
try:verify()
except BaseException as error:
 if primary is None or isinstance(primary,Exception)and not isinstance(error,Exception):primary=error
if primary is not None:raise primary
# Receipt uses the existing explicitly primary-preserving stream owner below.
stream=None;primary=None
try:
 stream=Path(v['receipt']).open('x');json.dump(dict(result,commandSha256=a.sha256,openingClosingCustody=True),stream,sort_keys=True,indent=2);stream.write('\n')
except BaseException as error:primary=error
if stream is not None:
 try:stream.close()
 except BaseException as error:
  if primary is None or isinstance(primary,Exception)and not isinstance(error,Exception):primary=error
if primary is not None:raise primary
if result['exitCode']:raise SystemExit(result['exitCode'])
