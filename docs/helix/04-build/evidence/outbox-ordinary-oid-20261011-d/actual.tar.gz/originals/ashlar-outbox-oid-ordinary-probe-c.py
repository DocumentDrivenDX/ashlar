"""Read-only ordinary ACK component gates; no writer/native authority minted."""
import argparse,hashlib,json,sys
from pathlib import Path
sys.path[:0]=['/Users/erik/Projects/ashlar/src','/private/tmp/ashlar-evolution-selected-pg-site-a','/private/tmp/ashlar-evolution-installed-native-20261011-e/typing-site']
from ashlar_host.ack import AckScope
from ashlar_host.source_sessions import OutboxSourceRegistration
from ashlar_host.existing_outbox_authority import OutboxAuthorityRegistration,ordinary,privileges,one
from ashlar_host.postgres import Session
from ashlar_host.lifecycle import finish,owned_context
import psycopg

def main(path,digest,output):
    with owned_context(path.open('rb')) as file:raw=file.read(65537)
    if len(raw)>65536 or hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('Original fixture differs')
    document=json.loads(raw)
    if document['endpoint']!={'host':'127.0.0.1','port':25433,'database':'truss_e2e'}:raise ValueError('Original endpoint differs')
    observations=[]
    for source in document['sources']:
        scope=AckScope(**source['scope'])
        selected=OutboxAuthorityRegistration(OutboxSourceRegistration(scope,source['schema'],source['binding']['source_signature_sha256'],lambda context:None),source['reader_role'],source['ack_role'],'truss_e2e',lambda context:None)
        connection=psycopg.connect(host='127.0.0.1',port=25433,dbname='truss_e2e',user=source['ack_role'],password='',sslmode='disable',connect_timeout=2,options='-c statement_timeout=5000',autocommit=False)
        primary=None
        session=Session(connection)
        try:
            ordinary(session,selected.ack_role,selected.database)
            privileges(session,selected,ack=True)
            native=one(session,'SELECT has_schema_privilege(current_user,:source,\'USAGE\') AS source_usage',{'source':source['schema']},('source_usage',))
            if native['source_usage'] is not False:raise ValueError('Unexpected source-schema access')
            binding=one(session,'SELECT "'+scope.service_schema+'".scope_binding(CAST(:scope AS uuid)) AS binding',{'scope':scope.scope_id},('binding',))['binding']
            expected=selected.source.metadata()['scope'];expected.pop('service_schema');expected.update(source_schema=source['schema'],source_signature_sha256=source['binding']['source_signature_sha256'])
            if binding!=expected:raise ValueError('Current original binding differs')
            observations.append({'feed':scope.feed,'ordinaryRole':selected.ack_role,'sourceUsage':False,'negativeSourceWritesAndAppend':False,'componentGatesPassed':True,'binding':binding})
        except BaseException as error:primary=error
        finish(primary,[lambda:ordinary(session,selected.ack_role,selected.database),
            lambda:privileges(session,selected,ack=True),connection.rollback,connection.close])
    with owned_context(path.open('rb')) as file:closing=file.read(65537)
    if closing!=raw:raise ValueError('Original fixture closing differs')
    with owned_context(output.open('x')) as file:json.dump({'profile':'ordinary-ack-components/0.1','observations':observations,'qualification':'Read-only component SQL only. Full ExistingOutboxAuthority.admit_scope requires an actual native writer lease and is not claimed here.','closing':True},file,sort_keys=True,indent=2);file.write('\n')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--fixture',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();main(a.fixture,a.sha256,a.output)
