import importlib.util,tempfile,pathlib,unittest,unittest.mock,os,sys
spec=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Controls(unittest.TestCase):
 def test_closing_cancel_over_body_failure(self):
  for c in (KeyboardInterrupt(),SystemExit(),GeneratorExit()):self.assertIs(m.select_failure(ValueError(),c),c)
 def test_body_cancel_identity(self):
  for c in (KeyboardInterrupt(),SystemExit(),GeneratorExit()):self.assertIs(m.select_failure(c,KeyboardInterrupt()),c)
 def test_input_refused_before_process(self):
  with tempfile.TemporaryDirectory()as d:
   p=pathlib.Path(d);(p/'link').symlink_to(p/'missing')
   with unittest.mock.patch.object(m.subprocess,'Popen')as launch:
    with self.assertRaises(OSError):m.capture([sys.executable],d,{},p/'out',p/'err',1,100,p/'link')
    launch.assert_not_called()
 def test_small_actual_stdin_custody(self):
  with tempfile.TemporaryDirectory()as d:
   p=pathlib.Path(d);(p/'input').write_bytes(b'original\x00bytes')
   r=m.capture([sys.executable,'-I','-S','-c','import sys;sys.stdout.buffer.write(sys.stdin.buffer.read())'],d,{'PATH':'/usr/bin:/bin'},p/'out',p/'err',3,100,p/'input')
   self.assertEqual(r['exitCode'],0);self.assertEqual((p/'out').read_bytes(),b'original\x00bytes');self.assertEqual((p/'input').read_bytes(),b'original\x00bytes')
if __name__=='__main__':unittest.main()
