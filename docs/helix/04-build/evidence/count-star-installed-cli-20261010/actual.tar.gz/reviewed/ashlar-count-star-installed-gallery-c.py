"""Installed-wheel public gallery authoring/offline admission; no native/PG I/O."""
import sys,json,hashlib
from pathlib import Path
WORK=Path('/private/tmp/ashlar-count-star-installed-cli-c')
SITE=WORK/'venv/lib/python3.11/site-packages'
sys.path.insert(0,str(SITE))
from ashlar_host.count_star_query import commerce_count_star_request,commerce_path_cases,commerce_count_star_cases
from ashlar_host.count_star_oracle import original_commerce_count_star_oracle
from ashlar_host.commerce_path_oracle import original_commerce_path_oracle
from ashlar.weft_count_star_distribution import CountStarDistributionPaths,installed_count_star_schema_bundle
PUBLICATION=Path('/private/tmp/ashlar-indexed-commerce-publication-20261010-c')
def encoded(value):return json.dumps(value,separators=(',',':'),ensure_ascii=False).encode()+b'\n'
def write(path,raw):
 with path.open('xb')as f:f.write(raw)
def main():
 if Path(sys.modules['ashlar_host.count_star_query'].__file__).resolve()!=SITE/'ashlar_host/count_star_query.py':raise ValueError('installed-module-selection')
 if sys.argv[1]=='author':
  model=(PUBLICATION/'original-ontology.json').read_bytes();graph=(PUBLICATION/'original-graph.json').read_bytes();bindings=json.loads((PUBLICATION/'development-bindings.json').read_bytes());report=json.loads((PUBLICATION/'report.json').read_bytes());manifest=report['native_manifest'];registry=report['table_registry'];aliases={t:t.replace('local.','spark_catalog.',1)for t in json.loads(manifest['table_versions_json'])};cases=[]
  for name,sql in commerce_path_cases()+commerce_count_star_cases():
   request=commerce_count_star_request(sql,model,bindings,manifest,registry,aliases)
   oracle=original_commerce_count_star_oracle if name in dict(commerce_count_star_cases())else original_commerce_path_oracle
   expected=oracle(model,graph,request)
   cases.append({'id':name,'requestHex':encoded(request).hex(),'sourceOracle':expected})
  if len(cases)!=14:raise ValueError('gallery-count')
  write(WORK/'gallery-requests.json',encoded({'cases':cases,'scope':'Separately authored exact original14 gallery requests/independent source values only; no publication/source authority or native execution.'}))
 elif sys.argv[1]=='validate':
  sys.path.insert(0,'/private/tmp/truss-python-report-schema-env/lib/python3.11/site-packages')
  from ashlar_host.count_star_schema import make_offline_count_star_schema_validation
  from ashlar_host.count_star_admission import CountStarAdmissionConfig,admit_count_star_artifact
  paths=CountStarDistributionPaths(Path('/private/tmp/ashlar-count-star-fresh-install-e/checkout/distributions/index.json'),WORK/'weft-installation')
  schemas=dict(installed_count_star_schema_bundle(paths));selected={k:schemas[k]for k in ('compile-request-v0.4.1.schema.json','compile-response-v0.4.1.schema.json','logical-plan-v0.4.1.schema.json')};config=CountStarAdmissionConfig(16777216,make_offline_count_star_schema_validation(selected));gallery=json.loads((WORK/'gallery-requests.json').read_bytes());admitted=[]
  for i,case in enumerate(gallery['cases']):
   q=json.loads(bytes.fromhex(case['requestHex']));raw=(WORK/f'gallery-{i}-0.stdout').read_bytes();again=(WORK/f'gallery-{i}-1.stdout').read_bytes()
   if raw!=again:raise ValueError('gallery-recompile')
   r=json.loads(raw);admit_count_star_artifact(q,r,json.loads(again),config=config)
   if case['id']in ('grouped-count-having','expanded-count-having'):
    having=r['logicalPlan']['having']
    if len(having)!=1 or having[0]['count']['op']!='count'or having[0]['threshold']['value']!='0':raise ValueError('positive-having-selection')
    if not case['sourceOracle']['rows']:raise ValueError('positive-original-witness')
   admitted.append({'id':case['id'],'responseSha256':hashlib.sha256(raw).hexdigest(),'status':r['status'],'requiredCapabilities':r['logicalPlan']['requiredCapabilities'],'sourceOracle':case['sourceOracle']})
  write(WORK/'gallery-admission.json',encoded({'cases':admitted,'schemas':{k:hashlib.sha256(v).hexdigest()for k,v in selected.items()},'qualification':'Actual installedCLI compilation/public offline041 admission and original source oracle for14 gallery; no native SQL/source authority/PG access.'}))
 else:raise ValueError('phase')
if __name__=='__main__':main()
