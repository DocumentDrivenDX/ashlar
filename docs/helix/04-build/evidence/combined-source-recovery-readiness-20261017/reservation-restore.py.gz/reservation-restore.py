"""Private operator-selected restore of exact independently archived reservation bytes."""
import os,sys,json,hashlib,tarfile,sqlite3,fcntl,stat
from pathlib import Path
ROOT=Path(__file__).parent
PREP=Path('/private/tmp/ashlar-combined-current-20261017-e_7rpgcr')
sys.path.insert(0,str(PREP/'installed'))
from ashlar_host.evolution_cli import InvocationFile,parse_evolution_invocation,load_evolution_provider
from ashlar_host.evolution_operator import ExistingEvolutionLease,private
from ashlar_host.evolution_run import EvolutionRunDefinition,EvolutionRunLedger
from ashlar_host.lifecycle import finish
ARCHIVE=Path('/Users/erik/Projects/ashlar/docs/helix/04-build/evidence/evolution-installed-capacity-safe-timeout-20261011-n/actual.tar.gz')
ARCHIVE_SHA='77aabb6978300cd552810b14210d092b5200c4ab4f88e27ab582b985d9af8bd7'
MEMBER='ashlar-evolution-installed-native-20261011-n/retained-local-state/original-run.json'
SHA='8abac861a6ada92aee0fb4080c1230867d358d776c16c92c5a776538ea657f95'
def require(value):
 if not value:raise ValueError('Exact original backup restoration refused')
def main():
 os.umask(0o077)
 config=InvocationFile.read(PREP/'configuration.json',65536)
 invocation=parse_evolution_invocation(config.raw,'continue');require(invocation.expected_sha256==SHA)
 selection_file=InvocationFile.read(PREP/'selection.json',65536);selection=json.loads(selection_file.raw)
 environment=InvocationFile.read(Path(selection['operator_environment']),262144);os.environ.update(json.loads(environment.raw))
 provider_file=InvocationFile.read(PREP/'evolution_provider.py',262144)
 provider=load_evolution_provider(provider_file,selection['provider_sha256']);operator=provider.existing_operator()
 require(operator.reservation_path==Path('/private/tmp/ashlar-evolution-installed-native-20261011-f/installation/original-run.json'))
 require(ARCHIVE.stat().st_size==2761616)
 archive=ARCHIVE.read_bytes();require(hashlib.sha256(archive).hexdigest()==ARCHIVE_SHA)
 import io
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz')as t:
  info=t.getmember(MEMBER);require(info.isfile()and info.size==8090)
  raw=t.extractfile(info).read(8091)
 require(len(raw)==8090 and hashlib.sha256(raw).hexdigest()==SHA)
 original=EvolutionRunDefinition(raw);document=original.document()
 registry={t.table:{'uuid':t.uuid,'path':str(t.path)}for t in operator.targets}
 require(document['installation']['installation_id']==operator.installation_id and document['installation']['registry']==registry)
 require(invocation.ledger_path.parent==operator.journal_path.parent and invocation.ledger_path not in (operator.journal_path,operator.reservation_path))
 parent_identity=private(operator.journal_path.parent,directory=True)
 lock=operator.journal_path.parent/'.evolution-operator.lock'
 # The original lock must already exist; this script does not initialize owners.
 private(lock,maximum=4096)
 fd=os.open(lock,os.O_RDWR|os.O_NOFOLLOW|os.O_NONBLOCK)
 owner=None;primary=None;locked=False;written=False
 try:
  identity=private(lock,maximum=4096);f=os.fstat(fd);require((f.st_dev,f.st_ino)==identity)
  fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);locked=True
  owner=ExistingEvolutionLease(operator,invocation,object(),fd,identity,parent_identity)
  owner.renew(owner.context)
  require(not operator.reservation_path.exists()and not operator.reservation_path.is_symlink())
  ledger_identity=private(invocation.ledger_path)
  c=sqlite3.connect('file:'+str(invocation.ledger_path)+'?mode=ro',uri=True)
  try:
   c.execute('PRAGMA query_only=ON');require(c.execute('PRAGMA journal_mode').fetchone()==('delete',))
   rows=c.execute('SELECT id,original,digest FROM original_run LIMIT 2').fetchall()
   require(rows==[(1,raw,SHA)])
  finally:c.close()
  require(private(invocation.ledger_path)==ledger_identity)
  config.renew(65536);selection_file.renew(65536);environment.renew(262144);provider_file.renew(262144)
  require(ARCHIVE.read_bytes()==archive)
  owner.renew(owner.context)
  # Exact archived original bytes only, exclusive creation, never repair/overwrite.
  out=os.open(operator.reservation_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  try:
   require(stat.S_ISREG(os.fstat(out).st_mode));offset=0
   while offset<len(raw):
    n=os.write(out,raw[offset:]);require(n>0);offset+=n
   os.fsync(out)
  finally:os.close(out)
  parent=os.open(operator.reservation_path.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
  try:os.fsync(parent)
  finally:os.close(parent)
  written=True
  owner.admit_run(original,owner.context)
  inventory=EvolutionRunLedger.inspect(invocation.ledger_path,original,context=owner.context,custody=owner._ledger_custody)
  require(len(inventory.slots)==8)
 except BaseException as error:primary=error
 def close():
  if owner is not None:owner.closed=True
  if locked:fcntl.flock(fd,fcntl.LOCK_UN)
 def report(error):
  value={'restored':written,'original_bytes':8090,'original_sha256':SHA,'archive_sha256':ARCHIVE_SHA,'member':MEMBER,'native_or_source_operations':False,'success':error is None,'failure_class':type(error).__name__ if error else None}
  with (ROOT/'result.json').open('x')as s:json.dump(value,s,sort_keys=True);s.write('\n')
 try:
  finish(primary,([lambda:owner.renew(owner.context)]if owner is not None else [])+[close,lambda:os.close(fd),lambda:config.renew(65536),lambda:selection_file.renew(65536),lambda:environment.renew(262144),lambda:provider_file.renew(262144)])
 except BaseException as error:
  try:report(error)
  except BaseException:pass
  raise
 report(None)
if __name__=='__main__':main()
