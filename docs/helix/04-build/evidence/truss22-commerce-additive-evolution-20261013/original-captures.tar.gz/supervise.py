import subprocess,time,os,signal,json
from pathlib import Path
r=Path(__file__).parent;t=time.monotonic()
with (r/'run.log').open('xb')as f:
 p=subprocess.Popen(['/private/tmp/truss-pg18-consumer-env-20261011/bin/python',str(r/'run.py')],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=30);status='completed'
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait();status='deadline'
answer={'status':status,'exit_code':code,'duration_seconds':time.monotonic()-t};(r/'supervisor-result.json').write_text(json.dumps(answer,indent=2));print(json.dumps(answer),flush=True)
