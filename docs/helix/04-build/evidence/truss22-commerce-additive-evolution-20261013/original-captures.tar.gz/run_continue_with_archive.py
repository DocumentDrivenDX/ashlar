import sys,json,time,os,hashlib
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;l=Path('/private/tmp/ashlar-truss22-commerce-lifecycle-20261013-a');s=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a');o=r/'continued-with-archive';o.mkdir(mode=0o700)
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical'];sys.path[:0]=[str(r/'ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_resume_setup import run_configure_truss_resume_command
from ashlar_host.truss_continue_cli import run_continue_truss_graph_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_example import private_file
from ashlar_host.truss_page_archive import decode_truss_page
previous={k:os.environ.get(k)for k in ('JAVA_HOME','PYSPARK_PYTHON','PYSPARK_DRIVER_PYTHON')};primary=None;answer=None;t=time.monotonic()
def restore():
 for k,v in previous.items():
  if v is None:os.environ.pop(k,None)
  else:os.environ[k]=v
try:
 os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
 with owned_context(LocalPostgres(s/'data'))as runtime:
  params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);administrator=psycopg.conninfo.make_conninfo(**params);params['user']=json.loads((s/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
  def conn():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
  pending=read_page(conn,'commerce22-full-native',maximum_bytes=2097152);assert pending.content==(r/'pending-source-page.json').read_bytes() and pending.prior.content==(r/'checkpoint-after.bin').read_bytes()
  old=json.loads((l/'continued/continuation.json').read_bytes())['publications'][-1];selection=json.loads((s/'native/publish.json').read_bytes());selection.update(connection_uri=ordinary,administrator_uri=administrator);selection['archived_acceptance_files']=[{'path':str(r/'evolution.json'),'sha256':hashlib.sha256((r/'evolution.json').read_bytes()).hexdigest()}];reader=o/'old-reader.json';run_configure_truss_resume_command(private_file(o/'publisher-selection.json',selection),old['publication_intent']['path'],reader)
  start=time.monotonic();report=run_continue_truss_graph_command(reader,o/'continuation.json',maximum_pages=2,maximum_page_bytes=2097152);duration=time.monotonic()-start
  assert report['predecessor']==old['manifest']['publication_id'] and len(report['publications'])==2
  prior=pending.prior.content;views=[]
  for item in report['publications']:
   page=decode_truss_page(Path(item['source_page']['path']).read_bytes(),item['source_page']['sha256'],'commerce22-full');assert page.prior.content==prior;prior=page.next.content;views.append({'publication_id':item['manifest']['publication_id'],'source_page_sha256':item['source_page']['sha256'],'changes':len(json.loads(page.content)['changes'])})
  after=read_page(conn,'commerce22-full-native',maximum_bytes=2097152);private_file(o/'checkpoint-after.bin',after.prior.content);private_file(o/'remaining-source-page.json',after.content);assert after.prior.content==prior
  answer={'outcome':'passed','continuation_seconds':duration,'predecessor':report['predecessor'],'publications':views,'source_advanced_to_exact_last_page_next':True,'scope':'Two actual original-commerce additive catalog/update transactions through existing local Delta publication/journal and exact source-retained receipt ACK, complete native effect parity. No subsequent query, Unity Catalog or protected production authority claim.'}
except BaseException as error:primary=error
finish(primary,[restore]);answer['duration_seconds']=time.monotonic()-t;private_file(o/'result.json',answer);print(json.dumps(answer),flush=True)
