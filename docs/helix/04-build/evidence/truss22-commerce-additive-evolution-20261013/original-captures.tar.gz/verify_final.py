import sys,json,time,os
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;s=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a');o=r/'verified';o.mkdir(mode=0o700)
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical'];sys.path[:0]=[str(r/'ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_resume_setup import run_configure_truss_resume_command
from ashlar_host.truss_scalar_query_cli import run_query_truss_scalars_command
from ashlar_host.truss_record_read import run_read_truss_record_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_example import private_file
from ashlar_host.truss_page_archive import decode_truss_page
report=json.loads((r/'continued-with-archive/continuation.json').read_bytes());assert len(report['publications'])==2
prior=(r/'checkpoint-before.bin').read_bytes();views=[]
for item in report['publications']:
 page=decode_truss_page(Path(item['source_page']['path']).read_bytes(),item['source_page']['sha256'],'commerce22-full');assert page.prior.content==prior;prior=page.next.content
 validation=json.loads(item['manifest']['validation_report_json']);assert validation['complete'] is True
 views.append({'publication_id':item['manifest']['publication_id'],'source_page_sha256':item['source_page']['sha256'],'changes':len(json.loads(page.content)['changes']),'validation':validation})
previous={k:os.environ.get(k)for k in ('JAVA_HOME','PYSPARK_PYTHON','PYSPARK_DRIVER_PYTHON')};primary=None;answer=None;t=time.monotonic();phases={}
def restore():
 for k,v in previous.items():
  if v is None:os.environ.pop(k,None)
  else:os.environ[k]=v
try:
 os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
 with owned_context(LocalPostgres(s/'data'))as runtime:
  params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);administrator=psycopg.conninfo.make_conninfo(**params);params['user']=json.loads((s/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
  def conn():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
  pending=read_page(conn,'commerce22-full-native',maximum_bytes=2097152);private_file(o/'checkpoint-before.bin',pending.prior.content);private_file(o/'remaining-source-page.json',pending.content);assert pending.prior.content==prior
  selection=json.loads((s/'native/publish.json').read_bytes());selection.update(connection_uri=ordinary,administrator_uri=administrator);selection['archived_acceptance_files']=[{'path':str(r/'evolution.json'),'sha256':__import__('hashlib').sha256((r/'evolution.json').read_bytes()).hexdigest()}];reader=o/'reader.json';run_configure_truss_resume_command(private_file(o/'publisher-selection.json',selection),report['publications'][-1]['publication_intent']['path'],reader)
  start=time.monotonic();price=run_query_truss_scalars_command(reader,o/'price-query.json',compiler='/private/tmp/ashlar-compatible-weft-compile-20261013-a/weft-runtime',sql='SELECT p.unit_price AS price FROM products p',revision='2',document_id='urn:umf:domain:commerce',physical_revisions=('1','2'),maximum_rows=1);phases['updated_price_query']=time.monotonic()-start;assert price['rows']==[{'price':{'decimal_token':'13.75'}}]
  start=time.monotonic();deleted=run_read_truss_record_command(reader,o/'evolved-product.json',type_id=7,entity_id=3);phases['evolved_singleton']=time.monotonic()-start;fields={x['field_id']:x for x in deleted['record']['fields']};assert len(fields)==5 and fields['products.display_label']['value']=='Original product P1' and fields['products.unit_price']['value']=={'decimal_token':'13.75'} and deleted['publication_id']==price['publication_id']==report['publications'][-1]['manifest']['publication_id']
  after=read_page(conn,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(o/'checkpoint-after.bin',after);assert after==pending.prior.content
  answer={'outcome':'passed','predecessor':report['predecessor'],'publications':views,'phases':phases,'source_advanced_to_exact_last_next':True,'final_price':price['rows'],'new_field_singleton_exact':True,'query_checkpoint_unchanged':True,'scope':'Read-only compatible-revision2 price query across selected original physical revisions1/2, exact new-field singleton and source checkpoint closure on completed original08 additive evolution publication; no source effects were retried.'}
except BaseException as error:primary=error
finish(primary,[restore]);answer['duration_seconds']=time.monotonic()-t;private_file(o/'result.json',answer);print(json.dumps({k:v for k,v in answer.items()if k!='publications'}),flush=True)
