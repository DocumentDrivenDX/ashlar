import sys,json,time,base64,hashlib
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;s=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a');p=Path('/private/tmp/ashlar-commerce-additive-evolution-proposal-20261013-a');l=Path('/private/tmp/ashlar-truss22-commerce-lifecycle-20261013-a')
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical'];sys.path[:0]=[str(r/'ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres,Ok,CatalogRuntimeConfiguration,create_reference_assembly,adopt_psycopg_host,ObjectFound,AcceptedDocument
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_example import private_file
from ashlar_host.truss_note_publication import read_page
from ashlar.cli import main
from dataclasses import asdict
t=time.monotonic()
with owned_context(LocalPostgres(s/'data'))as runtime:
 params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);params['user']=json.loads((s/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
 def conn():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
 before=read_page(conn,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(r/'checkpoint-before.bin',before);assert before==(l/'verified/checkpoint-after.bin').read_bytes()
 with conn()as connection:
  connection.execute('SET TRANSACTION ISOLATION LEVEL READ COMMITTED');connection.execute("SET LOCAL statement_timeout = '15000ms'");host=adopt_psycopg_host(connection);assembly=None;primary=None
  try:
   tx=host.adopt_transaction();assert isinstance(tx,Ok);a=create_reference_assembly(CatalogRuntimeConfiguration(),host);assert isinstance(a,Ok);assembly=a.value
   current=assembly.get_object_in_transaction(tx.value,document_id='urn:umf:domain:commerce',module_id='domain',record_id='products',object_id=3);assert isinstance(current,Ok)and isinstance(current.value,ObjectFound);obj=current.value.object;assert obj.version==2 and dict(obj.values)['unit_price'].text=='13.75'
   accepted=assembly.accepted_document_in_transaction(tx.value,document_id='urn:umf:domain:commerce');assert isinstance(accepted,Ok)and isinstance(accepted.value,AcceptedDocument);assert accepted.value.document_revision=='1'and accepted.value.content==(p/'revision1-original.json').read_bytes();private_file(r/'live-before.json',asdict(obj))
  except BaseException as error:primary=error
  def detach():
   if not host.detach():raise RuntimeError('detach refused')
  finish(primary,([assembly.dispose]if assembly else [])+[detach])
 config=json.loads((p/'evolution-configuration-proposed.json').read_bytes());config['connection_uri']=ordinary;configuration=private_file(r/'configuration.json',config)
 start=time.monotonic();sys.argv=['ashlar','evolve-truss-record','--configuration',str(configuration),'--output',str(r/'evolution.json')];main();duration=time.monotonic()-start;result=json.loads((r/'evolution.json').read_bytes())
 assert result['before']['version']==2 and result['after']['version']==3 and result['registration']['revision']==2 and dict(result['after']['values'])['display_label']=='Original product P1'and dict(result['after']['values'])['unit_price']=={'kind':'decimal','text':'13.75'}
 assert base64.b64decode(result['previous_document']['content_original_base64'])==(p/'revision1-original.json').read_bytes()and base64.b64decode(result['accepted_document']['content_original_base64'])==(p/'revision2-proposed.json').read_bytes()
 report=json.loads(base64.b64decode(result['report_original_base64']));properties=[x for x in report['properties']if x['moduleId']=='domain'and x['elementId']=='products.display_label'];assert len(properties)==1
 after=read_page(conn,'commerce22-full-native',maximum_bytes=2097152);private_file(r/'checkpoint-after.bin',after.prior.content);private_file(r/'pending-source-page.json',after.content);private_file(r/'pending-next.bin',after.next.content);assert after.prior.content==before
 answer={'outcome':'passed','evolution_seconds':duration,'catalog_revision':2,'observed_new_property_id':properties[0]['propertyId'],'object_version':3,'authored_name':'display_label','element_id':'products.display_label','source_checkpoint_unchanged':True,'duration_seconds':time.monotonic()-t,'scope':'Actual original08 additive absent-allowed STRING catalog acceptance, exact declared name update and complete public readback/replay. Originalrevision1/2 bytes retained. No Delta/feed/ACK or compatible-query qualification.'};private_file(r/'result.json',answer)
print(json.dumps(answer),flush=True)
