"""Closed native-probe process, capture and immutable opening/closing custody."""
import hashlib,json,os,selectors,signal,stat,subprocess,sys,time
from pathlib import Path
ROOT=Path('/Users/erik/Projects/ashlar')
SCRIPT=Path('/private/tmp/ashlar-scoped-phase-native-probe-20261010-b.py')
CLOSURE=Path('/private/tmp/ashlar-scoped-phase-native-closure-20261010-b.json')
CLOSURE_SHA='63557f3a0f082a457c4d217e3e7514fc330b180795519057089ce1a44fa4de96'
LOG=Path('/private/tmp/ashlar-scoped-phase-native-20261010-b.log')
RECEIPT=Path('/private/tmp/ashlar-scoped-phase-native-run-20261010-b.json')
PYTHON='/private/tmp/ashlar-spark311/bin/python'
MAXIMUM_CAPTURE=8*1024*1024
ENV={'PATH':'/opt/homebrew/opt/openjdk@21/bin:/usr/bin:/bin','JAVA_HOME':'/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home',
    'PYTHONPATH':str(ROOT/'src')+':/private/tmp/ashlar-indexed-delta4-python-20261010-a:/private/tmp/ashlar-spark4-python39-bridge',
    'PYSPARK_PYTHON':PYTHON,'PYSPARK_DRIVER_PYTHON':PYTHON,'SPARK_LOCAL_IP':'127.0.0.1','PYTHONDONTWRITEBYTECODE':'1'}
COMMAND=[PYTHON,'-B','-S',str(SCRIPT)]

def digest(path):
    result=hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda:source.read(1024*1024),b''):result.update(chunk)
    return result.hexdigest()

def verify(expected_runner):
    if digest(Path(__file__))!=expected_runner or digest(CLOSURE)!=CLOSURE_SHA:
        raise ValueError('Frozen runner/runtime closure custody differs')
    closure=json.loads(CLOSURE.read_bytes())
    current=set()
    for root in closure['roots']:
        current.update(str(p) for p in Path(root).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='.DS_Store')
    expected_runtime={name for name in closure['files'] if any(name.startswith(root+'/') for root in closure['roots'])}
    if current!=expected_runtime:raise ValueError('Complete selected immutable runtime inventory differs')
    for name,expected in closure['files'].items():
        path=Path(name)
        if (str(path.resolve())!=expected['resolved'] or not path.is_file()
                or path.stat().st_size!=expected['bytes'] or digest(path)!=expected['sha256']):
            raise ValueError('Frozen source/runtime/jar/probe custody differs')


def write_all(descriptor,raw):
    offset=0
    while offset<len(raw):
        written=os.write(descriptor,raw[offset:])
        if written<=0:raise OSError('Original capture write incomplete')
        offset+=written


def run(expected_runner):
    if len(expected_runner)!=64 or any(c not in '0123456789abcdef' for c in expected_runner):raise ValueError('Trusted reviewed runner hash required')
    verify(expected_runner)
    log_fd=os.open(LOG,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    try:receipt_fd=os.open(RECEIPT,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    except BaseException:os.close(log_fd);raise
    process=None;selector=None;primary=None;errors=[];captured=0;result=None;started=time.monotonic();cleanup=[];timed_out=False;capture_limited=False
    def collect(callback):
        try:callback()
        except BaseException as error:errors.append(error)
    def terminate():
        if process is None:return
        for sig,delay in ((signal.SIGTERM,5),(signal.SIGKILL,1)):
            try:os.killpg(process.pid,sig);cleanup.append(sig.name)
            except ProcessLookupError:break
            until=time.monotonic()+delay
            while time.monotonic()<until:
                process.poll()
                try:os.killpg(process.pid,0)
                except ProcessLookupError:break
                time.sleep(0.05)
    def force_kill():
        if process is None:return
        try:os.killpg(process.pid,signal.SIGKILL);cleanup.append('SIGKILL')
        except ProcessLookupError:pass
    def reap():
        if process is not None:process.wait(timeout=1)
    try:
        process=subprocess.Popen(COMMAND,cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
        selector=selectors.DefaultSelector();selector.register(process.stdout,selectors.EVENT_READ)
        while selector.get_map():
            if time.monotonic()-started>=180:timed_out=True;raise TimeoutError('Bounded native probe deadline')
            for key,_ in selector.select(timeout=0.2):
                chunk=os.read(key.fileobj.fileno(),65536)
                if not chunk:selector.unregister(key.fileobj);continue
                room=MAXIMUM_CAPTURE-captured
                if len(chunk)>room:
                    write_all(log_fd,chunk[:room]);captured+=room;capture_limited=True;raise ValueError('Bounded native probe capture limit')
                write_all(log_fd,chunk);captured+=len(chunk)
        result=process.wait(timeout=max(0.1,180-(time.monotonic()-started)))
        if result!=0:raise RuntimeError('Original native probe failed')
    except BaseException as error:primary=error
    finally:
        collect(terminate)
        collect(force_kill)
        collect(reap)
        if selector is not None:collect(selector.close)
        if process is not None and process.stdout is not None:collect(process.stdout.close)
        collect(lambda:os.fsync(log_fd));collect(lambda:os.close(log_fd))
        collect(lambda:verify(expected_runner))
        selected=primary
        cancellations=(KeyboardInterrupt,SystemExit,GeneratorExit)
        if not isinstance(selected,cancellations):
            selected=next((error for error in errors if isinstance(error,cancellations)),selected)
        if selected is None and errors:selected=errors[0]
        receipt={'result':result,'timed_out':timed_out,'capture_limited':capture_limited,'captured_bytes':captured,
            'elapsed_seconds':time.monotonic()-started,'process_group':None if process is None else process.pid,
            'cleanup_signals':cleanup,'command':COMMAND,'environment':ENV,'runner_sha256':expected_runner,
            'closure_sha256':CLOSURE_SHA,'primary_outcome':None if selected is None else type(selected).__name__,
            'cleanup_errors':[type(error).__name__ for error in errors],
            'qualification':'One bounded local native phase SQL probe; no cloud/source/ACK/graph/native full-run qualification.'}
        def retain():
            raw=(json.dumps(receipt,indent=2)+'\n').encode()
            write_all(receipt_fd,raw)
            os.fsync(receipt_fd)
        collect(retain);collect(lambda:os.close(receipt_fd))
        if not isinstance(primary,cancellations):
            cancellation=next((error for error in errors if isinstance(error,cancellations)),None)
            if cancellation is not None:selected=cancellation
        if selected is None and errors:selected=errors[0]
        if selected is not None:raise selected
    return 0

if __name__=='__main__':
    if len(sys.argv)!=2:raise ValueError('Exact reviewed runner SHA argument required')
    raise SystemExit(run(sys.argv[1]))
