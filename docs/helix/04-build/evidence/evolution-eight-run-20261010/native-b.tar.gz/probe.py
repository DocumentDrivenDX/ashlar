"""One bounded actual scoped-phase table; no graph/source/ACK publication proof."""
from contextlib import contextmanager
import hashlib,importlib.metadata,json,os,sys
from pathlib import Path
from ashlar.attempt_store import DeltaAttemptStore,AttemptStoreError
from ashlar.native import SQLResult
from ashlar.outbox import PostgresOutbox
from ashlar_host.driver import request_for
from pyspark.sql import SparkSession

OUTPUT=Path('/private/tmp/ashlar-scoped-phase-native-20261010-b')
ROOT=Path('/Users/erik/Projects/ashlar')
JARS=[Path('/private/tmp/ashlar-delta4-jars')/name for name in ('delta-spark_2.13-4.0.0.jar','delta-storage-4.0.0.jar')]
if OUTPUT.exists():raise ValueError('Fresh probe output required; no replacement')
if {name:importlib.metadata.version(name) for name in ('pyspark','delta-spark')}!={'pyspark':'4.0.1','delta-spark':'4.0.0'}:raise ValueError('Selected existing runtime required')
OUTPUT.mkdir(mode=0o700);records=[];spark=None
try:
    spark=(SparkSession.builder.master('local[1]').appName('Ashlar scoped phase bounded native probe')
        .config('spark.driver.memory','512m').config('spark.sql.shuffle.partitions','1')
        .config('spark.databricks.delta.snapshotPartitions','1').config('spark.ui.enabled','false')
        .config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true')
        .config('spark.sql.warehouse.dir',str(OUTPUT/'warehouse'))
        .config('spark.jars',','.join(str(path) for path in JARS))
        .config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension')
        .config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog').getOrCreate())
    table='spark_catalog.ashlar_scoped_phase_20261010b.attempts';quoted='`spark_catalog`.`ashlar_scoped_phase_20261010b`.`attempts`'
    spark.sql('CREATE DATABASE ashlar_scoped_phase_20261010b LOCATION '+repr(str(OUTPUT/'namespace')))
    spark.sql('CREATE TABLE '+quoted+' (stream STRING NOT NULL,batch_id STRING NOT NULL,phase STRING NOT NULL,request_digest STRING NOT NULL,payload_json STRING NOT NULL,payload_digest STRING NOT NULL) USING DELTA LOCATION '+repr(str(OUTPUT/'attempts')))
    uuid=spark.sql('DESCRIBE DETAIL '+quoted).first().id;context=object();held=False
    class Executor:
        def query(self,sql,parameters):
            rows=[row.asDict() for row in spark.sql(sql,args=parameters).collect()]
            records.append({'sql':sql,'parameters_sha256':hashlib.sha256(json.dumps(parameters,sort_keys=True).encode()).hexdigest(),'rows':rows})
            return SQLResult(rows)
    class Policy:
        @contextmanager
        def writer(self,selected,native_uuid,supplied):
            global held
            if held or supplied is not context or selected!=table or native_uuid!=uuid:raise PermissionError('Exact owned probe interval required')
            if spark.sql('DESCRIBE DETAIL '+quoted).first().id!=uuid:raise PermissionError('Actual native UUID differs')
            held=True
            try:yield
            finally:held=False
    raw=(ROOT/'examples/end-to-end/source.jsonl').read_bytes()
    if hashlib.sha256(raw).hexdigest()!='4d5e4b043d260e4ecc77f2ddc6ed051cb85cb75381d308da981ac1e2ea09c3de':raise ValueError('Pinned source fixture differs')
    class SourceReader:
        def query(self,sql,parameters):
            return SQLResult([{'position':'1'}] if '.head ' in sql else [{'position':'1','batch_id':'fixture-tx-1','payload':raw.decode(),'digest':hashlib.sha256(raw).hexdigest()}])
    requests=[];executor=Executor()
    def source(feed,predecessor='prior'):
        tx=PostgresOutbox(SourceReader(),feed=feed,epoch='original').read('0')[0]
        return request_for('shared-stream',tx,predecessor,{feed:'1'})
    def artifact(request):
        return json.dumps({'profile':'ashlar-scoped-phase-native-probe/0.1','qualification':'opaque original phase carrier only',
            'request_digest':request['request_digest'],'source_checkpoint':json.loads(request['source_checkpoint_json']),
            'original_attempt_table_uuid':uuid},sort_keys=True,separators=(',',':'))
    for feed in ('A','B'):
        request=source(feed);requests.append(request)
        store=DeltaAttemptStore(executor,Policy(),table,uuid,original_request=request)
        with store.session(context) as session:
            for phase in ('prepared','applying','applied','committing','committed'):
                kwargs={} if phase in ('prepared','applying') else {'result_json':artifact(request)}
                if phase=='committed':kwargs['descriptor_json']=artifact(request)
                session.append(request,phase,**kwargs)
    before=spark.sql('DESCRIBE HISTORY '+quoted).first().version
    original_rows=[row.asDict() for row in spark.sql('SELECT * FROM '+quoted).collect()]
    if len(original_rows)!=10:raise ValueError('Exactly ten original phase rows required')
    for request in requests:
        store=DeltaAttemptStore(executor,Policy(),table,uuid,original_request=request)
        with store.session(context) as session:
            if len(session.read('shared-stream','fixture-tx-1'))!=5:raise ValueError('Complete original phase replay required')
            for phase in ('prepared','applying','applied','committing','committed'):
                kwargs={} if phase in ('prepared','applying') else {'result_json':artifact(request)}
                if phase=='committed':kwargs['descriptor_json']=artifact(request)
                session.append(request,phase,**kwargs)
    after=spark.sql('DESCRIBE HISTORY '+quoted).first().version
    if before!=after:raise ValueError('Replay changed native table version')
    changed=source('A','replacement');refused=False
    with DeltaAttemptStore(executor,Policy(),table,uuid,original_request=changed).session(context) as session:
        try:session.read('shared-stream','fixture-tx-1')
        except AttemptStoreError:refused=True
    if not refused:raise ValueError('Changed same-source original was not refused')
    corrupt=json.dumps({});digest=hashlib.sha256(corrupt.encode()).hexdigest()
    spark.sql('INSERT INTO '+quoted+' VALUES (:stream,:batch,:phase,:request,:payload,:digest)',args={'stream':'shared-stream','batch':'fixture-tx-1','phase':'prepared','request':'a'*64,'payload':corrupt,'digest':digest})
    refused=False
    with DeltaAttemptStore(executor,Policy(),table,uuid,original_request=requests[0]).session(context) as session:
        try:session.read('shared-stream','fixture-tx-1')
        except AttemptStoreError:refused=True
    if not refused:raise ValueError('Malformed neighboring source custody hidden')
    summary={'state':'passed','runtime':{'pyspark':'4.0.1','delta-spark':'4.0.0'},'table':table,'uuid':uuid,
        'phase_rows_before_negative_control':original_rows,'native_version_before_replay':before,'native_version_after_replay':after,
        'native_history':[row.asDict() for row in spark.sql('DESCRIBE HISTORY '+quoted).collect()],
        'source_sha256':hashlib.sha256(raw).hexdigest(),'requests':requests,'changed_original_refused':True,'malformed_neighbor_refused':True,
        'qualification':'One local native six-column Delta phase carrier, two qualified sources sharing stream/local batch; ten immutable original phase rows plus one deliberate malformed negative-control row. No actual external source, native graph/publication/ACK, scale or installed eight-step qualification.'}
    (OUTPUT/'summary.json').write_text(json.dumps(summary,indent=2,default=str)+'\n')
finally:
    (OUTPUT/'sql-records.json').write_text(json.dumps(records,indent=2,default=str)+'\n')
    if spark is not None:spark.stop()
