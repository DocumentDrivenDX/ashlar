"""Pure path/source controls; no build, import of DuckDB, install or child process."""
import hashlib,json,runpy,tarfile
from pathlib import Path
P=Path('/private/tmp');prefix='ashlar-puppy-preparation-installed-';module=runpy.run_path(str(P/(prefix+'build-20261010-e.py')));work=module['WORK'];labels=['wheel','venv','pip-install','readback']+['prepare-'+v for v in ('ca4b40f78b1a27e3d6df50eb17816ec49e30f0f70d6ff7dabc195307c07642e7','a6a4cb268f6bb3f8d193b35289d5b593ad08e33d8fc561e29487919fd1502e3a')]
paths=[p for label in labels for p in module['phase_paths'](work,label)];assert len(paths)==len(set(paths));assert all(p.parent==work/'parent-phases'for p in paths);assert work/'readback.json'not in paths
for label in ('../readback','readback.json','x/y','',True):
 try:module['phase_paths'](work,label)
 except ValueError:pass
 else:raise AssertionError('Unclosed phase label accepted')
# Exact original provider authority and readback cell/oracle code preserved except named attempt path.
for role in ('provider','readback'):
 old=(P/(prefix+role+'-20261010-c.py')).read_bytes();new=(P/(prefix+role+'-20261010-e.py')).read_bytes();assert new==old.replace(b'20261010-c',b'20261010-e')
freeze=json.loads((P/(prefix+'failure-freeze-20261010-c.json')).read_bytes())
for x in freeze['outputs']:
 b=Path(x['path']).read_bytes();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256']
inv=json.loads((P/(prefix+'source-inventory-20261010-e.json')).read_bytes());rows={x['path']:x for x in inv['files']};seen=set()
with tarfile.open(P/(prefix+'source-20261010-d.tar'))as tar:
 for member in tar:
  if member.isdir():continue
  assert member.isfile()and member.name in rows and member.name not in seen;seen.add(member.name);b=tar.extractfile(member).read();x=rows[member.name];assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256']
assert seen==set(rows)
print('Pure complete phase namespace, unchanged original provider/readback, preserved25Coutputs and172Git-source archive correspondence PASS')
# Complete namespace renewal refuses pre-existing bytecode changes and new aliases.
import tempfile
runner=runpy.run_path(str(P/(prefix+'runner-20261010-e.py')))
with tempfile.TemporaryDirectory()as directory:
 root=Path(directory);(root/'__pycache__').mkdir();bytecode=root/'__pycache__/existing.pyc';bytecode.write_bytes(b'bytecode');target=root/'source.py';target.write_bytes(b'source');link=root/'alias.py';link.symlink_to(target)
 namespace={'root':str(root),'entries':runner['namespace_entries'](root)};runner['verify_namespace'](namespace)
 for extra in (root/'__pycache__/unlisted.pyc',root/'unlisted-alias.py'):
  if extra.suffix=='.pyc':extra.write_bytes(b'new')
  else:extra.symlink_to(target)
  try:runner['verify_namespace'](namespace)
  except ValueError:pass
  else:raise AssertionError('Unlisted importable carrier accepted')
  extra.unlink()
 link.unlink();link.symlink_to(bytecode)
 try:runner['verify_namespace'](namespace)
 except ValueError:pass
 else:raise AssertionError('Changed alias accepted')
print('Complete existing bytecode namespace and unlisted/changed alias refusal controls PASS')
