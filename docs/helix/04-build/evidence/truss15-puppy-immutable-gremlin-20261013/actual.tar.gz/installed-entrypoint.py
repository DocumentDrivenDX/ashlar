#!/private/tmp/ashlar-truss15-puppy-gremlin-20261013-a/venv/bin/python
# -*- coding: utf-8 -*-
import sys
from ashlar.cli import main
if __name__ == "__main__":
    if sys.argv[0].endswith("-script.pyw"):
        sys.argv[0] = sys.argv[0][:-11]
    elif sys.argv[0].endswith(".exe"):
        sys.argv[0] = sys.argv[0][:-4]
    sys.exit(main())
