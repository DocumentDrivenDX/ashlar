"""Pinned operator diagnostics around the unchanged public verification CLI."""
import os,sys,json,signal,faulthandler,hashlib,runpy,importlib.util
from pathlib import Path
from ashlar_host.lifecycle import finish,owned_context
R=Path(__file__).resolve().parent
original=(R/'preparation.json').read_bytes();selection=json.loads(original)
def renew():
 if (R/'preparation.json').read_bytes()!=original:raise PermissionError('Original operator selection changed')
 for pin in selection['pins']:
  raw=Path(pin['path']).read_bytes()
  if len(raw)!=pin['bytes']or hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise PermissionError('Original operator input changed')
renew();os.environ.update(json.loads((R/'operator-environment.json').read_bytes()))
boot=json.loads((R.parent/'native-bootstrap-control-r2/bootstrap-selection.json').read_bytes())
os.environ['JAVA_HOME']=boot['java_home'];os.environ['PYSPARK_PYTHON']=sys.executable;os.environ['PYSPARK_DRIVER_PYTHON']=sys.executable;os.environ['SPARK_LOCAL_IP']='127.0.0.1'
helper_path=R/'trace_native_verification.py';spec=importlib.util.spec_from_file_location('pinned_native_verification_trace',helper_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
owner=helper.NativeVerificationTrace(R/'trace.json')
sys.argv=['ashlar','verify-commerce-evolution-publication','--configuration',str(R/'configuration.json'),'--provider',str(R/'provider.py'),'--provider-sha256',hashlib.sha256((R/'provider.py').read_bytes()).hexdigest()]
def terminate(signum,frame):raise KeyboardInterrupt()
signal.signal(signal.SIGTERM,terminate)
primary=None;returned=False;closing_pins=False
try:
 with owned_context((R/'private-stack.txt').open('x'))as stream:
  faulthandler.enable(file=stream);faulthandler.dump_traceback_later(120,file=stream,repeat=False)
  body=None
  try:
   with owner:runpy.run_module('ashlar',run_name='__main__')
   returned=True
  except BaseException as error:body=error
  finish(body,[faulthandler.cancel_dump_traceback_later])
 if returned:
  answer=json.loads((R/'ordinal-0-verification.json').read_bytes())
  assert answer['ordinal']==0 and answer['completed_prefix']==selection['expected_completed_prefix']and answer['run_size']==8
  assert answer['native_schema_profile']=='canonical-managed-carriers/0.1'
  assert answer['generated_carriers_sha256']=='89bcb139316bfbb110c9f3beaa1b582de6d521239217abcc307e55fc43a81e45'
except BaseException as error:primary=error
def close_pins():
 global closing_pins
 renew();closing_pins=True
def retain_diagnostic():
 # Observer/report errors never discharge guards or replace an ordinary CLI
 # outcome. Cancellation remains BaseException-transparent through finish.
 fd=None;error=None
 try:
  raw=(json.dumps({'profile':'ashlar-operator-trace-runner-result/0.1','diagnostic_failed':owner.diagnostic_failed,'public_cli_returned':returned,'primary_error_class':None if primary is None else type(primary).__name__,'closing_pins_completed':closing_pins},sort_keys=True)+'\n').encode()
  if len(raw)>4096:raise ValueError('Bounded diagnostic result required')
  fd=os.open(R/'runner-result.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  if os.write(fd,raw)!=len(raw):raise OSError('Exact diagnostic write required')
  os.fsync(fd)
 except BaseException as failure:error=failure
 try:finish(error,[]if fd is None else[lambda:os.close(fd)])
 except Exception:pass
finish(primary,[close_pins,retain_diagnostic])
