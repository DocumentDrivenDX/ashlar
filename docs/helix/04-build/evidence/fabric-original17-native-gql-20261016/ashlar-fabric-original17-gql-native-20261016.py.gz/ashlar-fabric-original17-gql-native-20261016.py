"""Native original-pack oracle trial; NOT publication-bound adapter qualification."""
import pathlib,json,subprocess,urllib.request,urllib.error,urllib.parse,time,hashlib,sys,re
from ashlar_host.fabric_pack_scenarios import gql_plan,validate_gql_case
from ashlar_host.fabric_gql import FabricGqlResult
pack=sys.argv[1];root=pathlib.Path('/private/tmp/ashlar-fabric-typed-create-20261016b-'+pack);out=root/'gql';out.mkdir(exist_ok=False)
profile=json.loads((root/'definition/scenario-profile.json').read_bytes());cases=json.loads((root/'definition/queries.json').read_bytes())
items=[json.loads(p.read_bytes())for p in root.glob('operation-*.json')];item=next(x['body']for x in items if x['url'].endswith('/result')and x['http_status']==200)
token=json.loads(subprocess.run(['az','account','get-access-token','--resource','https://api.fabric.microsoft.com','-o','json'],capture_output=True,check=True,timeout=30).stdout)['accessToken']
endpoint='https://api.fabric.microsoft.com/v1/workspaces/'+item['workspaceId']+'/graphModels/'+item['id']+'/executeQuery?beta=true'
started=time.monotonic();deadline=started+180;passed=[]
def scalar(kind,value):
 if value is None:return None
 if kind=='STRING'and type(value)is str:return value
 if kind in ('INT64','UINT64'):
  if type(value)is str and re.fullmatch('0|-?[1-9][0-9]*',value)and len(value)<=20:value=int(value)
  if type(value)is int and (-(2**63)if kind=='INT64'else 0)<=value<(2**63 if kind=='INT64'else 2**64):return value
 raise ValueError('Exact native scalar required')
try:
 for case in cases:
  name=case['case'];query,names=gql_plan(profile,name);assert query==case['gql'];body=json.dumps({'query':query},ensure_ascii=False,separators=(',',':')).encode();url=endpoint;responses=[]
  (out/(name+'-intent.json')).write_text(json.dumps({'query':query,'request_sha256':hashlib.sha256(body).hexdigest()})+'\n')
  for page in range(12):
   remaining=deadline-time.monotonic()
   if remaining<=0:raise TimeoutError('Whole trial deadline')
   req=urllib.request.Request(url,data=body,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
   try:reply=urllib.request.urlopen(req,timeout=min(60,remaining))
   except urllib.error.HTTPError as e:reply=e
   with reply as r:raw=r.read(1048577);status=r.status
   (out/(name+'-response-'+str(page)+'.json')).write_bytes(raw)
   if len(raw)>1048576 or status!=200:raise ValueError('Native HTTP refusal/capacity')
   responses.append(raw);v=json.loads(raw);s=v['status'];table=v['result']
   if s['code']not in ('00000','02000')or s.get('cause')is not None or v.get('additionalStatuses',[])!=[]or table['kind']!='TABLE':raise ValueError('Native status warning/refusal')
   if table.get('nextPage')is not None:
    if table.get('columns')or table.get('data')or s['code']!='02000':raise ValueError('Partial response refused')
    page_token=table['nextPage'];assert type(page_token)is str and 0<len(page_token)<=8192
    url=endpoint+'&continuationToken='+urllib.parse.quote(page_token,safe='');continue
   columns=tuple((c['name'],c['gqlType'])for c in table['columns']);assert tuple(c[0]for c in columns)==tuple(names)
   data=table['data'];assert type(data)is list and len(data)<=1000
   if s['code']=='02000'and data:raise ValueError('Empty native status disagrees with rows')
   rows=[]
   for row in data:
    assert set(row)==set(names);rows.append(tuple(scalar(kind,row[n])for n,kind in columns))
   result=FabricGqlResult(hashlib.sha256(body).hexdigest(),tuple(responses),columns,tuple(rows));validate_gql_case(profile,name,result)
   if time.monotonic()>=deadline:raise TimeoutError('Whole trial deadline after oracle')
   passed.append({'case':name,'rows':len(rows),'columns':columns});(out/'passed.json').write_text(json.dumps(passed,indent=2)+'\n');print(json.dumps(passed[-1]),flush=True);break
  else:raise ValueError('Continuation capacity')
 (out/'result.json').write_text(json.dumps({'state':'passed','pack':pack,'cases':passed,'elapsed_seconds':time.monotonic()-started,'scope':'Native private typed graph original17 oracle only; not live publication/source ACK authority'},indent=2)+'\n')
except BaseException as e:
 (out/'failure.json').write_text(json.dumps({'state':'incomplete','type':type(e).__name__,'passed':len(passed),'elapsed_seconds':time.monotonic()-started,'uncertain_query':name})+'\n');raise
