"""Native complete typed graph-bag parity; no live publication authority."""
import pathlib,json,subprocess,urllib.request,urllib.error,time,sys,hashlib,re
from collections import Counter
pack=sys.argv[1];root=pathlib.Path('/private/tmp/ashlar-fabric-typed-create-20261016b-'+pack);out=root/'parity';out.mkdir(exist_ok=False)
p=json.loads((root/'definition/scenario-profile.json').read_bytes());d=json.loads((root/'definition/graphType.json').read_bytes());items=[json.loads(x.read_bytes())for x in root.glob('operation-*.json')];item=next(x['body']for x in items if x['url'].endswith('/result')and x['http_status']==200)
t=json.loads(subprocess.run(['az','account','get-access-token','--resource','https://api.fabric.microsoft.com','-o','json'],capture_output=True,check=True,timeout=30).stdout)['accessToken'];started=time.monotonic();deadline=started+180;receipts=[]
for role,kind,var,pattern in [('nodes','nodeTypes','n','(n:Scenario'+pack.title()+'Node)'),('edges','edgeTypes','e','()-[e:AshlarEdge]->()')]:
 props=d[kind][0]['properties'];names=[x['name']for x in props];query='MATCH '+pattern+' RETURN '+','.join(var+'.'+n+' AS '+n for n in names);body=json.dumps({'query':query},separators=(',',':')).encode();url='https://api.fabric.microsoft.com/v1/workspaces/'+item['workspaceId']+'/graphModels/'+item['id']+'/executeQuery?beta=true'
 (out/(role+'-intent.json')).write_text(json.dumps({'query':query,'sha256':hashlib.sha256(body).hexdigest()})+'\n')
 remaining=deadline-time.monotonic()
 if remaining<=0:raise TimeoutError('Whole deadline')
 with urllib.request.urlopen(urllib.request.Request(url,data=body,headers={'Authorization':'Bearer '+t,'Content-Type':'application/json'}),timeout=min(60,remaining))as r:
  raw=r.read(2097153);assert len(raw)<=2097152;assert r.status==200
 (out/(role+'-response.json')).write_bytes(raw);v=json.loads(raw);s=v['status'];table=v['result'];assert s['code']=='00000'and s.get('cause')is None and v.get('additionalStatuses',[])==[]and table['kind']=='TABLE'and table.get('nextPage')is None
 columns=table['columns'];assert [c['name']for c in columns]==names
 for col,prop in zip(columns,props):assert col['gqlType']==('INT64'if prop['type']=='INT'else'STRING')
 rows=[]
 for row in table['data']:
  assert set(row)==set(names);cells=[]
  for col in columns:
   value=row[col['name']]
   if value is not None:
    if col['gqlType']=='STRING':assert type(value)is str
    else:
     if type(value)is str:assert re.fullmatch('0|-?[1-9][0-9]*',value)and len(value)<=20;value=int(value)
     assert type(value)is int and -(2**63)<=value<2**63
   cells.append(value)
  rows.append(tuple(cells))
 assert len(rows)<=1000 and Counter(rows)==Counter(tuple(x[n]for n in names)for x in p[role])
 assert time.monotonic()<deadline
 receipts.append({'role':role,'rows':len(rows),'columns':len(columns),'passed':True});print(json.dumps(receipts[-1]),flush=True)
(out/'result.json').write_text(json.dumps({'pack':pack,'passed':True,'bags':receipts,'elapsed_seconds':time.monotonic()-started,'scope':'Complete private typed graph bags only; no live publication/source ACK authority'},indent=2)+'\n')
