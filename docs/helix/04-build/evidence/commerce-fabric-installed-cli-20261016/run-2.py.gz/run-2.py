from pathlib import Path
import subprocess,os,signal,time,json,hashlib,stat
r=Path(__file__).parent;old=Path('/private/tmp/ashlar-commerce-fabric-native-20261016-a')
original=json.loads((old/'report.json').read_bytes())
def hashes():return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in original['original_native_files_unchanged']}
before=hashes();assert before==original['original_native_files_unchanged']
(r/'native-before-2.json').write_text(json.dumps(before,indent=2)+'\n')
argv=[str(r/'environment/bin/python3'),'-I','-B','-m','ashlar','materialize-commerce-fabric','--configuration',str(r/'selection.json'),'--jars','/private/tmp/ashlar-current-commerce-preparation-20261015-9pn8k_h7/query-jars','--nodes',str(r/'nodes-2'),'--edges',str(r/'edges-2'),'--output',str(r/'report-2.json')]
env={'PATH':'/usr/bin:/bin','JAVA_HOME':'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home','PYTHONDONTWRITEBYTECODE':'1','SPARK_LOCAL_IP':'127.0.0.1','LANG':'C','LC_ALL':'C','TZ':'UTC','PYSPARK_PYTHON':str(r/'environment/bin/python3'),'PYSPARK_DRIVER_PYTHON':str(r/'environment/bin/python3')}
started=time.monotonic()
with(r/'stdout-2.log').open('xb')as out,(r/'stderr-2.log').open('xb')as err:
    p=subprocess.Popen(argv,cwd=r,env=env,stdout=out,stderr=err,start_new_session=True)
    try:code=p.wait(timeout=240);state='terminal'
    except subprocess.TimeoutExpired:
        state='outer-timeout';os.killpg(p.pid,signal.SIGTERM)
        try:code=p.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=10)
(r/'status-2.json').write_text(json.dumps({'state':state,'exit_code':code,'seconds':time.monotonic()-started,'argv':argv,'outer_seconds':240},indent=2)+'\n')
after=hashes();(r/'native-after-2.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
if code:raise SystemExit(code)
raw=(r/'report-2.json').read_bytes();report=json.loads(raw)
assert stat.S_IMODE((r/'report-2.json').stat().st_mode)==0o600
assert report['release_sha256']==original['release_sha256']
assert report['publication']==original['publication'] and report['snapshots']==original['snapshots']
assert {k:v['rows']for k,v in report['targets'].items()}=={'nodes':11,'edges':10}
(r/'comparison-2.json').write_text(json.dumps({'same_release':True,'same_manifest':True,'same_snapshot_vector':True,'original_native_files_unchanged':len(before),'report_bytes':len(raw),'report_mode':'0600','scope':'Actual installed CLI against existing publication and source ACK; no ACK submission or cloud operation.'},indent=2)+'\n')
print((r/'status-2.json').read_text(),(r/'comparison-2.json').read_text())
