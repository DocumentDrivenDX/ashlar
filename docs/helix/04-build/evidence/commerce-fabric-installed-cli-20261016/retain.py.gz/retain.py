from pathlib import Path
import gzip,hashlib,json
r=Path(__file__).parent;repo=Path('/Users/erik/Projects/ashlar')
d=repo/'docs/helix/04-build/evidence/commerce-fabric-installed-cli-20261016';d.mkdir(exist_ok=False)
names=['build.log','install.log','installed.json','selection.json','prepare.py','run.py','status.json','stdout.log','stderr.log','native-before.json','native-after.json','diagnose.py','run-diagnostic.py','diagnostic-status.json','diagnostic-exception.txt','diagnostic-stdout.log','diagnostic-stderr.log','diagnostic-native-before.json','diagnostic-native-after.json','source-restarted-state.json','run-2.py','status-2.json','stdout-2.log','stderr-2.log','native-before-2.json','native-after-2.json','report-2.json','comparison-2.json','runtime-info.json','retain.py']
pairs=[(name,r/name)for name in names]
for role in ('nodes-2','edges-2'):
    pairs.extend((p.relative_to(r).as_posix(),p)for p in sorted((r/role).rglob('*'))if p.is_file()and(p.suffix=='.parquet'or p.name=='00000000000000000000.json'))
a=Path('/private/tmp/ashlar-commerce-fabric-cli-native-20261016-a')
pairs.extend([('preparation-a-build.log',a/'build.log'),('preparation-a-install.log',a/'install.log'),('preparation-a-installed.json',a/'installed.json'),('prepare-a.py',Path('/private/tmp/prepare-commerce-fabric-cli-20261016.py'))])
manifest={}
for name,p in pairs:
    raw=p.read_bytes();encoded=gzip.compress(raw,mtime=0);key=name+'.gz'
    target=d/key;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(encoded)
    manifest[key]={'sha256':hashlib.sha256(raw).hexdigest(),'gzip_sha256':hashlib.sha256(encoded).hexdigest(),'bytes':len(raw)}
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(len(manifest),'retained records')
