from pathlib import Path
import subprocess,tarfile,io,json,hashlib,os
r=Path('/private/tmp/ashlar-commerce-fabric-cli-native-20261016-a');r.mkdir(exist_ok=False)
repo=Path('/Users/erik/Projects/ashlar');old=Path('/private/tmp/ashlar-commerce-fabric-native-20261016-a')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
source=r/'source';source.mkdir()
data=subprocess.check_output(['git','archive',head],cwd=repo)
with tarfile.open(fileobj=io.BytesIO(data))as t:t.extractall(source)
with (r/'build.log').open('xb')as f:
    subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/python3','-m','pip','wheel','--no-index','--no-deps','--no-build-isolation','--wheel-dir',str(r/'wheels'),str(source)],stdout=f,stderr=subprocess.STDOUT,check=True)
venv=r/'environment'
subprocess.run([str(old/'environment/bin/python3'),'-m','venv','--copies','--without-pip',str(venv)],check=True)
site=venv/'lib/python3.12/site-packages'
for p in (old/'environment/lib/python3.12/site-packages').iterdir():
    if p.is_symlink():(site/p.name).symlink_to(os.readlink(p))
wheel=next((r/'wheels').glob('*.whl'))
with (r/'install.log').open('xb')as f:
    subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/python3','-m','pip','install','--no-index','--no-deps','--target',str(site),str(wheel)],stdout=f,stderr=subprocess.STDOUT,check=True)
def pin(p):
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
files=[pin(p)for root in (site/'ashlar',site/'ashlar_host')for p in sorted(root.rglob('*'))if p.is_file()and '__pycache__'not in p.parts]
(r/'installed.json').write_text(json.dumps({'head':head,'wheel':pin(wheel),'files':files,'sdk_links':{p.name:os.readlink(p)for p in site.iterdir()if p.is_symlink()},'qualification':'Fresh pure Python wheel installation; reused SDK links, not whole SDK/OS closure.'},indent=2)+'\n')
(r/'selection.json').write_bytes((old/'selection.json').read_bytes())
print(r,head,len(files))
