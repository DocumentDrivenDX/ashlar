from pathlib import Path
import subprocess,os,signal,time,json,hashlib,stat
r=Path(__file__).parent;old=Path('/private/tmp/ashlar-commerce-fabric-native-20261016-a')
original=json.loads((old/'report.json').read_bytes())
def hashes():return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in original['original_native_files_unchanged']}
before=hashes();assert before==original['original_native_files_unchanged']
(r/'diagnostic-native-before.json').write_text(json.dumps(before,indent=2)+'\n')
argv=[str(r/'environment/bin/python3'),'-I','-B',str(r/'diagnose.py')]
env={'PATH':'/usr/bin:/bin','JAVA_HOME':'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home','PYTHONDONTWRITEBYTECODE':'1','SPARK_LOCAL_IP':'127.0.0.1','LANG':'C','LC_ALL':'C','TZ':'UTC','PYSPARK_PYTHON':str(r/'environment/bin/python3'),'PYSPARK_DRIVER_PYTHON':str(r/'environment/bin/python3')}
started=time.monotonic()
with(r/'diagnostic-stdout.log').open('xb')as out,(r/'diagnostic-stderr.log').open('xb')as err:
    p=subprocess.Popen(argv,cwd=r,env=env,stdout=out,stderr=err,start_new_session=True)
    try:code=p.wait(timeout=240);state='terminal'
    except subprocess.TimeoutExpired:
        state='outer-timeout';os.killpg(p.pid,signal.SIGTERM)
        try:code=p.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=10)
(r/'diagnostic-status.json').write_text(json.dumps({'state':state,'exit_code':code,'seconds':time.monotonic()-started,'argv':argv,'outer_seconds':240},indent=2)+'\n')
after=hashes();(r/'diagnostic-native-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
if code:raise SystemExit(code)
