from pathlib import Path
import traceback
from ashlar_host.commerce_fabric_delta_cli import run_materialize_commerce_fabric_command
r=Path(__file__).parent
try:
    run_materialize_commerce_fabric_command(r/'selection.json',Path('/private/tmp/ashlar-current-commerce-preparation-20261015-9pn8k_h7/query-jars'),str(r/'diagnostic-nodes'),str(r/'diagnostic-edges'),r/'diagnostic-report.json')
except BaseException:
    with(r/'diagnostic-exception.txt').open('x')as f:f.write(traceback.format_exc())
    raise
