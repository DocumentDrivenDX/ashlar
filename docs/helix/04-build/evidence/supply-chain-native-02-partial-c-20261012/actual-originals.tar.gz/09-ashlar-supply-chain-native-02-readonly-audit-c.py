"""Actual partial native state audit; no Spark/Bun/compiler/native mutation."""
import pathlib,json,hashlib,sqlite3,urllib.parse,sys
from collections import Counter
import duckdb
assert duckdb.__version__=='1.4.1'
REPO=pathlib.Path('/Users/erik/Projects/ashlar');sys.path.insert(0,str(REPO/'src'))
from ashlar.supply_chain_source import build_transaction
from ashlar_host.supply_chain_projection import original_supply_chain_oracle
from ashlar_host.supply_chain_oracle import supply_chain_result_oracle
from ashlar_host.schema_rows import fixture_columns
from ashlar_host.resources import RESOURCE_ROOT
R=pathlib.Path('/private/tmp/ashlar-supply-chain-native-02-prep-b');P=R/'publication';OUT=pathlib.Path('/private/tmp/ashlar-supply-chain-native-02-readonly-audit-c');OUT.mkdir()
enc=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def filepin(p):
 s=p.stat();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b),'identity':[s.st_dev,s.st_ino,s.st_mode,s.st_nlink]}
def pins():return [filepin(p)for p in sorted(P.rglob('*'))if p.is_file()and p.suffix in ('.json','.jsonl','.parquet','.sqlite','')and not p.name.endswith(('-shm','-wal','lock'))]
opening=pins();cfg=json.loads((R/'configuration.json').read_bytes());registry=json.loads((P/'registry.json').read_bytes());request=json.loads((P/'request.json').read_bytes());model=pathlib.Path(cfg['model']).read_bytes();graph=pathlib.Path(cfg['graph']).read_bytes();batch,bindings=build_transaction(model,graph,source_system='private-original-supply-chain-fixture');expected=original_supply_chain_oracle(model,graph,bindings,batch,fixture_columns(RESOURCE_ROOT))
c=sqlite3.connect('file:'+str(P/'operations.sqlite')+'?mode=ro',uri=True);c.execute('PRAGMA query_only=ON')
tableproof={}
for name in ['local_installation','local_operation','local_plan','local_source_plan','local_publication_artifact']:
 sizes=c.execute('SELECT count(*) FROM '+name).fetchone()[0];assert sizes<=128
 rows=c.execute('SELECT * FROM '+name+' ORDER BY 1').fetchall();text=enc([list(row)for row in rows]);assert len(text.encode())<=16*1024*1024
 tableproof[name]={'rows':len(rows),'complete_rows_sha256':sha(text.encode())}
operations=c.execute('SELECT operation,intent,intent_sha,before_version,state,receipt FROM local_operation').fetchall();c.close();assert len(operations)==9 and all(x[4]=='committed'for x in operations)
db=duckdb.connect(':memory:');db.execute("SET memory_limit='128MB'");db.execute('SET threads=1');cache={};native=[];total=0
try:
 for target in registry['targets']:
  folder=pathlib.Path(target['path']);logs=sorted((folder/'_delta_log').glob('*.json'));assert [int(p.stem)for p in logs]==list(range(len(logs)))
  active={};meta=protocol=None
  for log in logs:
   raw=log.read_bytes();assert len(raw)<=1048576
   for line in raw.splitlines():
    action=json.loads(line)
    if 'metaData'in action:meta=action['metaData']
    if 'protocol'in action:protocol=action['protocol']
    if 'add'in action:
     a=action['add'];assert 'deletionVector'not in a and not a.get('partitionValues');active[a['path']]=a
    if 'remove'in action:active.pop(action['remove']['path'],None)
   assert meta['id']==target['uuid'];assert protocol=={'minReaderVersion':1,'minWriterVersion':2};schema=json.loads(meta['schemaString']);assert all(f['type']in ('string','long','timestamp')for f in schema['fields'])
   rows=[];names=[f['name']for f in schema['fields']]
   for name,a in active.items():
    relative=pathlib.PurePosixPath(urllib.parse.unquote(name));assert not relative.is_absolute()and'..'not in relative.parts;file=folder/relative;assert file.stat().st_size==a['size']
    projection=','.join(('CAST(epoch_us("'+f['name']+'") AS VARCHAR)'if f['type']=='timestamp'else'CAST("'+f['name']+'" AS VARCHAR)')+' AS "'+f['name']+'"'for f in schema['fields'])
    cursor=db.execute('SELECT '+projection+' FROM read_parquet(?) LIMIT 10001',[str(file)]);assert[c[0]for c in cursor.description]==names
    result=cursor.fetchall();assert len(result)<=10000
    for row in result:
     for value in row:
      assert value is None or type(value)is str
      if value is not None:assert len(value.encode())<=1048576;total+=len(value.encode());assert total<=16777216
     rows.append(dict(zip(names,row)))
   cache[target['table'],int(log.stem)]={'rows':rows,'schema':schema}
  role=target['table'].split('.')[-1];current=cache[target['table'],len(logs)-1];proof={'table':target['table'],'uuid':target['uuid'],'version':len(logs)-1,'rows':len(current['rows']),'full_bag_sha256':sha(enc(sorted(current['rows'],key=enc)).encode()),'schema_sha256':sha(enc(current['schema']).encode())}
  if role in expected:
   assert Counter(map(enc,current['rows']))==Counter(map(enc,expected[role]));proof['independent_original_full_bag_match']=True
  native.append(proof)
finally:db.close()
receipts=[]
for operation,intent,intent_sha,before,state,raw in operations:
 assert sha(intent.encode())==intent_sha;value=json.loads(raw);assert value['operation']==operation and value['before_version']==before and value['operation_sha256']==intent_sha
 snapshot=cache[value['table'],value['version']];assert snapshot['schema']==json.loads(json.dumps(snapshot['schema']))
 # Receipt snapshot retains ordered names/native families and complete stringified rows.
 retained=value['snapshot'];assert Counter(map(enc,retained['rows']))==Counter(map(enc,snapshot['rows']))
 log=pathlib.Path(next(t['path']for t in registry['targets']if t['table']==value['table']))/'_delta_log'/f"{value['version']:020}.json"
 commits=[json.loads(line)['commitInfo']for line in log.read_bytes().splitlines()if'commitInfo'in json.loads(line)];assert len(commits)==1 and commits[0]['userMetadata']==value['commit_metadata'];assert value['uuid']==next(t['uuid']for t in registry['targets']if t['table']==value['table'])
 receipts.append({'operation':operation,'table':value['table'],'version':value['version'],'intent_sha256':intent_sha,'native_snapshot_and_commit_match':True})
manifest_table=registry['tables']['manifest'];manifests=cache[manifest_table,max(v for t,v in cache if t==manifest_table)]['rows'];assert len(manifests)==1;manifest=manifests[0];assert manifest['publication_id']==registry['publication_id'];assert manifest['schema_revisions_json']==request['schema_revisions_json'];validation=json.loads(manifest['validation_report_json']);assert validation['complete']is True and validation['request_digest']==request['request_digest']
vector=json.loads(manifest['table_versions_json']);assert set(vector)=={registry['tables'][role]for role in expected}
for role in expected:assert Counter(map(enc,cache[registry['tables'][role],vector[registry['tables'][role]]]['rows']))==Counter(map(enc,expected[role]))
protocols=[json.loads(line)for line in(P/'compiler-observations.jsonl').read_bytes().splitlines()];observed=[json.loads(line)for line in(P/'native-observations.jsonl').read_bytes().splitlines()];assert len(protocols)==30 and len(observed)==5
queries=[]
for actual in observed:
 name=actual['id'];pairs=[p for p in protocols if p['id']==name];assert len(pairs)==2 and pairs[0]['requestHex']==pairs[1]['requestHex']and pairs[0]['responseHex']==pairs[1]['responseHex'];req=json.loads(bytes.fromhex(pairs[0]['requestHex']));res=json.loads(bytes.fromhex(pairs[0]['responseHex']));assert res['status']=='compiled'and res['diagnostics']==[];binding=json.loads(req['target']['bindingJson']);assert binding['publication']['id']==manifest['publication_id'];assert {tuple(t['name']):t['version']for t in binding['publication']['tables']}=={tuple(('spark_catalog.'+t.split('.',1)[1]).split('.')):v for t,v in vector.items()}
 wanted=supply_chain_result_oracle(name,model,graph)['rows'];assert Counter(map(enc,actual['captured']['rows']))==Counter(map(enc,wanted));assert len(actual['captured']['schema'])==len(res['columns']);queries.append({'id':name,'rows':len(wanted),'original_result_bag_match':True,'request_sha256':sha(bytes.fromhex(pairs[0]['requestHex'])),'response_sha256':sha(bytes.fromhex(pairs[0]['responseHex']))})
closing=pins();assert opening==closing
report={'profile':'ashlar-supply-chain-native-02-readonly-partial-audit/0.1','engine':'DuckDB1.4.1 in-memory128MB/thread1, closed; SQLite mode=ro/query_only closed','journal':tableproof,'native':native,'receipts':receipts,'manifest':manifest,'source':{'model_sha256':sha(model),'graph_sha256':sha(graph),'source_batch_record_count':len(batch.records),'public_receipt_sha256':sha((P/'public-dataset.json').read_bytes())},'five_query_bags':queries,'protocol_records':30,'full_report_present':(P/'report.json').exists(),'opening_files':opening,'closing_files':closing,'qualification':'Actual native publication data/retained commit snapshots and originalfive query captured bags match independent source oracle. Overall installed0.2 child failed; firstten two-hop requests compiled twice; retained native cells for two-hop are unavailable, no complete17report or held/native closing result. Registry or current version equality is not independent exactreplay proof; unpatched program reached queries after its replay/readonlyrestore guards, but before/after replay snapshot receipt not retained. No protectedACK/Truss/UC/remote authority. No nativeSQL/Spark/Bun/compiler/provision/repair/restart/SDKmutation performed.'}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('AUDIT',[(p['table'],p['version'],p['rows'])for p in native],queries);print('reportSHA',sha((OUT/'report.json').read_bytes()))
