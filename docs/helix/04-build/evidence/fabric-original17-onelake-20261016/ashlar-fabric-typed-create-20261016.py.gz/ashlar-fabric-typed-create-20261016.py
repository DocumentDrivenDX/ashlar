"""One-shot existing-trial Graph Model creation; retain native continuation."""
import pathlib,json,subprocess,urllib.request,urllib.error,time,sys,hashlib
from ashlar_host.fabric_pack_preparation import prepare_fabric_pack
from ashlar_host.local_graph_export import LocalGraphExportSelection
w='0a4dbd9c-e1a7-4ec8-8ce9-aa51991ff793';l='ee66f2e8-9072-4a48-8364-ecd2f2967c3e';pack=sys.argv[1]
assert pack in ('archaeology','ecology')
root=pathlib.Path('/private/tmp/ashlar-fabric-typed-create-20261016-'+pack);root.mkdir(exist_ok=False)
upload=json.loads(pathlib.Path('/private/tmp/ashlar-fabric-typed-upload-20261016/result.json').read_bytes());assert upload['state']=='completed'
exports=pathlib.Path('/private/tmp/ashlar-fabric-original17-actual-preparation-20261016');release=exports/(pack+'-release.json');custody=exports/(pack+'-custody.json');src=pathlib.Path('/Users/erik/Projects/ashlar/examples/domain-packs')/pack/'upstream'
old=json.loads(pathlib.Path('/private/tmp/ashlar-fabric-typed-native-20261016-a/result.json').read_bytes());selected=next(x for x in old['receipts']if x['pack']==pack)
selection=LocalGraphExportSelection(release,custody,selected['release_sha256'],selected['custody_sha256'])
paths={x['role']:'abfss://'+w+'@onelake.dfs.fabric.microsoft.com/'+x['destination']for x in upload['tables']if x['pack']==pack}
prepare_fabric_pack(pack=pack,model=src/'ontology.json',graph=src/'graph/fixture.json',pack_file=src/'pack.json',selection=selection,nodes=paths['nodes'],edges=paths['edges'],output=root/'definition')
body={'displayName':'Ashlar_'+pack.title()+'_Typed_20261016a','description':'Original UMF 0.8 private typed graph projection; native integration trial','definition':json.loads((root/'definition/definition.json').read_bytes())}
raw=json.dumps(body,separators=(',',':')).encode();(root/'request.json').write_bytes(raw)
token=json.loads(subprocess.run(['az','account','get-access-token','--resource','https://api.fabric.microsoft.com','-o','json'],capture_output=True,check=True,timeout=30).stdout)['accessToken']
req=urllib.request.Request('https://api.fabric.microsoft.com/v1/workspaces/'+w+'/graphModels',data=raw,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
started=time.monotonic()
try:
 try:response=urllib.request.urlopen(req,timeout=45)
 except urllib.error.HTTPError as error:response=error
 with response as r:
  data=r.read(1048577);assert len(data)<=1048576
  headers={k:r.headers[k]for k in ('Location','x-ms-operation-id','Retry-After')if k in r.headers}
  result={'http_status':r.status,'headers':headers,'body':json.loads(data)if data else None,'elapsed_seconds':time.monotonic()-started,'request_sha256':hashlib.sha256(raw).hexdigest()}
 (root/'response.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
except (TimeoutError,OSError)as e:
 (root/'unknown.json').write_text(json.dumps({'state':'unknown','type':type(e).__name__,'elapsed_seconds':time.monotonic()-started})+'\n');raise
