import pathlib,json,subprocess,urllib.request,urllib.error,time,sys
root=pathlib.Path('/private/tmp/ashlar-fabric-typed-create-20261016b-'+sys.argv[1]);op=json.loads((root/'response.json').read_bytes())['headers']['x-ms-operation-id'];out=root/('operation-'+str(time.time_ns())+'.json')
token=json.loads(subprocess.run(['az','account','get-access-token','--resource','https://api.fabric.microsoft.com','-o','json'],capture_output=True,check=True,timeout=30).stdout)['accessToken']
url='https://api.fabric.microsoft.com/v1/operations/'+op+('/result'if len(sys.argv)>2 else '')
r=urllib.request.Request(url,headers={'Authorization':'Bearer '+token})
try:reply=urllib.request.urlopen(r,timeout=15)
except urllib.error.HTTPError as e:reply=e
with reply as f:
 raw=f.read(1048577);assert len(raw)<=1048576
 result={'url':url,'http_status':f.status,'headers':{k:f.headers[k]for k in ('Location','Retry-After')if k in f.headers},'body':json.loads(raw)if raw else None}
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
