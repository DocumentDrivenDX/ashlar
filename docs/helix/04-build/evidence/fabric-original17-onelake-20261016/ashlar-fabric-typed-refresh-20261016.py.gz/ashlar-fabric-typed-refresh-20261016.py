import pathlib,json,subprocess,urllib.request,urllib.error,time,sys
pack=sys.argv[1];root=pathlib.Path('/private/tmp/ashlar-fabric-typed-create-20261016b-'+pack)
results=[json.loads(p.read_bytes())for p in root.glob('operation-*.json')];item=next(x['body']for x in results if x['url'].endswith('/result')and x['http_status']==200)
assert item['displayName']=='Ashlar_'+pack.title()+'_Typed_20261016b'
out=root/'refresh.json'
if out.exists():raise ValueError('No resubmission')
token=json.loads(subprocess.run(['az','account','get-access-token','--resource','https://api.fabric.microsoft.com','-o','json'],capture_output=True,check=True,timeout=30).stdout)['accessToken']
u='https://api.fabric.microsoft.com/v1/workspaces/'+item['workspaceId']+'/graphModels/'+item['id']+'/jobs/refreshGraph/instances'
# Write submission intent before any HTTP; interrupted submissions stay unknown.
out.write_text(json.dumps({'state':'submitting','url':u})+'\n')
try:response=urllib.request.urlopen(urllib.request.Request(u,data=b'',headers={'Authorization':'Bearer '+token}),timeout=15)
except urllib.error.HTTPError as e:response=e
with response as r:
 b=r.read(1048577);assert len(b)<=1048576
 result={'url':u,'http_status':r.status,'headers':{k:r.headers[k]for k in ('Location','Retry-After')if k in r.headers},'body':json.loads(b)if b else None}
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
