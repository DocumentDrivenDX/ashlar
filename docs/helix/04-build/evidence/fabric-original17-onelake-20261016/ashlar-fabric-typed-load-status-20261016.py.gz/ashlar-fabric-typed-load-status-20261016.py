import pathlib,json,subprocess,urllib.request,time,sys
root=pathlib.Path('/private/tmp/ashlar-fabric-typed-create-20261016b-'+sys.argv[1]);u=json.loads((root/'refresh.json').read_bytes())['headers']['Location']
assert u.startswith('https://api.fabric.microsoft.com/v1/workspaces/0a4dbd9c-e1a7-4ec8-8ce9-aa51991ff793/items/')
token=json.loads(subprocess.run(['az','account','get-access-token','--resource','https://api.fabric.microsoft.com','-o','json'],capture_output=True,check=True,timeout=30).stdout)['accessToken']
with urllib.request.urlopen(urllib.request.Request(u,headers={'Authorization':'Bearer '+token}),timeout=15)as r:
 b=r.read(1048577);assert len(b)<=1048576;v={'url':u,'http_status':r.status,'body':json.loads(b)}
(root/('refresh-status-'+str(time.time_ns())+'.json')).write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
