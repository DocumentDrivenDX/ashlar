from pathlib import Path
import gzip,hashlib,json
r=Path(__file__).parent
d=Path('/Users/erik/Projects/ashlar/docs/helix/04-build/evidence/commerce-fabric-publication-gql-20261016')
d.mkdir(exist_ok=False)
files=sorted(p for p in r.rglob('*') if p.is_file() and p.suffix in ('.json','.py'))
manifest={}
for p in files:
    raw=p.read_bytes();name=p.relative_to(r).as_posix()+'.gz';encoded=gzip.compress(raw,mtime=0)
    target=d/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(encoded)
    manifest[name]={'sha256':hashlib.sha256(raw).hexdigest(),'gzip_sha256':hashlib.sha256(encoded).hexdigest(),'bytes':len(raw)}
for name in ['check_fabric_releases.py','run_graph_release_graphframes.py']:
    raw=(Path('/Users/erik/Projects/ashlar/tools')/name).read_bytes();encoded=gzip.compress(raw,mtime=0)
    key='validators/'+name+'.gz';target=d/key;target.parent.mkdir(exist_ok=True);target.write_bytes(encoded)
    manifest[key]={'sha256':hashlib.sha256(raw).hexdigest(),'gzip_sha256':hashlib.sha256(encoded).hexdigest(),'bytes':len(raw)}
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(len(manifest),'retained records')
