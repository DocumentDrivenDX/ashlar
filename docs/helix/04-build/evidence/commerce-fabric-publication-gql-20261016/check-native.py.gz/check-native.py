"""Finite copied-publication correspondence; no loaded-generation authority."""
from pathlib import Path
import hashlib,json,subprocess,sys,urllib.request,time
sys.path.insert(0,'/Users/erik/Projects/ashlar/tools')
from check_fabric_releases import cases,verify,request
ROOT=Path(__file__).parent
def save(name,value):
    with (ROOT/name).open('x') as f: json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
plan=json.loads((ROOT/'upload/plan.json').read_bytes())
rows={}
for table in plan:
    for entry in table['files']:
        raw=Path(entry['local']).read_bytes()
        assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
    data=next(e for e in table['files'] if e['name'].endswith('.parquet'))
    # Generated fixed operator path; escaped as an SQL string, no shell interpolation.
    sql="SELECT * FROM read_parquet('"+data['local'].replace("'","''")+"')"
    rows[table['role']]=json.loads(subprocess.run(['/opt/homebrew/bin/duckdb','-json','-c',sql],capture_output=True,check=True,timeout=10).stdout)
save('expected-rows.json',rows)
token=json.loads(subprocess.run(['az','account','get-access-token','--resource','https://api.fabric.microsoft.com','-o','json'],capture_output=True,check=True,timeout=30).stdout)['accessToken']
workspace='0a4dbd9c-e1a7-4ec8-8ce9-aa51991ff793';graph='c974e2ff-8bdb-4653-a007-1d213882d5c5'
url='https://api.fabric.microsoft.com/v1/workspaces/'+workspace+'/items/'+graph+'/jobs/instances/0d9b2c00-edec-44a4-ace1-2678295be7f6'
with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':'Bearer '+token}),timeout=20) as f:
    raw=f.read(1048577);assert len(raw)<=1048576
save('load-status-003.json',{'url':url,'body':json.loads(raw)})
records=[]
save('query-intent.json',{'workspace':workspace,'graph':graph,'cases':[c[0] for c in cases(rows)],'scope':'Copied publication fixture correspondence only; no source hold, loaded-generation lease, refresh exclusion, public query result, or durable ACK submission.'})
start=time.monotonic()
for name,query,expected,names in cases(rows):
    save(name+'-request.json',{'query':query,'expected':expected,'columns':names})
    t=time.monotonic();status,body=request(workspace,graph,query,token)
    save(name+'-response.json',{'httpStatus':status,'body':body,'seconds':time.monotonic()-t})
    assert status==200
    # Native INT64/UINT64 may be a canonical decimal JSON string.
    decoded=json.loads(json.dumps(body))
    if list(names)==['row_count']:
        for row in decoded.get('result',{}).get('data',[]):
            value=row.get('row_count')
            if type(value) is str:
                assert value=='0' or (value.isascii() and value.isdecimal() and not value.startswith('0'))
                value=int(value)
            assert type(value) is int and 0<=value<2**63
            row['row_count']=value
    verify(decoded,expected,names)
    records.append({'case':name,'rows':len(expected),'passed':True})
    print(name,len(expected),'passed',flush=True)
save('gql-result.json',{'allPassed':True,'records':records,'seconds':time.monotonic()-start,'scope':'Exact complete copied-publication STRING carriers and multiplicities only; no live held query or refresh exclusion qualification.'})
