"""Bounded one-shot commerce original-publication projection copy; no overwrite/retry."""
import pathlib,json,hashlib,subprocess,urllib.request,urllib.error,urllib.parse,time
W='0a4dbd9c-e1a7-4ec8-8ce9-aa51991ff793';L='ee66f2e8-9072-4a48-8364-ecd2f2967c3e'
ROOT=pathlib.Path('/private/tmp/ashlar-commerce-fabric-native-20261016-a')
OUT=pathlib.Path('/private/tmp/ashlar-commerce-fabric-cloud-20261016-a/upload');OUT.mkdir(exist_ok=False)
started=time.monotonic();deadline=started+180
# Retain only selected public pack bytes; never retain the bearer token.
token=json.loads(subprocess.run(['az','account','get-access-token','--resource','https://storage.azure.com/','-o','json'],capture_output=True,check=True,timeout=30).stdout)['accessToken']
def request(method,path,query='',data=None,extra=None):
 if time.monotonic()>=deadline:raise TimeoutError('Operator deadline')
 headers={'Authorization':'Bearer '+token,'x-ms-version':'2021-06-08',**(extra or {})}
 req=urllib.request.Request('https://onelake.dfs.fabric.microsoft.com/'+W+'/'+path+query,data=data,headers=headers,method=method)
 with urllib.request.urlopen(req,timeout=min(15,max(1,deadline-time.monotonic())))as f:
  raw=f.read(1048577)
  if len(raw)>1048576:raise ValueError('Response capacity')
  return f.status,raw
plans=[]
for pack in ('commerce',):
 for role in ('nodes','edges'):
  local=ROOT/role;commit=local/'_delta_log/00000000000000000000.json';raw=commit.read_bytes()
  entries=[json.loads(line)for line in raw.splitlines()];adds=[x['add']['path']for x in entries if 'add'in x]
  if len(adds)!=1 or pathlib.PurePosixPath(adds[0]).name!=adds[0]:raise ValueError('Expected one fresh flat data file')
  if any(x.get('remove')for x in entries):raise ValueError('Fresh insert only')
  metadata=[x['metaData']for x in entries if 'metaData'in x]
  receipt=json.loads((ROOT/'report.json').read_bytes());prior=receipt['targets'][role]
  if len(metadata)!=1 or metadata[0]['id']!=prior['uuid']:raise ValueError('Selected native identity differs')
  files=[]
  for name in adds+['_delta_log/00000000000000000000.json']:
   p=local/name
   if p.is_symlink()or not p.is_file():raise ValueError('Regular selected file required')
   b=p.read_bytes()
   archive=pathlib.Path('/Users/erik/Projects/ashlar/docs/helix/04-build/evidence/commerce-fabric-delta-native-20261016')
   inventory=json.loads((archive/'manifest.json').read_bytes());selected=inventory[role+'--'+name.replace('/','--')+'.gz']
   if len(b)!=selected['bytes']or hashlib.sha256(b).hexdigest()!=selected['sha256']:raise ValueError('Original reviewed native file pin differs')
   if len(b)>1048576:raise ValueError('Small functional file capacity')
   files.append({'name':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'local':str(p)})
  plans.append({'pack':pack,'role':role,'destination':L+'/Tables/dbo/ashlar_'+pack+'_'+role+'_20261016a','uuid':prior['uuid'],'files':files})
(OUT/'plan.json').write_text(json.dumps(plans,indent=2)+'\n')
completed=[]
try:
 for plan in plans:
  target=plan['destination']
  # Atomic fresh-directory creation refuses any prior/partial target. No retry.
  request('PUT',target,'?resource=directory',b'',{'If-None-Match':'*'})
  request('PUT',target+'/_delta_log','?resource=directory',b'',{'If-None-Match':'*'})
  for item in plan['files']:
   raw=pathlib.Path(item['local']).read_bytes()
   if len(raw)!=item['bytes']or hashlib.sha256(raw).hexdigest()!=item['sha256']:raise ValueError('Local file changed')
   remote=target+'/'+item['name']
   request('PUT',remote,'?resource=file',b'',{'If-None-Match':'*'})
   request('PATCH',remote,'?action=append&position=0',raw,{'Content-Type':'application/octet-stream'})
   request('PATCH',remote,'?action=flush&position='+str(len(raw)),b'')
   status,back=request('GET',remote)
   if back!=raw:raise ValueError('Remote byte readback differs')
   # Closing local bytes check; data precedes commit, no repair/retry/overwrite.
   if pathlib.Path(item['local']).read_bytes()!=raw:raise ValueError('Local file changed during copy')
  completed.append(plan)
  (OUT/'completed.json').write_text(json.dumps(completed,indent=2)+'\n')
 (OUT/'result.json').write_text(json.dumps({'state':'completed','elapsed_seconds':time.monotonic()-started,'tables':completed,'scope':'Exact-byte selected actual-publication Delta projection copy/readback; no continued source hold or loaded graph/query authority'},indent=2)+'\n')
 print(json.dumps({'state':'completed','tables':len(completed),'elapsed_seconds':time.monotonic()-started}))
except BaseException as error:
 (OUT/'failure.json').write_text(json.dumps({'state':'failed','type':type(error).__name__,'http_status':getattr(error,'code',None),'completed_tables':len(completed),'elapsed_seconds':time.monotonic()-started})+'\n')
 print((OUT/'failure.json').read_text());raise
