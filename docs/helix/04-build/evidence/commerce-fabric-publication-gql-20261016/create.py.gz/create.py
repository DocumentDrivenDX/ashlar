"""One-shot existing-trial Graph Model creation; retain native continuation."""
import pathlib,json,subprocess,urllib.request,urllib.error,time,sys,hashlib
w='0a4dbd9c-e1a7-4ec8-8ce9-aa51991ff793';root=pathlib.Path('/private/tmp/ashlar-commerce-fabric-cloud-20261016-a')
assert json.loads((root/'upload/result.json').read_bytes())['state']=='completed'
body=json.loads((root/'definition/create-request.json').read_bytes());assert body['displayName']=='Ashlar_Commerce_Publication1_20261016a'
if (root/'create-intent.json').exists():raise ValueError('No duplicate or unknown resubmission')
with (root/'create-intent.json').open('x')as intent:intent.write(json.dumps({'state':'submitting','workspace':w,'displayName':body['displayName']})+'\n')
raw=json.dumps(body,separators=(',',':')).encode();(root/'request.json').write_bytes(raw)
token=json.loads(subprocess.run(['az','account','get-access-token','--resource','https://api.fabric.microsoft.com','-o','json'],capture_output=True,check=True,timeout=30).stdout)['accessToken']
req=urllib.request.Request('https://api.fabric.microsoft.com/v1/workspaces/'+w+'/graphModels',data=raw,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
started=time.monotonic()
try:
 try:response=urllib.request.urlopen(req,timeout=45)
 except urllib.error.HTTPError as error:response=error
 with response as r:
  data=r.read(1048577);assert len(data)<=1048576
  headers={k:r.headers[k]for k in ('Location','x-ms-operation-id','Retry-After')if k in r.headers}
  result={'http_status':r.status,'headers':headers,'body':json.loads(data)if data else None,'elapsed_seconds':time.monotonic()-started,'request_sha256':hashlib.sha256(raw).hexdigest()}
 (root/'create-response.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
except (TimeoutError,OSError)as e:
 (root/'create-unknown.json').write_text(json.dumps({'state':'unknown','type':type(e).__name__,'elapsed_seconds':time.monotonic()-started})+'\n');raise
