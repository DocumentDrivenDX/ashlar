from pathlib import Path
import subprocess,json,urllib.request,uuid
r=Path(__file__).parent;prior=json.loads((r/'create-response.json').read_bytes());op=prior['headers']['x-ms-operation-id'];assert str(uuid.UUID(op))==op
t=json.loads(subprocess.run(['az','account','get-access-token','--resource','https://api.fabric.microsoft.com','-o','json'],capture_output=True,check=True,timeout=30).stdout)['accessToken']
def get(suffix,name):
 u='https://api.fabric.microsoft.com/v1/operations/'+op+suffix
 with urllib.request.urlopen(urllib.request.Request(u,headers={'Authorization':'Bearer '+t}),timeout=20)as f:
  raw=f.read(1048577);assert len(raw)<=1048576
 v=json.loads(raw);p=r/name
 with p.open('x')as out:out.write(json.dumps({'url':u,'body':v},indent=2)+'\n')
 return v
v=get('','create-operation.json');print('operation',v)
if v.get('status')=='Succeeded':print('item',get('/result','created-item.json'))
