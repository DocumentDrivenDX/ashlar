# Original-commerce GraphFrames declared-vector correspondence

Scope: narrow correction to the already owned driver GraphFrames source composition;
no legacy query API change, no runtime guard relaxation, no source or native effects.

## Direct evidence and semantics

Diagnostic F exact owner event ends at driver.py1024 (source8386): an exact
`PinVector` is refused when `len(original_versions)!=6`. `original_versions` is
captured from the native manifest's table_versions_json. The retained original E
manifest declares exactly four data tables: object_current, edge_current,
tombstone and whole_source_history. The complete native installation registry
contains six tables, additionally attempts and manifest coordination tables.
All four data table UUIDs/versions remain required; coordination tables are
installation custody, not invented publication-vector entries.

The subsequent `manifest_pin_vector` call currently receives all six registry
UUIDs and would also violate exact UUID-map/manifest correspondence. Both mismatches
must be corrected; removing the count guard alone does not establish acceptance.
The exact PinVector type guard remains mandatory.

## Proposed desired CONTRACT-003 clarification

For the installed original-commerce GraphFrames profile, “complete publication
vector” means the complete exact original manifest-declared data-role vector,
covering object_current, edge_current, tombstone and whole_source_history. The
current native installation registry, journal and reservations independently cover
those four data tables plus attempts and manifest coordination tables. Neither
coordination role may be synthesized into the publication vector. Every-use
renewal MUST preserve complete six-target native UUID/location and file-byte
custody, current actual reader pins/context/lease, source and protected ACK
admission. Full original publication snapshot and independent raw-bag admission
remain mandatory at opening and closing, including errors/cancellation while
pins are active. A vector is correspondence, never a source or installation grant.

## Exact implementation slice

Own driver.py current_graph_source and its GraphIdentity observer, focused
commerce_query_sources and commerce_graphframes_release controls, and the narrow
CONTRACT-003 clarification. No module extraction or caller-supplied callbacks.

1. At GraphFrames source renewal, require exact PinVector and exact original
   manifest role set derived from the owning driver.tables mapping for the four
   named data roles. Compare captured version keys to that exact set; require the
   complete six original registry roles independently. Refuse missing/extra/unknown
   roles, duplicate identities and altered version/UUID/context/factory/pins.
2. Build expected manifest_pin_vector using ONLY UUIDs selected by those exact
   captured manifest keys from the immutable original target inventory, never
   an arbitrary subset of a caller's vector or current mutable targets.
3. Compare the entire expected immutable pin vector (publication ID, authority,
   UUIDs, versions and order/owner invariants) to the supplied exact vector.
4. Keep original ReadCustody full snapshot admission unchanged. Keep GraphIdentity
   every-use complete six-directory byte inventory and original journal/registry/
   reservations. Observe actual DESCRIBE DETAIL UUID/location for all six original
   targets, not only published data roles. Coordination versions are not published
   versions; their retained exact native files remain checked without manufacturing
   publication progress. Selected published version existence/current retention is
   still admitted by full opening/closing snapshots and unchanged native bytes.
5. Preserve current registered ordinary source/ACK checks before/after use and the
   independent full native/raw closing callbacks with cancellation precedence.

## Meaningful controls and qualification

Exercise the actual driver binding and GraphFrames renewable owner with a manifest
containing exactly four data roles and an actual six-target registry: positive exact
PinVector expected construction; missing/extra manifest roles; coordination inserted
into vector; wrong UUID/version/publication; bool/float version; forged vector;
mutated current coordination UUID/location/file; released pins/context/factory;
source/ACK revocation; opening/body cancellation and independent closing attempts.
Legacy full read controls remain unchanged. No synthetic vector expansion and no
mocked always-success policy are accepted as authority.

After independently reviewed source tests and main/CI, prepare fresh installed
native recipe retaining original E/C and unchanged 300s/runtime caps. F failure
remains original evidence; it is not promoted to newsource qualification. No
append, reset, publication, replay or query SQL rewrite is part of this correction.
