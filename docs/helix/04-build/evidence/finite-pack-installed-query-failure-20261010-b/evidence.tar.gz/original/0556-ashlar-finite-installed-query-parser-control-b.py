"""Registered public CLI argv only; replace the final operation, never parser."""
import ast,contextlib,io,json,sys
from pathlib import Path
from unittest.mock import patch
from ashlar.cli import main
from ashlar_host import pack_native_cli
runner=Path('/private/tmp/ashlar-finite-pack-installed-query-runner-b.py').read_text();tree=ast.parse(runner)
selected=next(node for node in ast.walk(tree)if isinstance(node,ast.Call)and isinstance(node.func,ast.Name)and node.func.id=='run'and node.args and isinstance(node.args[0],ast.BinOp)and isinstance(node.args[0].right,ast.Constant)and node.args[0].right.value=='-query')
argv_node=selected.args[1];configuration='/private/tmp/explicit-original-pack-invocation.json'
assert isinstance(argv_node,ast.List)
# Derive fixed console tokens from the actual reviewed runner AST.
fixed=[item.value for item in argv_node.elts if isinstance(item,ast.Constant)]
assert fixed==['-B','-S','query-finite-pack','--configuration']
for name in ('archaeology','ecology'):
 with patch.object(sys,'argv',['ashlar',*fixed[2:],configuration]),patch.object(pack_native_cli,'run_finite_pack_command',return_value={'pack':name,'mode':'query'})as operation,contextlib.redirect_stdout(io.StringIO())as output:
  main();operation.assert_called_once_with(configuration,'query');assert json.loads(output.getvalue())['pack']==name
print('PASS actual registered parser argv bothpacks; final operation inert, no SDK/build/native/source operation')
