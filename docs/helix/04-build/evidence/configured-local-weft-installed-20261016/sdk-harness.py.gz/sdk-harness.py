from pathlib import Path
from dataclasses import asdict,is_dataclass
from unittest.mock import patch
import hashlib,json,sqlite3,sys,time,os,signal
from ashlar.weft_count_star_distribution import CountStarDistributionPaths
from ashlar.weft_path_decode import PathDecodeConfig
from ashlar_host.path_capture import PathCaptureConfig
from ashlar_host.configured_local_cli import parse_configured_local
from ashlar_host.configured_local_runtime import read_configured_local
from ashlar_host.configured_local_read import open_configured_local_read,read_configured_local_singleton
from ashlar_host.configured_query_aliases import open_configured_query_aliases
from ashlar_host.configured_weft_compile import ConfiguredWeftCompileConfig
from ashlar_host.configured_weft_query import query_configured_count_star

def retain_exception(kind,error,tb):
    import traceback
    path=Path(sys.argv[1])/'worker-failure.txt'
    raw=''.join(traceback.format_exception(kind,error,tb)).encode()
    assert len(raw)<=1048576
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:assert os.write(fd,raw)==len(raw)
    finally:os.close(fd)
sys.excepthook=retain_exception
root=Path(sys.argv[1]);invocation=parse_configured_local((root/'read.json').read_bytes());config=invocation.runtime
# Finite SDK test harness, one process/one Spark worker, no new ingestion. The
# read-function hook composes the new SDK at the existing runtime's actual
# source/installation/native-admission boundary; it never replaces admission.
results=[];called=[]
def write(path,value):
    raw=(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2,default=lambda v:asdict(v)if is_dataclass(v)else (_ for _ in ()).throw(TypeError(type(v).__name__)))+'\n').encode()
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:assert os.write(fd,raw)==len(raw)
    finally:os.close(fd)
def state():
    installation=config.installation
    registry=hashlib.sha256((installation/'installation.json').read_bytes()).hexdigest()
    logs={str(p.relative_to(installation)):hashlib.sha256(p.read_bytes()).hexdigest()for p in installation.glob('*/_delta_log/*.json')}
    with sqlite3.connect('file:'+str(installation/'operations.sqlite')+'?mode=ro',uri=True)as db:
        journal={name:sorted([list(r)for r in db.execute('SELECT * FROM "'+name+'"')],key=lambda r:json.dumps(r,sort_keys=True))for name in ('local_operation','local_plan','jsonl_consumer_progress')}
    return {'registry_sha256':registry,'delta_logs':logs,'journal_counts':{k:len(v)for k,v in journal.items()},'journal_sha256':hashlib.sha256(json.dumps(journal,sort_keys=True,separators=(',',':')).encode()).hexdigest()}

def selected(transport,source,progress,**kwargs):
    assert not called;called.append(True)
    args={k:v for k,v in kwargs.items()if k not in ('type_id','entity_id')}
    with open_configured_local_read(transport,source,progress,**args)as held:
        with open_configured_query_aliases(held,transport)as aliases:
            compiler=ConfiguredWeftCompileConfig(CountStarDistributionPaths(Path('/private/tmp/ashlar-count-star-public-install-20261014-a/checkout/distributions/index.json'),Path('/private/tmp/ashlar-count-star-public-install-20261014-a/compiler')),1048576)
            for name,sql in (('count','SELECT COUNT(*) AS n FROM Item i'),('projection','SELECT i.label FROM Item i')):
                def observe(iteration,request,response):
                    for kind,raw in (('request',request),('response',response)):
                        path=root/(name+'-'+str(iteration)+'.'+kind+'.json')
                        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
                        try:assert os.write(fd,raw)==len(raw)
                        finally:os.close(fd)
                def oracle(model,original,request):
                    assert model==source.configuration.intake.source and original==source.original_source and request['sql']==sql
                    population={};commits=0
                    for line in original.splitlines():
                        event=json.loads(line)
                        if event['kind']=='commit':
                            commits+=1
                            if commits==kwargs['ordinal']:break
                        if event['kind']=='event':
                            assert event['entity_kind']=='object'and event['type_id']=='1017'and event['source_system']=='configured-example'
                            key=(event['source_system'],event['type_id'],event['id'])
                            if event['operation']=='delete':population.pop(key)
                            else:population[key]=json.loads(event['props_json'])
                    assert commits==kwargs['ordinal']
                    labels=[props['1023']for _,props in sorted(population.items())]
                    expected=[[str(len(labels))]]if name=='count'else[[label]for label in labels]
                    return {'rows':expected,'witnesses':{'original_source_sha256':hashlib.sha256(original).hexdigest(),'completed_source_batches':commits,'full_population_labels':labels},'scope':'Independent literal source-event fold for these two authored count/required-STRING cases only; not compiler-SQL interpretation'}
                started=time.monotonic()
                result=query_configured_count_star(held,aliases,sql,compiler,capture=PathCaptureConfig(1000,65536,1048576),decoder=PathDecodeConfig(65536),observe=observe,original_oracle=oracle)
                write(root/(name+'-evidence.json'),result['evidence'])
                results.append({'case':name,'elapsed_seconds':time.monotonic()-started,'native_rows':result['evidence']['native_result']['rows'],'guard_count':len(result['evidence']['guards']),'publication_id':held.descriptor.publication_id})
    return read_configured_local_singleton(transport,source,progress,**kwargs)

before=state();write(root/'before.json',before)
def expired(*_):raise TimeoutError('small configured native SDK test deadline')
signal.signal(signal.SIGALRM,expired);signal.setitimer(signal.ITIMER_REAL,180)
started=time.monotonic()
try:
    with patch('ashlar_host.configured_local_read.read_configured_local_singleton',side_effect=selected):
        read=read_configured_local(config,ordinal=invocation.ordinal,type_id=invocation.selector[0],entity_id=invocation.selector[1])
    after=state();write(root/'after.json',after);assert before==after
    assert len(called)==1 and len(results)==2 and read['row']['id']=='1'and json.loads(read['row']['props_json'])=={'1023':'updated','1024':'雪'}
    write(root/'results.json',{'status':'complete','elapsed_seconds':time.monotonic()-started,'cases':results,'read':read,'unchanged_native_and_journal':True,'qualification':'Installed SDK adapters actual compiler/Spark/Delta inside original runtime source/native owner via disclosed test hook. No query CLI qualification or protected ACK; original full native/source/Spark cleanup completed before this result.'})
    print(json.dumps({'status':'complete','cases':results,'elapsed_seconds':time.monotonic()-started}))
finally:signal.setitimer(signal.ITIMER_REAL,0)
