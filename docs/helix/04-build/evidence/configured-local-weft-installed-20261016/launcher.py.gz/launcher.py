from pathlib import Path
import os,json,time
from ashlar_host.process_capture import capture_process
root=Path('/private/tmp/ashlar-configured-weft-native-ready-20261016-gwrxrgts')
python='/private/tmp/ashlar-publication-query-runtime-20261016-b/bin/python'
environment={'PATH':'/usr/bin:/bin','HOME':'/Users/erik','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','JAVA_HOME':'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home','PYSPARK_PYTHON':python,'PYSPARK_DRIVER_PYTHON':python,'PYTHONDONTWRITEBYTECODE':'1','SPARK_LOCAL_IP':'127.0.0.1'}
started=time.monotonic()
try:
 out,err=capture_process([python,'-I','-B','/private/tmp/ashlar-configured-weft-native-20261016.py',str(root)],cwd=root,environment=environment,timeout_seconds=240,maximum_output_bytes=1048576)
 for name,raw in (('stdout',out),('stderr',err)):
  fd=os.open(root/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
  try:assert os.write(fd,raw)==len(raw)
  finally:os.close(fd)
 terminal={'status':'terminal-success','elapsed_seconds':time.monotonic()-started,'stdout_bytes':len(out),'stderr_bytes':len(err),'result_present':(root/'results.json').is_file()}
except BaseException as error:
 terminal={'status':'terminal-refused','error_type':type(error).__name__,'elapsed_seconds':time.monotonic()-started}
 (root/'terminal.json').write_text(json.dumps(terminal,indent=2)+'\n');print(json.dumps(terminal));raise
(root/'terminal.json').write_text(json.dumps(terminal,indent=2)+'\n');print(json.dumps(terminal))
