"""Single reviewed local native process with closed env, capture and cleanup."""
import hashlib,json,os,selectors,signal,subprocess,sys,time
from pathlib import Path
BASE=Path('/private/tmp/ashlar-puppy-refresh-command-20261010-e.json')
def verify(recipe):
    for item in recipe['files']:
        path=Path(item['path'])
        if str(path.resolve(strict=True))!=item['resolved'] or path.stat().st_size!=item['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:
            raise ValueError('Closing/opening resource pin changed: '+str(path))
def main():
    if len(sys.argv)!=3 or hashlib.sha256(Path(__file__).read_bytes()).hexdigest()!=sys.argv[1]: raise ValueError('Independent runner pin required')
    if hashlib.sha256(BASE.read_bytes()).hexdigest()!=sys.argv[2]: raise ValueError("Independent recipe pin required")
    recipe=json.loads(BASE.read_bytes()); verify(recipe)
    process=None; errors=[]; primary=None; result=None; total=0; timed=False; capped=False
    log=Path('/private/tmp/ashlar-puppy-refresh-capture-20261010-e.log')
    receipt=Path('/private/tmp/ashlar-puppy-refresh-outcome-20261010-e.json')
    try:
        with log.open('xb') as output:
            os.chmod(log,0o600)
            process=subprocess.Popen(recipe['argv'],env=recipe['environment'],cwd='/Users/erik/Projects/ashlar',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
            selector=selectors.DefaultSelector(); selector.register(process.stdout,selectors.EVENT_READ)
            try:
                start=time.monotonic()
                while selector.get_map():
                    if time.monotonic()-start>180: timed=True; raise TimeoutError('180s native owner deadline')
                    for key,_ in selector.select(.2):
                        data=os.read(key.fileobj.fileno(),65536)
                        if not data: selector.unregister(key.fileobj); break
                        total+=len(data)
                        if total>8*1024*1024: capped=True; raise ValueError('8MiB native capture cap')
                        output.write(data); output.flush()
                result=process.wait(timeout=5)
                if result: raise ValueError('Native probe exited '+str(result))
            finally: selector.close()
    except BaseException as error: primary=error
    finally:
        def collect(fn):
            nonlocal primary
            try: fn()
            except BaseException as error:
                errors.append(type(error).__name__+':'+str(error))
                if primary is None or (isinstance(primary,Exception) and not isinstance(error,Exception)): primary=error
        def terminate():
            if process and process.poll() is None:
                os.killpg(process.pid,signal.SIGTERM); process.wait(timeout=3)
        def kill():
            if process and process.poll() is None: os.killpg(process.pid,signal.SIGKILL)
        def reap():
            if process: process.wait(timeout=5); process.stdout.close()
        collect(terminate); collect(kill); collect(reap)
        # Only this uniquely labelled fixture may be removed, even if probe died.
        def fixture_cleanup():
            command=['/usr/local/bin/docker']
            raw=subprocess.check_output(command+['ps','-aq','--filter','name=^/ashlar-puppy-refresh-20261010-e$'],env=recipe['environment'],timeout=10).decode().strip()
            if raw:
                found=subprocess.check_output(command+['inspect','--format','{{.Image}} {{index .Config.Labels "ashlar.refresh.fixture"}}',raw],env=recipe['environment'],timeout=10).decode().strip()
                if found!='sha256:6d016d5a7e3eab0a57bd4d23c4e218467d00c7661fcda215ea2a429941a68cee 20261010-e': raise ValueError('Refuse changed fixture cleanup')
                subprocess.check_output(command+['rm','-f',raw],env=recipe['environment'],timeout=15)
        collect(fixture_cleanup); collect(lambda:verify(recipe))
        with receipt.open('x') as target:
            json.dump({'exit':result,'bytes':total,'timeout':timed,'cap':capped,'openingClosingCustody':not errors,'cleanupErrors':errors,'primary':None if primary is None else type(primary).__name__+':'+str(primary),'scope':'One actual local Puppy fixture only'},target,indent=2)
        if primary is not None: raise primary
if __name__=='__main__': main()
