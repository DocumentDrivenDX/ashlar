"""Bounded real local PuppyGraph refresh; invoked only after recipe review."""
import base64, hashlib, json, subprocess, time, urllib.request, urllib.error
from pathlib import Path
from contextlib import contextmanager
from neo4j import GraphDatabase, Query
from ashlar.graph_release import GraphRelease
from ashlar_host.lifecycle import finish
from ashlar_host.puppy_release import PuppyReleaseHandle, PuppyReleaseOwner
from puppy_release_adapter import PuppyNativeReleaseAdapter, encoded, decode, original_model, admit_original_subset

ROOT = Path('/private/tmp/ashlar-puppy-refresh-20261010-c')
REPO = Path('/Users/erik/Projects/ashlar')
CARRIERS = Path('/private/tmp/ashlar-puppy-carrier-check-6whdg91o')
NAME = 'ashlar-puppy-refresh-20261010-c'
IMAGE = 'sha256:6d016d5a7e3eab0a57bd4d23c4e218467d00c7661fcda215ea2a429941a68cee'
DIGESTS = ['ca4b40f78b1a27e3d6df50eb17816ec49e30f0f70d6ff7dabc195307c07642e7', 'a6a4cb268f6bb3f8d193b35289d5b593ad08e33d8fc561e29487919fd1502e3a']
# Deliberately supplied credentials for this new isolated local fixture only.
USER, PASSWORD = 'ashlarfixture', 'ashlar-local-refresh-fixture'
def docker(*args):
    return subprocess.check_output(['/usr/local/bin/docker', *args], timeout=20).decode().strip()
def main():
    ROOT.mkdir(mode=0o700, exist_ok=False)
    prepared, handles = {}, []
    for digest in DIGESTS:
        directory = CARRIERS / digest
        receipt = directory / 'receipt.json'
        info = json.loads(receipt.read_bytes())
        prepared[digest] = (str(directory/info['database_name']), str(directory/'model.json'), str(receipt), hashlib.sha256(receipt.read_bytes()).hexdigest())
        raw = (REPO/'docs/helix/04-build/evidence/puppygraph-releases-20261009'/ (digest+'.graph.json')).read_bytes()
        handles.append(PuppyReleaseHandle(GraphRelease(raw, digest)))
    records, mode, posts = [], None, []
    rejected = ValueError("Actual native rejected control")
    interrupted = KeyboardInterrupt("Controlled cancellation after actual partial native POST")
    def raw_http(path, data):
        headers = {'Authorization':'Basic '+base64.b64encode((USER+':'+PASSWORD).encode()).decode()}
        if data is not None: headers['Content-Type'] = 'application/json'
        request = urllib.request.Request('http://127.0.0.1:18883'+path, data=data, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=15) as response:
                status, raw = response.status, response.read(1024*1024+1)
        except urllib.error.HTTPError as error:
            with error: status, raw = error.code, error.read(1024*1024+1)
        if len(raw)>1024*1024: raise ValueError('HTTP response cap')
        records.append({'path':path,'request':None if data is None else data.decode(),'status':status,'response':raw.decode()})
        return status, raw
    def runtime(context):
        actual = docker('inspect','--format','{{.Id}} {{.Image}} {{.State.Running}}', NAME)
        if actual != container+' '+IMAGE+' true': raise ValueError('Native instance changed')
        return container, '1.13.0'
    def http(path, data, context):
        nonlocal mode
        runtime(context)
        if data is not None:
            posts.append(data)
            if mode == 'reject':
                status, raw = raw_http(path, b'{"catalog":[],"node":[{"label":"broken"}],"edge":[]}')
                if status < 400 and decode(raw).get('ok') is True: raise AssertionError('Invalid schema unexpectedly accepted')
                mode = None
                raise rejected
            if mode == 'interrupt':
                model = decode(data)
                original = decode(adapter.model)
                partial = dict(model)
                partial['edge'] = original['edge']
                (ROOT/'interrupted-original-intent.json').write_bytes(data)
                (ROOT/'interrupted-native-subset-request.json').write_bytes(encoded(partial))
                status, raw = raw_http(path, encoded(partial))
                if status != 200 or decode(raw).get('ok') is not True: raise ValueError('Native partial staging rejected')
                mode = None
                raise interrupted
        status, raw = raw_http(path, data)
        if status != 200: raise ValueError('Native HTTP refused: '+str(status))
        return raw
    def cypher(query, context):
        runtime(context)
        with client.session() as session:
            return session.run(Query(query, timeout=15)).data()
    class Policy:
        @contextmanager
        def writer(self, context):
            runtime(context)
            try: yield None
            finally: runtime(context)
        def admit(self, handle, context):
            runtime(context)
            if handle.release not in [item.release for item in handles]: raise ValueError('Unknown original release')
            for digest, files in prepared.items():
                if hashlib.sha256(Path(files[2]).read_bytes()).hexdigest()!=files[3]: raise ValueError('Carrier receipt changed')
    container = ''
    client = None
    primary = None
    try:
        if docker('ps','-aq','--filter','name=^/'+NAME+'$'): raise ValueError('Owned name already exists')
        args = ['run','-d','--pull=never','--name',NAME,'--label','ashlar.refresh.fixture=20261010-c','--cpus','2','--memory','3g','-p','127.0.0.1:18883:8081','-p','127.0.0.1:17690:7687','-e','PUPPYGRAPH_USERNAME='+USER,'-e','PUPPYGRAPH_PASSWORD='+PASSWORD]
        for digest, files in prepared.items(): args += ['--mount','type=bind,source='+files[0]+',target=/tmp/'+Path(files[0]).name+',readonly']
        container = docker(*args, IMAGE)
        start=time.monotonic()
        while True:
            try:
                status, initial = raw_http('/schemajson',None)
                if status==200: break
            except (OSError, urllib.error.URLError): pass
            if time.monotonic()-start>75: raise TimeoutError('Native readiness')
            time.sleep(1)
        initial_value=decode(initial)
        if initial_value.get('node') != [] or initial_value.get('edge') != []: raise ValueError('Fresh native inventory not empty')
        client=GraphDatabase.driver('bolt://127.0.0.1:17690', auth=(USER,PASSWORD), connection_timeout=10, connection_acquisition_timeout=10, max_connection_pool_size=1)
        adapter=PuppyNativeReleaseAdapter(prepared=prepared,prior_model=encoded({'catalog':[],'node':[],'edge':[]}), http=http,cypher=cypher,runtime=runtime,evidence=ROOT/'native')
        owner=PuppyReleaseOwner(adapter,Policy())
        first=owner.refresh(handles[0].release,context=None)
        first_bytes=owner.read(first,context=None)
        mode='reject'
        try: owner.refresh(handles[1].release,context=None)
        except ValueError as error: assert error is rejected
        else: raise AssertionError('Expected native rejection')
        assert owner.read(first,context=None)==first_bytes
        mode='interrupt'
        try: owner.refresh(handles[1].release,context=None)
        except KeyboardInterrupt as error: assert error is interrupted
        else: raise AssertionError('Expected actual interrupted subset')
        _, partial = raw_http('/schemajson',None)
        (ROOT/'interrupted-native-schema.json').write_bytes(partial)
        partial_value=decode(partial)
        addition=decode(Path(prepared[DIGESTS[1]][1]).read_bytes())
        _, complete=admit_original_subset(partial_value,decode(adapter.model),addition)
        assert not complete
        assert addition['node'][0] in partial_value['node'] and addition['edge'][0] not in partial_value['edge']
        assert any(item['path'].startswith('/schema?') and item['request']=='{"catalog":[],"node":[{"label":"broken"}],"edge":[]}' and (item['status']>=400 or decode(item['response'].encode()).get('ok') is not True) for item in records)
        assert owner.read(first,context=None)==first_bytes
        second=owner.refresh(handles[1].release,context=None)
        second_bytes=owner.read(second,context=None)
        assert posts[-1]==(ROOT/'interrupted-original-intent.json').read_bytes()
        count=len(posts)
        assert owner.refresh(handles[1].release,context=None)==second and len(posts)==count
        assert owner.read(first,context=None)==first_bytes
        reopened=PuppyReleaseOwner(adapter,Policy())
        assert reopened.read(first,context=None)==first_bytes and reopened.read(second,context=None)==second_bytes
        (ROOT/'summary.json').write_bytes(encoded({'engine':container,'image':IMAGE,'version':'1.13.0','r1':json.loads(first_bytes),'r2':json.loads(second_bytes),'controlledNativePartialPostThenCancellation':True,'nativeRejectedAttempt':True,'oldReleaseStable':True,'originalResumeBytesEqual':True,'completedReplayNoPost':True,'explicitHandleReopening':True,'nativeGeneration':'unsupported/unobserved','scope':'Actual local release activation/full value queries only; no installed facade/native source ACK/UC qualification'}))
    except BaseException as error: primary=error
    def cleanup_container():
        if container:
            actual=docker('inspect','--format','{{.Id}} {{.Image}}',NAME)
            if actual != container+' '+IMAGE: raise ValueError('Refuse cleanup of changed native instance')
            docker('rm','-f',container)
    finish(primary, [lambda: client.close() if client is not None else None,
        lambda:(ROOT/'http-records.json').write_bytes(encoded(records)),cleanup_container])
if __name__=='__main__': main()
