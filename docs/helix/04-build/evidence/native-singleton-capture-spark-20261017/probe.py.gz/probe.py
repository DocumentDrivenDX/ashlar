"""Six tiny native capture actions only; no business/source/publication authority."""
from pathlib import Path
import os,json,hashlib,time,datetime,decimal,signal,sys
from ashlar_host.delta_custody import LocalDeltaTransport,LocalDeltaError
from ashlar_host.evolution_verification_types import VerificationBounds
from ashlar_host.lifecycle import finish
R=Path(__file__).resolve().parent;os.umask(0o077)
def encode(value):
 from pyspark.sql import Row
 if value is None or type(value)in(str,int,bool):return value
 if type(value)is datetime.datetime:return {'native_type':'datetime','iso':value.isoformat(timespec='microseconds'),'timezone':'naive'if value.tzinfo is None else str(value.tzinfo)}
 if type(value)is datetime.date:return {'native_type':'date','iso':value.isoformat()}
 if type(value)is decimal.Decimal:return {'native_type':'decimal','token':str(value)}
 if type(value)is bytes:return {'native_type':'bytes','hex':value.hex()}
 if type(value)is Row:return {'native_type':'struct','fields':[[k,encode(v)]for k,v in value.asDict().items()]}
 if type(value)is dict:return {k:encode(v)for k,v in value.items()}
 if type(value)in(list,tuple):return [encode(v)for v in value]
 raise TypeError('Unsupported actual probe carrier')
def retain(name,value):
 raw=(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
 if len(raw)>1048576:raise ValueError('Bounded probe report required')
 fd=os.open(R/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);primary=None
 try:
  if os.write(fd,raw)!=len(raw):raise OSError('Exact probe write required')
  os.fsync(fd)
 except BaseException as e:primary=e
 finish(primary,[lambda:os.close(fd)])
def stop(*args):raise KeyboardInterrupt()
signal.signal(signal.SIGTERM,stop)
def main():
 from pyspark.sql import SparkSession
 original_selection=(R/'preparation.json').read_bytes();selection=json.loads(original_selection)
 def renew():
  if (R/'preparation.json').read_bytes()!=original_selection:raise PermissionError('Original probe selection changed')
  for pin in selection['pins']:
   raw=Path(pin['path']).read_bytes()
   if len(raw)!=pin['bytes']or hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise PermissionError('Original probe file changed')
 renew();cfg=json.loads((R/'configuration.json').read_bytes())
 if Path(sys.executable)!=Path(cfg['python'])or SparkSession.getActiveSession()is not None:raise PermissionError('Exact fresh installed runtime required')
 target=R/'probe-delta'
 if target.exists()or target.is_symlink():raise PermissionError('Exclusive fresh probe Delta required')
 spark=None;primary=None;cases=[];startup=time.monotonic();before=None;after=None
 try:
  spark=(SparkSession.builder.master('local[1]').appName('ashlar-native-singleton-capture-probe').config('spark.driver.memory','512m').config('spark.executor.memory','512m').config('spark.ui.enabled','false').config('spark.jars',','.join(cfg['jars'])).config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension').config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog').config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true').config('spark.sql.shuffle.partitions','1').config('spark.databricks.delta.snapshotPartitions','1').getOrCreate())
  startup_seconds=time.monotonic()-startup
  spark.sql('CREATE TABLE delta.`'+str(target)+'` (`id` BIGINT NOT NULL) USING DELTA')
  def table_facts():
   files=sorted((target/'_delta_log').glob('*.json'))
   if [p.name for p in files]!=['00000000000000000000.json']:raise PermissionError('Exact unchanged empty history0 required')
   raw=files[0].read_bytes();actions=[json.loads(line)for line in raw.splitlines()];metadata=[a['metaData']for a in actions if 'metaData'in a];commit=[a['commitInfo']for a in actions if 'commitInfo'in a]
   if len(metadata)!=1 or len(commit)!=1 or any('add'in a or 'remove'in a for a in actions)or commit[0]['operation']!='CREATE TABLE':raise PermissionError('Fresh zero-business-row metadata required')
   schema={'type':'struct','fields':[{'name':'id','type':'long','nullable':False,'metadata':{}}]}
   if json.loads(metadata[0]['schemaString'])!=schema:raise PermissionError('Original NOT NULL schema required')
   return {'uuid':metadata[0]['id'],'version':0,'schema':schema,'metadata_json_sha256':hashlib.sha256(raw).hexdigest(),'data_add_actions':0}
  before=table_facts();retain('before.json',before)
  # This transport object exercises only the capture component. It has no
  # journal, registry, NativeDriver, source session, policy or authority.
  capture=object.__new__(LocalDeltaTransport);capture.spark=spark;capture.observation_bounds=VerificationBounds(262144,2,65536,1048576,1048576,1048576)
  def action(name,frame,limit,sql_call_seconds,refuse=False):
   schema=frame.schema.json();start=time.monotonic();result=None;error=None
   try:result=capture._bounded_native_rows(frame,maximum_rows=limit)
   except LocalDeltaError as e:error=type(e).__name__
   elapsed=time.monotonic()-start
   if frame.schema.json()!=schema:raise PermissionError('Original frame schema changed')
   if refuse and error!='LocalDeltaError'or not refuse and error is not None:raise AssertionError('Native capture outcome differs')
   item={'case':name,'maximum_rows':limit,'spark_sql_call_seconds':sql_call_seconds,'guarded_capture_seconds':elapsed,'schema_json':schema,'rows':None if result is None else encode(result),'error_class':error};cases.append(item);return result
  start=time.monotonic();detail=spark.sql('DESCRIBE DETAIL delta.`'+str(target)+'`');sql_seconds=time.monotonic()-start
  one=action('detail-singleton',detail,1,sql_seconds);general=action('same-detail-general',detail,2,None)
  if one!=general or len(one)!=1 or one[0]['id']!=before['uuid']:raise AssertionError('Exact original typed detail result differs')
  start=time.monotonic();empty=spark.sql('SELECT CAST(NULL AS STRING) AS empty_value WHERE false');elapsed=time.monotonic()-start
  if action('empty-singleton',empty,1,elapsed)!=[]:raise AssertionError('Empty capture differs')
  start=time.monotonic();nulls=spark.sql('SELECT CAST(NULL AS STRUCT<day:DATE,amount:DECIMAL(18,2),attrs:MAP<STRING,STRING>,items:ARRAY<STRING>>) AS nested, CAST(NULL AS DATE) AS day, CAST(NULL AS DECIMAL(18,2)) AS amount, CAST(NULL AS MAP<STRING,ARRAY<BIGINT>>) AS attrs, CAST(NULL AS ARRAY<STRING>) AS items');elapsed=time.monotonic()-start
  if action('all-null-typed-singleton',nulls,1,elapsed)!=[{'nested':None,'day':None,'amount':None,'attrs':None,'items':None}]:raise AssertionError('All-null row lost or changed')
  start=time.monotonic();duplicate=spark.sql('SELECT id FROM range(2)');elapsed=time.monotonic()-start;action('two-row-singleton-refusal',duplicate,1,elapsed,True)
  start=time.monotonic();oversize=spark.sql("SELECT repeat('雪',22000) AS oversized");elapsed=time.monotonic()-start;action('oversize-cell-refusal',oversize,1,elapsed,True)
  after=table_facts();retain('after.json',after)
  if before!=after or len(cases)!=6:raise AssertionError('Probe metadata changed or action inventory differs')
 except BaseException as e:primary=e
 finish(primary,([]if spark is None else[spark.stop])+[renew])
 retain('result.json',{'profile':'ashlar-native-singleton-capture-probe/0.1','status':'passed','spark_startup_seconds':startup_seconds,'capture_actions':6,'cases':cases,'native_metadata_unchanged':before==after,'spark_closing_completed':True,'qualification':'Six guarded capture actions plus fresh CREATE and DESCRIBE metadata commands; zero business rows. Same original detail frame reused in fixed singleton-then-general order; no cache-control experiment or speed guarantee. spark_sql_call_seconds measures the call returning a frame; guarded_capture_seconds includes its native guard execution and transfer. Date/decimal/map/array/struct NULLs are typed SQL values, not nonnull decimal payload qualification. No source/ACK/publication/installation authority.'})
 print(json.dumps({'status':'passed','capture_actions':6,'spark_closing_completed':True}))
if __name__=='__main__':main()
