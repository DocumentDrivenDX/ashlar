"""Actual selected public passive constructors/verification, existing files only."""
from pathlib import Path
from dataclasses import dataclass
import ast,hashlib,json,re,subprocess,sys,types
R=Path('/Users/erik/Projects/ashlar');REV='6ced38ec82b893e4f79e8412687f09adb7178906'
raw=subprocess.check_output(['/usr/bin/git','-C',str(R),'show',REV+':src/ashlar_host/graphframes_release.py'])
assert raw==(R/'src/ashlar_host/graphframes_release.py').read_bytes()
module=types.ModuleType('actual_pinned_graphframes_inventory_control');sys.modules[module.__name__]=module
sys.path.insert(0,str(R/'src'));from ashlar_host.evolution_producer import snapshot
module.__dict__.update(Path=Path,dataclass=dataclass,hashlib=hashlib,json=json,re=re,snapshot=snapshot,SDK_INVENTORIES=('pyspark','delta-spark','graphframes-py','transitive-imports'))
tree=ast.parse(raw);nodes=[n for n in tree.body if isinstance(n,ast.ClassDef)and n.name in ('GraphFramesRuntimeFile','GraphFramesRuntimeInventory','GraphFramesRuntimeConfig')];exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual-selected-public-passive-classes>','exec'),module.__dict__)
def descriptors(root):
 result={}
 for p in root.rglob('*'):
  if p.is_file():
   q=p.resolve();b=q.read_bytes();result[str(q)]={'path':str(q),'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)}
 return [result[k]for k in sorted(result)]
SDK=Path('/private/tmp/ashlar-spark311/lib/python3.11/site-packages');BASE=Path('/Users/erik/.local/share/uv/python/cpython-3.11.17-macos-aarch64-none')
sdks={}
for name,roots in [('pyspark',['pyspark','pyspark-3.5.3.dist-info']),('delta-spark',['delta','delta_spark-3.2.1.dist-info']),('graphframes-py',['graphframes','graphframes_py-0.12.3.dist-info'])]:sdks[name]=sorted([r for p in roots for r in descriptors(SDK/p)],key=lambda r:r['path'])
named={r['path']for rows in sdks.values()for r in rows};remaining={r['path']:r for r in descriptors(BASE)+descriptors(SDK)if r['path']not in named};sdks['transitive-imports']=[remaining[k]for k in sorted(remaining)]
b=raw;worker=[{'path':str(R/'src/ashlar_host/graphframes_release.py'),'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)}]
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
F=module.GraphFramesRuntimeFile;inv=module.GraphFramesRuntimeInventory(REV,tuple(F(Path(r['path']),r['sha256'],r['size'])for r in worker),tuple((name,tuple(F(Path(r['path']),r['sha256'],r['size'])for r in rows))for name,rows in sdks.items()))
config=module.GraphFramesRuntimeConfig(BASE/'bin/python3.11',hashlib.sha256((BASE/'bin/python3.11').read_bytes()).hexdigest(),Path('/private/tmp/ashlar-db-client/lib/python3.9/site-packages/jdk4py/java-runtime'),'0'*64,REV,digest(worker),digest(sdks),Path('/private/tmp/selected-future-jars'),Path('/private/tmp/selected-future-work'))
inv.verify(config)
try:module.GraphFramesRuntimeInventory(REV,inv.worker,inv.sdks[:3])
except ValueError:pass
else:raise AssertionError('Incomplete transitive inventory accepted')
print(json.dumps({'pass':True,'actualPinnedPublicClasses':REV,'groups':[name for name,_ in inv.sdks],'files':len(inv.worker)+sum(len(rows)for _,rows in inv.sdks),'bytes':sum(f.size for f in inv.worker)+sum(f.size for _,rows in inv.sdks for f in rows),'sdkImported':any(name in sys.modules for name in ('pyspark','delta','graphframes')),'qualification':'Passive ABI/full existing SDK+stdlib byte verification only; future installed resolution/current independent authority not inferred.'}))
