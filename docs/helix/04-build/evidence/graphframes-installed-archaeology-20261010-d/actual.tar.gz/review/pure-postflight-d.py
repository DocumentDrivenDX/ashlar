"""Read-only current byte/namespace/canonical-plan verification; no authority grant."""
from pathlib import Path
import ast,hashlib,json,os,sys,csv,io,base64,zipfile,subprocess
P=Path('/private/tmp');W=P/'ashlar-graphframes-installed-20261010-c';REV='6ced38ec82b893e4f79e8412687f09adb7178906';R=Path('/Users/erik/Projects/ashlar')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return json.dumps(v,sort_keys=True,separators=(',',':')).encode()+b'\n'
def descriptors(root):
 result={}
 for p in root.rglob('*'):
  if p.is_file():
   q=p.resolve();b=q.read_bytes();result[str(q)]={'path':str(q),'sha256':sha(b),'size':len(b)}
 return [result[k]for k in sorted(result)]
def namespace(root):return [{'path':str(p),'kind':'link'if p.is_symlink()else 'file'if p.is_file()else 'directory'if p.is_dir()else 'refused',**({'target':os.readlink(p),'resolved':str(p.resolve())}if p.is_symlink()else {})}for p in sorted(root.rglob('*'))]
runner=(P/'ashlar-graphframes-installed-runner-c.py').read_text();tree=ast.parse(runner);verify=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='verify');ns={'Path':Path,'sha':sha,'hashlib':hashlib,'json':json,'os':os,'CLOSURE':P/'ashlar-graphframes-installed-closure-c.json','CLOSURE_SHA':'69095fc3026bb45b5ecadf2569a7b608c5abae4c3d35da497d8e3e78801583af'};exec(compile(ast.Module(body=[verify],type_ignores=[]),'<actual-frozen-outer-closing>','exec'),ns);ns['verify']()
source=json.loads((P/'ashlar-graphframes-installed-source-inventory-c.json').read_bytes())
assert source['revision']==REV
for row in source['files']:
 path=W/'source'/row['path'];raw=path.read_bytes();assert not path.is_symlink()and len(raw)==row['bytes']and sha(raw)==row['sha256']
site=W/'venv/lib/python3.11/site-packages';venv=W/'venv';base=Path('/Users/erik/.local/share/uv/python/cpython-3.11.17-macos-aarch64-none')
for name in ('python','python3','python3.11'):
 p=venv/'bin'/name;assert not p.is_symlink()and sha(p.read_bytes())==sha((base/'bin/python3.11').read_bytes())
assert 'include-system-site-packages = false'in (venv/'pyvenv.cfg').read_text()
with zipfile.ZipFile(next((W/'wheels').iterdir()))as wheel:
 for name in wheel.namelist():
  if name.endswith('/RECORD'):continue
  assert (site/name).read_bytes()==wheel.read(name)
console=venv/'bin/ashlar';assert console.read_bytes()==(W/'installed-console.txt').read_bytes()
record=(site/'ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD').read_bytes();assert record==(W/'installed-RECORD.csv').read_bytes()
for name,digest,size in csv.reader(io.StringIO(record.decode())):
 p=site/name;assert p.is_file()and not p.is_symlink()and p.resolve().is_relative_to(venv)
 raw=p.read_bytes()
 if name.endswith('/RECORD'):assert not digest and not size
 else:assert digest=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).rstrip(b'=').decode()and size==str(len(raw))
# Actual frozen generated-package helper; binaries separately checked above.
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='main');gen=next(n for n in main.body if isinstance(n,ast.FunctionDef)and n.name=='generated_inventory')
def bounded_read(p,maximum):
 assert p.is_file()and not p.is_symlink()and p.stat().st_size<=maximum;return p.read_bytes()
ns={'WORK':W,'source':W/'source','venv':venv,'bounded_read':bounded_read,'sha':sha};exec(compile(ast.Module(body=[gen],type_ignores=[]),'<actual-frozen-package-closing>','exec'),ns);assert ns['generated_inventory']()==json.loads((W/'generated-custody.json').read_bytes())
SDK=Path('/private/tmp/ashlar-spark311/lib/python3.11/site-packages');plan=json.loads((W/'runtime-plan.json').read_bytes())
parts={}
for name,dirs in [('pyspark',['pyspark','pyspark-3.5.3.dist-info']),('delta-spark',['delta','delta_spark-3.2.1.dist-info']),('graphframes-py',['graphframes','graphframes_py-0.12.3.dist-info'])]:parts[name]=sorted([row for d in dirs for row in descriptors(SDK/d)],key=lambda row:row['path'])
named={r['path']for rows in parts.values()for r in rows};transitive={r['path']:r for r in descriptors(base)+descriptors(SDK)if r['path']not in named}
for p in [venv/'pyvenv.cfg',*sorted((venv/'bin').iterdir())]:
 if p.is_file():transitive[str(p.resolve())]={'path':str(p.resolve()),'sha256':sha(p.read_bytes()),'size':p.stat().st_size}
parts['transitive-imports']=[transitive[k]for k in sorted(transitive)]
roots={str(p):descriptors(p)for p in (site,SDK,base)};namespaces={str(p):namespace(p)for p in (site,SDK,base)};links=[{'path':str(p),'target':os.readlink(p),'resolved':str(p.resolve())}for root in (site,SDK,base)for p in sorted(root.rglob('*'))if p.is_symlink()]
original_memory={'worker':descriptors(site),'sdks':list(parts.items()),'roots':roots,'namespaces':namespaces,'symlinks':links,'sys_path':[str(base/'lib/python311.zip'),str(base/'lib/python3.11'),str(base/'lib/python3.11/lib-dynload'),str(site),str(SDK)]}
assert original_memory!=plan
assert json.loads(enc(original_memory))==plan
sys.path.insert(0,str(site))
from ashlar_host.graphframes_release import GraphFramesRuntimeFile,GraphFramesRuntimeInventory
from ashlar_host.graphframes_cli import parse_graphframes_invocation
F=GraphFramesRuntimeFile;inventory=GraphFramesRuntimeInventory(REV,tuple(F(Path(r['path']),r['sha256'],r['size'])for r in plan['worker']),tuple((name,tuple(F(Path(r['path']),r['sha256'],r['size'])for r in rows))for name,rows in plan['sdks']))
invocation=parse_graphframes_invocation((W/'archaeology-invocation.json').read_bytes());invocation.runtime.renew();inventory.verify(invocation.runtime)
operator=json.loads((W/'operator-plan.json').read_bytes());assert operator==json.loads((P/'ashlar-graphframes-installed-export-plan-c.json').read_bytes());assert (W/'provider.py').read_bytes()==(P/'ashlar-graphframes-installed-provider-c.py').read_bytes()
from ashlar_host.private_graph_custody import load_private_graph_release
load_private_graph_release(Path(operator['packs']['archaeology']['release']).read_bytes(),operator['packs']['archaeology']['release_sha256'],(W/'archaeology-custody.json').read_bytes(),operator['packs']['archaeology']['custody_sha256'])
for pack in ('archaeology','ecology'):
 for field in ('model','graph'):
  p=Path(operator['packs'][pack][field]);assert not any(q.is_symlink()for q in (p,*p.parents))
query=json.loads((W/'archaeology-query.json').read_bytes());transport=json.loads((W/'archaeology-output/engine/transport.json').read_bytes());assert query['exitCode']==0 and transport['complete']is True and transport['exit']==0
result={'profile':'ashlar-graphframes-installed-pure-postflight/0.1','sourceRevision':REV,'originalFailurePreserved':True,'sdkImported':any(n in sys.modules for n in ('pyspark','delta','graphframes')),'nativeOrChildStarted':False,'closingChecks':['original9398closure','172originalsource','allthreecopiedinterpreters','wholewheelpayload','175installedRECORD','console','sealedgeneratedpackage/cacheabsence','allSDKandstdlibfilesandnamespace','exactnativeconfigJARs','originalproviderandscope','originalprotectedACKexport','transportcompleteexit0'],'runtimePlanMismatch':'Original in-memory sdk entry tuples compare unequal to persisted JSON lists; fully reconstructed current facts serialize exactly to original persisted bytes/values. No file or runtime namespace drift detected.','qualification':'Pure postflight current byte/namespace/correspondence audit only; does not rewrite failed receipt, repeat native execution, extend closed authority hold, or grant source/native authority.'}
p=P/'ashlar-graphframes-installed-pure-postflight-d.json'
with p.open('xb')as f:f.write(json.dumps(result,sort_keys=True,indent=2).encode()+b'\n')
print(json.dumps({'pass':True,'path':str(p),'sha256':sha(p.read_bytes()),'sdkImported':result['sdkImported']}))
