"""Actual H config dispatch with capture replaced inert; no child/build/SDK."""
import importlib.util,json,sys,tempfile,types
from pathlib import Path
from unittest.mock import patch
P=Path('/private/tmp');command=P/'ashlar-graphframes-installed-command-d.json';digest='1e749d2789095b770c72515c474e8148423206071e753293b672ecf2cf2bbe3b2'
import hashlib;digest=hashlib.sha256(command.read_bytes()).hexdigest()
plan=json.loads(command.read_bytes())
spec=importlib.util.spec_from_file_location('reviewed_real_H_launcher',P/'ashlar-supply-chain-native-read-launcher-h.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
seen=[]
def inert(*args):
 c=next(c for c in plan['commands']if c['phase']==phase)
 assert args==(c['argv'],c['cwd'],plan['environment'],c['stdout'],c['stderr'],c['timeoutSeconds'],16*1024*1024)
 seen.append(phase);return {'exitCode':0,'stdoutBytes':0,'stderrBytes':0}
fake=types.SimpleNamespace(capture=inert);loader=types.SimpleNamespace(exec_module=lambda obj:None)
with tempfile.TemporaryDirectory(prefix='ashlar-gf-H-control-',dir='/private/tmp')as directory:
 for phase in ('archaeology','ecology'):
  receipt=Path(directory)/(phase+'.json')
  with patch.object(sys,'argv',['launcher','--command',str(command),'--sha256',digest,'--phase',phase,'--receipt',str(receipt)]),patch.object(module.importlib.util,'spec_from_file_location',return_value=types.SimpleNamespace(loader=loader)),patch.object(module.importlib.util,'module_from_spec',return_value=fake):module.main()
  value=json.loads(receipt.read_bytes());assert value['exitCode']==0 and value['phase']==phase and value['commandSha256']==digest
assert seen==['archaeology','ecology'];assert not Path('/private/tmp/ashlar-graphframes-installed-20261010-c').exists()
print('PASS actual H required command shape/phase dispatch and receipt; capture inert, no child/build/SDK')
