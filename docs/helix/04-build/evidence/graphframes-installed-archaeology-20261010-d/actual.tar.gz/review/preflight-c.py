"""Pure fixed command custody/parser/control preflight; no build/SDK/producer/native."""
from pathlib import Path
import ast,json,hashlib,os,subprocess,sys,tempfile,contextlib,io
from unittest.mock import patch
P=Path('/private/tmp');R=Path('/Users/erik/Projects/ashlar')
def sha(b):return hashlib.sha256(b).hexdigest()
command=json.loads((P/'ashlar-graphframes-installed-command-c.json').read_bytes());metadata=json.loads((P/'ashlar-graphframes-installed-metadata-c.json').read_bytes())
assert metadata['command']['sha256']==sha((P/'ashlar-graphframes-installed-command-c.json').read_bytes())
for pin in command['resources']:
 p=Path(pin['path']);assert p.stat().st_size==pin['bytes']and sha(p.read_bytes())==pin['sha256']
runner=(P/'ashlar-graphframes-installed-runner-c.py').read_text();tree=ast.parse(runner)
verify=next(node for node in tree.body if isinstance(node,ast.FunctionDef)and node.name=='verify')
ns={'hashlib':hashlib,'Path':Path,'sha':sha,'json':json,'os':os,'CLOSURE':P/'ashlar-graphframes-installed-closure-c.json','CLOSURE_SHA':'69095fc3026bb45b5ecadf2569a7b608c5abae4c3d35da497d8e3e78801583af'}
exec(compile(ast.Module(body=[verify],type_ignores=[]),'<actual-reviewed-verify>','exec'),ns);ns['verify']()
inventory=json.loads((P/'ashlar-graphframes-installed-source-inventory-c.json').read_bytes())
for row in inventory['files']:
 raw=subprocess.check_output(['/usr/bin/git','-C',str(R),'show',inventory['revision']+':'+row['path']]);assert len(raw)==row['bytes']and sha(raw)==row['sha256']
assert not Path(metadata['freshWork']).exists()
for c in command['commands']:
 for field in ['stdout','stderr']:assert not Path(c[field]).exists()
# Actual registered CLI parser with only final operation inert.
sys.path.insert(0,str(R/'src'))
from ashlar.cli import main
from ashlar_host import graphframes_cli
query=next(n for n in ast.walk(tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='run'and n.args and isinstance(n.args[0],ast.BinOp)and isinstance(n.args[0].right,ast.Constant)and n.args[0].right.value=='-query')
fixed=[n.value for n in query.args[1].elts if isinstance(n,ast.Constant)]
assert fixed==['-I','-B','query-graphframes','--configuration','--provider','--provider-sha256']
with patch.object(sys,'argv',['ashlar','query-graphframes','--configuration','/explicit/config','--provider','/explicit/provider','--provider-sha256','0'*64]),patch.object(graphframes_cli,'run_graphframes_command',return_value={'scope':'inert'})as call,contextlib.redirect_stdout(io.StringIO()):
 main();call.assert_called_once_with('/explicit/config','/explicit/provider','0'*64)
# Namespace control detects extra aliases even to already retained bytes.
provider=ast.parse((P/'ashlar-graphframes-installed-provider-c.py').read_text());namespace=next(n for n in provider.body if isinstance(n,ast.FunctionDef)and n.name=='namespace')
ns={'os':os};exec(compile(ast.Module(body=[namespace],type_ignores=[]),'<actual-namespace>','exec'),ns)
with tempfile.TemporaryDirectory(prefix='ashlar-gf-namespace-control-',dir='/private/tmp')as d:
 root=Path(d);(root/'original').write_bytes(b'original');before=ns['namespace'](root);(root/'alias').symlink_to('original');assert ns['namespace'](root)!=before
# Existing copied binary bytes require dedicated custody, never package8MiB gate.
python=Path('/Users/erik/.local/share/uv/python/cpython-3.11.17-macos-aarch64-none/bin/python3.11');raw=python.read_bytes();assert len(raw)>8388608 and len(raw)<=67108864
print(json.dumps({'pass':True,'closureFiles':metadata['closureFiles'],'closureBytes':metadata['closureBytes'],'GitSourceFiles':len(inventory['files']),'actualRegisteredParser':True,'extraAliasRefusedByNamespace':True,'copiedInterpreterBytes':len(raw),'sdkImported':False,'buildOrNativeStarted':False}))
