"""Explicit trusted local retained-export operator; no current canonical/PG claim."""
from contextlib import contextmanager
from pathlib import Path
import hashlib,importlib.util,importlib.metadata,json,os,stat,sys,fcntl
from ashlar_host.finite_pack import FinitePackDefinition
from ashlar_host.finite_dataset import FiniteDatasetConfig,HeldFiniteDataset,FinitePackSource
from ashlar_host.graphframes_release import GraphFramesOfflineSession,GraphFramesRuntimeInventory,GraphFramesRuntimeFile,VERSIONS
from ashlar_host.private_graph_custody import load_private_graph_release
from ashlar_host.lifecycle import finish,owned_context
WORK=Path('/private/tmp/ashlar-graphframes-installed-20261010-c')
SDK=Path('/private/tmp/ashlar-spark311/lib/python3.11/site-packages')
REV='6ced38ec82b893e4f79e8412687f09adb7178906'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode()
def namespace(root):
 return [{'path':str(p),'kind':'link'if p.is_symlink()else 'file'if p.is_file()else 'directory'if p.is_dir()else 'refused',**({'target':os.readlink(p),'resolved':str(p.resolve())}if p.is_symlink()else {})}for p in sorted(root.rglob('*'))]
def files(root):
 result=[]
 for p in sorted(root.rglob('*')):
  if p.is_file():
   q=p.resolve();result.append({'path':str(q),'sha256':digest(q.read_bytes()),'size':q.stat().st_size})
 return sorted({r['path']:r for r in result}.values(),key=lambda r:r['path'])
class RuntimePolicy:
 def __init__(self,plan):
  self.plan=plan;self.raw=(WORK/'runtime-plan.json').read_bytes();self.inventory=GraphFramesRuntimeInventory(REV,tuple(GraphFramesRuntimeFile(Path(r['path']),r['sha256'],r['size'])for r in plan['worker']),tuple((name,tuple(GraphFramesRuntimeFile(Path(r['path']),r['sha256'],r['size'])for r in rows))for name,rows in plan['sdks']))
 def renew(self,config,context):
  if (WORK/'runtime-plan.json').read_bytes()!=self.raw:raise PermissionError('Original runtime admission plan changed')
  if context is not self or Path(sys.executable)!=config.python or sys.flags.isolated!=1:raise PermissionError('Actual isolated selected interpreter required')
  if Path(sys.prefix)!=WORK/'venv' or sys.base_prefix==sys.prefix:raise PermissionError('Actual separate selected virtual environment required')
  paths=[str(Path(p).resolve())for p in sys.path if p]
  if paths!=self.plan['sys_path']:raise PermissionError('Actual isolated import path selection changed')
  for link in self.plan['symlinks']:
   p=Path(link['path'])
   if not p.is_symlink()or os.readlink(p)!=link['target']or str(p.resolve())!=link['resolved']:raise PermissionError('Actual startup/runtime link changed')
  for root,expected in self.plan['namespaces'].items():
   if namespace(Path(root))!=expected:raise PermissionError('Exact actual import namespace/link inventory changed')
  for root,expected in self.plan['roots'].items():
   if files(Path(root))!=expected:raise PermissionError('Complete actual import closure changed')
  for name,package in [('pyspark','pyspark'),('delta-spark','delta'),('graphframes-py','graphframes')]:
   distribution=importlib.metadata.distribution(name)
   if distribution.version!=VERSIONS[name]or not Path(distribution.locate_file('')).resolve()==SDK:raise PermissionError('Actual selected SDK metadata differs')
   spec=importlib.util.find_spec(package)
   if spec is None or Path(spec.origin).resolve()!=SDK/package/'__init__.py':raise PermissionError('Actual SDK resolution differs')
  worker=importlib.util.find_spec('ashlar_host.graphframes_release')
  if worker is None or Path(worker.origin)!=WORK/'venv/lib/python3.11/site-packages/ashlar_host/graphframes_release.py':raise PermissionError('Actual installed worker resolution differs')
  for name in ('sitecustomize','usercustomize'):
   if importlib.util.find_spec(name)is not None:raise PermissionError('Unselected startup hook')
  if (WORK/'venv/lib/python3.11/site-packages/selected-sdk.pth').read_bytes()!=(str(SDK)+'\n').encode():raise PermissionError('Explicit plain SDK path selector changed')
  self.inventory.verify(config)
 def admit_graphframes_runtime(self,config,context):self.renew(config,context);return self.inventory
 def renew_graphframes_runtime(self,inventory,config,context):
  if inventory is not self.inventory:raise PermissionError('Original runtime inventory required')
  self.renew(config,context)
class ExportPolicy:
 def __init__(self,invocation,release,custody,model,graph,plan):
  self.invocation=invocation;self.release=release;self.custody=custody;self.model=model;self.graph=graph;self.plan=plan;self.held=False;self.fd=None
  self.original_plan=(WORK/'operator-plan.json').read_bytes()
  self.sources={str(p):(p.stat().st_dev,p.stat().st_ino,p.read_bytes())for p in (model,graph,invocation.pack,invocation.release,invocation.custody)}
 def renew(self):
  if (WORK/'operator-plan.json').read_bytes()!=self.original_plan:raise PermissionError('Original independently selected scope inventory changed')
  if not self.held or self.fd is None:raise PermissionError('Current cooperative retained-export custody required')
  lock=WORK/(self.plan['pack']+'-operator.lock');current=lock.lstat();opened=os.fstat(self.fd)
  if stat.S_ISLNK(current.st_mode)or not stat.S_ISREG(current.st_mode)or current.st_uid!=os.getuid()or stat.S_IMODE(current.st_mode)!=0o600 or (current.st_dev,current.st_ino)!=(opened.st_dev,opened.st_ino):raise PermissionError('Current owned retained-export lease changed')
  for path,(dev,ino,raw)in self.sources.items():
   p=Path(path)
   if any(q.is_symlink()for q in (p,*p.parents))or (p.stat().st_dev,p.stat().st_ino)!=(dev,ino)or p.read_bytes()!=raw:raise PermissionError('Original retained source/export custody changed')
  if digest(self.release.payload)!=self.plan['release_sha256']or digest(self.custody)!=self.plan['custody_sha256']:raise PermissionError('Independent selected original protected ACK export differs')
  load_private_graph_release(self.release.payload,self.plan['release_sha256'],self.custody,self.plan['custody_sha256'])
 @contextmanager
 def writer(self,context):
  if context is not self or self.held:raise PermissionError('Exact nonreentrant retained-export hold required')
  path=WORK/(self.plan['pack']+'-operator.lock');fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_RDWR|os.O_NOFOLLOW,0o600);self.fd=fd;primary=None
  try:
   fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);self.held=True;self.renew();yield;self.renew()
  except BaseException as error:primary=error
  def release():self.held=False;fcntl.flock(fd,fcntl.LOCK_UN)
  def close():self.fd=None;os.close(fd)
  finish(primary,[release,close])
 @contextmanager
 def source_hold(self):
  with owned_context(self.writer(self)):yield
 def admit_source(self,facts,context):
  self.renew()
  if context is not self or dict(facts)!=FinitePackDefinition(self.plan['pack']).inputs(self.model.read_bytes(),self.graph.read_bytes()):raise PermissionError('Actual current original finite-file scope differs')
 def admit_original_export(self,release,custody,source,context):
  self.renew()
  if context is not self or release!=self.release or custody!=self.custody or source.model!=self.model.read_bytes()or source.graph!=self.graph.read_bytes():raise PermissionError('Actual original source/retained export differs')
 @contextmanager
 def writer_nested(self,context):
  if context is not self:raise PermissionError('Exact held context required')
  self.renew();yield;self.renew()
@contextmanager
def open_graphframes(invocation,release,custody_bytes):
 plan=json.loads((WORK/'operator-plan.json').read_bytes())['packs'][invocation.pack.parent.parent.name]
 model=Path(plan['model']);graph=Path(plan['graph']);policy=ExportPolicy(invocation,release,custody_bytes,model,graph,plan)
 # Outer hold owns actual file lease; session writer renews that existing hold.
 with owned_context(policy.source_hold()):
  producer=HeldFiniteDataset(FiniteDatasetConfig(FinitePackDefinition(plan['pack']),Path('/private/tmp/ashlar-umf-compact-clean-07357ead'),Path('/opt/homebrew/Cellar/bun/1.4.2/bin/bun'),Path('/usr/bin/git'),5,1048576,33554432),model,graph,invocation.output/'public-dataset.json')
  source=FinitePackSource(FinitePackDefinition(plan['pack']),model,graph,producer,policy=policy,context=policy)
  runtime=RuntimePolicy(json.loads((WORK/'runtime-plan.json').read_bytes()))
  class SessionPolicy:
   def writer(self,context):return policy.writer_nested(context)
   def admit_original_export(self,*args):return policy.admit_original_export(*args)
  runtime.renew(invocation.runtime,runtime)
  yield GraphFramesOfflineSession(release,custody_bytes,invocation.custody_sha256,source,SessionPolicy(),policy,runtime,runtime)
  source.renew();runtime.renew(invocation.runtime,runtime);policy.renew()
