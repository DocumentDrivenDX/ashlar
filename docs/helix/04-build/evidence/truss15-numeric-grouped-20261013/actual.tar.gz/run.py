import os,sys,tempfile,time,json,base64,hashlib,importlib.metadata
from pathlib import Path
import psycopg,psycopg.pq,jsonschema,referencing
root=Path(__file__).parent;(root/'ipc').mkdir();os.environ['TMPDIR']=str(root/'ipc');tempfile.tempdir=None
os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
for p in reversed(json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical']):sys.path.insert(0,p)
sys.path.insert(0,'/Users/erik/Projects/ashlar/src');sys.path.insert(0,'/private/tmp/ashlar-truss15-parallel-example-20261013-a/truss-target')
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context
from ashlar_host.truss_example import private_file
from ashlar_host.truss_example_reader import run_configure_truss_example_reader_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_two_hop_count_cli import run_query_truss_two_hop_count_command
from ashlar_host.truss_two_hop_target_count_cli import run_query_truss_two_hop_target_count_command
from decimal import Decimal
from ashlar_host.truss_numeric_grouped_count_cli import run_query_truss_numeric_grouped_count_command
start=time.monotonic();result=None
try:
 example=Path('/private/tmp/ashlar-truss15-parallel-example-20261013-a/example')
 with owned_context(LocalPostgres(example/'data'))as runtime:
  live=private_file(root/'live.json',{'profile':'ashlar-local-truss-connection/0.1','data_directory':str(example/'data'),'connection_uri':runtime.info.connection_uri})
  reader=root/'reader.json';run_configure_truss_example_reader_command(example,live,reader,reader_configuration=example/'reader-configuration.json');config=json.loads(reader.read_bytes())
  def connection():return psycopg.connect(config['connection_uri'],autocommit=False,connect_timeout=5)
  before=read_page(connection,'example-related-delta',maximum_bytes=2097152).prior.content;private_file(root/'checkpoint-before.json',{'cursor_base64':base64.b64encode(before).decode()})
  values=[]
  for name,field,tokens in (('integer','quantity',('9007199254740993','2')),('decimal','amount',('1.2300','2.0000'))):
   expected={Decimal(token).as_integer_ratio():1 for token in tokens}
   value=run_query_truss_numeric_grouped_count_command(reader,root/(name+'-query.json'),compiler='/private/tmp/ashlar-compatible-weft-compile-20261013-a/weft-runtime',sql='SELECT a.'+field+' AS value, COUNT(*) AS n FROM TypedRecord a GROUP BY a.'+field,revision='1',document_id='typed-related-record',physical_revisions=('1',),maximum_rows=2)
   actual={Decimal(next(iter(row['value'].values()))).as_integer_ratio():row['n']for row in value['rows']}
   if actual!=expected or len(actual)!=len(value['rows'])or value['publication_id']!='truss-graph-5':raise ValueError('Complete exact original numeric group bag differs')
   values.append({'case':name,'rows':value['rows'],'integrity':value['integrity'],'publication_id':value['publication_id']})
  after=read_page(connection,'example-related-delta',maximum_bytes=2097152).prior.content;private_file(root/'checkpoint-after.json',{'cursor_base64':base64.b64encode(after).decode()})
  if before!=after:raise ValueError('Numeric grouped read changed source checkpoint')
 result={'outcome':'passed','duration_seconds':round(time.monotonic()-start,3),'truss_version':'0.0.15','compiler_profile':'authenticated compatible0.2 candidate','queries':values,'source_checkpoint_unchanged':True,'qualification':'Actual public compatible numeric grouped counts on originalrequired signed64quantity and decimal18,4amount, complete independent two-node numeric group oracle and full original publication/nativeguards/closing custody. Originalmodel07 retained, physicalrevision1 explicit; no indexed0.4.2 or independentrecompile claim. No mutations, ACK, ingest or cloud qualification.'}
except BaseException as error:result={'outcome':'failed','duration_seconds':round(time.monotonic()-start,3),'error_type':type(error).__name__};raise
finally:private_file(root/'run-result.json',result);print(json.dumps(result),flush=True)
