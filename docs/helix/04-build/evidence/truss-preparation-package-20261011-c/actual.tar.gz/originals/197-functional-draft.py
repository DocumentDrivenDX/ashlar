"""Draft only: exact host-source pin must be finalized after independent B review."""
from pathlib import Path
import hashlib,json,base64

def functional_cases(run,python,prep,work,wheel,installed,deps,host):
 def pin(p):
  b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 def root(p):
  files=sorted(x for x in p.rglob('*')if x.is_file());directories=sorted(str(x.relative_to(p))for x in p.rglob('*')if x.is_dir())
  if any(x.is_symlink()for x in p.rglob('*')):raise ValueError('closed-import-alias')
  return {'path':str(p),'files':[pin(x)for x in files],'directories':directories}
 roots=[root(installed),root(deps)]
 for name,status in [('supported','prepared'),('unsupported','refused')]:
  out=work/(name+'-preparation');source=prep/(name+'.umf.json');choices=prep/'preparation-choices.json'
  config={'profile':'ashlar-truss-preparation/0.1','documents':[{'document_id':'future','document_revision':'r1','artifact_identity':None,'source':pin(source)}],'configuration':pin(choices),'runtime':{'python':pin(Path(python)),'bun':pin(Path('/opt/homebrew/Cellar/bun/1.4.2/bin/bun')),'python_version':'3.12.14','bun_version':'1.4.2','import_roots':roots},'package':{'distribution':'truss-toolkit','version':'0.0.1.dev0','source_revision':'9c54bd66bff3995d7548b9ff6cb024f462fae52e','wheel':pin(wheel),'module_origin':str(installed/'truss/__init__.py')},'output':str(out),'limits':{'input_bytes':1048576,'capture_bytes':16777216,'output_bytes':16777216,'receipt_bytes':1048576,'deadline_seconds':60}}
  path=work/(name+'-configuration.json');path.write_text(json.dumps(config,sort_keys=True)+'\n')
  raw=run('prepare-'+name,[python,'-I','-B','-S',str(prep/'host-cli.py'),str(host),'prepare-truss-catalog','--config',str(path)],90,expected_exit=0 if status=='prepared'else 2)
  if status=='prepared':
   summary=json.loads(raw)
   if summary['status']!=status or summary['closing']is not True or summary['qualification']!='original_umf_preparation_only':raise ValueError('exact-public-status')
  else:
   if raw!=b''or(work/('prepare-'+name+'.stderr')).read_bytes()!=b'ashlar Truss preparation command failed\n':raise ValueError('exact-public-refusal')
   if(out/'receipt.json').exists():raise ValueError('refusal-is-not-success-receipt')
   diagnostics=sorted(out.glob('refusal-*.json'))
   if not diagnostics:raise ValueError('original-refusal-diagnostics-required')
   for diagnostic in diagnostics:json.loads(diagnostic.read_bytes())
   summary={'status':'refused','expectedExitCode':2,'successfulReceiptProduced':False,'scope':'Original retained refusal diagnostics only; no acceptance or successful preparation receipt.'}
  if (out/'original-configuration.json').read_bytes()!=choices.read_bytes():raise ValueError('original-choice-bytes')
  if status=='prepared':
   original=source.read_bytes();value=json.loads(original)
   if (out/'document-0000.umf.json').read_bytes()!=original:raise ValueError('original-source-bytes')
   acceptance=json.loads((out/'input.json').read_bytes())
   if base64.b64decode(acceptance['documents'][0]['artifact']['bytesBase64'])!=original:raise ValueError('acceptance-original-bytes')
   archive=json.loads((out/'archive-documents.json').read_bytes())
   observation=json.loads((out/'observation-0000.json').read_bytes())
   if archive[0]['originalText']!=original.decode()or observation['source']['extensions']!=value['extensions']:raise ValueError('opaque-original-extension')
   if summary['provenance']['installation_profiles_verified']is not False:raise ValueError('no-profile-promotion')
  # Retain ALL observation/report bytes, including explicit unavailable owner observations.
  result={'summary':summary,'configuration':pin(path),'outputs':[pin(x)for x in sorted(out.iterdir())if x.is_file()]}
  (work/(name+'-qualification.json')).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
