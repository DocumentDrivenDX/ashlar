"""Reviewed offline packaging preparation only; functional host recipe is separate."""
from pathlib import Path
import argparse,json,hashlib,subprocess,importlib.util,sys,time,zipfile,csv,io,os,base64
P=Path('/private/tmp/ashlar-truss-offline-package-prep-c');W=Path('/private/tmp/ashlar-truss-offline-package-work-c')
PYTHON='/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
REPO='/Users/erik/Projects/truss'
def sha(b):return hashlib.sha256(b).hexdigest()
def choose(primary,error):
 return error if primary is None or isinstance(primary,Exception) and not isinstance(error,Exception) else primary
def read(path,limit):
 if path.is_symlink() or path.stat().st_size>limit:raise ValueError('input-shape')
 with path.open('rb') as f:b=f.read(limit+1)
 if len(b)>limit:raise ValueError('input-bound')
 return b
def write(path,raw):
 primary=None;stream=None
 try:
  stream=path.open('xb')
  if stream.write(raw)!=len(raw):raise OSError('incomplete-inventory-write')
  stream.flush();os.fsync(stream.fileno())
 except BaseException as e:primary=e
 finally:
  if stream is not None:
   try:stream.close()
   except BaseException as e:primary=choose(primary,e)
 if primary is not None:raise primary

def inventory(root):
 if root.is_symlink()or not root.is_dir():raise ValueError('owned-root-shape')
 result=[];total=0
 for p in sorted(root.rglob('*')):
  if len(result)>=8192 or p.is_symlink():raise ValueError('owned-namespace-bound')
  st=p.stat();r={'relative':str(p.relative_to(root)),'dev':st.st_dev,'ino':st.st_ino,'mode':st.st_mode,'mtimeNs':st.st_mtime_ns}
  if p.is_dir():r['kind']='directory'
  elif p.is_file():
   total+=st.st_size
   if total>134217728:raise ValueError('owned-copy-byte-bound')
   raw=read(p,st.st_size);after=p.stat()
   if (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):raise ValueError('owned-copy-drift')
   r.update(kind='file',bytes=len(raw),sha256=sha(raw))
  else:raise ValueError('owned-namespace-kind')
  result.append(r)
 return result

def main():
 a=argparse.ArgumentParser();a.add_argument('--command',type=Path,required=True);a.add_argument('--sha256',required=True);v=a.parse_args();raw=read(v.command,2097152)
 if sha(raw)!=v.sha256:raise ValueError('external-command-pin')
 plan=json.loads(raw);deadline=time.monotonic()+510
 def renew():
  runtime=json.loads(read(P/'stdlib-metadata.json',2097152));found=[]
  for x in sorted(Path(runtime['root']).rglob('*')):
   if x.relative_to(Path(runtime['root'])).parts[0]=='site-packages':continue
   st=x.lstat();found.append({'path':str(x),'dev':st.st_dev,'ino':st.st_ino,'bytes':st.st_size,'mtimeNs':st.st_mtime_ns,'mode':st.st_mode,'link':os.readlink(x)if x.is_symlink()else None})
  if found!=runtime['entries']:raise ValueError('qualified-stdlib-metadata-drift')
  if sha(read(v.command,2097152))!=v.sha256:raise ValueError('command-drift')
  for r in plan['resources']:
   p=Path(r['path']);b=read(p,max(r['bytes'],1))
   if len(b)!=r['bytes'] or sha(b)!=r['sha256']:raise ValueError('resource-drift')
 renew()
 if W.exists():raise ValueError('fresh-work-required')
 W.mkdir(mode=0o700)
 spec=importlib.util.spec_from_file_location('capture',plan['captureModule']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','PIP_CONFIG_FILE':'/dev/null','PIP_NO_INDEX':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1','PIP_NO_CACHE_DIR':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_ALLOW_PROTOCOL':'file','GIT_TERMINAL_PROMPT':'0'}
 phases=[]
 def run(name,argv,seconds=120,environment=None,expected_exit=0):
  nonlocal captured_bytes
  remaining=int(deadline-time.monotonic()-60)
  if remaining<1:raise TimeoutError('whole-package-budget')
  result=m.capture(argv,str(W),environment or env,str(W/(name+'.stdout')),str(W/(name+'.stderr')),min(seconds,remaining),1048576)
  captured_bytes+=(W/(name+'.stdout')).stat().st_size+(W/(name+'.stderr')).stat().st_size
  if captured_bytes>16777216:raise ValueError('aggregate-capture-bound')
  phases.append({'phase':name,**result})
  if result['exitCode']!=expected_exit:raise ValueError('package-phase-refused')
  return read(W/(name+'.stdout'),1048576)
 primary=None;closing=True;import_ready=False;opening_import=None;captured_bytes=0;builder_ready=False;builder_import=None;owned_roots={}
 try:
  sources=json.loads(read(P/'source-inventory.json',1048576));deps=json.loads(read(P/'dependency-inventory.json',2097152));root=W/'source';isolated=W/'dependencies';root.mkdir();isolated.mkdir()
  owned_roots[str(root)]=inventory(root);owned_roots[str(isolated)]=inventory(isolated)
  # Exact original Git blobs, no working-tree package substitution.
  for i,r in enumerate(sources['files']):
   b=run('source-'+str(i),['/usr/bin/git','-C',REPO,'show',sources['revision']+':'+r['path']],30)
   if len(b)!=r['bytes'] or sha(b)!=r['sha256']:raise ValueError('git-source-pin')
   target=root/Path(r['path']).relative_to('packages/python');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
  owned_roots[str(root)]=inventory(root)
  for r in deps['files']:
   if 'relative' not in r:continue
   target=isolated/r['relative'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(read(Path(r['path']),r['bytes']))
  buildenv={**env,'PYTHONPATH':str(isolated)}
  owned_roots[str(isolated)]=inventory(isolated)
  wheelroot=W/'wheel';wheelroot.mkdir();owned_roots[str(wheelroot)]=inventory(wheelroot)
  builder_ready=True
  builder_import=run('builder-imports-opening',[PYTHON,'-I','-B','-S',str(P/'builder-probe.py'),str(isolated)],30)
  # Normal declared setuptools backend over COMPLETE package and bundled assets.
  run('wheel',[PYTHON,'-B','-S','-m','pip','wheel','--no-index','--no-deps','--no-build-isolation','--wheel-dir',str(W/'wheel'),str(root)],120,buildenv)
  for r in sources['files']:
   staged=root/Path(r['path']).relative_to('packages/python')
   if sha(read(staged,r['bytes']))!=r['sha256']:raise ValueError('build-original-source-drift')
  owned_roots[str(root)]=inventory(root)
  owned_roots[str(wheelroot)]=inventory(wheelroot)
  wheels=list((W/'wheel').glob('*.whl'))
  if len(wheels)!=1:raise ValueError('one-wheel-required')
  target=W/'installed';target.mkdir();owned_roots[str(target)]=inventory(target)
  run('install',[PYTHON,'-B','-S','-m','pip','install','--no-index','--no-deps','--no-compile','--target',str(target),str(wheels[0])],120,buildenv)
  owned_roots[str(target)]=inventory(target)
  with zipfile.ZipFile(wheels[0]) as z:
   records=[n for n in z.namelist() if n.endswith('.dist-info/RECORD')]
   if len(records)!=1:raise ValueError('one-wheel-record')
   for name,digest,size in csv.reader(io.StringIO(z.read(records[0]).decode())):
    if not digest:
     if name!=records[0] or size:raise ValueError('unhashed-wheel-record')
     continue
    raw=z.read(name)
    if digest!='sha256='+base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip('=') or size!=str(len(raw)):raise ValueError('wheel-record-pin')
   expected={r['path'].removeprefix('packages/python/src/'):r for r in sources['files'] if r['path'].startswith('packages/python/src/')}
   actual={n for n in z.namelist() if n.startswith('truss/') and not n.endswith('/')}
   if actual!=set(expected):raise ValueError('complete-bundled-wheel-membership')
   for n,r in expected.items():
    b=z.read(n)
    if sha(b)!=r['sha256'] or read(target/n,r['bytes'])!=b:raise ValueError('source-wheel-installed-correspondence')
  host=W/'host';host.mkdir();owned_roots[str(host)]=inventory(host)
  for r in json.loads(read(P/'host-source-draft-inventory.json',1048576))['files']:
   dest=host/r['relative'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(read(Path(r['path']),r['bytes']))
  owned_roots[str(host)]=inventory(host)
  write(W/'copied-generated-opening-inventory.json',json.dumps(owned_roots,sort_keys=True,indent=2).encode()+b'\n')
  import_ready=True
  opening_import=run('imports-opening',[PYTHON,'-I','-B','-S',str(P/'import-probe-a.py'),str(target),str(isolated)],30)

  functional=importlib.util.spec_from_file_location('functional',P/'functional-draft.py');fm=importlib.util.module_from_spec(functional);functional.loader.exec_module(fm)
  fm.functional_cases(run,PYTHON,P,W,wheels[0],target,isolated,host)
 except BaseException as e:primary=e
 finally:
  if builder_ready:
   try:
    observed=run('builder-imports-closing',[PYTHON,'-I','-B','-S',str(P/'builder-probe.py'),str(isolated)],30)
    if builder_import is not None and builder_import!=observed:raise ValueError('builder-origin-closing')
   except BaseException as e:closing=False;primary=choose(primary,e)
  if import_ready:
   try:
    closing_import=run('imports-closing',[PYTHON,'-I','-B','-S',str(P/'import-probe-a.py'),str(target),str(isolated)],30)
    if opening_import is not None and opening_import!=closing_import:raise ValueError('origin-closing-drift')
   except BaseException as e:closing=False;primary=choose(primary,e)
  for name,original in owned_roots.items():
   try:
    if inventory(Path(name))!=original:raise ValueError('copied-generated-closing-drift')
   except BaseException as e:closing=False;primary=choose(primary,e)
  try:renew()
  except BaseException as e:closing=False;primary=choose(primary,e)
  result={'profile':'ashlar-truss-offline-package-preparation/0.1','phases':phases,'openingClosingCustody':closing,'wholeSuccess':primary is None,'functionalPreparationExecuted':any(r['phase'].startswith('prepare-')for r in phases),'scope':'Actual immutable Truss public package preparation through frozen candidate Ashlar CLI; no accepted catalog/feed/ACK/database authority.'}
  stream=None
  try:
   stream=(W/'receipt.json').open('x');json.dump(result,stream,sort_keys=True,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
  except BaseException as e:primary=choose(primary,e)
  finally:
   if stream is not None:
    try:stream.close()
    except BaseException as e:primary=choose(primary,e)
 if primary is not None:raise primary
if __name__=='__main__':main()
