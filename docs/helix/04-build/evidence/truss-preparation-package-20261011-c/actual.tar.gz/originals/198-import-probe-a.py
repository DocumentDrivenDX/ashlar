"""Import-only exact selected package roots; no producer or DB execution."""
import sys,json,importlib,importlib.metadata
from pathlib import Path
installed=Path(sys.argv[1]);deps=Path(sys.argv[2]);sys.path[:0]=[str(installed),str(deps)]
versions={'truss-toolkit':'0.0.1.dev0','jsonschema':'4.26.0','referencing':'0.37.0','attrs':'26.1.0','rpds-py':'2026.9.1','jsonschema-specifications':'2025.9.1','typing-extensions':'4.16.0'}
observed={}
for name in ['truss','truss.preparation','jsonschema','referencing','attrs','rpds','jsonschema_specifications','typing_extensions']:
 m=importlib.import_module(name);p=Path(m.__file__).resolve();expected=installed if name.startswith('truss') else deps
 if not p.is_relative_to(expected.resolve()):raise ValueError('selected-import-origin')
 observed[name]=str(p)
for name,value in versions.items():
 if importlib.metadata.version(name)!=value:raise ValueError('selected-version')
print(json.dumps({'origins':observed,'versions':versions,'scope':'Import-only; no preparation/Bun/DB/native authority.'},sort_keys=True))
