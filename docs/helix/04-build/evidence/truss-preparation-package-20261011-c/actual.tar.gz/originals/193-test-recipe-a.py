import ast,json,unittest
from pathlib import Path
P=Path(__file__).parent
class Tests(unittest.TestCase):
 def test_complete_original_assets(self):
  d=json.loads((P/'source-inventory.json').read_bytes());names={r['path'] for r in d['files']}
  self.assertIn('packages/python/src/truss/_umf/owner/producer.js',names)
  self.assertIn('packages/python/src/truss/_umf/packages/umf-bun/src/bridge.js',names)
  self.assertIn('packages/python/pyproject.toml',names)
 def test_normal_backend_and_closed_offline_recipe(self):
  s=(P/'runner-a.py').read_text();ast.parse(s)
  self.assertIn("'--no-build-isolation'",s);self.assertIn("'--no-index'",s);self.assertIn("actual!=set(expected)",s)
  self.assertNotIn('check-python-fresh-wheel',s)
 def test_actual_failure_priority(self):
  tree=ast.parse((P/'runner-a.py').read_text());f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='choose');ns={};exec(compile(ast.Module(body=[f],type_ignores=[]),'owning','exec'),ns)
  primary=KeyboardInterrupt();self.assertIs(ns['choose'](primary,OSError()),primary)
  cancel=GeneratorExit();self.assertIs(ns['choose'](ValueError(),cancel),cancel)
 def test_fixture_versions_unknown_content_and_explicit_choices(self):
  s=json.loads((P/'supported.umf.json').read_bytes());u=json.loads((P/'unsupported.umf.json').read_bytes());self.assertEqual(s['umf'],'0.7.0');self.assertEqual(u['umf'],'99.0.0');self.assertEqual(s['extensions'],u['extensions'])
  c=json.loads((P/'preparation-choices.json').read_bytes());self.assertEqual(c['binding'],{'state':'absent'});self.assertEqual(c['transforms'],[])
 def test_zero_byte_original_payload_retained(self):
  d=json.loads((P/'source-inventory.json').read_bytes());r=next(r for r in d['files']if r['path'].endswith('/py.typed'));self.assertEqual(r['bytes'],0)
 def test_owning_supervisor_external_hash_and_cleanup(self):
  tree=ast.parse((P/'supervisor-draft.py').read_text());f=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='choose');ns={};exec(compile(ast.Module(body=[f],type_ignores=[]),'owner','exec'),ns)
  primary=KeyboardInterrupt();self.assertIs(ns['choose'](primary,OSError()),primary)
  s=(P/'supervisor-draft.py').read_text();self.assertIn("a.sha256 if x=='EXTERNAL_COMMAND_SHA256'else x",s)
 def test_public_dispatch_and_closed_original_choices(self):
  s=(P/'functional-draft.py').read_text();ast.parse(s)
  self.assertIn("'prepare-truss-catalog','--config'",s);self.assertIn("'deadline_seconds':60",s);self.assertIn("original-configuration.json",s)
  self.assertNotIn('prepare_acceptance(',s)
if __name__=='__main__':unittest.main()
