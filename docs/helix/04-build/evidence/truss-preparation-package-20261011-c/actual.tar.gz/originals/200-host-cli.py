"""Exact selected Ashlar package entry; no sibling/site imports."""
import sys,runpy
from pathlib import Path
root=Path(sys.argv.pop(1));sys.path.insert(0,str(root));sys.argv[0]='ashlar'
runpy.run_module('ashlar',run_name='__main__')
