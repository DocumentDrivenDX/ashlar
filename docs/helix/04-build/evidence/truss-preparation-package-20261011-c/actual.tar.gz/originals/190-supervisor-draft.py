"""Exact externally pinned finite wrapper; no network/environment inheritance."""
import argparse,json,hashlib,importlib.util,time,os
from pathlib import Path

def choose(primary,error):return error if primary is None or isinstance(primary,Exception)and not isinstance(error,Exception)else primary

def main():
 p=argparse.ArgumentParser();p.add_argument('--command',required=True,type=Path);p.add_argument('--sha256',required=True);a=p.parse_args();started=time.monotonic()
 if a.command.is_symlink()or a.command.stat().st_size>2097152:raise ValueError('command-bound')
 raw=a.command.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=a.sha256:raise ValueError('external-command-pin')
 plan=json.loads(raw)
 def renew():
  phase_deadline=time.monotonic()+20
  if hashlib.sha256(a.command.read_bytes()).hexdigest()!=a.sha256:raise ValueError('command-drift')
  for r in plan['resources']:
   if time.monotonic()>phase_deadline:raise TimeoutError('bounded-resource-renewal')
   path=Path(r['path'])
   if path.is_symlink()or not path.is_file()or path.stat().st_size!=r['bytes']:raise ValueError('resource-shape')
   h=hashlib.sha256()
   with path.open('rb')as f:
    for b in iter(lambda:f.read(65536),b''):
     if time.monotonic()>phase_deadline:raise TimeoutError('bounded-resource-renewal')
     h.update(b)
   if h.hexdigest()!=r['sha256']:raise ValueError('resource-pin')
 renew()
 spec=importlib.util.spec_from_file_location('capture',plan['captureModule']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 primary=None;result=None;closed=False
 try:
  if Path(plan['freshWork']).exists():raise ValueError('fresh-work')
  argv=[a.sha256 if x=='EXTERNAL_COMMAND_SHA256'else x for x in plan['runnerArgv']]
  result=m.capture(argv, '/private/tmp', {'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'},plan['stdout'],plan['stderr'],max(1,540-int(time.monotonic()-started)-20),1048576)
 except BaseException as e:primary=e
 finally:
  try:renew();closed=True
  except BaseException as e:primary=choose(primary,e)
  stream=None
  try:
   stream=Path(plan['outerReceipt']).open('x');json.dump({'result':result,'openingClosingCustody':closed,'wholeSuccess':primary is None and result is not None and result['exitCode']==0},stream,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
  except BaseException as e:primary=choose(primary,e)
  finally:
   if stream is not None:
    try:stream.close()
    except BaseException as e:primary=choose(primary,e)
 if primary is not None:raise primary
 if result['exitCode']!=0:raise SystemExit(result['exitCode'])
if __name__=='__main__':main()
