import unittest,tempfile,importlib.util,json,hashlib
from pathlib import Path
P=Path(__file__).parent
class Tests(unittest.TestCase):
 def test_actual_owned_inventory_detects_growth_and_namespace(self):
  spec=importlib.util.spec_from_file_location('owner',P/'runner-a.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp);f=root/'file';f.write_bytes(b'original');before=m.inventory(root);f.write_bytes(b'changed!');self.assertNotEqual(m.inventory(root),before)
   before=m.inventory(root);(root/'extra').write_bytes(b'');self.assertNotEqual(m.inventory(root),before)
   primary=KeyboardInterrupt();self.assertIs(m.choose(primary,OSError()),primary)
 def test_actual_functional_public_exit_and_retained_refusal(self):
  spec=importlib.util.spec_from_file_location('functional',P/'functional-draft.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  with tempfile.TemporaryDirectory()as tmp:
   w=Path(tmp);installed=w/'installed';deps=w/'deps';installed.mkdir();deps.mkdir();wheel=w/'wheel';wheel.write_bytes(b'wheel');calls=[]
   def run(name,argv,seconds,expected_exit=0):
    calls.append((name,expected_exit));config=json.loads(Path(argv[-1]).read_bytes());out=Path(config['output']);out.mkdir();(out/'original-configuration.json').write_bytes((P/'preparation-choices.json').read_bytes())
    if expected_exit==2:
     (out/'refusal-0000.json').write_text('{"code":"unsupported_version"}');(w/(name+'.stderr')).write_bytes(b'ashlar Truss preparation command failed\n');return b''
    source=(P/'supported.umf.json').read_bytes();value=json.loads(source);(out/'document-0000.umf.json').write_bytes(source)
    import base64
    (out/'input.json').write_text(json.dumps({'documents':[{'artifact':{'bytesBase64':base64.b64encode(source).decode()}}]}));(out/'archive-documents.json').write_text(json.dumps([{'originalText':source.decode()}]));(out/'observation-0000.json').write_text(json.dumps({'source':{'extensions':value['extensions']}}))
    return json.dumps({'status':'prepared','closing':True,'qualification':'original_umf_preparation_only','provenance':{'installation_profiles_verified':False}}).encode()
   m.functional_cases(run,'/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',P,w,wheel,installed,deps,w)
   self.assertEqual(calls,[('prepare-supported',0),('prepare-unsupported',2)]);self.assertFalse((w/'unsupported-preparation/receipt.json').exists())
if __name__=='__main__':unittest.main()
