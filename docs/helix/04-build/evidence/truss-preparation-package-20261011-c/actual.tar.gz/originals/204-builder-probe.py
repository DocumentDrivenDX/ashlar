import sys,importlib,importlib.metadata,json
from pathlib import Path
root=Path(sys.argv[1]);sys.path.insert(0,str(root));observed={}
for name,version in [('pip','26.2.1'),('setuptools','84.0.0'),('wheel','0.48.0'),('packaging','26.3')]:
 m=importlib.import_module(name);p=Path(m.__file__).resolve()
 if not p.is_relative_to(root.resolve())or importlib.metadata.version(name)!=version:raise ValueError('selected-builder-origin')
 observed[name]={'origin':str(p),'version':version}
if sys.version_info[:3]!=(3,12,14):raise ValueError('selected-python-version')
print(json.dumps(observed,sort_keys=True))
