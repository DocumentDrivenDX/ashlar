"""Explicit original-F installed verification provider; zero submission route."""
from contextlib import contextmanager
import importlib.util,sys,json,hashlib
from pathlib import Path
from ashlar_host.evolution_verification_types import VerifyEvolutionInvocation,VerificationBounds,VerificationSupervision
from ashlar_host.evolution_cli import InvocationFile
from ashlar_host.evolution_operator import ExistingEvolutionOperator
from ashlar_host.delta_custody import DeltaTarget,LOCAL_OPERATION_CAPACITY_8M
from ashlar_host.lifecycle import finish,owned_context
ROOT=Path('/private/tmp/ashlar-evolution-installed-native-20261011-f/installation')
RUN='8abac861a6ada92aee0fb4080c1230867d358d776c16c92c5a776538ea657f95'
TARGETS='9cb62b91070d7cb499990a55c045096b288c432c515b7cff47efb8fc4198a154'
BOUNDS=VerificationBounds(262144,10000,1048576,16777216,1048576,1048576)
SUPERVISION=VerificationSupervision(300,1048576,'operator-owned-process-supervisor/0.1')
@contextmanager
def open_verification(invocation):
    if type(invocation) is not VerifyEvolutionInvocation or invocation.ordinal!=0 or invocation.expected_sha256!=RUN or invocation.ledger_path!=ROOT/'run.sqlite' or invocation.bounds!=BOUNDS or invocation.supervision!=SUPERVISION:
        raise PermissionError('Exact original-F completed ordinal0 bounded verification required')
    if (str(invocation.producer.source),str(invocation.producer.bun),str(invocation.producer.git),invocation.producer.timeout_seconds,invocation.producer.maximum_output_bytes,invocation.producer.maximum_receipt_bytes)!=('/private/tmp/ashlar-umf-evolution-land-6a292','/opt/homebrew/Cellar/bun/1.4.2/bin/bun','/usr/bin/git',30,1048576,4194304):
        raise PermissionError('Exact original producer selection required')
    original=None;targets_file=None;selected=None;spark=None;primary=None
    try:
        original=InvocationFile.read(ROOT/'original-run.json',65536)
        targets_file=InvocationFile.read(ROOT/'targets.json',65536)
        if hashlib.sha256(original.raw).hexdigest()!=RUN or hashlib.sha256(targets_file.raw).hexdigest()!=TARGETS:
            raise PermissionError('Original run and six-target bytes differ')
        spec=importlib.util.spec_from_file_location('explicit_verification_fixture','/private/tmp/ashlar-evolution-installed-verification-helper-b.py')
        helper=importlib.util.module_from_spec(spec);sys.modules[spec.name]=helper;spec.loader.exec_module(helper)
        selected=helper.FixtureSelection.capture('/private/tmp/ashlar-private-outbox-fixture-prep-b/operation/fixture-c/inventory.json','f6f77011c66650b4eecc7efe034806a36db0e54c4bc1e4babdfd5d6eb8c1c7b9')
        targets=tuple(DeltaTarget(row['table'],Path(row['path']),row['uuid'])for row in json.loads(targets_file.raw))
        from pyspark.sql import SparkSession
        spark=(SparkSession.builder.master('local[1]').appName('Ashlar original-F completed ordinal0 verification')
            .config('spark.driver.memory','512m').config('spark.sql.shuffle.partitions','1')
            .config('spark.databricks.delta.snapshotPartitions','1').config('spark.ui.enabled','false')
            .config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true')
            .config('spark.executorEnv.PYTHONDONTWRITEBYTECODE','1')
            .config('spark.jars','/private/tmp/ashlar-supply-chain-finite-native-jars-f/delta-spark_2.13-4.0.0.jar,/private/tmp/ashlar-supply-chain-finite-native-jars-f/delta-storage-4.0.0.jar')
            .config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension')
            .config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog').getOrCreate())
        @contextmanager
        def native():yield spark
        operator=ExistingEvolutionOperator('private-public-evolution-20261011-a',ROOT/'operations.sqlite',ROOT/'original-run.json',targets,helper.registrations(selected),LOCAL_OPERATION_CAPACITY_8M,native)
        original.renew(65536);targets_file.renew(65536);selected.renew()
        with owned_context(operator.open_verification(invocation))as configuration:yield configuration
    except BaseException as error:primary=error
    callbacks=[]
    if spark is not None:callbacks.append(spark.stop)
    if original is not None:callbacks.append(lambda:original.renew(65536))
    if targets_file is not None:callbacks.append(lambda:targets_file.renew(65536))
    if selected is not None:callbacks.append(selected.renew)
    finish(primary,callbacks)
