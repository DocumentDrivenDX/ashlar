"""Pure closing orchestration, no wheel/compiler/SDK/native operation."""
import runpy
from pathlib import Path
module=runpy.run_path('/private/tmp/ashlar-commerce-original-installed-compile-runner-c.py');close=module['preserving_closure'];calls=[]
original=ValueError('required-case-blocked')
def operation():
 for name in ('partial-return','fulfillment','settlement','refund'):
  for iteration in (0,1):calls.append((name,iteration))
 raise original
def source():calls.append('source')
def interpreter():calls.append('interpreter')
def installed():calls.append('installed')
def payload():calls.append('payload')
try:close(operation,[source,interpreter,installed,payload])
except BaseException as error:assert error is original
else:raise AssertionError('Wholefailure released success')
assert len(calls)==12 and calls[-4:]==['source','interpreter','installed','payload']
for body,closing,expected in ((KeyboardInterrupt('body'),ValueError('closing'),'body'),(ValueError('body'),SystemExit('closing'),'closing'),(KeyboardInterrupt('body'),SystemExit('closing'),'body')):
 events=[]
 def fail_body():raise body
 def fail_closing():events.append('firstclose');raise closing
 def later_close():events.append('laterclose')
 try:close(fail_body,[fail_closing,later_close])
 except BaseException as error:assert error is (body if expected=='body'else closing)
 else:raise AssertionError('Failure lost')
 assert events==['firstclose','laterclose']
closing=OSError('closing')
try:close(lambda: 'provisional',[lambda:(_ for _ in ()).throw(closing)])
except BaseException as error:assert error is closing
else:raise AssertionError('Closing failure released provisional result')
print('All8captured beforeblockedwholefailure; all4closingchecks run; closingrefusal and cancellationpriority identities PASS')
