"""Inert classification flow; no compiler/SDK/imported probe pipeline."""
import ast,hashlib,json
from pathlib import Path
p=Path('/private/tmp/ashlar-commerce-original-installed-compile-probe-c.py');tree=ast.parse(p.read_bytes());function=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='classify_case');calls=[]
def admit(*args,**kwargs):calls.append(args[0]['sql'])
namespace={'json':json,'hashlib':hashlib,'admit_count_star_artifact':admit};exec(compile(ast.Module(body=[function],type_ignores=[]),str(p),'exec'),namespace);classify=namespace['classify_case'];results=[]
for name in ('partial-return','fulfillment','settlement','refund'):
 response=json.dumps({'status':'blocked','diagnostics':[{'code':'WFT-UNSUPPORTED','message':'original'}]}if name=='partial-return'else{'status':'compiled','logicalPlan':{'requiredCapabilities':['scan']}}).encode();row,failed=classify(name,{'sql':name},b'original',[response,response],{'rows':[['source']]},object());results.append((row,failed))
assert len(results)==4 and [failed for _,failed in results]==[True,False,False,False]and calls==['fulfillment','settlement','refund'];assert results[0][0]['diagnostics']==[{'code':'WFT-UNSUPPORTED','message':'original'}]
original=KeyboardInterrupt('original');namespace['admit_count_star_artifact']=lambda *a,**k:(_ for _ in ()).throw(original)
compiled=b'{"status":"compiled","logicalPlan":{"requiredCapabilities":[]}}'
try:classify('refund',{},b'r',[compiled,compiled],{},object())
except BaseException as error:assert error is original
else:raise AssertionError('Cancellation swallowed')
print('Firstblocked doesnotstoplater3 classification; diagnostics exact; admissiononlycompiled; cancellationidentity PASS')
