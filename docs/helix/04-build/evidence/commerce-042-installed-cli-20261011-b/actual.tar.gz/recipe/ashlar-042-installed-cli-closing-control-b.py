import ast
from pathlib import Path
runner=Path('/private/tmp/ashlar-042-installed-cli-runner-b.py');tree=ast.parse(runner.read_text());start=next(i for i,n in enumerate(tree.body)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='primary'for t in n.targets))
body=ast.Module(body=tree.body[start:],type_ignores=[])
select=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='select')
def check(primary=None,closing=None,write_error=None):
 calls=[];retained=[]
 def main():
  calls.append('opening-and-main')
  if primary is not None:raise primary
  return {'actual':'provisional'}
 def verify():
  calls.append('closing')
  if closing is not None:raise closing
 def write(path,value):
  retained.append(path.name)
  if write_error is not None and path.name=='preparation.json':raise write_error
 ns={'main':main,'verify':verify,'write':write,'WORK':Path('/unselected-owned'), 'REVISION':'fixed','Path':Path,'encoded':lambda x:x}
 exec(compile(ast.Module(body=[select],type_ignores=[]),str(runner),'exec'),ns)
 caught=None
 try:exec(compile(body,str(runner),'exec'),ns)
 except BaseException as error:caught=error
 assert calls==['opening-and-main','closing']
 return caught,retained
assert check()==(None,['preparation.json','ashlar-042-installed-cli-runner-b.receipt.json'])
ordinary=ValueError();assert check(primary=ordinary)[0]is ordinary
cancel=KeyboardInterrupt();assert check(primary=cancel,closing=ValueError())[0]is cancel
close_cancel=SystemExit();assert check(primary=ValueError(),closing=close_cancel)[0]is close_cancel
receipt_cancel=KeyboardInterrupt();assert check(write_error=receipt_cancel)[0]is receipt_cancel
print('Five actual owned finalizer controls PASS; no build/SDK/process/file output')
