import sys,json,pathlib
from ashlar.cli import main
from ashlar_host.implicit_arithmetic_configuration import QueryCommerceImplicitArithmeticConfig
from ashlar_host.config import HostError
assert not any(n.split('.')[0] in ('pyspark','delta','duckdb','psycopg') for n in sys.modules)
# Capture the real CLI typedconfiguration refusal: zero row limit before provider/files/SDK.
argv=['query-commerce-implicit-arithmetic']
for name in ('output','jars','model','graph','umf-source','bun','git','index','installation','publication','session-provider','pack'):
 argv.extend(['--'+name,'/unselected-nonexistent-'+name])
argv+=['--session-provider-sha256','0'*64,'--postgres-container','ashlar-e2e-truss-pg17','--postgres-host','127.0.0.1','--postgres-database','truss_e2e']
for name,value in [('producer-timeout-seconds','1'),('producer-maximum-output-bytes','1'),('producer-maximum-receipt-bytes','1'),('postgres-port','15432'),('maximum-artifact-bytes','1024'),('maximum-rows','0'),('maximum-cell-bytes','1024'),('maximum-total-cell-bytes','1024')]:argv+=['--'+name,value]
from ashlar_host.config import ProducerConfig,PrivatePostgresConfig
from ashlar_host.path_capture import PathCaptureConfig,PathCaptureError
from ashlar.weft_path_decode import PathDecodeConfig
ProducerConfig(pathlib.Path('/unselected-nonexistent-umf-source'),pathlib.Path('/unselected-nonexistent-bun'),pathlib.Path('/unselected-nonexistent-git'),1,1,1)
PrivatePostgresConfig('ashlar-e2e-truss-pg17','127.0.0.1',15432,'truss_e2e')
PathDecodeConfig(1024)
try:PathCaptureConfig(0,1024,1024)
except PathCaptureError as error:
 if str(error)!='Explicit positive capture limits required':raise
else:raise ValueError('Exact zero row limit must refuse')
sys.argv=['ashlar']+argv
try:main()
except SystemExit as refused:result=refused.code
else:raise ValueError('Expected typed refusal')
if result!=2:raise ValueError('Expected real typed CLI refusal')
if any(n.split('.')[0] in ('pyspark','delta','duckdb','psycopg') for n in sys.modules):raise ValueError('Unexpected native import')
print(json.dumps({'typedInvalidBeforeProviderOrNative':True,'independentExactInvalidField':'maximum_rows=0','independentCaptureError':'Explicit positive capture limits required','exitCode':result}))
