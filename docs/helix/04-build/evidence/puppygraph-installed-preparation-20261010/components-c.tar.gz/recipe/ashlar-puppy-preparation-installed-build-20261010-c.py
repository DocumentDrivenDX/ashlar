"""Finite fresh immutable wheel/CLI operation. No PG, Spark, network or Weft rebuild."""
import base64,csv,gzip,hashlib,importlib.util,io,json,os,stat,sys,tarfile,zipfile
from pathlib import Path,PurePosixPath
WORK=Path('/private/tmp/ashlar-puppy-preparation-installed-20261010-c');REPO=Path('/Users/erik/Projects/ashlar');REV='b24042c9640782155b8fbca0352c3f44b5cf26ef'
PRIMARY='/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
PY311='/Users/erik/.local/share/uv/python/cpython-3.12.15-macos-aarch64-none/bin/python3.12'
ENV={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','PIP_CONFIG_FILE':'/dev/null','PIP_DISABLE_PIP_VERSION_CHECK':'1','PIP_NO_CACHE_DIR':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_TERMINAL_PROMPT':'0','GIT_ALLOW_PROTOCOL':'file'}
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return json.dumps(v,separators=(',',':'),sort_keys=True).encode()+b'\n'
def write(p,b):
 stream=None;primary=None
 try:
  stream=p.open('xb')
  if stream.write(b)!=len(b):raise ValueError('exact-evidence-write')
 except BaseException as error:primary=error
 if stream is not None:
  try:stream.close()
  except BaseException as error:
   if primary is None or isinstance(primary,Exception) and not isinstance(error,Exception):primary=error
 if primary is not None:raise primary
def safe(name):
 p=PurePosixPath(name)
 if not name or '\\'in name or p.is_absolute()or any(v in ('','..','.')for v in name.split('/')):raise ValueError('member-path')
 return p

def main():
 WORK.mkdir(mode=0o700);(WORK/'tmp').mkdir();ENV['TMPDIR']=str(WORK/'tmp')
 spec=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
 phases=[];source=WORK/'source';inventory=json.loads(Path('/private/tmp/ashlar-puppy-preparation-installed-source-inventory-20261010-c.json').read_bytes());rows={r['path']:r for r in inventory['files']}
 if inventory['revision']!=REV:raise ValueError('source-revision')
 def run(label,argv,timeout=30,maximum=4*1024*1024,stdin=None,cwd=None):
  out=WORK/(label+'.stdout');err=WORK/(label+'.stderr');result=capture.capture(argv,str(cwd or WORK),ENV,str(out),str(err),timeout,maximum,str(stdin)if stdin else None)
  record={'phase':label,**result,'stdoutSha256':sha(out.read_bytes()),'stderrSha256':sha(err.read_bytes())};phases.append(record);write(WORK/(label+'.json'),enc(record))
  if result['exitCode']:raise ValueError('phase-refused:'+label)
  return out.read_bytes()
 original_archive=Path('/private/tmp/ashlar-puppy-preparation-installed-20261010-b/archive.stdout');archive_bytes=original_archive.read_bytes()
 if len(archive_bytes)!=3297280 or sha(archive_bytes)!='3bfa031b7b3acb369d45c4cf84370ace8d105b72d35b8f60156df3084abec9df':raise ValueError('retained-B-archive-custody')
 write(WORK/'archive.stdout',archive_bytes)
 source.mkdir();seen=set();decoded=0
 with tarfile.open(WORK/'archive.stdout','r:')as tar:
  members=tar.getmembers()
  if len(members)>512:raise ValueError('source-member-bound')
  names=set()
  for m in members:
   name=m.name.rstrip('/')if m.isdir()else m.name;safe(name)
   if name in names:raise ValueError('source-duplicate')
   names.add(name)
   if m.isdir():
    if not any(p.startswith(name+'/')for p in rows):raise ValueError('source-directory')
    continue
   if not m.isfile()or name not in rows:raise ValueError('source-extra')
   r=rows[name];decoded+=m.size
   if decoded>8*1024*1024 or m.size!=r['bytes']:raise ValueError('source-bound')
   raw=tar.extractfile(m).read(r['bytes']+1)
   if len(raw)!=r['bytes']or sha(raw)!=r['sha256']or m.mode&0o777!=(0o775 if r['gitMode']=='100755'else 0o664):
    # Git archive uses umask-independent 0664/0775 payload permissions.
    raise ValueError('source-custody')
   p=source/name;p.parent.mkdir(parents=True,exist_ok=True);write(p,raw);p.chmod(0o755 if r['gitMode']=='100755'else 0o644);seen.add(name)
 if seen!=set(rows):raise ValueError('source-closure')
 def source_custody():
  for name,r in rows.items():
   p=source/name;b=p.read_bytes()
   if p.is_symlink()or len(b)!=r['bytes']or sha(b)!=r['sha256']:raise ValueError('source-closing-custody')
 source_custody();(WORK/'wheels').mkdir()
 original_wheel=Path('/private/tmp/ashlar-puppy-preparation-installed-20261010-b/wheels/ashlar_graph_toolkit-0.1.0.dev0-py3-none-any.whl');wheel_bytes=original_wheel.read_bytes()
 if len(wheel_bytes)!=974938 or sha(wheel_bytes)!='f0d7e6532d61b2f64a318ea559a99340e5d93f1056c5575501f4365169901292':raise ValueError('retained-B-wheel-custody')
 write(WORK/'wheels'/original_wheel.name,wheel_bytes)
 wheels=list((WORK/'wheels').iterdir())
 if len(wheels)!=1 or wheels[0].is_symlink()or wheels[0].suffix!='.whl'or wheels[0].stat().st_size>8*1024*1024:raise ValueError('wheel-selection')
 wheel=wheels[0];expected={name[4:]:r for name,r in rows.items()if name.startswith('src/')and name!='src/ashlar/README.md'};payload={};metadata={};total=0;names=set()
 with zipfile.ZipFile(wheel)as archive:
  infos=archive.infolist()
  if len(infos)>512:raise ValueError('wheel-member-bound')
  for info in infos:
   name=info.filename;safe(name);mode=info.external_attr>>16
   if name in names or info.flag_bits&1 or stat.S_IFMT(mode)not in (0,stat.S_IFREG)or info.is_dir():raise ValueError('wheel-member-shape')
   names.add(name);total+=info.file_size
   if total>16*1024*1024:raise ValueError('wheel-decoded-bound')
   raw=archive.read(info)
   if name in expected:
    r=expected[name]
    if len(raw)!=r['bytes']or sha(raw)!=r['sha256']:raise ValueError('wheel-source')
    payload[name]=raw
   elif name.startswith('ashlar_graph_toolkit-0.1.0.dev0.dist-info/')and name.rsplit('/',1)[1]in ('METADATA','WHEEL','entry_points.txt','top_level.txt','RECORD'):metadata[name]=raw
   else:raise ValueError('wheel-extra')
 if set(payload)!=set(expected)or len(metadata)!=5:raise ValueError('wheel-closure')
 if metadata['ashlar_graph_toolkit-0.1.0.dev0.dist-info/entry_points.txt']!=b'[console_scripts]\nashlar = ashlar.cli:main\n':raise ValueError('wheel-entrypoint')
 write(WORK/'wheel-inventory.json',enc({'wheel':wheel.name,'bytes':wheel.stat().st_size,'sha256':sha(wheel.read_bytes()),'members':[{'path':n,'bytes':len(b),'sha256':sha(b)}for n,b in sorted({**payload,**metadata}.items())]}))
 run('venv',[PY311,'-B','-I','-m','venv','--without-pip',str(WORK/'venv')]);venv=WORK/'venv';python=venv/'bin/python';site=venv/'lib/python3.12/site-packages'
 def interpreter():
  if python.resolve()!=Path(PY311).resolve()or 'include-system-site-packages = false'not in (venv/'pyvenv.cfg').read_text():raise ValueError('venv-selection')
 interpreter();run('pip-install',[PRIMARY,'-B','-I','-m','pip','--python',str(python),'install','--no-deps','--no-index','--no-compile',str(wheel)],timeout=60);interpreter()
 for name,b in payload.items():
  p=site/name
  if p.is_symlink()or p.read_bytes()!=b:raise ValueError('installed-source-correspondence')
 console=venv/'bin/ashlar'
 console_bytes=console.read_bytes()
 if not console_bytes.startswith(('#!'+str(python)+'\n').encode())or b'from ashlar.cli import main\n'not in console_bytes:raise ValueError('console-entrypoint')
 write(WORK/'installed-console.txt',console_bytes)
 record_path=site/'ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD';record_bytes=record_path.read_bytes()
 if len(record_bytes)>128*1024:raise ValueError('installed-record-bound')
 write(WORK/'installed-RECORD.csv',record_bytes)
 def installed_custody():
  if console.is_symlink()or console.read_bytes()!=console_bytes:raise ValueError('console-closing-custody')
  for name,b in metadata.items():
   if name.endswith('/RECORD'):continue
   if (site/name).is_symlink()or (site/name).read_bytes()!=b:raise ValueError('installed-metadata-correspondence')
  if record_path.read_bytes()!=record_bytes:raise ValueError('installed-record-custody')
  entries=list(csv.reader(io.StringIO(record_bytes.decode('utf-8'))));seen_record=set()
  if len(entries)>512:raise ValueError('installed-record-members')
  for entry in entries:
   if len(entry)!=3 or entry[0]in seen_record:raise ValueError('installed-record-shape')
   name,digest,size=entry;seen_record.add(name);path=site/name
   if name!='../../../bin/ashlar':safe(name)
   if path.is_symlink()or not path.is_file()or not path.resolve().is_relative_to(venv):raise ValueError('installed-record-path')
   raw=path.read_bytes()
   if name=='ashlar_graph_toolkit-0.1.0.dev0.dist-info/RECORD':
    if digest or size:raise ValueError('installed-record-self')
   elif digest!='sha256='+base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).rstrip(b'=').decode()or size!=str(len(raw)):raise ValueError('installed-record-hash')
  if not set(payload).issubset(seen_record)or '../../../bin/ashlar'not in seen_record:raise ValueError('installed-record-closure')
 installed_custody()
 write(WORK/'installed-custody.json',enc({'revision':REV,'wheel_sha256':sha(wheel.read_bytes()),'payload_files':len(payload),'console_sha256':sha(console_bytes),'fresh_venv':True,'private_working_directory':str(WORK)}))
 source_custody();installed_custody()
 ENV['PYTHONPATH']='/private/tmp/ashlar-duckdb-sdk-20261010-c'
 originals=WORK/'originals';originals.mkdir()
 provider=Path('/private/tmp/ashlar-puppy-preparation-installed-provider-20261010-c.py');provider_sha=sha(provider.read_bytes())
 expected_releases=('ca4b40f78b1a27e3d6df50eb17816ec49e30f0f70d6ff7dabc195307c07642e7','a6a4cb268f6bb3f8d193b35289d5b593ad08e33d8fc561e29487919fd1502e3a')
 for release in expected_releases:
  original=REPO/'docs/helix/04-build/evidence/puppygraph-releases-20261009'/(release+'.graph.json')
  raw=original.read_bytes()
  if len(raw)>16*1024*1024 or sha(raw)!=release:raise ValueError('Original fixture release changed')
  selected=originals/(release+'.graph.json');write(selected,raw);selected.chmod(0o444)
  configuration=WORK/('invocation-'+release+'.json')
  write(configuration,enc({'profile':'ashlar-puppy-preparation-invocation/0.1','release_path':str(selected),'release_sha256':release,'output_directory':str(WORK/('carrier-'+release))}))
  stdout=run('prepare-'+release,[str(console),'prepare-puppy-release','--configuration',str(configuration),'--provider',str(provider),'--provider-sha256',provider_sha],timeout=30)
  receipt=json.loads(stdout)
  if receipt['release_sha256']!=release:raise ValueError('Actual installed console original release differs')
  census=json.loads((WORK/('carrier-'+release)/'installed-modules.json').read_bytes())
  if not census:raise ValueError('Actual project import census required')
  for observed in census.values():
   name=str(Path(observed['path']).relative_to(site))
   if name not in payload or sha(payload[name])!=observed['sha256']:raise ValueError('Actual console import differs from original wheel')
  source_custody();installed_custody()
 run('readback',[str(venv/'bin/python'),'-B','/private/tmp/ashlar-puppy-preparation-installed-readback-20261010-c.py'],timeout=30)
 report=json.loads((WORK/'readback.json').read_bytes())
 if report['duckdb_version']!='1.5.6' or len(report['releases'])!=2:raise ValueError('Actual selected DuckDB/original case inventory differs')
 for observed in report['installed_modules'].values():
  name=str(Path(observed['path']).relative_to(site))
  if name not in payload or sha(payload[name])!=observed['sha256']:raise ValueError('Readback import differs from original wheel')
 source_custody();installed_custody()
 write(WORK/'build-phases.json',enc(phases))
if __name__=='__main__': main()
