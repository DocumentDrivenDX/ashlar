"""Independently supplied operator admission for the two original local fixtures.

This explicit original-fixture grant supplies no live UC/source or Puppy native
operations authority. The caller/root authorizes use of these selected originals.
"""
from contextlib import contextmanager
import hashlib,json,sys
from pathlib import Path
from ashlar_host.lifecycle import finish
from ashlar_host.puppy_carrier_cli import PuppyPreparationSession
from ashlar_host.puppy_release_document import load_graph_release
GRANTS={'a6a4cb268f6bb3f8d193b35289d5b593ad08e33d8fc561e29487919fd1502e3a': {'publication': {'profile_version': 'ashlar-delta/0.3', 'publication_id': 'R2', 'recorded_at': '1791569872504251', 'schema_revisions_json': '{"local-fixture":"synthetic-1"}', 'source_progress_json': '{"local-fixture":{"profile":"explicit-local-refresh-fixture/0.1","publication":"R2"}}\n', 'table_versions_json': '{"local.runtime.edge_current":1,"local.runtime.object_current":1}\n', 'validation_report_json': '{"complete":true,"retention":{"profile":"private-local-no-cleanup-one-hour/0.1","targets":{"local.runtime.edge_current":{"committed_at":"1791555471646000","readable_until":"1791573472504249","uuid":"6f6c1658-0bf8-431b-9fc9-dbd00917af02","version":1},"local.runtime.object_current":{"committed_at":"1791555471333000","readable_until":"1791573472189241","uuid":"07712abf-cb63-43bd-babc-34d9ddb558ed","version":1}}},"scope":"Private local canonical fixture, full independent row oracle; no UMF/Truss/UC or remote policy claim","source_oracle_sha256":"fcc3f95d4872d09cef1209bdfc42f804dfdb2df648908f75fd365356849b321f"}\n'}, 'snapshots': {'local.runtime.edge_current': {'uuid': '6f6c1658-0bf8-431b-9fc9-dbd00917af02', 'version': 1}, 'local.runtime.object_current': {'uuid': '07712abf-cb63-43bd-babc-34d9ddb558ed', 'version': 1}}, 'roles': {'edges': 'local.runtime.edge_current', 'nodes': 'local.runtime.object_current'}}, 'ca4b40f78b1a27e3d6df50eb17816ec49e30f0f70d6ff7dabc195307c07642e7': {'publication': {'profile_version': 'ashlar-delta/0.3', 'publication_id': 'R1', 'recorded_at': '1791569865455769', 'schema_revisions_json': '{"local-fixture":"synthetic-1"}', 'source_progress_json': '{"local-fixture":{"profile":"explicit-local-refresh-fixture/0.1","publication":"R1"}}\n', 'table_versions_json': '{"local.runtime.edge_current":0,"local.runtime.object_current":0}\n', 'validation_report_json': '{"complete":true,"retention":{"profile":"private-local-no-cleanup-one-hour/0.1","targets":{"local.runtime.edge_current":{"committed_at":"1791555463767000","readable_until":"1791573465455767","uuid":"6f6c1658-0bf8-431b-9fc9-dbd00917af02","version":0},"local.runtime.object_current":{"committed_at":"1791555463065000","readable_until":"1791573465097685","uuid":"07712abf-cb63-43bd-babc-34d9ddb558ed","version":0}}},"scope":"Private local canonical fixture, full independent row oracle; no UMF/Truss/UC or remote policy claim","source_oracle_sha256":"ba1d22c9d1a109b413bf37b173427a01809ad790cfd0b9d3a20a09ba2addbb74"}\n'}, 'snapshots': {'local.runtime.edge_current': {'uuid': '6f6c1658-0bf8-431b-9fc9-dbd00917af02', 'version': 0}, 'local.runtime.object_current': {'uuid': '07712abf-cb63-43bd-babc-34d9ddb558ed', 'version': 0}}, 'roles': {'edges': 'local.runtime.edge_current', 'nodes': 'local.runtime.object_current'}}}
class Policy:
 def admit_original_release(self,release,context):
  if context is not GRANTS:raise PermissionError('Independent fixture context required')
  value=load_graph_release(release.payload,release.sha256)
  original=GRANTS.get(release.sha256)
  if original is None or any(value[k]!=original[k]for k in ('publication','snapshots','roles')):
   raise PermissionError('Independently granted original publication/vector/roles required')
@contextmanager
def open_puppy_preparation(invocation,release):
 yield PuppyPreparationSession(Policy(),GRANTS)
 census={}
 root=Path('/private/tmp/ashlar-puppy-preparation-installed-20261010-c/venv/lib/python3.12/site-packages')
 for name,module in list(sys.modules.items()):
  if name=='ashlar' or name.startswith('ashlar.')or name=='ashlar_host'or name.startswith('ashlar_host.'):
   p=getattr(module,'__file__',None)
   if p:
    p=Path(p).resolve()
    if not p.is_relative_to(root):raise ValueError('Project import outside fresh installation')
    census[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 stream=None;primary=None
 try:
  stream=(Path(invocation['output_directory'])/'installed-modules.json').open('x')
  json.dump(census,stream,indent=2);stream.write('\n')
 except BaseException as error:primary=error
 finish(primary,[lambda:stream.close()if stream is not None else None])
