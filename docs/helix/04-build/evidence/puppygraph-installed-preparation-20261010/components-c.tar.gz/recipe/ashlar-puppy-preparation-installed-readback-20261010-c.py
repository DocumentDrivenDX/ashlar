"""Independent full original VARCHAR cell/schema/endpoint readback; no Puppy."""
import sys
if sys.path[0]!='/private/tmp':raise ValueError('Explicit readback selection required')
del sys.path[0]
import hashlib,json
from pathlib import Path
import duckdb
from ashlar.graph_release import release_columns
from ashlar_host.puppy_release_document import load_graph_release
from ashlar_host.lifecycle import finish,owned_context
WORK=Path('/private/tmp/ashlar-puppy-preparation-installed-20261010-c')
rows=[]
for original in sorted((WORK/'originals').glob('*.graph.json')):
 raw=original.read_bytes();sha=hashlib.sha256(raw).hexdigest();value=load_graph_release(raw,sha);output=WORK/('carrier-'+sha)
 receipt=json.loads((output/'receipt.json').read_bytes());model=json.loads((output/'model.json').read_bytes());database=output/receipt['database_name'];before=hashlib.sha256(database.read_bytes()).hexdigest()
 if receipt['release_sha256']!=sha or before!=receipt['database_sha256'] or hashlib.sha256((output/'model.json').read_bytes()).hexdigest()!=receipt['model_sha256']:raise ValueError('Exact prepared carrier receipt mismatch')
 connection=duckdb.connect(str(database),read_only=True)
 primary=None
 try:
  for kind,role in (('node','nodes'),('edge','edges')):
   names=list(release_columns(kind));actual=connection.execute('SELECT '+','.join('"'+n+'"'for n in names)+' FROM carrier.'+role).fetchall()
   schema=connection.execute('DESCRIBE carrier.'+role).fetchall()
   if [r[0]for r in schema]!=names+['carrier_key','carrier_id']or any(r[1]!='VARCHAR'for r in schema):raise ValueError('Complete original VARCHAR schema required')
   expected=[[r[n]for n in names]for r in value[role]]
   encode=lambda v:json.dumps(list(v),ensure_ascii=False,separators=(',',':'))
   if sorted(map(encode,actual))!=sorted(map(encode,expected)):raise ValueError('Complete independent original String/null bag differs')
   ids=connection.execute('SELECT graph_id,carrier_key,id,carrier_id FROM carrier.'+role).fetchall()
   if any(a!=b or c!=d for a,b,c,d in ids):raise ValueError('Independent exact original graph identities differ')
  keys={r['graph_id']for r in value['nodes']}
  if any(r['src']not in keys or r['dst']not in keys for r in value['edges']):raise ValueError('Complete original incident endpoints differ')
 except BaseException as error:primary=error
 finish(primary,[connection.close])
 if hashlib.sha256(database.read_bytes()).hexdigest()!=before:raise ValueError('Readonly verification changed carrier bytes')
 if model['catalog'][0]['name']!='ashlar_'+sha[:24] or model['edge'][0]['fromKey']!=[{'name':'src','type':'STRING'}] or model['edge'][0]['toKey']!=[{'name':'dst','type':'STRING'}]:raise ValueError('Original catalog/incident mapping differs')
 rows.append({'release_sha256':sha,'nodes':len(value['nodes']),'edges':len(value['edges']),'database_sha256':before,'model_sha256':receipt['model_sha256'],'full_original_values':True,'full_string_null_schema':True,'independent_ids':True,'incident_endpoints':True,'readonly_byte_custody':True})
if len(rows)!=2:raise ValueError('Two exact original releases required')
census={}
for name,module in list(sys.modules.items()):
 if name=='ashlar' or name.startswith('ashlar.')or name=='ashlar_host'or name.startswith('ashlar_host.'):
  p=getattr(module,'__file__',None)
  if p:
   p=Path(p).resolve()
   if not p.is_relative_to(WORK/'venv/lib/python3.12/site-packages'):raise ValueError('Readback project import outside fresh installation')
   census[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
report={'duckdb_version':duckdb.__version__,'releases':rows,'installed_modules':census,'qualification':'Two original local fixture release carriers prepared by fresh installed CLI; no Puppy activation/query, current UC reads or production authority.'}
with owned_context((WORK/'readback.json').open('x'))as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({'releases':len(rows),'duckdb_version':duckdb.__version__}))
