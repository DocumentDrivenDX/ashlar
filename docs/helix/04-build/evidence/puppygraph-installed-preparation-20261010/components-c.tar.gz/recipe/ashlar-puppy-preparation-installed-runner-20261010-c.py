"""One finite installed carrier qualification; no Puppy/Spark/cloud operation."""
import hashlib,importlib.util,json,os,sys
from pathlib import Path
RECIPE=Path('/private/tmp/ashlar-puppy-preparation-installed-command-20261010-c.json')
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  for chunk in iter(lambda:f.read(262144),b''):h.update(chunk)
 return h.hexdigest()
def verify(plan):
 for item in plan['files']:
  p=Path(item['path'])
  if str(p.resolve(strict=True))!=item['resolved'] or p.stat().st_size!=item['bytes'] or digest(p)!=item['sha256']:raise ValueError('Original selected resource changed: '+str(p))
 for link in plan['symlinks']:
  p=Path(link['path'])
  if not p.is_symlink() or os.readlink(p)!=link['target'] or str(p.resolve(strict=True))!=link['resolved']:raise ValueError('Selected SDK alias changed')
 for root in plan['closedRoots']:
  actual={str(p.resolve())for p in Path(root).rglob('*')if p.is_file()and '__pycache__'not in p.parts and p.suffix!='.pyc'and p.name!='.DS_Store'}
  expected={f['resolved']for f in plan['files']if f['path'].startswith(root+'/')}
  if actual!=expected:raise ValueError('Selected SDK file inventory changed')
def select_failure(primary,closing):
 if primary is None or isinstance(primary,Exception)and not isinstance(closing,Exception):return closing
 return primary
def write_result(path,value,primary):
 stream=None
 try:
  stream=path.open('x');json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
 except BaseException as error:primary=select_failure(primary,error)
 if stream is not None:
  try:stream.close()
  except BaseException as error:primary=select_failure(primary,error)
 if primary is not None:raise primary
def main():
 if len(sys.argv)!=3 or digest(Path(__file__))!=sys.argv[1]or digest(RECIPE)!=sys.argv[2]:raise ValueError('Externally reviewed runner and recipe pins required')
 plan=json.loads(RECIPE.read_bytes());verify(plan)
 if Path(plan['work']).exists()or Path(plan['receipt']).exists():raise ValueError('Fresh private outputs required')
 spec=importlib.util.spec_from_file_location('capture',plan['capture']);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
 primary=None;result=None;closing=True
 try:
  result=capture.capture(plan['argv'],plan['cwd'],plan['environment'],plan['stdout'],plan['stderr'],plan['deadline'],16*1024*1024)
 except BaseException as error:primary=error
 try:verify(plan)
 except BaseException as error:closing=False;primary=select_failure(primary,error)
 write_result(Path(plan['receipt']),{'result':result,'openingClosingCustody':closing,'primaryType':None if primary is None else type(primary).__name__,'sourceRevision':plan['revision'],'qualification':plan['scope']},primary)
 if result['exitCode']:raise SystemExit(result['exitCode'])
if __name__=='__main__':main()
