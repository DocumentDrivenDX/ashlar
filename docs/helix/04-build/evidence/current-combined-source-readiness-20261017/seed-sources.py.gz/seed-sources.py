"""Private reviewed ordinary-writer seed, refuses absent successful producer admission."""
from pathlib import Path
import os,sys,json,hashlib
ROOT=Path(__file__).parent
sys.path.insert(0,'/private/tmp/ashlar-combined-current-20261017-e_7rpgcr/installed')
import psycopg
from psycopg import sql
from ashlar_host.ack import AckScope
from ashlar_host.source_sessions import OutboxSourceRegistration
from ashlar_host.existing_outbox_authority import OutboxAuthorityRegistration,ordinary,privileges
from ashlar_host.postgres import Session
INVENTORY_SHA='0cd9e98efcf46d8a987859868514cf2ff2319582773f7d4552b4bb60ad141fe1'
def require(x):
 if not x:raise ValueError('Exact fresh source seed refused')
def main():
 os.umask(0o077)
 inventory_raw=(ROOT/'postgres-inventory/inventory.json').read_bytes();require(hashlib.sha256(inventory_raw).hexdigest()==INVENTORY_SHA);inventory=json.loads(inventory_raw)
 require(inventory['container']=='ashlar-private-outbox-combined-current-20261017')
 require(hashlib.sha256((ROOT/'source-admission-r2/result.json').read_bytes()).hexdigest()=='04d05454e16f48c10077df7307aab12970ec525a0874811f205914b7a9d9adb8')
 require(hashlib.sha256((ROOT/'source-admission-r2/source-files.json').read_bytes()).hexdigest()=='71798a912b9be9968dea8639a402f4e3ef2f92dfa530b2c575aec90b8db6e81a')
 result=json.loads((ROOT/'source-admission-r2/result.json').read_bytes());require(result['success']is True and result['full_batches']==8)
 entries=json.loads((ROOT/'source-admission-r2/source-files.json').read_bytes());require(len(entries)==8)
 payloads={}
 for entry in entries:
  require(entry['feed']in ('A','B')and type(entry['ordinal'])is int and 1<=entry['ordinal']<=4)
  raw=(ROOT/'source-admission-r2'/entry['file']).read_bytes();require(len(raw)==entry['bytes']and hashlib.sha256(raw).hexdigest()==entry['sha256']);payloads[(entry['feed'],entry['ordinal'])]=(entry,raw)
 require(len(payloads)==8)
 endpoint=inventory['endpoint'];require(endpoint=={'database':'ashlar_current','host':'127.0.0.1','port':25436})
 def connect(role):return psycopg.connect(host=endpoint['host'],port=endpoint['port'],dbname=endpoint['database'],user=role,password='',passfile='/dev/null',sslmode='disable',gssencmode='disable',connect_timeout=3,options='-c statement_timeout=5000 -c lock_timeout=1000')
 # Verify genuine original scope + ordinary source/ACK privilege owners before writer calls.
 for source in inventory['sources']:
  scope=AckScope(**source['scope']);registration=OutboxAuthorityRegistration(OutboxSourceRegistration(scope,source['schema'],source['binding']['source_signature_sha256'],lambda context,s=source:connect(s['reader_role'])),source['reader_role'],source['ack_role'],endpoint['database'],lambda context,s=source:connect(s['ack_role']))
  for ack in (False,True):
   role=source['ack_role']if ack else source['reader_role']
   with connect(role)as c:
    c.execute('SET TRANSACTION ISOLATION LEVEL READ COMMITTED');session=Session(c);ordinary(session,role,endpoint['database']);privileges(session,registration,ack=ack)
    if ack:
     binding=c.execute(sql.SQL('SELECT {}.scope_binding(%s::uuid)').format(sql.Identifier(scope.service_schema)),(scope.scope_id,)).fetchone()[0];require(binding==source['binding'])
     row=c.execute(sql.SQL('SELECT * FROM {}.observe(%s::uuid,1)').format(sql.Identifier(scope.service_schema)),(scope.scope_id,)).fetchone();require(row==('0',None,None,None))
    else:require(c.execute(sql.SQL('SELECT position FROM {}.head WHERE id=1').format(sql.Identifier(source['schema']))).fetchone()==(0,))
    c.rollback()
 out=ROOT/'seed-attempt';out.mkdir(mode=0o700);observed=[]
 for source in inventory['sources']:
  feed=source['scope']['feed']
  with connect(source['writer_role'])as c:
   c.execute('SET TRANSACTION ISOLATION LEVEL READ COMMITTED');ordinary(Session(c),source['writer_role'],endpoint['database'])
   for ordinal in range(1,5):
    entry,raw=payloads[(feed,ordinal)];position=c.execute(sql.SQL('SELECT {}.append(%s,%s)').format(sql.Identifier(source['schema'])),(entry['batch_id'],raw.decode('utf8'))).fetchone()[0];require(position==ordinal)
    observed.append({'feed':feed,'position':position,'batch_id':entry['batch_id'],'source_sha256':entry['sha256']})
   c.commit()
  (out/(feed+'-committed.json')).write_text(json.dumps(observed,indent=2)+'\n')
 for source in inventory['sources']:
  with connect(source['reader_role']) as c:
   c.execute('SET TRANSACTION READ ONLY');ordinary(Session(c),source['reader_role'],endpoint['database'])
   rows=c.execute(sql.SQL('SELECT position,batch_id,payload,encode(digest,\'hex\') FROM {}.batch ORDER BY position LIMIT 5').format(sql.Identifier(source['schema']))).fetchall()
   require(len(rows)==4)
   for ordinal,row in enumerate(rows,1):
    entry,raw=payloads[(source['scope']['feed'],ordinal)]
    require(row==(ordinal,entry['batch_id'],raw.decode('utf8'),entry['sha256']))
   require(c.execute(sql.SQL('SELECT position FROM {}.head WHERE id=1').format(sql.Identifier(source['schema']))).fetchone()==(4,))
   c.rollback()
 (out/'result.json').write_text(json.dumps({'seeded_original_batches':8,'publication':False,'ack_submission':False,'observed':observed},indent=2)+'\n')
if __name__=='__main__':main()
