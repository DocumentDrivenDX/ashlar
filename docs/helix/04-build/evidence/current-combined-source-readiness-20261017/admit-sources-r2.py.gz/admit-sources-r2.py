from pathlib import Path
import os,sys,json,hashlib,time
ROOT=Path(__file__).parent
sys.path.insert(0,'/private/tmp/ashlar-combined-current-20261017-e_7rpgcr/installed')
from ashlar_host.config import EvolutionAdmissionConfig
from ashlar_host.evolution_admission import admit_commerce_evolution,EvolutionSourceSet
os.umask(0o077);out=ROOT/'source-admission-r2';out.mkdir(mode=0o700)
config=EvolutionAdmissionConfig(Path('/private/tmp/ashlar-combined-evolution-e44-20261014-mo9wk6_y/producer'),Path('/private/tmp/ashlar-bun-1.4.2-original-20261017/bun'),Path('/usr/bin/git'),60,1048576,4194304)
started=time.monotonic();admissions=[];files=[]
for label in ('A','B'):
 admitted=admit_commerce_evolution(config,source_system=label,epoch='original-private-epoch');admissions.append(admitted)
 for name,raw in ((label+'-receipt.json',admitted.receipt_bytes),(label+'-custody.json',admitted.custody_bytes),(label+'-registry.json',admitted.prepared.registry_json.encode())):
  (out/name).write_bytes(raw)
 for ordinal,batch in enumerate(admitted.prepared.batches,1):
  raw=batch.begin+b''.join(record.raw for record in batch.records)+batch.commit;name=label+'-'+str(ordinal)+'.jsonl';(out/name).write_bytes(raw);files.append({'feed':label,'epoch':batch.epoch,'ordinal':ordinal,'batch_id':batch.batch_id,'file':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
sources=EvolutionSourceSet(tuple(admissions));metadata=sources.metadata()
(out/'source-set.json').write_text(json.dumps(metadata,indent=2)+'\n');(out/'source-files.json').write_text(json.dumps(files,indent=2)+'\n');(out/'result.json').write_text(json.dumps({'success':True,'producer_calls':2,'full_batches':len(files),'elapsed_seconds':time.monotonic()-started,'postgres_calls':False,'native_calls':False},indent=2)+'\n')
print('Actual public A/B producer admission passed; eight original qualified source batches retained.')
