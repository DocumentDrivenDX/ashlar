"""Read-only stage1 correspondence snapshot; no native/publication admission grant."""
from pathlib import Path
from collections import Counter
import json,hashlib,sqlite3
from ashlar_host.supply_chain_oracle import supply_chain_result_oracle
ROOT=Path(__file__).resolve().parent;PUB=ROOT/'publication'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def encoded(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def pin(path):
    raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':sha(raw)}
config=json.loads((ROOT/'fresh-publication-configuration.json').read_bytes())
model=Path(config['model']).read_bytes();graph=Path(config['graph']).read_bytes()
registry=json.loads((PUB/'registry.json').read_bytes());request=json.loads((PUB/'request.json').read_bytes());report=json.loads((PUB/'report.json').read_bytes())
assert(report['source']['records'],report['source']['relationships'])==(20,23)
assert report['exact_replay_unchanged']is True and report['reader_reopened_from_committed_phases']is True
expected_ids=['split-excursion','excursion','replay','lineage','sensor'];assert[x['id']for x in report['cases']]==expected_ids
manifest=report['manifest'];mh=sha(encoded(manifest));targets={x['table']:x for x in registry['targets']};versions=json.loads(manifest['table_versions_json'])
assert set(versions)=={registry['tables'][r]for r in ('object_current','edge_current','tombstone','whole_source_history')}
assert manifest['publication_id']==registry['publication_id']
assert json.loads(manifest['schema_revisions_json'])==json.loads(request['schema_revisions_json'])
cases=[]
for case in report['cases']:
    evidence=case['evidence'];expected=supply_chain_result_oracle(case['id'],model,graph)
    assert evidence['oracle']==expected
    assert Counter(map(encoded,evidence['native_result']['rows']))==Counter(map(encoded,expected['rows']))
    assert evidence['opening_native_files']==evidence['closing_native_files']
    assert evidence['interval']['manifest_sha256']==mh and evidence['interval']['source']==report['source']
    assert all(g['native']['rows']==[['0']]for g in evidence['guards'])
    cases.append({'id':case['id'],'rows':len(expected['rows']),'complete_original_oracle_bag_equal':True,'result_sha256':sha(encoded(evidence['native_result'])),'original_oracle_sha256':sha(encoded(expected)),'guard_count':len(evidence['guards']),'all_guards_zero':True,'captured_native_files_opening_closing_equal':True})
connection=sqlite3.connect('file:'+str(PUB/'operations.sqlite')+'?mode=ro',uri=True)
try:
    connection.execute('PRAGMA query_only=ON');connection.execute('BEGIN')
    assert connection.execute('PRAGMA integrity_check').fetchall()==[('ok',)]
    tables=[x[0]for x in connection.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    snapshot={}
    for table in tables:
        columns=[x[1]for x in connection.execute('PRAGMA table_info('+table+')')]
        rows=connection.execute('SELECT * FROM '+table+' ORDER BY '+','.join('"'+x+'"'for x in columns)).fetchall()
        snapshot[table]={'columns':columns,'rows':rows}
    assert len(snapshot['local_operation']['rows'])==9
    state_index=snapshot['local_operation']['columns'].index('state')
    assert all(row[state_index]=='committed'for row in snapshot['local_operation']['rows'])
finally:
    try:connection.rollback()
    finally:connection.close()
raw=encoded(snapshot)+b'\n';snapshot_path=ROOT/'stage1-journal-readonly-snapshot.json'
with snapshot_path.open('xb')as stream:stream.write(raw)
paths=[PUB/n for n in ['registry.json','request.json','report.json','operations.sqlite']]+[ROOT/'fresh-publication-command-result.json',ROOT/'publication-control/outer-attempt.json',ROOT/'publication-control/resume-terminal.json',snapshot_path,Path(config['model']),Path(config['graph'])]
wal=PUB/'operations.sqlite-wal'
if wal.exists():paths.append(wal)
value={'profile':'ashlar-fresh-supply-chain-stage2-selection/0.1','source_snapshot_only':True,'qualification':'Actual stage1 complete nativeCLI report/source oracles, current registry/request and consistent mode=ro/query_only SQLite snapshot. No Spark/GraphFrames/DuckDB or source execution, no authority inferred from pins; stage2 must independently acquire actual original owner and native/source opening/closing. SHM coordinates SQLite readers and is not a byte-equality gate.','preparation_sha256':sha((ROOT/'preparation.json').read_bytes()),'command_result_sha256':sha((ROOT/'fresh-publication-command-result.json').read_bytes()),'source_counts':{'nodes':20,'edges':23},'cases':cases,'manifest_sha256':mh,'vector':{table:{'uuid':targets[table]['uuid'],'version':version}for table,version in versions.items()},'journal':{'consistent_snapshot_sha256':sha(raw),'tables':{t:len(v['rows'])for t,v in snapshot.items()},'integrity':'ok','all_operations_committed':True,'readonly_transaction_rollback_and_close_completed':True},'pins':[pin(p)for p in paths],'root_and_independent_review_required':True,'native_not_launched_by_snapshot':True}
with(ROOT/'stage2-selection.json').open('x')as stream:stream.write(json.dumps(value,sort_keys=True,indent=2)+'\n')
print(json.dumps({'selection':str(ROOT/'stage2-selection.json'),'sha256':sha((ROOT/'stage2-selection.json').read_bytes()),'five_bags':True,'journal_operations':9}))
