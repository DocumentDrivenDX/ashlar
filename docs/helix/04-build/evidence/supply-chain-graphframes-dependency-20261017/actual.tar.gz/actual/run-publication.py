"""One explicit fresh original20/23 finite publication; never an old-authority repair."""
from pathlib import Path
import hashlib,json,os,sys
ROOT=Path(__file__).resolve().parent
os.umask(0o077)
selection=json.loads((ROOT/'preparation.json').read_bytes())
for pin in selection['pins']:
    raw=Path(pin['path']).read_bytes()
    if len(raw)!=pin['bytes']or hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise PermissionError('Original preparation changed')
os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable,SPARK_LOCAL_IP='127.0.0.1')
from ashlar_host.supply_chain_native_cli import run_supply_chain_native_command
result=run_supply_chain_native_command(ROOT/'fresh-publication-configuration.json')
for pin in selection['pins']:
    raw=Path(pin['path']).read_bytes()
    if len(raw)!=pin['bytes']or hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise PermissionError('Closing preparation changed')
(ROOT/'fresh-publication-command-result.json').write_text(json.dumps(result,sort_keys=True)+'\n')
print(json.dumps({'completed':'fresh-supply-chain-publication-and-five-authored-queries'}))
