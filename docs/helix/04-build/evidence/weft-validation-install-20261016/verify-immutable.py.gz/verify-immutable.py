import sys,json,hashlib,importlib.metadata,os
from pathlib import Path
import ashlar,ashlar_host,jsonschema,referencing,rpds
from ashlar.weft_implicit_arithmetic_distribution import ImplicitArithmeticDistributionPaths,installed_implicit_arithmetic_schema_bundle
from ashlar_host.implicit_arithmetic_profile import PROFILE,ImplicitArithmeticAdmissionConfig
from ashlar_host.count_star_schema import make_offline_implicit_arithmetic_schema_validation
from ashlar_host.count_star_admission import admit_implicit_arithmetic_artifact
root=Path(__file__).parent;retained=Path('/private/tmp/ashlar-payments-held-guard-proposal-20261016-upgg9_5l')
assert '/Users/erik/Projects/ashlar'not in str(Path(ashlar.__file__).resolve())
assert '/Users/erik/Projects/ashlar'not in str(Path(ashlar_host.__file__).resolve())
assert 'PYTHONPATH'not in os.environ
paths=ImplicitArithmeticDistributionPaths(retained/'original-index.json',retained/'fresh-installation');schemas=dict(installed_implicit_arithmetic_schema_bundle(paths));request_raw=(retained/'request-042.json').read_bytes();artifact_raw=(retained/'response-042.json').read_bytes();request=json.loads(request_raw);artifact=json.loads(artifact_raw)
validate=make_offline_implicit_arithmetic_schema_validation({k:schemas[k]for k,_ in PROFILE.schemas})
admitted=admit_implicit_arithmetic_artifact(request,artifact,json.loads(artifact_raw),config=ImplicitArithmeticAdmissionConfig(1048576,validate))
import importlib.util
assert importlib.util.find_spec('ashlar_host.medical_commit_inspection')is None
metadata=importlib.metadata.metadata('ashlar-graph-toolkit');requirements=metadata.get_all('Requires-Dist');selected=[line for line in requirements if 'weft-validation'in line]
assert any('jsonschema==4.25.1'in line for line in selected)
assert all('typing-extensions==4.15.0'in line for line in requirements if line.startswith('typing-extensions')and('weft-validation'in line or'diagnostics'in line))
versions={name:importlib.metadata.version(name)for name in ('ashlar-graph-toolkit','jsonschema','referencing','rpds-py','attrs','jsonschema-specifications','typing-extensions')}
assert versions['typing-extensions']=='4.15.0'
result={'status':'passed','python_version':sys.version,'installed_ashlar':ashlar.__file__,'installed_host':ashlar_host.__file__,'versions':versions,'weft_validation_requirements':selected,'schemas':{k:hashlib.sha256(v).hexdigest()for k,v in schemas.items()},'request_sha256':hashlib.sha256(request_raw).hexdigest(),'artifact_sha256':hashlib.sha256(artifact_raw).hexdigest(),'obligations':len(admitted.obligations),'pyspark_imported':any(n=='pyspark'or n.startswith('pyspark.')for n in sys.modules),'scope':'ImmutablebaseAshlarwheelplusonlyownedpyprojectoverlayinstalledofflinewithweft-validationextraandactualcompatibledependencies; actualfixed042offlineadmission fromauthenticexistingreadonlycompilerinstallation; no SDK, Spark, nativequery/source/ACK or cloud qualification'}
(root/'verification-immutable.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
