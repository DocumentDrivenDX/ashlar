import sys,json,hashlib,time,os
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;n=r/'native';n.mkdir(mode=0o700)
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical']
sys.path[:0]=[str(r/'native-ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_record_group import run_create_truss_record_group_command
from ashlar_host.truss_note_cli import run_publish_truss_graph_command
from ashlar_host.truss_resume_setup import run_configure_truss_resume_command
from ashlar_host.truss_record_read import run_read_truss_record_command
from ashlar_host.truss_scalar_query_cli import run_query_truss_scalars_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_example import private_file
from ashlar_host.delta_custody import encoded
from ashlar.cli import main
t=time.monotonic();phases={};previous={k:os.environ.get(k) for k in ('JAVA_HOME','PYSPARK_PYTHON','PYSPARK_DRIVER_PYTHON')};primary=None;result=None
def restore():
 for k,v in previous.items():
  if v is None:os.environ.pop(k,None)
  else:os.environ[k]=v
def stage(name,body):
 started=time.monotonic();print('starting '+name,flush=True);answer=body();phases[name]=time.monotonic()-started;print('completed '+name,flush=True);return answer
try:
 os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
 bootstrap=json.loads((r/'setup-result.json').read_bytes());template=json.loads((r/'group-template.json').read_bytes())
 with owned_context(LocalPostgres(r/'data')) as runtime:
  params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);administrator=psycopg.conninfo.make_conninfo(**params);params['user']=bootstrap['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
  template['connection_uri']=ordinary;configuration=private_file(n/'group.json',template)
  def create():
   sys.argv=['ashlar','create-truss-record-group','--configuration',str(configuration),'--output',str(n/'group-result.json')];main();return json.loads((n/'group-result.json').read_bytes())
  group=stage('atomic-group',create)
  assert len(group['objects'])==11 and len(group['edges'])==10
  for obj,selection in zip(group['objects'],template['records']):
   expected={key:({'kind':v['kind'],'text':v['text']} if v['kind'] in ('integer','decimal') else v['text']) for key,v in selection['values'].items()}
   assert dict(obj['values'])==expected and obj['retained']==[] and obj['record_id']==selection['record_id']
  aliases={selection['alias']:obj['identity'] if 'identity'in obj else {'id':str(obj['id']),'type_id':str(obj['type_id']),'definition_pin':obj['definition_pin'],'owner':{'document_id':obj['document_id'],'module_id':obj['module_id']}} for selection,obj in zip(template['records'],group['objects'])}
  for edge,selection in zip(group['edges'],template['edges']):assert edge['source']==aliases[selection['source']['alias']] and edge['target']==aliases[selection['target']['alias']] and edge['retained']==[]
  publish=private_file(n/'publish.json',{'administrator_uri':administrator,'connection_uri':ordinary,'reader_role':bootstrap['roles']['reader'],'consumer_id':'commerce22-full-native','feed':'commerce22-full','destination_id':'ashlar-commerce22-local-receipt','jars':['/private/tmp/ashlar-supply-chain-finite-native-jars-f/delta-spark_2.13-4.0.0.jar','/private/tmp/ashlar-supply-chain-finite-native-jars-f/delta-storage-4.0.0.jar'],'maximum_pages':3,'maximum_page_bytes':2097152})
  published=stage('delta-publication',lambda:run_publish_truss_graph_command(publish,n/'publication'))
  assert len(published['publications'])==2
  reader=n/'reader.json';run_configure_truss_resume_command(publish,n/'publication/publication-intent-2.json',reader)
  def connection():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
  before=read_page(connection,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(n/'checkpoint-before.bin',before)
  product=next(o for o in group['objects'] if o['record_id']=='products')
  singleton=stage('product-singleton',lambda:run_read_truss_record_command(reader,n/'product-singleton.json',type_id=product['type_id'],entity_id=product['id']))
  fields={f['field_id']:f for f in singleton['record']['fields']};assert len(fields)==4 and fields['products.unit_price']['value']=={'decimal_token':'12.50'}
  query=stage('weft-decimal-query',lambda:run_query_truss_scalars_command(reader,n/'price-query.json',compiler='/private/tmp/ashlar-compatible-weft-compile-20261013-a/weft-runtime',sql='SELECT p.unit_price AS price FROM products p',revision='1',document_id='urn:umf:domain:commerce',physical_revisions=('1',),maximum_rows=1))
  assert query['rows']==[{'price':{'decimal_token':'12.50'}}] and singleton['publication_id']==query['publication_id']==published['publications'][-1]['manifest']['publication_id']
  after=read_page(connection,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(n/'checkpoint-after.bin',after);assert before==after
  result={'outcome':'passed','objects':11,'edges':10,'publications':2,'publication_id':query['publication_id'],'product_price':query['rows'],'phases':phases,'source_checkpoint_unchanged':True,'destination_receipt_mode':True,'scope':'Original commerce fixture through public atomic Truss group, actual committed replay, source-retained receipt ACK, local Delta publication and unchanged original Weft decimal projection. No Unity Catalog, production authority, lifecycle/evolution or full query-gallery qualification.'}
except BaseException as error:primary=error
finish(primary,[restore])
result['duration_seconds']=time.monotonic()-t;private_file(n/'result.json',result);print(json.dumps(result),flush=True)
