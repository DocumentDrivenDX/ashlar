import sys,json,time,os,hashlib
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;n=r/'native';o=r/'continued';o.mkdir(mode=0o700)
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical']
sys.path[:0]=[str(r/'continued-ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_continue_cli import run_continue_truss_graph_command
from ashlar_host.truss_resume_setup import run_configure_truss_resume_command
from ashlar_host.truss_continuation_setup import run_configure_truss_continuation_command
from ashlar_host.truss_record_read import run_read_truss_record_command
from ashlar_host.truss_scalar_query_cli import run_query_truss_scalars_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_example import private_file
from ashlar_host.truss_page_archive import decode_truss_page
t=time.monotonic();phases={};previous={k:os.environ.get(k)for k in ('JAVA_HOME','PYSPARK_PYTHON','PYSPARK_DRIVER_PYTHON')};primary=None;answer=None
def restore():
 for k,v in previous.items():
  if v is None:os.environ.pop(k,None)
  else:os.environ[k]=v
def stage(name,body):
 started=time.monotonic();print('starting '+name,flush=True);result=body();phases[name]=time.monotonic()-started;private_file(o/(name+'-phase.json'),{'completed':True,'seconds':phases[name]});print('completed '+name,flush=True);return result
try:
 os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
 with owned_context(LocalPostgres(r/'data')) as runtime:
  params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);administrator=psycopg.conninfo.make_conninfo(**params);params['user']=json.loads((r/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
  def connection():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
  prior=read_page(connection,'commerce22-full-native',maximum_bytes=2097152)
  assert prior.content==(n/'pending-raw.json').read_bytes() and prior.prior.content==(n/'checkpoint-pending.bin').read_bytes()
  publish=json.loads((n/'publish.json').read_bytes());publish.update(connection_uri=ordinary,administrator_uri=administrator);selection=private_file(o/'publisher-selection.json',publish)
  old_reader=o/'old-reader.json';run_configure_truss_resume_command(selection,n/'publication/publication-intent-1.json',old_reader)
  continued=stage('delta-continuation',lambda:run_continue_truss_graph_command(old_reader,o/'continuation.json',maximum_pages=1,maximum_page_bytes=2097152))
  assert continued['predecessor']=='truss-graph-1' and len(continued['publications'])==1
  item=continued['publications'][0];page=decode_truss_page(Path(item['source_page']['path']).read_bytes(),item['source_page']['sha256'],'commerce22-full')
  assert page.content==prior.content and page.prior.content==prior.prior.content and page.next.content==prior.next.content
  reader=o/'reader.json';run_configure_truss_continuation_command(old_reader,o/'continuation.json',reader)
  before=read_page(connection,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(o/'checkpoint-before.bin',before);assert before==prior.next.content
  group=json.loads((n/'group-result.json').read_bytes());product=next(obj for obj in group['objects']if obj['record_id']=='products')
  singleton=stage('product-singleton',lambda:run_read_truss_record_command(reader,o/'product-singleton.json',type_id=product['type_id'],entity_id=product['id']))
  fields={field['field_id']:field for field in singleton['record']['fields']};assert len(fields)==4 and fields['products.unit_price']['value']=={'decimal_token':'12.50'}
  query=stage('weft-decimal-query',lambda:run_query_truss_scalars_command(reader,o/'price-query.json',compiler='/private/tmp/ashlar-compatible-weft-compile-20261013-a/weft-runtime',sql='SELECT p.unit_price AS price FROM products p',revision='1',document_id='urn:umf:domain:commerce',physical_revisions=('1',),maximum_rows=1))
  assert query['rows']==[{'price':{'decimal_token':'12.50'}}] and singleton['publication_id']==query['publication_id']==item['manifest']['publication_id']
  after=read_page(connection,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(o/'checkpoint-after.bin',after);assert before==after
  answer={'outcome':'passed','objects':11,'edges':10,'continuations':1,'publication_id':query['publication_id'],'price':query['rows'],'phases':phases,'source_checkpoint_unchanged_by_reads':True,'pending_page_exactly_preserved':True,'source_advanced_to_exact_pending_next':True,'destination_receipt_mode':True,'scope':'Original full commerce fixture atomic Truss group/replay, continued local Delta publication from retained catalog predecessor and source-retained receipt ACK, exact singleton and original Weft decimal projection. No Unity Catalog, production ACK, lifecycle/evolution or full query-gallery claim.'}
except BaseException as error:primary=error
finish(primary,[restore]);answer['duration_seconds']=time.monotonic()-t;private_file(o/'result.json',answer);print(json.dumps(answer),flush=True)
