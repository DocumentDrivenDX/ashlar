import json,hashlib
from pathlib import Path
r=Path(__file__).parent
model=Path('/Users/erik/Projects/ashlar/examples/domain-packs/commerce/upstream/ontology.json').read_bytes()
raw=Path('/Users/erik/Projects/ashlar/examples/domain-packs/commerce/upstream/graph/fixture.json').read_bytes()
assert hashlib.sha256(model).hexdigest()=='51d87c554df36846e41378cfaafc81277fcab61f6c891a6c64f34dba8fd9ac2a'
assert hashlib.sha256(raw).hexdigest()=='8052dbcf2cf48a5e344c492d661872bc0a3f80a5c7be033ab5008dea9c86119e'
m=json.loads(model);g=json.loads(raw);fields={(mod['id'],e['id']):e for mod in m['modules'] for e in mod['elements'] if e['kind']=='field'}
aliases={node['key']:'node-'+str(i) for i,node in enumerate(g['objects'])}
records=[]
for node in g['objects']:
 owner=node['type'];values={}
 for field_id,text in node['values'].items():
  field=fields[owner['module'],field_id];kind=field['scalarType'];assert kind in ('string','integer','decimal') and type(text)is str
  assert field['name']not in values;values[field['name']]={'kind':kind,'text':text}
 records.append({'alias':aliases[node['key']],'module_id':owner['module'],'record_id':owner['element'],'values':values})
edges=[{'alias':'edge-'+str(i),'module_id':edge['relationship']['module'],'relationship_id':edge['relationship']['id'],'source':{'state':'alias','alias':aliases[edge['source']]},'target':{'state':'alias','alias':aliases[edge['target']]},'values':{},'order_key':{'state':'null'}} for i,edge in enumerate(g['edges'])]
assert len(records)==11 and len(edges)==10
body={'profile':'ashlar-truss-record-group/0.1','connection_uri':'PRIVATE_RUNTIME_SELECTION_PENDING','bun':'/opt/homebrew/Cellar/bun/1.4.2/bin/bun','document_path':'/Users/erik/Projects/ashlar/examples/domain-packs/commerce/upstream/ontology.json','document_revision':'1','document_id':m['id'],'source_version':m['umf'],'origin_path':str(r/'origin.json'),'request_key':'commerce22-original-full-graph','records':records,'edges':edges}
(r/'group-template.json').write_text(json.dumps(body,indent=2));(r/'fixture-selection.json').write_text(json.dumps({'model_sha256':hashlib.sha256(model).hexdigest(),'graph_fixture_sha256':hashlib.sha256(raw).hexdigest(),'records':11,'edges':10,'original_key_to_alias':aliases},indent=2))
print(len(json.dumps(body).encode()))
