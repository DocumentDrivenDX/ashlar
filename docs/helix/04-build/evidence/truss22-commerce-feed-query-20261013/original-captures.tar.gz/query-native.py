import sys,json,time,os,base64,hashlib
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;n=r/'native';c=r/'continued';o=r/'queried';o.mkdir(mode=0o700)
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical']
sys.path[:0]=[str(r/'continued-ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_resume_setup import run_configure_truss_resume_command
from ashlar_host.truss_scalar_query_cli import run_query_truss_scalars_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_example import private_file
from decimal import Decimal
t=time.monotonic();primary=None;answer=None;previous={k:os.environ.get(k)for k in ('JAVA_HOME','PYSPARK_PYTHON','PYSPARK_DRIVER_PYTHON')}
def restore():
 for k,v in previous.items():
  if v is None:os.environ.pop(k,None)
  else:os.environ[k]=v
try:
 # The prior assertion expected the input token; this checks the ORIGINAL feed token.
 pending=json.loads((n/'pending-raw.json').read_bytes());change=next(x for x in pending['changes']if x['entity_id']==3)
 event_raw=base64.b64decode(change['new_value']['bytesBase64']);assert hashlib.sha256(event_raw).hexdigest()==change['new_value']['bytesSha256']
 prop=next(p for p in json.loads(event_raw)['after']['properties']if p['propertyId']=='25');assert prop['value']=={'kind':'decimal','text':'12.5'}
 singleton=json.loads((c/'product-singleton.json').read_bytes());fields={f['field_id']:f for f in singleton['record']['fields']};assert len(fields)==4 and fields['products.unit_price']['value']=={'decimal_token':prop['value']['text']}
 assert Decimal(prop['value']['text']).as_integer_ratio()==Decimal('12.50').as_integer_ratio()
 os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
 with owned_context(LocalPostgres(r/'data')) as runtime:
  params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);administrator=psycopg.conninfo.make_conninfo(**params);params['user']=json.loads((r/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
  def connection():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
  before=read_page(connection,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(o/'checkpoint-before.bin',before);assert before==(c/'checkpoint-before.bin').read_bytes()
  item=json.loads((c/'continuation.json').read_bytes())['publications'][0];selection=json.loads((n/'publish.json').read_bytes());selection.update(connection_uri=ordinary,administrator_uri=administrator)
  publisher=private_file(o/'publisher-selection.json',selection);reader=o/'reader.json';run_configure_truss_resume_command(publisher,item['publication_intent']['path'],reader)
  started=time.monotonic();query=run_query_truss_scalars_command(reader,o/'price-query.json',compiler='/private/tmp/ashlar-compatible-weft-compile-20261013-a/weft-runtime',sql='SELECT p.unit_price AS price FROM products p',revision='1',document_id='urn:umf:domain:commerce',physical_revisions=('1',),maximum_rows=1);duration=time.monotonic()-started
  assert query['rows']==[{'price':{'decimal_token':'12.50'}}] and query['publication_id']==item['manifest']['publication_id']==singleton['publication_id']
  after=read_page(connection,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(o/'checkpoint-after.bin',after);assert before==after
  answer={'outcome':'passed','query_seconds':duration,'publication_id':query['publication_id'],'rows':query['rows'],'singleton_original_feed_token':'12.5','group_original_input_token':'12.50','compiler_result_token':'12.50','tokens_mathematically_equal':True,'source_checkpoint_unchanged':True,'singleton_feed_bytes_correspond':True,'scope':'One required decimal18,2 projection from original UMF0.8 on the completed full commerce Truss-fed Delta publication; all original compiler guards and source/pin closing admitted. No lifecycle/evolution/full-gallery/Unity Catalog claim.'}
except BaseException as error:primary=error
finish(primary,[restore]);answer['duration_seconds']=time.monotonic()-t;private_file(o/'result.json',answer);print(json.dumps(answer),flush=True)
