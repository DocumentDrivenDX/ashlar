import json,hashlib,collections
from pathlib import Path
from ashlar_host.commerce_original_scenarios import commerce_original_cases,original_commerce_scenario_oracle
p=Path('/private/tmp/ashlar-original-commerce-query-20261011-g');freeze=Path('/private/tmp/ashlar-original-commerce-workflow-prep-g/actual-freeze-g.json');f=json.loads(freeze.read_bytes())
for a in f['files']:
 b=Path(a['path']).read_bytes();assert len(b)==a['size'] and hashlib.sha256(b).hexdigest()==a['sha256']
r=json.loads((p/'query/report.json').read_bytes());pub=Path('/private/tmp/ashlar-original-commerce-native-20261011-e/publication');m=(pub/'original-ontology.json').read_bytes();g=(pub/'original-graph.json').read_bytes();cases=commerce_original_cases(Path('/Users/erik/Projects/ashlar/examples/domain-packs/commerce/upstream/pack.json').read_bytes());print('cases',type(cases),str(cases)[:200])
for c in r['cases']:
 q=json.loads(c['originalRequestText']);o=original_commerce_scenario_oracle(m,g,q);assert o==c['provisional']['oracle'];assert c['originalResponseText']==c['originalRecompiledText'];assert c['provisional']['opening_native_files']==c['provisional']['closing_native_files'];print(c['case'],q['sql'],o['rows'])
def bag(rows):return collections.Counter(json.dumps(x,ensure_ascii=False,separators=(',',':')) for x in rows)
assert [(c['case'],json.loads(c['originalRequestText'])['sql']) for c in r['cases']]==list(cases)
case_results=[]
for c in r['cases']:
 pr=c['provisional'];q=json.loads(c['originalRequestText']);o=original_commerce_scenario_oracle(m,g,q);assert bag(o['rows'])==bag(pr['native_result']['rows']);response=json.loads(c['originalResponseText']);assert response['backend']['backendVersion']=='0.4.2-implicit-arithmetic-labels-candidate'
 for guard in pr['guards']:
  if guard['native']['schema']==[['violations','STRING']]:assert guard['native']['rows']==[['0']]
  else:
   for row in guard['native']['rows']:
    expected=next(a for a in json.loads((pub/'report.json').read_bytes())['complete_original_oracle']['object_current'] if (a['source_system'],a['type_id'],a['id'])==tuple(row[:3]));assert row[3]==expected['schema_revision'] and json.loads(row[4])==json.loads(expected['props_json']);assert row[5] in [str(v) for v in json.loads(row[4]).values()]
 for side in ['opening_ack','closing_ack']:
  observation=pr['interval'][side]['observation'];assert observation['position']=='1';assert json.loads(bytes.fromhex(observation['manifest_hex']))==r['original_manifest'];assert observation['receipt_hex']
 for row,decoded in zip(pr['native_result']['rows'],pr['decoded']):
  for original,cell in zip(row,decoded):assert cell['original']==original;assert type(cell['value'])in(int,str)
 case_results.append({'case':c['case'],'rows':o['rows'],'guards':len(pr['guards']),'requestSha256':hashlib.sha256(c['originalRequestText'].encode()).hexdigest(),'responseSha256':hashlib.sha256(c['originalResponseText'].encode()).hexdigest()})
assert r['opening_native_files']==r['closing_native_files']
for path,digest in r['closing_native_files'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
assert r['cleanup']=={'readerClosed':True,'sparkStopped':True}
outer=json.loads((p/'outer-receipt.json').read_bytes());assert outer['closing']is True and outer['primary']is None and [a['capture']['exitCode']for a in outer['phases']]==[0]*4
installed=json.loads((p/'installed-host.json').read_bytes());assert installed['sourceRevision']=='6eef1fdf458321e34e0b8fb4481b537f3cfd31d1'
for a in installed['files']:
 raw=Path(a['path']).read_bytes();assert len(raw)==a['size'] and hashlib.sha256(raw).hexdigest()==a['sha256']
result={'approved':True,'scope':'Finite private originalcommerce public installed042 fourquery pass against independently qualified E publication','freezeSha256':hashlib.sha256(freeze.read_bytes()).hexdigest(),'caseResults':case_results,'checks':['all originalactualfreeze pins exact','all4 originalpack SQL unchanged and rawfreshcompiler response equals recompiled bytes','all4complete native occurrencebags independentlymatch originalgraph oracle','numericviolationcounts0 and fullunfilteredguardcarrier/tokenrows match originalobjectoracle; decoded exactvalues retained','percaseopeningclosingACKposition1/exactmanifest/receipt present','wholeopeningclosingnativefilemap equal and currentselectednativebytes match','all4runner phases0/outerclosingtrue/nullprimary/readerclosed/sparkstopped','allinstalledsource6eef payload/RECORD/console inventory hashes current'], 'limits':['No production/Truss/canonicalauthority claim','No republish/sourceappend/reset performed inqueryonlyG','No SDK/JVM/PG rerun byreviewer','Inheritedruntime explicitselection nothermeticclosure; nativewarningstderr retained']}
out=Path('/private/tmp/ashlar-original-commerce-workflow-independent-actual-review-g.json');out.write_text(json.dumps(result,indent=2)+'\n');print(out,hashlib.sha256(out.read_bytes()).hexdigest())
