from pathlib import Path
import hashlib,json,os,sqlite3,sys,subprocess,time
from ashlar_host.lifecycle import finish
R=Path(__file__).resolve().parent
os.umask(0o077)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def retain(name,value):
 raw=canonical(value)+b'\n';assert len(raw)<=8388608
 fd=os.open(R/name,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
 with os.fdopen(fd,'wb')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
def fingerprint(root):
 files=[];databases=[];total=0
 for path in sorted(root.rglob('*')):
  if path.is_symlink():raise ValueError('Original native symlink refused')
  if not path.is_file():continue
  relative=str(path.relative_to(root))
  if path.suffix in ('.sqlite','.db'):
   before=path.stat();connection=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True)
   try:
    tables=[]
    for name,sql in connection.execute("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name"):
     escaped=name.replace('"','""');rows=connection.execute('SELECT * FROM "'+escaped+'"').fetchall()
     def atom(value):return {'blob':value.hex()}if type(value)is bytes else value
     ordered=sorted(([atom(v)for v in row]for row in rows),key=lambda v:canonical(v));tables.append([name,sql,ordered])
    raw=canonical(tables);assert len(raw)<=134217728;databases.append({'path':relative,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
   finally:connection.close()
   after=path.stat();assert (before.st_dev,before.st_ino)==(after.st_dev,after.st_ino)
   continue
  if path.name.endswith(('-shm','-wal')):continue
  raw=path.read_bytes();total+=len(raw);assert len(files)<4096 and total<=134217728
  files.append({'path':relative,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 return {'files':files,'databases':databases,'scope':'Original owned registry/Delta/data files and canonical SQLite contents; excludes transient SQLite WAL/SHM bytes.'}
raw=(R/'configuration.json').read_bytes();config=json.loads(raw)
source_config=Path(config['source_configuration']);source_raw=source_config.read_bytes();refs=json.loads(source_raw)
source_paths=[source_config]+[(source_config.parent/refs[k]['path']).resolve() for k in ('source','schema','bindings')]
source_before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
before=fingerprint(Path(config['installation']));retain('native-before.json',before);retain('source-before.json',source_before)
primary=None;started=time.monotonic();code=None
try:
 argv=[sys.executable,'-I','-B','-m','ashlar','run-configured-local','--configuration',str(R/'configuration.json')]
 with (R/'query.stdout').open('xb')as out,(R/'query.stderr').open('xb')as err:
  code=subprocess.run(argv,cwd=R,stdout=out,stderr=err,check=False).returncode
 retain('query-terminal.json',{'argv':argv,'exit_code':code,'elapsed_seconds':time.monotonic()-started})
 assert code==0
 answer=json.loads((R/'query.stdout').read_bytes());assert answer==json.loads((R/'query-output/report.json').read_bytes())==json.loads((R/'query-output/runtime-report.json').read_bytes())
 assert answer['ordinal']==1 and answer['completed_batches']==2 and answer['protected_ack']is False
 q=answer['query'];assert q['sql']==config['query']['sql'] and q['rows']==[['18446744073709551615','12.50','true']]
 assert q['protocol']['response']==q['protocol']['recompiled']
 guards=q['evidence']['guards'];assert guards and all(g['native']['rows']==[['0']]for g in guards)
 retain('query-result.json',answer)
except BaseException as e:primary=e
def closing():
 after=fingerprint(Path(config['installation']));retain('native-after.json',after);assert before==after
 source_after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths};retain('source-after.json',source_after)
 assert source_before==source_after and (R/'configuration.json').read_bytes()==raw
finish(primary,[closing])
retain('summary.json',{'status':'passed','rows':[['18446744073709551615','12.50','true']],'zero_guard_count':len(guards),'original_native_and_source_unchanged':True,'scope':'One installed public CLI read of retained named typed ordinal1. No ingest, publication or protected ACK mutation.'})
print(json.dumps({'status':'passed','zero_guard_count':len(guards)}))
