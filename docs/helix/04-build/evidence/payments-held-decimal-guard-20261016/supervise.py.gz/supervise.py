"""One explicit local diagnostic process, <=180s including timeout shutdown."""
import hashlib,json,os,signal,subprocess,time
from pathlib import Path
root=Path(__file__).parent;repo=Path('/Users/erik/Projects/ashlar');expected='bf29f1918e3258b1ce0628ad9459003797be00f6'
assert subprocess.check_output(['/usr/bin/git','-C',str(repo),'rev-parse','HEAD']).decode().strip()==expected
configuration=json.loads((root/'configuration.json').read_bytes());native=Path(configuration['publication'])
def pin(path):
 h=hashlib.sha256()
 with path.open('rb')as stream:
  for block in iter(lambda:stream.read(65536),b''):h.update(block)
 return {'bytes':path.stat().st_size,'sha256':h.hexdigest()}
def inputs():
 files=[path for path in native.rglob('*')if path.is_file()]
 if len(files)>256 or sum(path.stat().st_size for path in files)>64*1024*1024:raise ValueError('Finite original closure exceeds diagnostic bound')
 return {str(path.relative_to(native)):pin(path)for path in sorted(files)}
jar_pins={'delta-spark_2.13-4.0.0.jar':'538511702aae0ef6973a6a70af3d4543c9009f8edbed786a00737e2d3cd7f04e','delta-storage-4.0.0.jar':'9bdb9fb450f1e119eba53feb427f331b0d09072d26485b8273883ad72c9a2e1d'}
jars=Path(configuration['jars']);assert {path.name for path in jars.iterdir()}==set(jar_pins)
for name,digest in jar_pins.items():assert pin(jars/name)['sha256']==digest
before=inputs();(root/'original-closure-before-7.json').write_text(json.dumps(before,indent=2))
python=str(root/'diagnostic-environment-311/bin/python3')
environment={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','JAVA_HOME':'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home','PYSPARK_PYTHON':python,'PYSPARK_DRIVER_PYTHON':python,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(root)}
argv=[python,'-I','-B',str(root/'proposal.py'),'--index',str(root/'original-index.json'),'--execute']
receipt=root/'attempt-7.json'
with receipt.open('x')as stream:json.dump({'state':'starting','maximum_total_seconds':180,'work_seconds':168,'argv':argv,'code_commit':expected},stream)
started=time.monotonic()
with (root/'stdout-7.log').open('xb')as out,(root/'stderr-7.log').open('xb')as err:
 process=subprocess.Popen(argv,cwd=root,env=environment,stdout=out,stderr=err,start_new_session=True)
 try:code=process.wait(timeout=168);state='terminal'
 except subprocess.TimeoutExpired:
  state='deadline';os.killpg(process.pid,signal.SIGTERM)
  try:code=process.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=5)
after=inputs();(root/'original-closure-after-7.json').write_text(json.dumps(after,indent=2))
result={'state':state,'exit_code':code,'elapsed_seconds':time.monotonic()-started,'code_commit':expected,'original_native_closure_unchanged':before==after,'added_files':sorted(set(after)-set(before)),'missing_files':sorted(set(before)-set(after)),'changed_files':sorted(path for path in before.keys()&after.keys()if before[path]!=after[path]),'argv':argv,'scope':'One local1/512MiB guarded finite publication diagnostic; no retries, cloud or protectedACK operations'}
receipt.write_text(json.dumps(result,indent=2));print(json.dumps(result))
