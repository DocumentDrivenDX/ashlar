"""Private proposed owning diagnostic; --execute explicitly starts local Spark."""
import argparse,hashlib,json,os,sys
from pathlib import Path
root=Path(__file__).parent
sys.path.insert(0,'/Users/erik/Projects/ashlar/src')

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--index',type=Path,required=True)
 parser.add_argument('--execute',action='store_true')
 args=parser.parse_args()
 from ashlar.weft_implicit_arithmetic_distribution import INDEX_SHA256,ImplicitArithmeticDistributionPaths,compile_implicit_arithmetic_distribution,installed_implicit_arithmetic_schema_bundle
 from ashlar_host.evolution_cli import InvocationFile
 from ashlar_host.lifecycle import owned_context,finish
 from ashlar_host.pack_native_cli import parse_finite_pack_invocation,_open,_aliases
 from ashlar_host.pack_count_star_reader import FinitePackProvider
 from ashlar_host.count_star_execution import HeldFrameAdapter,_schema
 from ashlar_host.path_capture import PathCaptureConfig
 from ashlar_host.implicit_arithmetic_profile import PROFILE,ImplicitArithmeticAdmissionConfig
 from ashlar_host.count_star_schema import make_offline_implicit_arithmetic_schema_validation
 from ashlar_host.count_star_admission import admit_implicit_arithmetic_artifact
 # Existing indexed realization remains mandatory; missing index is not recreated.
 index=InvocationFile.read(args.index,262144)
 if hashlib.sha256(index.raw).hexdigest()!=INDEX_SHA256:raise PermissionError('Exact independently pinned042index required')
 configuration=InvocationFile.read(root/'configuration.json',65536)
 value=json.loads(configuration.raw);value['query']['index']=str(args.index)
 invocation=parse_finite_pack_invocation(json.dumps(value).encode(),'query',query_profile='payments-scenario')
 request_pin=InvocationFile.read(root/'request-042.json',262144);artifact_pin=InvocationFile.read(root/'response-042.json',262144)
 request=json.loads(request_pin.raw);artifact=json.loads(artifact_pin.raw)
 paths=ImplicitArithmeticDistributionPaths(args.index,invocation.query['installation'])
 # Opening schema bundle authenticates actual fixed installation before native use.
 schemas=dict(installed_implicit_arithmetic_schema_bundle(paths))
 from ashlar_host.supply_chain_native import finite_runtime
 selected_jars=finite_runtime(invocation.native)
 responses=[compile_implicit_arithmetic_distribution(paths,request_pin.raw)for _ in range(2)]
 if responses[0]!=responses[1]or json.loads(responses[0])!=artifact:raise PermissionError('Exact original042compiler artifact differs')
 admitted=admit_implicit_arithmetic_artifact(request,artifact,json.loads(responses[1]),config=ImplicitArithmeticAdmissionConfig(1048576,make_offline_implicit_arithmetic_schema_validation({k:schemas[k]for k,_ in PROFILE.schemas})))
 for i,response in enumerate(responses):(root/('fresh-response-4-'+str(i)+'.json')).write_bytes(response)
 if not args.execute:
  from ashlar_host.finite_dataset import HeldFiniteDataset
  producer=HeldFiniteDataset(invocation.native.producer,invocation.native.model,invocation.native.graph,root/'preflight-public-dataset-4.json')
  producer.renew();public=json.loads(producer.receipt(*producer.originals))
  facts=invocation.native.producer.definition.inputs(*producer.originals)
  if public['umfRevision']!='07357eadbda9cf8299b9d72d004cbb77f8091aee'or public['sourceSha256']!=facts['model_sha256']or public['graphSha256']!=facts['graph_sha256']or public['receipt']['datasetValidation']['valid']is not True or public['receipt']['datasetValidation']['complete']is not True or len(public['receipt']['records'])!=13 or len(public['receipt']['relationships'])!=14 or len(public['controls'])!=3:raise PermissionError('Actual publicfinite revalidation differs')
  result={'status':'compile-validator-preflight-passed','actual_finite_runtime_passed':True,'actual_public_producer_passed':True,'public_receipt_sha256':hashlib.sha256(producer.raw).hexdigest(),'selected_jars':[str(path)for path in selected_jars],'python_version':sys.version,'scope':'Twoauthentic042compilerresponsesidentical; actualofflineartifact/schemaadmissionpassed; actualpublicproducerpassed; no Spark/native/query operation started','required_index_sha256':INDEX_SHA256}
  (root/'preflight-4.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));return
 report=None;primary=None
 try:
  with owned_context(_open(invocation.native,root/'native-observations-7'/'public-dataset.json'))as driver:
   provider=FinitePackProvider(driver,_aliases(driver),json.loads(request['target']['bindingJson']))
   binding=json.loads(request['target']['bindingJson']);slots={'p'+str(p['position']):p['value']for p in artifact['parameters']}
   checks=next(o['parameters']['checks']for o in artifact['obligations']if o['id']=='ashlar.candidate.scalarIntegrity')
   if len(checks)!=5 or [c['field']['element']for c in checks]!=['payment_instructions.id','status_events.payment_id','status_events.status','settlements.amount','settlements.payment_id']:raise PermissionError('Exact original5scalarchecks required')
   captures=[]
   with owned_context(provider.interval(driver.context)):
    provider.runtime(driver.context);resolved=provider.resolve(driver.context);provider.admit_binding(binding,resolved,driver.context)
    schemas=[]
    for table in binding['publication']['tables']:
     required={'source_system':'STRING','id':'BIGINT','schema_revision':'STRING','props_json':'STRING'}
     if table['name'][-1]=='object_current':required['type_id']='BIGINT'
     elif table['name'][-1]in('tombstone','whole_source_history'):required={}
     else:required.update(rel_type_id='BIGINT',source_id='BIGINT',target_id='BIGINT')
     schemas.append(_schema(provider,driver.context,resolved,table,required))
    adapter=HeldFrameAdapter(provider,driver.context,PathCaptureConfig(10,10000,100000))
    for position,check in enumerate(checks):
     provider.runtime(driver.context)
     captured=adapter.capture(check['sql'],slots)
     captures.append({'index':position,'field':check['field'],'original_sql':check['sql'],'sql_sha256':hashlib.sha256(check['sql'].encode()).hexdigest(),'capture':captured})
     # Partial is explicitly provisional; final report waits for all owners.
     (root/'partial-guards.json').write_text(json.dumps({'provisional':True,'guards':captures},indent=2))
    # Separate diagnostic expression; derive actual admitted alias and version.
    from ashlar.native import quote_table_identifier
    selected=[table for table in binding['publication']['tables']if table['name'][-1]=='object_current']
    if len(selected)!=1:raise PermissionError('Exact original object target required')
    table=selected[0];actual_alias=_aliases(driver)[driver.tables['object_current']]
    if actual_alias.split('.')!=table['name']or type(table['version'])is not int or table['version']!=2:raise PermissionError('Original probe alias/version differs')
    probe="SELECT CAST(r.id AS STRING) AS id, CAST(schema_of_variant(variant_get(parse_json(r.props_json), :p13)) AS STRING) AS variant_type, CAST(variant_get(parse_json(r.props_json), :p13) AS STRING) AS atom FROM "+quote_table_identifier(actual_alias)+" VERSION AS OF "+str(table['version'])+" r WHERE (r.source_system COLLATE UTF8_BINARY) = (:p10 COLLATE UTF8_BINARY) AND r.type_id = CAST(:p11 AS BIGINT) AND (r.schema_revision COLLATE UTF8_BINARY) = (:p12 COLLATE UTF8_BINARY)"
    variant=adapter.capture(probe,slots)
    provider.admit_binding(binding,provider.resolve(driver.context),driver.context);provider.runtime(driver.context)
   custody=provider.closed_interval_custody(driver.context)
   report={'profile':'ashlar-private-payments-held-guard-diagnostic/0.1','guards':captures,'variant_probe':{'sql':probe,'capture':variant},'native_schemas':schemas,'source_publication_custody':custody,'scope':'Five unchanged original042guards plus separate type observation only; no userSQL/result/financialqueryqualification, source mutation or protectedACK authority'}
 except BaseException as error:primary=error
 finish(primary,[lambda:configuration.renew(65536),lambda:request_pin.renew(262144),lambda:artifact_pin.renew(262144),lambda:index.renew(262144)])
 raw=json.dumps(report,indent=2).encode()
 if len(raw)>1048576:raise ValueError('Complete bounded diagnostic report required')
 with os.fdopen(os.open(root/'report.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb')as stream:
  if stream.write(raw)!=len(raw):raise OSError('Incomplete final diagnostic report write')
 print(json.dumps({'status':'completed','report':str(root/'report.json')}))
if __name__=='__main__':main()
