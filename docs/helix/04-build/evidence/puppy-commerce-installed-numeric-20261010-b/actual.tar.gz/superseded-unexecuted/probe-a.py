"""Actual installed public numerical preparation; explicit retained-fixture scope."""
import sys
# Script directory is not an import authority.
sys.path[:]=[p for p in sys.path if p not in ('','/private/tmp')]
import base64,hashlib,json,os,stat,fcntl
from pathlib import Path
from contextlib import contextmanager
from ashlar_host.commerce_admission import CommerceAdmission
from ashlar_host.puppy_commerce_prepare import PuppyCommercePrepareConfig,prepare_exact_commerce
from ashlar_host.puppy_commerce_scenarios import bag
from ashlar_host.lifecycle import finish,owned_context
from ashlar.commerce_source import build_transaction
WORK=Path('/private/tmp/ashlar-puppy-commerce-installed-20261010-a')
REPO=Path('/Users/erik/Projects/ashlar')
SOURCE=REPO/'examples/domain-packs/commerce/upstream'
EXPORT=REPO/'docs/helix/04-build/evidence/commerce-graph-export-20261009'
PUBLIC=REPO/'docs/helix/04-build/evidence/commerce-public-dataset-20261009.json'
paths=[SOURCE/'ontology.json',SOURCE/'graph/fixture.json',SOURCE/'pack.json',EXPORT/'release.graph.json',EXPORT/'custody.json',PUBLIC]
def read(p,maximum=16777216):
 if p.is_symlink()or not p.is_file()or p.stat().st_size>maximum:raise ValueError('Exact ordinary bounded original required')
 with owned_context(p.open('rb'))as f:raw=f.read(maximum+1)
 if len(raw)>maximum:raise ValueError('Original bound')
 return raw
originals={str(p):(read(p),(p.stat().st_dev,p.stat().st_ino),str(p.parent.resolve()),(p.parent.stat().st_dev,p.parent.stat().st_ino))for p in paths}
model,graph,pack,release,custody,public=[originals[str(p)][0]for p in paths]
rs=hashlib.sha256(release).hexdigest();cs=hashlib.sha256(custody).hexdigest()
release_value=json.loads(release)
bindings_raw=base64.b64decode(json.loads(release_value['publication']['validation_report_json'])['source_admission']['original_bindings_base64'],validate=True)
binding_path=WORK/'original-bindings.json'
with owned_context(binding_path.open('xb'))as stream:stream.write(bindings_raw)
batch,bindings=build_transaction(model,graph,source_system=release_value['nodes'][0]['source_system'])
admission=CommerceAdmission(batch,bindings,paths[0],paths[1],binding_path,PUBLIC)
context=object()
class RetainedFixturePolicy:
 """Explicit operator-authorized original retained fixture; no production grant.

 Named file/inode readback and a cooperating local lease renew that selected
 finite fixture interval. Digests establish correspondence, not authorization.
 No source activation, graph model activation or live publication is permitted.
 """
 def __init__(self):self.fd=None;self.identity=None;self.opening=False;self.closing=False
 def current(self):
  for name,(raw,identity,parent,parent_identity)in originals.items():
   p=Path(name)
   if p.is_symlink()or(p.stat().st_dev,p.stat().st_ino)!=identity or str(p.parent.resolve())!=parent or(p.parent.stat().st_dev,p.parent.stat().st_ino)!=parent_identity or read(p)!=raw:raise PermissionError('Current selected retained fixture custody lost')
  admission.metadata()
  if self.fd is not None:
   p=WORK/'retained-source.lease';st=os.fstat(self.fd)
   if p.is_symlink()or not stat.S_ISREG(st.st_mode)or(st.st_dev,st.st_ino)!=self.identity or(p.stat().st_dev,p.stat().st_ino)!=self.identity or st.st_uid!=os.getuid()or st.st_mode&0o777!=0o600:raise PermissionError('Current owned retained fixture interval lost')
 @contextmanager
 def hold(self,c):
  if c is not context or self.fd is not None:raise PermissionError('Exact retained fixture context required')
  self.current();p=WORK/'retained-source.lease';fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_RDWR|os.O_NOFOLLOW,0o600);self.fd=fd;self.identity=(os.fstat(fd).st_dev,os.fstat(fd).st_ino);primary=None
  def close():
   self.fd=None;os.close(fd)
  def remove():
   if p.is_symlink()or(p.stat().st_dev,p.stat().st_ino)!=self.identity:raise PermissionError('Owned lease name changed; no foreign unlink')
   p.unlink()
  try:
   fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);self.current();self.opening=True;yield
  except BaseException as error:primary=error
  finish(primary,[self.current,lambda:fcntl.flock(fd,fcntl.LOCK_UN),remove,close])
  self.closing=True
 def admit_exact_commerce(self,facts,c):
  if c is not context or self.fd is None or facts['release_sha256']!=rs or facts['custody_sha256']!=cs:raise PermissionError('Only explicitly selected original retained fixture admitted')
  self.current()
  import duckdb
  if duckdb.__version__!='1.5.6':raise PermissionError('Exact selected native SDK required before database effects')
 def renew_exact_commerce(self,facts,c):self.admit_exact_commerce(facts,c)
policy=RetainedFixturePolicy();output=WORK/'numeric'
result=prepare_exact_commerce(PuppyCommercePrepareConfig(release,custody,rs,cs,pack,output),policy,context,source_admission=admission)
import duckdb
if duckdb.__version__!='1.5.6':raise ValueError('Selected cached SDK version required')
connection=None;primary=None
try:
 connection=duckdb.connect(str(output/'commerce-exact.duckdb'),read_only=True)
 for role in ('nodes','edges'):
  names=list(result[role][0]);actual=[dict(zip(names,row))for row in connection.execute('SELECT '+','.join('"'+n+'"'for n in names)+' FROM carrier.'+role).fetchall()]
  if bag(actual)!=bag(result[role]):raise ValueError('Complete readonly reopened carrier differs')
except BaseException as error:primary=error
finish(primary,[]if connection is None else[connection.close])
policy.current()
if not policy.opening or not policy.closing or (WORK/'retained-source.lease').exists():raise PermissionError('Successful held cleanup required')
files={};total=0
for p in output.iterdir():
 if p.is_symlink()or not p.is_file()or p.stat().st_mode&0o777!=0o444:raise ValueError('Sealed fresh preparation artifact required')
 raw=read(p,33554432);total+=len(raw);files[p.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
if total>33554432 or set(files)!={'commerce-exact.duckdb','model.json','receipt.json'}:raise ValueError('Complete bounded preparation inventory required')
summary={'format':'ashlar-installed-puppy-numeric-preparation/0.1','nodeCount':len(result['nodes']),'edgeCount':len(result['edges']),'readonlyReopenComplete':True,'sourceHoldOpeningClosing':True,'selectedDuckDBVersion':duckdb.__version__,'files':files,'numericInputGuards':result['numeric_input_guards'],'allUnfilteredIntermediateGuards':result['all_unfiltered_intermediate_guards'],'expectedOriginalFour':result['expected'],'scope':'Installed publicAPI/actualDuckDB preparation and readonlyreopen only. Existing original retained source policy; no Puppy activation, native graph queries, live publication or productionauthority.'}
raw=(json.dumps(summary,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode()
with owned_context((WORK/'numeric-preparation.json').open('xb'))as stream:
 if stream.write(raw)!=len(raw):raise ValueError('Owned complete report required')
print(json.dumps({'nodeCount':len(result['nodes']),'edgeCount':len(result['edges']),'readonlyReopenComplete':True,'sourceHoldOpeningClosing':True,'reportSha256':hashlib.sha256(raw).hexdigest()},sort_keys=True))
