import os,sys,tempfile,time,json,base64,hashlib,importlib.metadata
from pathlib import Path
import psycopg,psycopg.pq,jsonschema,referencing
root=Path(__file__).parent;(root/'ipc').mkdir();os.environ['TMPDIR']=str(root/'ipc');tempfile.tempdir=None
os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
for p in reversed(json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical']):sys.path.insert(0,p)
sys.path.insert(0,'/Users/erik/Projects/ashlar/src');sys.path.insert(0,'/private/tmp/ashlar-truss15-parallel-example-20261013-a/truss-target')
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context
from ashlar_host.truss_example import private_file
from ashlar_host.truss_example_reader import run_configure_truss_example_reader_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_two_hop_count_cli import run_query_truss_two_hop_count_command
from ashlar_host.truss_two_hop_target_count_cli import run_query_truss_two_hop_target_count_command
from ashlar_host.truss_graph_export_cli import run_export_truss_graph_command
start=time.monotonic();result=None
try:
 example=Path('/private/tmp/ashlar-truss15-parallel-example-20261013-a/example')
 with owned_context(LocalPostgres(example/'data'))as runtime:
  live=private_file(root/'live.json',{'profile':'ashlar-local-truss-connection/0.1','data_directory':str(example/'data'),'connection_uri':runtime.info.connection_uri})
  reader=root/'reader.json';run_configure_truss_example_reader_command(example,live,reader,reader_configuration=example/'reader-configuration.json');config=json.loads(reader.read_bytes())
  def connection():return psycopg.connect(config['connection_uri'],autocommit=False,connect_timeout=5)
  before=read_page(connection,'example-related-delta',maximum_bytes=2097152).prior.content;private_file(root/'checkpoint-before.json',{'cursor_base64':base64.b64encode(before).decode()})
  report=run_export_truss_graph_command(reader,root/'export.json');graph=json.loads(Path(report['release']['path']).read_bytes())
  if (report['nodes'],report['edges'])!=(2,2)or {e['id']for e in graph['edges']}!={'3','4'}or any(e['src']!=e['dst']for e in graph['edges'])or len({e['src']for e in graph['edges']})!=1:raise ValueError('Exact original parallel self-edge graph required')
  for node in graph['nodes']:
   record=json.loads((example/('record-'+node['id']+'.json')).read_bytes())['record']['row']
   if node['props_json']!=record['props_json']or node['retained_json']!=record['retained_json']:raise ValueError('Exact original node value carrier differs')
  after=read_page(connection,'example-related-delta',maximum_bytes=2097152).prior.content;private_file(root/'checkpoint-after.json',{'cursor_base64':base64.b64encode(after).decode()})
  if before!=after:raise ValueError('Export changed source checkpoint')
 result={'outcome':'passed','duration_seconds':round(time.monotonic()-start,3),'publication_id':report['publication_id'],'nodes':2,'edges':2,'source_edge_ids':['3','4'],'release_sha256':report['release']['sha256'],'custody_sha256':report['custody']['sha256'],'source_checkpoint_unchanged':True,'qualification':'Actual immutable export of existing releasedTruss15 parallelselfedge publication under original fullsource/vector/nativecustody; exactoriginalnodepropertycarriers and distinctedgeIDs retained. No mutation, ACK, ingest, graph engine or numeric filtering qualification.'}
except BaseException as error:result={'outcome':'failed','duration_seconds':round(time.monotonic()-start,3),'error_type':type(error).__name__};raise
finally:private_file(root/'run-result.json',result);print(json.dumps(result),flush=True)
