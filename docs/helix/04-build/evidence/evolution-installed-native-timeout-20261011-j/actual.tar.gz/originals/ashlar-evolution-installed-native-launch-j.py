"""One bounded installed public evolution workflow; external review required."""
import argparse,hashlib,importlib.util,json,pathlib,time
from contextlib import contextmanager
def cleanup_primary(primary,closing):
 if primary is None:return closing
 if isinstance(primary,Exception) and not isinstance(closing,Exception):return closing
 try:primary.closing_custody_failed=True
 except BaseException:pass
 return primary

@contextmanager
def owned(stream):
 primary=None
 try:yield stream
 except BaseException as error:primary=error
 try:stream.close()
 except BaseException as error:primary=cleanup_primary(primary,error)
 if primary is not None:raise primary

def write_receipt(path,result):
 primary=None;stream=None
 try:
  stream=path.open('x');json.dump(result,stream,sort_keys=True,indent=2);stream.write('\n')
 except BaseException as error:primary=error
 finally:
  if stream is not None:
   try:stream.close()
   except BaseException as error:primary=cleanup_primary(primary,error)
 if primary is not None:raise primary

def main():
 p=argparse.ArgumentParser();p.add_argument('--command',required=True,type=pathlib.Path);p.add_argument('--sha256',required=True);p.add_argument('--phase',required=True);p.add_argument('--receipt',required=True,type=pathlib.Path);a=p.parse_args()
 started=time.monotonic()
 raw=a.command.read_bytes()
 if len(raw)>1000000 or hashlib.sha256(raw).hexdigest()!=a.sha256:raise ValueError('command-pin')
 plan=json.loads(raw)
 deadline=started+plan['wholeDeadlineSeconds']
 def verify():
  phase_deadline=min(deadline,time.monotonic()+plan['hashPhaseSeconds'])
  for r in plan['resources']:
   path=pathlib.Path(r['path'])
   if path.is_symlink() or not path.is_file() or path.stat().st_size!=r['bytes']:raise ValueError('resource-shape')
   if time.monotonic()>phase_deadline:raise TimeoutError('bounded custody phase')
   h=hashlib.sha256();count=0
   with owned(path.open('rb')) as f:
    for block in iter(lambda:f.read(262144),b''):
     count+=len(block)
     if count>r['bytes']or time.monotonic()>phase_deadline:raise TimeoutError('bounded custody bytes/time')
     h.update(block)
   if count!=r['bytes']or h.hexdigest()!=r['sha256']:raise ValueError('resource-pin')
 verify()
 closure_path=pathlib.Path(plan['runtimeClosure'])
 closure_raw=closure_path.read_bytes()
 if len(closure_raw)>8388608:raise ValueError('runtime closure capacity')
 closure=json.loads(closure_raw)
 if len(closure['files'])!=18547 or sum(r['bytes']for r in closure['files'])!=1093433411:raise ValueError('selected runtime capacity')
 runtime_metadata=json.loads(pathlib.Path(plan['runtimeMetadata']).read_bytes())
 if {r['path'] for r in runtime_metadata['files']}!={r['path'] for r in closure['files']}:raise ValueError('runtime metadata correspondence')
 def renew_runtime_metadata():
  for r in runtime_metadata['files']:
   p=pathlib.Path(r['path']);s=p.stat()
   if p.is_symlink() or (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_mode)!=(r['dev'],r['ino'],r['bytes'],r['mtimeNs'],r['mode']):raise ValueError('selected runtime metadata changed')
 renew_runtime_metadata()
 spec=importlib.util.spec_from_file_location('bounded_capture',plan['captureModule']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 c=next(c for c in plan['commands'] if c['phase']==a.phase)
 if a.phase!='installed-native'or len(plan['commands'])!=1:raise ValueError('closed installed native phase required')
 primary=None;result=None
 try:
  remaining=int(deadline-time.monotonic()-plan['hashPhaseSeconds'])
  if remaining<1:raise TimeoutError('whole operation deadline before child')
  result=m.capture(c['argv'],c['cwd'],plan['environment'],c['stdout'],c['stderr'],min(c['timeoutSeconds'],remaining),16*1024*1024)
 except BaseException as e:primary=e
 finally:
  try:
   verify()
   renew_runtime_metadata()
  except BaseException as e:
   primary=cleanup_primary(primary,e)
 if primary is not None:raise primary
 result.update({'commandSha256':a.sha256,'phase':a.phase,'openingClosingCustody':True,'environmentInherited':False,'qualification':plan['qualification']})
 write_receipt(a.receipt,result)
 if result['exitCode']:raise SystemExit(result['exitCode'])

if __name__=='__main__':main()
