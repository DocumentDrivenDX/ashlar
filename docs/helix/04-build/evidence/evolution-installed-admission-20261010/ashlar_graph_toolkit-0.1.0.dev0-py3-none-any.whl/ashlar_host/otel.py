"""Explicit C006 signal composition and owned isolated-worker supervision.

No SDK provider is constructed in this process. Process termination/reaping
relies on POSIX scheduling and signal semantics; transport-specific qualification
remains separate from this supervision boundary.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import asdict
from importlib import metadata
import json
import math
import os
import selectors
import signal
import struct
import subprocess
import sys
import threading
import time
from typing import Optional

from .config import DiagnosticsConfig, with_diagnostics_transport
from .diagnostics import (DiagnosticSignalSink, DiagnosticsError, decode_event,
                          validate_signal_loss)


FRAME_LIMIT = 65536


class OtelStartupError(DiagnosticsError):
    """Payload-free startup disposition from the owned worker boundary."""
    def __init__(self, *, cleanup_complete: bool, dependency_admitted: bool):
        if type(cleanup_complete) is not bool or type(dependency_admitted) is not bool:
            raise DiagnosticsError('diagnostics-configuration')
        super().__init__('diagnostics-configuration')
        object.__setattr__(self, '_cleanup_complete', cleanup_complete)
        object.__setattr__(self, '_dependency_admitted', dependency_admitted)

    def __setattr__(self, name, value):
        if name in ('_cleanup_complete', '_dependency_admitted',
                    'cleanup_complete', 'dependency_admitted'):
            raise AttributeError('immutable-startup-disposition')
        super().__setattr__(name, value)

    def __delattr__(self, name):
        if name in ('_cleanup_complete', '_dependency_admitted',
                    'cleanup_complete', 'dependency_admitted'):
            raise AttributeError('immutable-startup-disposition')
        super().__delattr__(name)

    @property
    def cleanup_complete(self):
        return self._cleanup_complete

    @property
    def dependency_admitted(self):
        return self._dependency_admitted


def require(value: bool) -> None:
    if not value:
        raise DiagnosticsError('diagnostics-configuration')


def unknown_loss() -> dict:
    return {name: {'submitted': None, 'handed_off': None, 'dropped': None,
                   'unknown': True, 'flush': 'failed'} for name in ('logs', 'spans', 'metrics')}


class OtelRun:
    """One run's trusted signal sink; application composition owns its closure."""
    def __init__(self, config: DiagnosticsConfig):
        self._process = None
        self._lock = threading.Lock()
        self._cleanup_lock = threading.Lock()
        self._operation_binding = ContextVar('ashlar_otel_operation', default=(None, None, True))
        self._closed = False
        self._group_termination_attempted = False
        self._group_termination_complete = False
        self._dependency_admitted = False
        refusal = None
        try:
            require(type(config) is DiagnosticsConfig and os.name == 'posix'
                    and signal.getsignal(signal.SIGCHLD) == signal.SIG_DFL
                    and sys.version_info[:2] == (3, 11))
            self._config = config
            version = metadata.version('ashlar-graph-toolkit')
            # Startup precedes work effects; shutdown's selected budget governs
            # closure only. Construction has its own finite two-second ceiling.
            deadline = time.monotonic() + 2
            self._process = subprocess.Popen(
                [sys.executable, '-I', '-B', '-m', 'ashlar_host._otel_worker'],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, env={'PATH': '/usr/bin:/bin'},
                start_new_session=True, close_fds=True, bufsize=0)
            for stream in (self._process.stdin, self._process.stdout):
                os.set_blocking(stream.fileno(), False)
            def initialize(endpoint, headers, tls, ca_file):
                return self._exchange({'op': 'init', 'settings': {
                    'endpoint': endpoint, 'headers': [list(pair) for pair in headers],
                    'tls': tls, 'ca_file': str(ca_file) if ca_file is not None else None,
                    'environment': config.environment, 'limits': asdict(config.limits),
                    'service_version': version}}, deadline)
            require(with_diagnostics_transport(config, initialize) == 'ready'
                    and self._dependency_admitted)
            self._sink = DiagnosticSignalSink(self.emit, self.trace_context, self.shutdown)
        except BaseException as primary:
            try:
                cleanup_complete = self._dispose(primary=primary)
            except Exception:
                cleanup_complete = False
            except BaseException:
                if not isinstance(primary, Exception):
                    raise primary
                raise
            if isinstance(primary, Exception):
                refusal = OtelStartupError(cleanup_complete=cleanup_complete is True,
                                           dependency_admitted=self._dependency_admitted)
            else:
                raise
        if refusal is not None:
            # Raise outside the handler: do not retain private startup arguments
            # in Python's implicit exception context on the public disposition.
            raise refusal from None

    @property
    def sink(self) -> DiagnosticSignalSink:
        return self._sink

    def _dispose(self, deadline: Optional[float] = None,
                primary: Optional[BaseException] = None) -> bool:
        """Terminate and reap only this new session; never wait for remote export."""
        self._closed = True
        process = self._process
        if process is None:
            return True
        end = deadline if deadline is not None else time.monotonic() + 2
        try:
            acquired = self._cleanup_lock.acquire(timeout=max(0, end-time.monotonic()))
        except BaseException as cleanup:
            if primary is not None and not isinstance(primary, Exception):
                try:
                    primary.cleanup_failed = True
                except BaseException:
                    pass
                return False
            raise
        if not acquired:
            if primary is not None:
                try:
                    primary.cleanup_failed = True
                except BaseException:
                    pass
                return False
            raise DiagnosticsError('diagnostics-configuration')
        try:
            return self._dispose_owned(process, end, primary)
        finally:
            self._cleanup_lock.release()

    def _dispose_owned(self, process, end: float,
                       primary: Optional[BaseException]) -> bool:
        """Cleanup lock covers group action through reaping, including failures."""
        failure = None
        def terminate():
            # Do not reap the leader before this one-shot group action: its
            # unreaped PID protects the session identity from numeric reuse.
            if not self._group_termination_attempted:
                self._group_termination_attempted = True
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                self._group_termination_complete = True
            require(self._group_termination_complete)
        actions = [terminate]
        actions.extend(stream.close for stream in (process.stdin, process.stdout)
                       if stream is not None)
        actions.append(lambda: process.wait(timeout=max(0, end - time.monotonic())))
        for action in actions:
            try:
                action()
            except BaseException as exc:
                if failure is None or (isinstance(failure, Exception)
                                       and not isinstance(exc, Exception)):
                    failure = exc
        if failure is not None:
            if (not isinstance(failure, Exception)
                    and (primary is None or isinstance(primary, Exception))):
                raise failure
            if primary is not None:
                try:
                    primary.cleanup_failed = True
                except BaseException:
                    pass
                return False
            elif isinstance(failure, Exception):
                raise DiagnosticsError('diagnostics-configuration') from None
            else:
                raise failure
        return True

    def _exchange(self, request: dict, deadline: float):
        raw = json.dumps(request, ensure_ascii=True, separators=(',', ':'),
                         allow_nan=False).encode('utf8')
        require(0 < len(raw) <= FRAME_LIMIT and not self._closed)
        process = self._process
        require(process is not None and process.returncode is None)
        def transfer(stream, size, outgoing=None):
            result = bytearray()
            offset = 0
            selector = selectors.DefaultSelector()
            primary = None
            try:
                selector.register(stream, selectors.EVENT_WRITE if outgoing is not None
                                  else selectors.EVENT_READ)
                while offset < size:
                    remaining = deadline - time.monotonic()
                    require(remaining > 0)
                    require(bool(selector.select(remaining)))
                    try:
                        if outgoing is not None:
                            count = os.write(stream.fileno(), outgoing[offset:])
                        else:
                            part = os.read(stream.fileno(), size - offset)
                            count = len(part)
                            result.extend(part)
                    except BlockingIOError:
                        continue
                    require(count > 0)
                    offset += count
            except BaseException as exc:
                primary = exc
                raise
            finally:
                try:
                    selector.close()
                except BaseException as cleanup:
                    if primary is None or (isinstance(primary, Exception)
                                           and not isinstance(cleanup, Exception)):
                        raise
                    try:
                        primary.cleanup_failed = True
                    except BaseException:
                        pass
            return bytes(result)
        payload = struct.pack('>I', len(raw)) + raw
        transfer(process.stdin, len(payload), payload)
        close_deadline = deadline
        active_transport = False
        # At most two log/span queues and 20 metric series, begin/end per unit.
        progress_limit = 2 * (2 * self._config.limits.max_queue_records + 20) + 1
        def pairs(items):
            result = {}
            for key, value in items:
                require(key not in result)
                result[key] = value
            return result
        def constant(token):
            raise DiagnosticsError('diagnostics-configuration')
        def protocol_require(condition):
            if not condition and request['op'] == 'init':
                self._dependency_admitted = False
            require(condition)
        for _ in range(progress_limit):
            count = struct.unpack('>I', transfer(process.stdout, 4))[0]
            protocol_require(0 < count <= FRAME_LIMIT)
            response_raw = transfer(process.stdout, count)
            try:
                response = json.loads(response_raw, object_pairs_hook=pairs,
                                      parse_constant=constant)
            except Exception:
                if request['op'] == 'init':
                    self._dependency_admitted = False
                raise
            protocol_require(type(response) is dict and set(response) == {'ok', 'value'}
                             and type(response['ok']) is bool
                             and time.monotonic() <= deadline)
            if (request['op'] == 'init' and response['ok'] is False
                    and response['value'] == 'diagnostics-configuration'):
                # A valid worker startup refusal after positive admission may
                # degrade only once the parent also proves owned cleanup.
                require(False)
            protocol_require(response['ok'] is True)
            value = response['value']
            if request['op'] == 'init' and type(value) is dict:
                protocol_require(set(value) == {'dependency_admitted'}
                                 and value['dependency_admitted'] is True
                                 and not self._dependency_admitted)
                self._dependency_admitted = True
                continue
            if request['op'] == 'init':
                protocol_require(value == 'ready' and self._dependency_admitted)
            if request['op'] == 'close' and type(value) is dict:
                if set(value) == {'transport_deadline'}:
                    end = value['transport_deadline']
                    require(not active_transport and type(end) in (int, float)
                            and math.isfinite(end) and end <= close_deadline
                            and end <= time.monotonic()
                            + self._config.limits.export_timeout_ms / 1000)
                    deadline = end
                    active_transport = True
                    continue
                if set(value) == {'transport_complete'}:
                    require(active_transport and value['transport_complete'] is True)
                    deadline = close_deadline
                    active_transport = False
                    continue
            require(not active_transport)
            return value
        raise DiagnosticsError('diagnostics-configuration')

    def _invoke(self, request: dict):
        require(self._lock.acquire(blocking=False))
        try:
            return self._exchange(request, time.monotonic()
                                 + self._config.limits.export_timeout_ms / 1000)
        except BaseException as primary:
            self._dispose(primary=primary)
            if isinstance(primary, Exception):
                raise DiagnosticsError('diagnostics-configuration') from None
            raise
        finally:
            self._lock.release()

    @contextmanager
    def operation_context(self, parent_context=None, retry_link=None, *, create_span=True):
        """Select span creation and explicit parents; never read ambient context."""
        require(type(create_span) is bool and (parent_context is None or retry_link is None)
                and (create_span or (parent_context is None and retry_link is None)))
        def wire(value):
            if value is None:
                return None
            from opentelemetry.trace import SpanContext
            require(type(value) is SpanContext and value.is_valid)
            return {'trace_id': format(value.trace_id, '032x'),
                    'span_id': format(value.span_id, '016x'),
                    'trace_flags': int(value.trace_flags), 'is_remote': value.is_remote}
        token = self._operation_binding.set((wire(parent_context), wire(retry_link), create_span))
        try:
            yield
        finally:
            self._operation_binding.reset(token)

    def trace_context(self, attempt: str, operation: str, event: str) -> Optional[dict]:
        started = event == 'ashlar.operation.started'
        parent, retry, create_span = (self._operation_binding.get()
                         if started else (None, None, None))
        request = {'op': 'context', 'attempt_id': attempt,
                             'operation': operation, 'event_name': event,
                             'parent': parent, 'retry_link': retry}
        if started:
            request['create_span'] = create_span
        value = self._invoke(request)
        require(value is None or (type(value) is dict
                and set(value) == {'trace_id', 'span_id', 'trace_flags'}))
        return value

    def emit(self, raw: bytes) -> None:
        decode_event(raw)
        require(self._invoke({'op': 'emit', 'event': raw.decode('utf8')}) is None)

    def shutdown(self, deadline: float) -> dict:
        if self._closed or not self._lock.acquire(blocking=False):
            self._dispose(deadline)
            return unknown_loss()
        primary = None
        try:
            value = self._exchange({'op': 'close', 'deadline': deadline}, deadline)
            require(type(value) is dict and set(value) == {'logs', 'spans', 'metrics'})
            for item in value.values():
                validate_signal_loss(item)
            return value
        except Exception:
            return unknown_loss()
        except BaseException as exc:
            primary = exc
            raise
        finally:
            try:
                self._dispose(deadline, primary)
            finally:
                self._lock.release()


def make_otel_run(config: Optional[DiagnosticsConfig]) -> Optional[OtelRun]:
    """None disables SDK discovery and subprocess construction."""
    return None if config is None else OtelRun(config)
