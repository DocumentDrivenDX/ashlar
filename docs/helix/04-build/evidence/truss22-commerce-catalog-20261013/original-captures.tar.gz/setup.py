import sys,json,time
from pathlib import Path
import psycopg,jsonschema,referencing
sys.path[:0]=['/private/tmp/ashlar-truss22-commerce-preparation-20261013-a/ashlar-target','/private/tmp/ashlar-truss22-public-inspect-20261013-a/target']
from ashlar_host.truss_local_setup import run_setup_truss_local_command
r=Path(__file__).parent
(r/'origin.json').write_text('{"operator":"ashlar-commerce-truss22-example"}')
model=Path('/Users/erik/Projects/ashlar/examples/domain-packs/commerce/upstream/ontology.json')
config={'data_directory':str(r/'data'),'bun':'/opt/homebrew/Cellar/bun/1.4.2/bin/bun','document_path':str(model),'document_id':json.loads(model.read_bytes())['id'],'document_revision':'1','origin_path':str(r/'origin.json'),'request_key':'commerce22-setup'}
(r/'setup-configuration.json').write_text(json.dumps(config))
t=time.monotonic();result=run_setup_truss_local_command(r/'setup-configuration.json',r/'setup-result.json')
print(json.dumps({'outcome':'accepted','revision':result['revision'],'registration_id':result['registration_id'],'duration_seconds':time.monotonic()-t}),flush=True)
