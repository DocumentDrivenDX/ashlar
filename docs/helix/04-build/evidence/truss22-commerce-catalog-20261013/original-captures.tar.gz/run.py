import sys,json,time,hashlib,dataclasses
from pathlib import Path
import jsonschema,referencing
sys.path.insert(0,'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target')
from truss import CatalogDocument,prepare_catalog
r=Path(__file__).parent;t=time.monotonic()
raw=Path('/Users/erik/Projects/ashlar/examples/domain-packs/commerce/upstream/ontology.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='51d87c554df36846e41378cfaafc81277fcab61f6c891a6c64f34dba8fd9ac2a'
doc=json.loads(raw);assert doc['umf']=='0.8.0'
p=prepare_catalog((CatalogDocument(doc['id'],'1',raw),),source_version='0.8.0',bun_executable='/opt/homebrew/Cellar/bun/1.4.2/bin/bun')
assert len(p.documents)==1 and p.documents[0].document.content==raw
views={}
for name in ('input_bytes','declarations_bytes','archive_documents_bytes','report_evidence_bytes'):
 b=getattr(p,name);(r/(name+'.json')).write_bytes(b);views[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(r/'observation.json').write_bytes(p.documents[0].observation_bytes)
result={'outcome':'prepared','duration_seconds':time.monotonic()-t,'declared_umf':doc['umf'],'model_sha256':hashlib.sha256(raw).hexdigest(),'views':views,'provenance':dataclasses.asdict(p.provenance),'accepted':False,'database_started':False}
(r/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
