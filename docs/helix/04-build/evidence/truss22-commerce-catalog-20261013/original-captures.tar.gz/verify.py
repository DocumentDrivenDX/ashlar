import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target')
from truss import resolve_catalog_report_source
r=Path(__file__).parent;raw=(r/'accepted-report.json').read_bytes();report=json.loads(raw)
model=Path('/Users/erik/Projects/ashlar/examples/domain-packs/commerce/upstream/ontology.json').read_bytes()
entries=report['source']['assertionEntries'];assert len(entries)==213
assert report['interfaceVersion']=='truss-catalog-registration-report/0.2'
for entry in entries:
 resolved=resolve_catalog_report_source(raw,entry['source'])
 assert resolved.content==model and resolved.document_revision=='1' and resolved.document_id=='urn:umf:domain:commerce'
 assert resolved.sha256==hashlib.sha256(model).hexdigest()
 pointer=entry['assertion']['sourcePointer'];node=json.loads(model)
 for token in pointer.split('/')[1:]:
  token=token.replace('~1','/').replace('~0','~');node=node[int(token)] if isinstance(node,list) else node[token]
result={'outcome':'all-original-source-references-resolved','assertion_count':len(entries),'accepted_report_sha256':hashlib.sha256(raw).hexdigest(),'original_sha256':hashlib.sha256(model).hexdigest(),'allocation_counts':{k:len(report[k]) for k in ('types','properties','relationships')},'source_format':report['source']['sourceFormat'],'declared_umf':json.loads(model)['umf'],'authority_scope':'fresh local accepted catalog only; no feed, ACK, Delta or query qualification'}
(r/'verify-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
