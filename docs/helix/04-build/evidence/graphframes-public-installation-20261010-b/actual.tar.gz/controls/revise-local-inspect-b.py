from pathlib import Path
import json,hashlib,ast
prefix='/private/tmp/ashlar-graphframes-local-installed-'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):return {'path':str(p),'bytes':Path(p).stat().st_size,'sha256':sha(p)}
def save(p,v):Path(p).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
probe=Path(prefix+'inspect-a.py').read_text()
probe=probe.replace('before = set(sys.modules)\n',"def refuse_loaded_native_sdks():\n    if any(name == sdk or name.startswith(sdk + '.') for name in sys.modules for sdk in ('pyspark', 'delta', 'graphframes')):\n        raise ValueError('Inspection must not import or inherit a native SDK')\n\n\nrefuse_loaded_native_sdks()\n")
probe=probe.replace("if any(name == sdk or name.startswith(sdk + '.') for name in set(sys.modules) - before for sdk in ('pyspark', 'delta', 'graphframes')):\n    raise ValueError('Inspection must not import a native SDK')",'refuse_loaded_native_sdks()')
assert 'before = set(sys.modules)' not in probe
Path(prefix+'inspect-b.py').write_text(probe)
closure=json.loads(Path(prefix+'closure-a.json').read_bytes())
del closure['files'][prefix+'inspect-a.py']
r=pin(prefix+'inspect-b.py');closure['files'][r['path']]={k:v for k,v in r.items() if k!='path'}
save(prefix+'closure-b.json',closure)
runner=Path(prefix+'prepare-a.py').read_text().replace(prefix+'closure-a.json',prefix+'closure-b.json').replace(sha(prefix+'closure-a.json'),sha(prefix+'closure-b.json')).replace(prefix+'inspect-a.py',prefix+'inspect-b.py').replace(prefix+'prepare-a.receipt.json',prefix+'prepare-b.receipt.json')
Path(prefix+'prepare-b.py').write_text(runner)
cmd=json.loads(Path(prefix+'command-a.json').read_bytes())
cmd['commands'][0]['argv'][-1]=prefix+'prepare-b.py'
cmd['commands'][0]['stdout']=prefix+'prepare-b.outer.stdout';cmd['commands'][0]['stderr']=prefix+'prepare-b.outer.stderr'
cmd['supersedesUnexecuted']=prefix+'command-a.json'
cmd['resources']=[pin(r['path'].replace(prefix+'prepare-a.py',prefix+'prepare-b.py').replace(prefix+'closure-a.json',prefix+'closure-b.json').replace(prefix+'inspect-a.py',prefix+'inspect-b.py')) for r in cmd['resources']]
save(prefix+'command-b.json',cmd)
m=json.loads(Path(prefix+'metadata-a.json').read_bytes());m['command']=pin(prefix+'command-b.json');m['resources']=cmd['resources']
m['actual_command']=[x.replace(prefix+'command-a.json',prefix+'command-b.json').replace(sha(prefix+'command-a.json'),sha(prefix+'command-b.json')).replace(prefix+'outer-a.receipt.json',prefix+'outer-b.receipt.json') for x in m['actual_command']]
m['fresh_outputs']=[x.replace('prepare-a.outer','prepare-b.outer').replace('outer-a.receipt','outer-b.receipt').replace('prepare-a.receipt','prepare-b.receipt') for x in m['fresh_outputs']]
m['supersedes_unexecuted']=prefix+'metadata-a.json';m['work_path_note']='Fresh A work path retained because A was never executed; recipe and helper B are distinct immutable files.'
save(prefix+'metadata-b.json',m)
# Execute only the extracted pure module-name guard; no import of SDK or Ashlar.
node=next(n for n in ast.parse(probe).body if isinstance(n,ast.FunctionDef) and n.name=='refuse_loaded_native_sdks')
class Modules:pass
s=Modules();s.modules={};scope={'sys':s};exec(compile(ast.Module(body=[node],type_ignores=[]),'<pure inspected guard>','exec'),scope)
checks=0
for key in ('pyspark','pyspark.sql','delta','delta.tables','graphframes','graphframes.foo'):
 s.modules={key:object()}
 try:scope['refuse_loaded_native_sdks']()
 except ValueError:checks+=1
 else:raise AssertionError(key)
s.modules={'pysparkish':object(),'unrelated':object()};scope['refuse_loaded_native_sdks']()
assert checks==6
for p in (prefix+'prepare-b.py',prefix+'inspect-b.py'):ast.parse(Path(p).read_text())
print(json.dumps({'metadata':pin(prefix+'metadata-b.json'),'command':pin(prefix+'command-b.json'),'resources':cmd['resources'],'preloaded_sdk_controls':checks,'non_sdk_positive':True,'scope':'Pure guard controls; no SDK/import/install/child'},indent=2))
