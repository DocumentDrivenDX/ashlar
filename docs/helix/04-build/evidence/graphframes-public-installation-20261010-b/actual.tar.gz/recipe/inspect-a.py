"""Actual installed public inspection only; candidate bytes confer no authority."""
import hashlib
import json
from pathlib import Path
import sys

from ashlar_host.graphframes_local_setup import inspect_local_graphframes_runtime
from ashlar_host.graphframes_local import local_encoded
from ashlar_host.lifecycle import finish

WORK = Path('/private/tmp/ashlar-graphframes-local-installed-20261010-a')
REVISION = '1f0272d7198339a4984e8dcf5df41de53b86f9db'
VENV = WORK / 'venv'
SDK = Path('/private/tmp/ashlar-spark311/lib/python3.11/site-packages')
BASE = Path('/Users/erik/.local/share/uv/python/cpython-3.11.17-macos-aarch64-none')
JAVA = Path('/private/tmp/ashlar-db-client/lib/python3.9/site-packages/jdk4py/java-runtime')
SITE = VENV / 'lib/python3.11/site-packages'


def write(path, raw):
    stream = None; primary = None
    try:
        stream = path.open('xb')
        if stream.write(raw) != len(raw): raise ValueError('Incomplete candidate retention')
        stream.flush()
        import os
        os.fsync(stream.fileno())
    except BaseException as error: primary = error
    finish(primary, [lambda: stream.close() if stream is not None else None])


if sys.flags.isolated != 1 or Path(sys.executable) != VENV / 'bin/python' or Path(sys.prefix) != VENV or Path(sys.base_prefix) != BASE:
    raise ValueError('Actual selected isolated copied interpreter required')
before = set(sys.modules)
raw = inspect_local_graphframes_runtime(REVISION, (SITE,), SDK, (VENV, BASE, JAVA, WORK / 'jars'))
if any(name == sdk or name.startswith(sdk + '.') for name in set(sys.modules) - before for sdk in ('pyspark', 'delta', 'graphframes')):
    raise ValueError('Inspection must not import a native SDK')
if (WORK / 'ecology-output').exists() or (WORK / 'operator').exists():
    raise ValueError('Inspection cannot initialize engine/provider output')
write(WORK / 'runtime-candidate.json', raw)
candidate = json.loads(raw)
summary = {'format': 'ashlar-public-graphframes-runtime-candidate/0.1',
    'revision': REVISION, 'candidate_sha256': hashlib.sha256(raw).hexdigest(),
    'candidate_bytes': len(raw), 'worker_files': len(candidate['worker']),
    'sdk_files': {name: len(rows) for name, rows in candidate['sdks']},
    'namespace_roots': list(candidate['roots']), 'actual_interpreter': str(Path(sys.executable)),
    'actual_prefix': str(Path(sys.prefix)), 'actual_base_prefix': str(Path(sys.base_prefix)),
    'native_sdk_imported': False, 'producer_executed': False, 'engine_executed': False,
    'scope': 'Candidate correspondence only; no source/runtime grant, provider setup or engine execution'}
write(WORK / 'inspection.json', local_encoded(summary))
print(json.dumps(summary, sort_keys=True))
