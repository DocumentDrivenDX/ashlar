import os,sys,tempfile,time,json,importlib.metadata
from pathlib import Path
import psycopg,psycopg.pq,jsonschema,referencing
root=Path(__file__).parent;(root/'ipc').mkdir();os.environ['TMPDIR']=str(root/'ipc');tempfile.tempdir=None
for p in reversed(json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical']):sys.path.insert(0,p)
sys.path.insert(0,str(root/'ashlar-source/src'));sys.path.insert(0,str(root/'truss-target'))
import truss,ashlar
if not Path(truss.__file__).resolve().is_relative_to(root/'truss-target')or importlib.metadata.version('truss-toolkit')!='0.0.15':raise ValueError('Actual isolated released Truss15 required')
if not Path(ashlar.__file__).resolve().is_relative_to(root/'ashlar-source/src'):raise ValueError('Immutable selected Ashlar source required')
(root/'runtime-selection.json').write_text(json.dumps({'truss_file':truss.__file__,'truss_version':importlib.metadata.version('truss-toolkit'),'ashlar_file':ashlar.__file__,'ashlar_revision':'adf0ffcd7546bb04a5de1466241d002cc59c1a99'},indent=2)+'\n')
start=time.monotonic();result=None
try:
 from ashlar.cli import main
 sys.argv=['ashlar','run-truss-typed-related-example','--configuration',str(root/'configuration.json'),'--output',str(root/'example'),'--topology','parallel-self-loops']
 main()
 report=json.loads((root/'example/result.json').read_bytes())
 result={'outcome':'passed','duration_seconds':round(time.monotonic()-start,3),'truss_version':'0.0.15','ashlar_revision':'adf0ffcd7546bb04a5de1466241d002cc59c1a99','report_path':str(root/'example/result.json'),'qualification':'Actual released isolated Truss15 publicCLI fresh typed07 parallel-self-loop example; report owns full source/Delta/read/query/closure assertions. No retained source upgrade, core08, external graph engine or general production qualification.'}
except BaseException as error:result={'outcome':'failed','duration_seconds':round(time.monotonic()-start,3),'error_type':type(error).__name__};raise
finally:(root/'run-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
