import ast, pathlib, unittest, types, tempfile, sys
from unittest.mock import patch
from contextlib import contextmanager
sys.path.insert(0,'/Users/erik/Projects/ashlar/src')
from ashlar_host.lifecycle import owned_context,finish
class Tests(unittest.TestCase):
 def test_actual_provider_wrapper_retains_owner_result_cancel_and_closing(self):
  source=pathlib.Path('/private/tmp/ashlar-evolution-continuation-provider-m.py').read_text();tree=ast.parse(source);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='open_evolution');helper=__import__('hashlib');raw=pathlib.Path('/Users/erik/Projects/ashlar/tools/evolution_stage_observer.py').read_bytes()
  for primary in (None,KeyboardInterrupt(),ValueError()):
   events=[];configuration=object()
   @contextmanager
   def native(invocation):
    events.append('native-enter')
    try:yield configuration
    finally:events.append('native-close')
   class Capture:
    def __init__(self):self.raw=raw
    def renew(self,limit):events.append('tool-renew')
   class File:
    @staticmethod
    def read(path,limit):return Capture()
   @contextmanager
   def observe(owners,directory):
    self.assertEqual(set(owners),{'driver','ledger','transport','acks'});events.append('observe-enter')
    try:yield
    finally:events.append('observe-close')
   def compile_tool(*args):return compile('observe_fixed_owners = supplied_observe','selected','exec')
   def module(spec):
    selected=types.ModuleType('fixed');selected.supplied_observe=observe;return selected
   # Real selected owner imports are source-only; compiled wrapper itself unchanged.
   ns={'contextmanager':contextmanager,'Path':pathlib.Path,'InvocationFile':File,'hashlib':helper,'OBSERVER_SHA':helper.sha256(raw).hexdigest(),'importlib':types.SimpleNamespace(util=types.SimpleNamespace(spec_from_file_location=lambda *a:None,module_from_spec=module)),'compile':compile_tool,'owned_context':owned_context,'_open_evolution':native,'EvolutionRunLedger':object,'finish':finish}
   exec(compile(ast.Module(body=[node],type_ignores=[]),'actual-provider-wrapper','exec'),ns)
   with tempfile.TemporaryDirectory()as d:
    invocation=types.SimpleNamespace(receipt_path=pathlib.Path(d)/'receipt')
    try:
     with ns['open_evolution'](invocation)as actual:
      self.assertIs(actual,configuration)
      if primary is not None:raise primary
    except BaseException as caught:self.assertIs(caught,primary)
   self.assertEqual(events,['observe-enter','native-enter','native-close','observe-close','tool-renew'])
 def test_runner_keeps_actual_native_cap_and_exact_observer_source(self):
  tree=ast.parse(pathlib.Path('/private/tmp/ashlar-evolution-installed-native-runner-m.py').read_text())
  calls=[n for n in ast.walk(tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='run'];native=next(n for n in calls if n.args and isinstance(n.args[0],ast.Constant)and n.args[0].value=='continue');self.assertEqual(next(k.value.value for k in native.keywords if k.arg=='timeout'),300)
  archive=next(n for n in calls if n.args and isinstance(n.args[0],ast.Constant)and n.args[0].value=='archive');self.assertIn('tools/evolution_stage_observer.py',[n.value for n in ast.walk(archive)if isinstance(n,ast.Constant)])
if __name__=='__main__':unittest.main()
