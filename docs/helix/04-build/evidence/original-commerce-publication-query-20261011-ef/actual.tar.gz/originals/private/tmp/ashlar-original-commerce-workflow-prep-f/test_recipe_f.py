import json,hashlib,importlib.util,sys,unittest,os
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/private/tmp/ashlar-original-commerce-workflow-prep-f')
sys.path.insert(0,'/private/tmp/ashlar-original-commerce-workflow-prep-e/host-source/src')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
class Controls(unittest.TestCase):
 def test_actual_closed_entry_query_dispatch_retains_publication_and_full_jdk(self):
  module=load('query_only_entry',ROOT/'entry-f.py');path=ROOT/'command-f.json';raw=path.read_bytes();command=json.loads(raw);pin=hashlib.sha256(raw).hexdigest();observed=[]
  def dispatch():observed.append((list(sys.argv),os.environ['JAVA_HOME']))
  with patch.dict(os.environ,command['queryEnvironment'],clear=True),patch.object(sys,'argv',['entry','query','--command',str(path),'--sha256',pin]),patch('ashlar.cli.main',side_effect=dispatch):module.main()
  self.assertEqual(len(observed),1);argv,jdk=observed[0]
  self.assertEqual(argv[argv.index('--publication')+1],'/private/tmp/ashlar-original-commerce-native-20261011-e/publication')
  self.assertEqual(jdk,'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home')
  for mode in ('setup','publication'):
   with patch.object(sys,'argv',['entry',mode,'--command',str(path),'--sha256',pin]),patch.object(module.runpy,'run_path') as effect:
    with self.assertRaises(ValueError):module.main()
    effect.assert_not_called()
 def test_retained_publication_reports_exact_original_source_and_ack(self):
  command=json.loads((ROOT/'command-f.json').read_bytes());report=json.loads(Path(command['queryArgv'][command['queryArgv'].index('--publication')+1],'report.json').read_bytes())
  self.assertEqual(command['retainedContainerId'],'c6c94f79b2afd34c77521a74af4037b38238df1f712bb89522d69103e695294c')
  self.assertEqual(report['protected_ack_scope']['feed'],'private-original-commerce-fixture')
 def test_external_digest_refuses_consistent_changed_command(self):
  module=load('query_only_entry_pin',ROOT/'entry-f.py')
  import tempfile
  with tempfile.TemporaryDirectory() as directory:
   path=Path(directory)/'command.json';path.write_bytes(b'{}')
   with self.assertRaises(ValueError):module.read_command(path,'0'*64)
if __name__=='__main__':unittest.main()
