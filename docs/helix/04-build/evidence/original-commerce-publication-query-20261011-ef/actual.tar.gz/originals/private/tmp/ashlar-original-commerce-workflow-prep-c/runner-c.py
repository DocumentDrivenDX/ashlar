"""Bounded prepared installed original-commerce workflow; no import-side effects."""
import hashlib,importlib.util,json,os,re,stat,time,zipfile,csv,base64,argparse
from pathlib import Path
ROOT=Path('/private/tmp/ashlar-original-commerce-workflow-prep-c')
COMMAND=ROOT/'command-a.json'
def select(primary,error):
    return error if primary is None or isinstance(primary,Exception) and not isinstance(error,Exception) else primary

def read(path,maximum=16*1024*1024):
    stream=Path(path).open('rb');primary=None;raw=None
    try:
        raw=stream.read(maximum+1)
        if len(raw)>maximum:raise ValueError('Bounded file required')
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
    return raw

def retain(path,value):
    raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();stream=path.open('xb');primary=None
    try:
        if stream.write(raw)!=len(raw):raise OSError('Short evidence write')
        stream.flush();os.fsync(stream.fileno())
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--command',required=True,type=Path);parser.add_argument('--sha256',required=True);args=parser.parse_args()
    if re.fullmatch('[0-9a-f]{64}',args.sha256) is None:raise ValueError('External command pin required')
    command_path=args.command
    raw=read(command_path,1024*1024)
    if hashlib.sha256(raw).hexdigest()!=args.sha256:raise ValueError('Externally selected command differs')
    command=json.loads(raw);start=time.monotonic();deadline=start+720
    output=Path(command['output']);records=[];primary=None;closing=False;capture=None;installed=[];owned_id=None;whole=None;host_namespaces={}
    def verify():
        if read(command_path,1024*1024)!=raw:raise ValueError('Original command changed')
        for item in command['resources']:
            if time.monotonic()>=deadline-30:raise TimeoutError('Closing budget required')
            p=Path(item['path']);info=p.lstat()
            if not stat.S_ISREG(info.st_mode):raise ValueError('Original regular resource required')
            b=read(p,max(1,item['size']))
            if len(b)!=item['size'] or hashlib.sha256(b).hexdigest()!=item['sha256']:raise ValueError('Resource changed')
        for directory,names in command['jarNamespaces'].items():
            if sorted(p.name for p in Path(directory).iterdir())!=names:raise ValueError('Exact selected JAR namespace required')
        for link in command['dockerLinks']:
            p=Path(link['path']);s=p.lstat()
            if not stat.S_ISLNK(s.st_mode) or os.readlink(p)!=link['target'] or (s.st_dev,s.st_ino)!=(link['device'],link['inode']):raise ValueError('Docker selected link changed')
    def phase(name,argv,cwd,env,seconds):
        remaining=deadline-time.monotonic()-30
        if remaining<1:raise TimeoutError('No phase budget remains')
        result=capture.capture(argv,cwd,env,output/(name+'.stdout'),output/(name+'.stderr'),min(seconds,remaining),4*1024*1024)
        records.append({'phase':name,'argv':argv,'capture':result})
        if result['exitCode']!=0:raise RuntimeError('Required phase refused: '+name)
        return result
    def installed_verify():
        for directory,expected in host_namespaces.items():
            actual=[]
            for p in Path(directory).rglob('*'):
                if p.is_symlink():raise ValueError('Installed host alias introduced')
                if p.is_file():actual.append(str(p.relative_to(directory)))
                elif not p.is_dir():raise ValueError('Unexpected installed host carrier')
            if sorted(actual)!=expected:raise ValueError('Installed host namespace changed')
        for item in installed:
            if hashlib.sha256(read(item['path'],max(1,item['size']))).hexdigest()!=item['sha256']:raise ValueError('Installed host changed')
    try:
        verify()
        if output.exists() or output.is_symlink():raise ValueError('Fresh whole output required')
        output.mkdir(mode=0o700)
        spec=importlib.util.spec_from_file_location('selected_capture',command['captureModule']);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
        base=command['environment'];installer=command['installer'];python=command['python311'];source=str(ROOT/'host-source')
        wheel_dir=output/'wheel';wheel_dir.mkdir(mode=0o700)
        phase('wheel',[installer,'-I','-B','-m','pip','wheel','--no-deps','--no-index','--no-build-isolation','--wheel-dir',str(wheel_dir),source],source,base,60)
        wheels=list(wheel_dir.glob('*.whl'))
        if len(wheels)!=1:raise ValueError('One actual host wheel required')
        wheel=wheels[0];archive=zipfile.ZipFile(wheel);primary_zip=None;members=[]
        try:
            for name in archive.namelist():
                if name.startswith(('ashlar/','ashlar_host/')):
                    original=ROOT/'host-source/src'/name
                    if archive.read(name)!=read(original):raise ValueError('Immutable source/wheel correspondence differs')
                if not name.endswith('/'):members.append((name,archive.read(name)))
        except BaseException as error:primary_zip=error
        try:archive.close()
        except BaseException as error:primary_zip=select(primary_zip,error)
        if primary_zip is not None:raise primary_zip
        for kind in ('publication','query'):
            envdir=output/(kind+'-env')
            phase(kind+'-venv',[python,'-I','-B','-m','venv','--copies',str(envdir)],str(output),base,30)
            phase(kind+'-install',[installer,'-I','-B','-m','pip','--python',str(envdir/'bin/python'),'install','--no-deps','--no-index','--no-compile',str(wheel)],str(output),base,30)
            site=Path(command['hostSites'][kind])
            for name,expected in members:
                if name.endswith('/RECORD'):continue
                p=site/name;b=read(p)
                if b!=expected:raise ValueError('Installed wheel payload/metadata differs')
                installed.append({'path':str(p),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
            for package in ('ashlar','ashlar_host'):
                expected=sorted(name[len(package)+1:] for name,data in members if name.startswith(package+'/'))
                host_namespaces[str(site/package)]=expected
            installed_verify()
            records_file=next(site.glob('ashlar_graph_toolkit-*.dist-info/RECORD'))
            record_raw=read(records_file)
            for relative,hashed,size in csv.reader(record_raw.decode().splitlines()):
                actual=(site/relative).resolve()
                if not actual.is_relative_to(envdir.resolve()):raise ValueError('Installed RECORD escapes owned environment')
                if not hashed:
                    if actual!=records_file.resolve():raise ValueError('Unexpected unhashed RECORD entry')
                    continue
                data=read(actual)
                if hashed!='sha256='+base64.urlsafe_b64encode(hashlib.sha256(data).digest()).decode().rstrip('=') or str(len(data))!=size:raise ValueError('Actual installed RECORD differs')
            installed.append({'path':str(records_file),'size':len(record_raw),'sha256':hashlib.sha256(record_raw).hexdigest()})
            console=envdir/'bin/ashlar';b=read(console)
            if b'from ashlar.cli import main' not in b or not b.startswith(('#!'+str(envdir/'bin/python')+'\n').encode()):raise ValueError('Installed public entrypoint differs')
            installed.append({'path':str(console),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
        retain(output/'installed-host.json',{'sourceRevision':command['sourceRevision'],'wheelSha256':hashlib.sha256(read(wheel)).hexdigest(),'files':installed})
        public_python=str(output/'publication-env/bin/python');query_python=str(output/'query-env/bin/python')
        phase('pg-setup',[public_python,'-I','-B','-S',str(ROOT/'entry-c.py'),'setup','--command',str(command_path),'--sha256',args.sha256],str(ROOT),base,90)
        fixture=json.loads(read(output/'pg/inventory.json',1024*1024));owned_id=fixture['container_id']
        if not re.fullmatch('[0-9a-f]{64}',owned_id) or fixture['container']!=command['container']:raise ValueError('Owned setup result differs')
        phase('publication',[public_python,'-I','-B','-S',str(ROOT/'entry-c.py'),'publication','--command',str(command_path),'--sha256',args.sha256],str(ROOT),command['publicationEnvironment'],300)
        phase('query',[query_python,'-I','-B','-S',str(ROOT/'entry-c.py'),'query','--command',str(command_path),'--sha256',args.sha256],str(ROOT),command['queryEnvironment'],300)
        report=json.loads(read(output/'query/report.json'))
        whole={'sourceRevision':command['sourceRevision'],'reportSha256':hashlib.sha256(read(output/'query/report.json')).hexdigest(),'qualification':'Four original042 queries admitted only by public host; independent actual bag review remains required.','retainedContainerId':owned_id}
    except BaseException as error:primary=error
    finally:
        try:verify();installed_verify();closing=True
        except BaseException as error:primary=select(primary,error)
        if primary is None and whole is not None:
            try:retain(output/'whole-result.json',whole)
            except BaseException as error:primary=select(primary,error)
        if output.is_dir():
            try:retain(output/'outer-receipt.json',{'commandSha256':hashlib.sha256(raw).hexdigest(),'phases':records,'closing':closing,'primary':None if primary is None else type(primary).__name__,'ownedContainerId':owned_id,'cleanup':'Container retained; no outer deletion based on unproven mutable handle. Public setup handles its positively acquired failures.','elapsedSeconds':time.monotonic()-start})
            except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
if __name__=='__main__':main()
