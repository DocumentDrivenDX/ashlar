"""Prepared explicit original publication; execute only after recipe approval."""
import fcntl,hashlib,json,os,stat
from pathlib import Path
from contextlib import contextmanager
from ashlar.manifest import FIELDS
from ashlar_host.config import ProducerConfig
from ashlar_host.source import original_inputs
from ashlar_host.schema_rows import fixture_columns
from ashlar_host.driver import ROOT,PrivatePolicy
from ashlar_host.delta_custody import DeltaTarget,LocalDeltaTransport,LOCAL_OPERATION_CAPACITY_8M
from ashlar_host.original_commerce_publication import OriginalCommercePublicationConfig,OriginalCommercePublicationOperator,publish_original_commerce,write_observation
from ashlar_host.commerce import runtime_paths
from ashlar_host.lifecycle import finish,owned_context
import importlib.util
_provider_spec=importlib.util.spec_from_file_location('selected_original_provider',Path('/private/tmp/ashlar-original-commerce-workflow-prep-a/provider-d.py'))
provider_a=importlib.util.module_from_spec(_provider_spec)
_provider_spec.loader.exec_module(provider_a)

class BootstrapPolicy(PrivatePolicy):
    def __init__(self,context,targets,config,root,fd,gate_fd):
        super().__init__(context,targets);self.config=config;self.root=root;self.fd=fd;self.gate_fd=gate_fd
        info=os.fstat(fd);self.original=(info.st_dev,info.st_ino)
        gate=os.fstat(gate_fd);self.gate_original=(gate.st_dev,gate.st_ino)
        self.inputs=original_inputs(config.model,config.graph)
    def renew(self):
        info=self.root.lstat();held=os.fstat(self.fd)
        if self.root.resolve()!=self.root or (info.st_dev,info.st_ino)!=self.original or (held.st_dev,held.st_ino)!=self.original:raise PermissionError('Held fresh bootstrap root changed')
        named=(self.root/'.evolution-operator.lock').lstat();gate=os.fstat(self.gate_fd)
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid!=os.getuid() or stat.S_IMODE(info.st_mode)!=0o700
                or not stat.S_ISREG(named.st_mode) or named.st_uid!=os.getuid() or stat.S_IMODE(named.st_mode)!=0o600
                or (named.st_dev,named.st_ino)!=self.gate_original or (gate.st_dev,gate.st_ino)!=self.gate_original):raise PermissionError('Original private bootstrap lock/root changed')
        if original_inputs(self.config.model,self.config.graph)!=self.inputs:raise PermissionError('Original source changed')
        runtime_paths(self.config,True,require_fresh=False)
    @contextmanager
    def writer(self,*args):
        self.renew();primary=None
        try:
            with owned_context(super().writer(*args)):yield
        except BaseException as error:primary=error
        finish(primary,[self.renew])
    def admit(self,intent,context):
        self.renew();return super().admit(intent,context)

def run(settings):
    producer=ProducerConfig(Path(settings['umf_source']),Path(settings['bun']),Path(settings['git']),30,1024*1024,4*1024*1024)
    config=OriginalCommercePublicationConfig(Path(settings['publication_output']),Path(settings['model']),Path(settings['graph']),Path(settings['publication_jars']),producer)
    jars=runtime_paths(config,True);root=Path(settings['native_root'])
    if root.exists() or root.is_symlink():raise ValueError('Fresh explicit native root required')
    primary=None;spark=None;transport=None;targets=None;fd=None;gate=None;policy=None
    try:
        root.mkdir(mode=0o700)
        fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        gate=os.open(root/'.evolution-operator.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
        fcntl.flock(gate,fcntl.LOCK_EX|fcntl.LOCK_NB)
        from pyspark.sql import SparkSession
        spark=(SparkSession.builder.master('local[1]').appName('Original commerce public publication')
            .config('spark.driver.memory','512m').config('spark.sql.shuffle.partitions','1')
            .config('spark.databricks.delta.snapshotPartitions','1').config('spark.ui.enabled','false')
            .config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true')
            .config('spark.jars',','.join(str(x) for x in jars))
            .config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension')
            .config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog').getOrCreate())
        context=object();policy=BootstrapPolicy(context,(),config,root,fd,gate);policy.renew()
        columns=dict(fixture_columns(ROOT));columns['attempts']=tuple((x,'STRING') for x in ('stream','batch_id','phase','request_digest','payload_json','payload_digest'))
        columns['manifest']=tuple((x,'TIMESTAMP' if x=='recorded_at' else 'STRING') for x in FIELDS)
        selected=[]
        for role,schema in columns.items():
            policy.renew();path=root/role
            spark.sql('CREATE TABLE delta.`'+str(path)+'` ('+','.join(name+' '+kind for name,kind in schema)+') USING DELTA').collect()
            selected.append(DeltaTarget('local.original.'+role,path,spark.sql('DESCRIBE DETAIL delta.`'+str(path)+'`').first().id))
        targets=tuple(selected);policy.targets=targets;policy.renew()
        transport=LocalDeltaTransport.initialize(spark,root/'operations.sqlite',settings['installation_id'],targets,policy,context=context,capacity=LOCAL_OPERATION_CAPACITY_8M)
        transport.close();transport=None;policy.renew()
    except BaseException as error:primary=error
    finish(primary,([transport.close] if transport is not None else [])+([spark.stop] if spark is not None else [])+([policy.renew] if policy is not None else [])+([lambda:os.close(gate)] if gate is not None else [])+([lambda:os.close(fd)] if fd is not None else []))
    @contextmanager
    def native():
        selected=None;primary=None
        try:
            selected=(SparkSession.builder.master('local[1]').appName('Original commerce admitted publisher')
                .config('spark.driver.memory','512m').config('spark.sql.shuffle.partitions','1')
                .config('spark.databricks.delta.snapshotPartitions','1').config('spark.ui.enabled','false')
                .config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true')
                .config('spark.jars',','.join(str(x) for x in jars))
                .config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension')
                .config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog').getOrCreate())
            yield selected
        except BaseException as error:primary=error
        finish(primary,([selected.stop] if selected is not None else []))
    operator=OriginalCommercePublicationOperator(settings['installation_id'],root/'operations.sqlite',targets,provider_a.publication_ports(),LOCAL_OPERATION_CAPACITY_8M,native)
    return publish_original_commerce(config,operator=operator)

if __name__=='__main__':
    settings,inventory,source,scope=provider_a.selected()
    result=run(settings)
    print(json.dumps({'complete':True,'source_transaction_sha256':result['source_transaction_sha256'],'record_count':result['record_count'],'edge_count':result['edge_count']}))
