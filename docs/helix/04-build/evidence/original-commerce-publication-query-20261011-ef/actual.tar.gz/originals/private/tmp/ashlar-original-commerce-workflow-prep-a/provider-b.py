"""Explicit selected original-fixture ports; no setup, discovery or environment."""
import json
from pathlib import Path
from ashlar_host.ack import AckScope
from ashlar_host.lifecycle import owned_context
from ashlar_host.source_sessions import OutboxSourceRegistration
from ashlar_host.existing_outbox_authority import OutboxAuthorityRegistration
from ashlar_host.commerce_publication_sources import OriginalCommerceSourcePorts,FEED,EPOCH
from ashlar_host.commerce_query_sources import CommerceQuerySourceFactory
from ashlar_host.ordinary_query_connection import OrdinaryQueryConnectionFactory
SETTINGS=Path('/private/tmp/ashlar-original-commerce-workflow-prep-a/run-settings.json')

def selected():
    def load(path):
        with owned_context(path.open('rb')) as stream:raw=stream.read(1024*1024+1)
        if len(raw)>1024*1024:raise ValueError('Bounded explicit metadata required')
        def pairs(items):
            value={}
            for key,item in items:
                if key in value:raise ValueError('Duplicate metadata key')
                value[key]=item
            return value
        return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda value:(_ for _ in ()).throw(ValueError('Nonfinite metadata')))
    settings=load(SETTINGS)
    inventory=load(Path(settings['fixture_inventory']))
    if inventory['format']!='ashlar-private-outbox-fixture/0.1' or inventory['authentication']!='loopback-trust':raise ValueError('Explicit development fixture required')
    if len(inventory['sources'])!=2:raise ValueError('Closed two-scope fixture required')
    selected=[item for item in inventory['sources'] if item['scope']['feed']==FEED and item['scope']['epoch']==EPOCH]
    if len(selected)!=1:raise ValueError('One exact original source required')
    source=selected[0];scope=AckScope(**source['scope'])
    if scope.feed!=FEED or scope.epoch!=EPOCH:raise ValueError('Original feed/epoch required')
    endpoint=inventory['endpoint']
    if endpoint!={'host':'127.0.0.1','port':settings['postgres_port'],'database':'truss_e2e'}:raise ValueError('Selected original endpoint differs')
    return settings,inventory,source,scope

def open_role(role):
    settings,inventory,source,scope=selected()
    if type(role) is not str or role not in (source['writer_role'],source['reader_role'],source['ack_role']):raise ValueError('Closed original ordinary role required')
    import psycopg
    return psycopg.connect(host='127.0.0.1',port=settings['postgres_port'],dbname='truss_e2e',user=role,password='',passfile='/dev/null',sslmode='disable',gssencmode='disable',options='-c statement_timeout=15000 -c lock_timeout=5000',connect_timeout=5,autocommit=False)

def registration():
    settings,inventory,s,scope=selected()
    source=OutboxSourceRegistration(scope,s['schema'],s['binding']['source_signature_sha256'],lambda context:open_role(s['reader_role']))
    return OutboxAuthorityRegistration(source,s['reader_role'],s['ack_role'],'truss_e2e',lambda context:open_role(s['ack_role']))

def publication_ports():
    settings,inventory,s,scope=selected()
    return OriginalCommerceSourcePorts(registration(),s['writer_role'],lambda context:open_role(s['writer_role']))

def ordinary_query_connection_factory(config):
    settings,inventory,s,scope=selected()
    endpoint=config.postgres
    if (endpoint.container,endpoint.host,endpoint.port,endpoint.database)!=(inventory['container'],'127.0.0.1',settings['postgres_port'],'truss_e2e'):raise ValueError('Explicit query endpoint correspondence required')
    return OrdinaryQueryConnectionFactory(open_role)

def commerce_query_source_factory(config):
    ordinary_query_connection_factory(config)
    return CommerceQuerySourceFactory(registration())
