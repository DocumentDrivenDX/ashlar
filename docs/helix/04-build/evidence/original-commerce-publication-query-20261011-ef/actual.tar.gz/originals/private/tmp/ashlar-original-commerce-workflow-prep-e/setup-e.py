"""Read-only exact retained C fixture preflight; never provisions or resets."""
import importlib.util,json,hashlib,sys
from pathlib import Path
ROOT=Path('/private/tmp/ashlar-original-commerce-workflow-prep-e')
INVENTORY=Path('/private/tmp/ashlar-original-commerce-native-20261011-c/pg/inventory.json')
EXPECTED_ID='c6c94f79b2afd34c77521a74af4037b38238df1f712bb89522d69103e695294c'
def main():
 spec=importlib.util.spec_from_file_location('retained_original_provider',ROOT/'provider-e.py');provider=importlib.util.module_from_spec(spec);sys.modules[spec.name]=provider;spec.loader.exec_module(provider)
 from ashlar_host.lifecycle import finish
 from ashlar_host.resources import RESOURCE_ROOT
 spec=importlib.util.spec_from_file_location('retained_fixture_tool',ROOT/'host-source/tools/setup_private_outbox_fixture.py');tool=importlib.util.module_from_spec(spec);sys.modules[spec.name]=tool;spec.loader.exec_module(tool)
 settings,inventory,source,scope=provider.selected()
 if inventory['container_id']!=EXPECTED_ID or inventory['container']!='ashlar-private-outbox-original-20261011-c':raise ValueError('Exact retained C fixture required')
 runtime=tool.Runtime()
 import subprocess
 raw=runtime.command(['/usr/local/bin/docker','--host','unix:///Users/erik/.orbstack/run/docker.sock','inspect','--format','{{json .Id}} {{json .Name}} {{json .Image}}',EXPECTED_ID],timeout=10)
 image=inventory['image']
 if type(image)is not dict or set(image)!={'architecture','digests','os'} or image['architecture']!='arm64' or image['os']!='linux' or type(image['digests'])is not list or len(image['digests'])!=1 or type(image['digests'][0])is not str or image['digests'][0]!='postgres@sha256:2a0d0fe14825b0939f78a8cad5cd4e6aa68bf94d0e5dd96e24b6d23af4315545':raise ValueError('Exact selected cached image metadata required')
 cached=runtime.command(['/usr/local/bin/docker','--host','unix:///Users/erik/.orbstack/run/docker.sock','image','inspect','--format','{{json .Id}}',image['digests'][0]],timeout=10)
 parts=raw.decode().strip().split()
 if len(parts)!=3 or json.loads(parts[0])!=EXPECTED_ID or json.loads(parts[1])!='/'+inventory['container'] or json.loads(parts[2])!=json.loads(cached):raise ValueError('Current selected container identity differs')
 facts=[]
 for role in (source['writer_role'],source['reader_role'],source['ack_role']):
  connection=provider.open_role(role);primary=None
  try:
   identity=tool.ordinary_identity(connection,role,'truss_e2e')
   if role==source['reader_role']:
    head=connection.execute('SELECT position::text FROM '+source['schema']+'.head WHERE id=1').fetchone()
    count=connection.execute('SELECT count(*) FROM '+source['schema']+'.batch').fetchone()
    if type(head)is not tuple or head!=('0',) or type(count)is not tuple or type(count[0])is not int or count!=(0,):raise ValueError('Retained original source is not empty')
   if role==source['ack_role']:
    binding=connection.execute('SELECT '+scope.service_schema+'.scope_binding(%s::uuid)',(scope.scope_id,)).fetchone()[0]
    if binding!=source['binding']:raise ValueError('Current original binding/signature differs')
   facts.append(identity)
  except BaseException as error:primary=error
  finally:finish(primary,[connection.rollback,connection.close])
 print(json.dumps({'scope':'Read-only retained original C fixture empty-source preflight','container_id':EXPECTED_ID,'ordinaryIdentities':facts,'head':'0','batchCount':0},sort_keys=True))
if __name__=='__main__':main()
