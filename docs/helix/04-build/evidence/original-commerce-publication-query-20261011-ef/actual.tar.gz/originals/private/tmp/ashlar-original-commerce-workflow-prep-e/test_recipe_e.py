import importlib.util,json,os,sys,tempfile,unittest,hashlib
from pathlib import Path
from unittest.mock import patch,Mock
ROOT=Path('/private/tmp/ashlar-original-commerce-workflow-prep-e')
sys.path.insert(0,str(ROOT/'host-source/src'))
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
class Controls(unittest.TestCase):
    def test_current_closed_fixture_and_original_cli(self):
        tool=load('fixture_tool',ROOT/'host-source/tools/setup_private_outbox_fixture.py')
        value=json.loads((ROOT/'fixture-settings.json').read_text());sources=tuple(tool.Source(tool.AckScope(**x['scope']),x['schema'],x['writer'],x['reader'],x['ack']) for x in value['sources'])
        with tempfile.TemporaryDirectory() as directory:
            settings=tool.Settings(Path(value['docker']),value['docker_host'],value['image'],value['container'],value['port'],value['database'],value['authentication'],sources,Path(directory).resolve()/'fresh')
            settings.__post_init__()
        self.assertEqual(sum(s.scope.feed=='private-original-commerce-fixture' for s in sources),1)
        command=json.loads((ROOT/'command-e.json').read_text());argv=command['queryArgv']
        self.assertEqual(argv[argv.index('--postgres-profile')+1],'explicit-loopback')
        self.assertEqual(argv[argv.index('--jars')+1],'/private/tmp/ashlar-supply-chain-finite-native-jars-f')
        from ashlar_host.commerce_original_scenarios import commerce_original_cases
        cases=commerce_original_cases(Path(argv[argv.index('--pack')+1]).read_bytes())
        self.assertEqual(tuple(name for name,sql in cases),('partial-return','fulfillment','settlement','refund'))
    def test_actual_entry_forwards_explicit_jdk17_for_both_native_phases(self):
        module=load('selected_entry_d',ROOT/'entry-e.py')
        command=json.loads((ROOT/'command-e.json').read_bytes())
        java='/private/tmp/ashlar-original-commerce-jdk17-20261011-a/package/jdk4py/java-runtime'
        for key,mode in (('publicationEnvironment','publication'),('queryEnvironment','query')):
            self.assertEqual(command[key]['JAVA_HOME'],java)
            # Real entry consumes captured command; inherited selected child env is preserved.
            observed=[]
            with patch.dict(os.environ,command[key],clear=True),patch.object(sys,'argv',['entry',mode,'--command',str(ROOT/'command-e.json'),'--sha256',hashlib.sha256((ROOT/'command-e.json').read_bytes()).hexdigest()]),patch.object(module.runpy,'run_path',side_effect=lambda *a,**k:observed.append(os.environ['JAVA_HOME'])),patch('ashlar.cli.main',side_effect=lambda:observed.append(os.environ['JAVA_HOME'])):
                module.main()
            self.assertEqual(observed,[java])

    def test_actual_retained_preflight_selects_digest_and_preserves_cleanup_cancel(self):
        setup=load('retained_preflight_e',ROOT/'setup-e.py')
        inventory=json.loads(setup.INVENTORY.read_bytes())
        source=next(x for x in inventory['sources'] if x['scope']['feed']=='private-original-commerce-fixture')
        from ashlar_host.ack import AckScope
        scope=AckScope(**source['scope']);commands=[];connections=[]
        def command(runtime,argv,timeout=30):
            self.assertTrue(all(type(x)is str for x in argv));commands.append(argv)
            if argv[3]=='image':
                self.assertEqual(argv[-1],inventory['image']['digests'][0]);return b'"sha256:selected"'
            return json.dumps(setup.EXPECTED_ID).encode()+b' '+json.dumps('/'+inventory['container']).encode()+b' "sha256:selected"'
        def open_role(role):
            connection=Mock();connection.autocommit=False
            def execute(sql,*args):
                if 'scope_binding' in sql:return Mock(fetchone=lambda:(source['binding'],))
                if 'count(*)' in sql:return Mock(fetchone=lambda:(0,))
                return Mock(fetchone=lambda:('0',))
            connection.execute.side_effect=execute;connections.append(connection);return connection
        provider=type('Provider',(),{'selected':staticmethod(lambda:({},inventory,source,scope)),'open_role':staticmethod(open_role)})()
        original=setup.importlib.util.module_from_spec
        def selected(spec):
            module=original(spec);execute=spec.loader.exec_module
            def run(value):
                if spec.name=='retained_original_provider':
                    value.selected=provider.selected;value.open_role=provider.open_role
                else:
                    execute(value);value.Runtime.command=command;value.ordinary_identity=lambda connection,*args:connection.execute('identity').fetchone()
            spec.loader.exec_module=run;return module
        with patch.object(setup.importlib.util,'module_from_spec',side_effect=selected):setup.main()
        self.assertEqual(len(commands),2);self.assertEqual(len(connections),3)
        for connection in connections:connection.rollback.assert_called_once();connection.close.assert_called_once()
        cancel=KeyboardInterrupt('original-read');connections.clear()
        def canceled(role):
            connection=open_role(role);connection.execute.side_effect=cancel;connection.rollback.side_effect=OSError('rollback');connection.close.side_effect=OSError('close');return connection
        provider.open_role=canceled
        with patch.object(setup.importlib.util,'module_from_spec',side_effect=selected):
            try:setup.main()
            except KeyboardInterrupt as observed:self.assertIs(observed,cancel)
            else:self.fail('Original cancellation lost')
        for connection in connections:connection.rollback.assert_called_once();connection.close.assert_called_once()

    def test_bootstrap_named_lock_replacement_refuses(self):
        module=load('original_publication_probe',ROOT/'publication-e.py')
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory).resolve();root.chmod(0o700);lock=root/'.evolution-operator.lock'
            fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY);gate=os.open(lock,os.O_CREAT|os.O_RDWR,0o600)
            try:
                with patch.object(module,'original_inputs',return_value=(b'original',b'graph')),patch.object(module,'runtime_paths',return_value=[]):
                    policy=module.BootstrapPolicy(object(),(),Mock(),root,fd,gate);policy.renew()
                    lock.rename(root/'original-lock');lock.touch(mode=0o600)
                    with self.assertRaises(PermissionError):policy.renew()
            finally:os.close(gate);os.close(fd)
    def test_retention_primary_cancel_preserved_when_close_fails(self):
        module=load('original_runner',ROOT/'runner-e.py');cancel=KeyboardInterrupt('body');stream=Mock();stream.write.side_effect=cancel;stream.close.side_effect=OSError('close')
        path=Mock();path.open.return_value=stream
        try:module.retain(path,{'raw':'exact'})
        except KeyboardInterrupt as observed:self.assertIs(observed,cancel)
        else:self.fail('Original cancellation lost')
        stream.close.assert_called_once()
    def test_external_pin_refuses_changed_command_before_executable_import(self):
        launch=load('original_launcher',ROOT/'launch-e.py');entry=load('original_entry',ROOT/'entry-e.py')
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'command.json';original=b'{"original":true}';pin=hashlib.sha256(original).hexdigest();path.write_bytes(b'{"forged":true}')
            with patch.object(sys,'argv',['launch','--command',str(path),'--sha256',pin]),patch.object(launch.importlib.util,'spec_from_file_location') as executable:
                with self.assertRaises(ValueError):launch.main()
                executable.assert_not_called()
            with self.assertRaises(ValueError):entry.read_command(path,pin)

if __name__=='__main__':unittest.main()
