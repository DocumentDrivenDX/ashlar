"""Bounded prepared installed original-commerce workflow; no import-side effects."""
import hashlib,importlib.util,json,os,re,stat,time,zipfile,csv,base64,argparse
from pathlib import Path
ROOT=Path('/private/tmp/ashlar-original-commerce-workflow-prep-f')
COMMAND=ROOT/'command-a.json'
def select(primary,error):
    return error if primary is None or isinstance(primary,Exception) and not isinstance(error,Exception) else primary

def read(path,maximum=16*1024*1024):
    stream=Path(path).open('rb');primary=None;raw=None
    try:
        raw=stream.read(maximum+1)
        if len(raw)>maximum:raise ValueError('Bounded file required')
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
    return raw

def retain(path,value):
    raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();stream=path.open('xb');primary=None
    try:
        if stream.write(raw)!=len(raw):raise OSError('Short evidence write')
        stream.flush();os.fsync(stream.fileno())
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--command',required=True,type=Path);parser.add_argument('--sha256',required=True);args=parser.parse_args()
    if re.fullmatch('[0-9a-f]{64}',args.sha256) is None:raise ValueError('External command pin required')
    command_path=args.command
    raw=read(command_path,1024*1024)
    if hashlib.sha256(raw).hexdigest()!=args.sha256:raise ValueError('Externally selected command differs')
    command=json.loads(raw);start=time.monotonic();deadline=start+720
    output=Path(command['output']);records=[];primary=None;closing=False;capture=None;installed=[];owned_id=None;whole=None;host_namespaces={}
    def verify():
        if read(command_path,1024*1024)!=raw:raise ValueError('Original command changed')
        for item in command['resources']:
            if time.monotonic()>=deadline-30:raise TimeoutError('Closing budget required')
            p=Path(item['path']);info=p.lstat()
            if not stat.S_ISREG(info.st_mode):raise ValueError('Original regular resource required')
            b=read(p,max(1,item['size']))
            if len(b)!=item['size'] or hashlib.sha256(b).hexdigest()!=item['sha256']:raise ValueError('Resource changed')
        for directory,names in command['jarNamespaces'].items():
            if sorted(p.name for p in Path(directory).iterdir())!=names:raise ValueError('Exact selected JAR namespace required')
        for link in command['dockerLinks']:
            p=Path(link['path']);s=p.lstat()
            if not stat.S_ISLNK(s.st_mode) or os.readlink(p)!=link['target'] or (s.st_dev,s.st_ino)!=(link['device'],link['inode']):raise ValueError('Docker selected link changed')
    def phase(name,argv,cwd,env,seconds):
        remaining=deadline-time.monotonic()-30
        if remaining<1:raise TimeoutError('No phase budget remains')
        result=capture.capture(argv,cwd,env,output/(name+'.stdout'),output/(name+'.stderr'),min(seconds,remaining),4*1024*1024)
        records.append({'phase':name,'argv':argv,'capture':result})
        if result['exitCode']!=0:raise RuntimeError('Required phase refused: '+name)
        return result
    def installed_verify():
        for directory,expected in host_namespaces.items():
            actual=[]
            for p in Path(directory).rglob('*'):
                if p.is_symlink():raise ValueError('Installed host alias introduced')
                if p.is_file():actual.append(str(p.relative_to(directory)))
                elif not p.is_dir():raise ValueError('Unexpected installed host carrier')
            if sorted(actual)!=expected:raise ValueError('Installed host namespace changed')
        for item in installed:
            if hashlib.sha256(read(item['path'],max(1,item['size']))).hexdigest()!=item['sha256']:raise ValueError('Installed host changed')
    try:
        verify()
        if output.exists() or output.is_symlink():raise ValueError('Fresh whole output required')
        output.mkdir(mode=0o700)
        spec=importlib.util.spec_from_file_location('selected_capture',command['captureModule']);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
        prior=json.loads(read(Path(command['installedInventory'])))
        if prior['sourceRevision']!=command['sourceRevision']:raise ValueError('Original installed source differs')
        site=Path(command['hostSites']['query'])
        installed=[x for x in prior['files'] if str(x['path']).startswith(str(site)) or str(x['path']).startswith(str(site.parent.parent.parent/'bin'))]
        for package in ('ashlar','ashlar_host'):
            directory=site/package
            host_namespaces[str(directory)]=sorted(str(Path(x['path']).relative_to(directory)) for x in installed if Path(x['path']).is_relative_to(directory))
        installed_verify()
        fixture=json.loads(read(Path(command['retainedFixtureInventory']),1024*1024));owned_id=fixture['container_id']
        if owned_id!=command['retainedContainerId'] or fixture['container']!=command['container']:raise ValueError('Retained exact fixture differs')
        query_python='/private/tmp/ashlar-original-commerce-native-20261011-e/query-env/bin/python'
        phase('query',[query_python,'-I','-B','-S',str(ROOT/'entry-f.py'),'query','--command',str(command_path),'--sha256',args.sha256],str(ROOT),command['queryEnvironment'],300)
        report=json.loads(read(output/'query/report.json'))
        whole={'sourceRevision':command['sourceRevision'],'reportSha256':hashlib.sha256(read(output/'query/report.json')).hexdigest(),'qualification':'Four original042 queries admitted only by public host; independent actual bag review remains required.','retainedContainerId':owned_id}
    except BaseException as error:primary=error
    finally:
        try:verify();installed_verify();closing=True
        except BaseException as error:primary=select(primary,error)
        if primary is None and whole is not None:
            try:retain(output/'whole-result.json',whole)
            except BaseException as error:primary=select(primary,error)
        if output.is_dir():
            try:retain(output/'outer-receipt.json',{'commandSha256':hashlib.sha256(raw).hexdigest(),'phases':records,'closing':closing,'primary':None if primary is None else type(primary).__name__,'ownedContainerId':owned_id,'cleanup':'Container retained; no outer deletion based on unproven mutable handle. Public setup handles its positively acquired failures.','elapsedSeconds':time.monotonic()-start})
            except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
if __name__=='__main__':main()
