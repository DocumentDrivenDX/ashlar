"""Externally pinned command and explicit installed/runtime lookup roots."""
import sys,json,runpy,hashlib,argparse
from pathlib import Path
ROOT=Path('/private/tmp/ashlar-original-commerce-workflow-prep-a')
def select(primary,error):
    return error if primary is None or isinstance(primary,Exception) and not isinstance(error,Exception) else primary

def read_command(path,expected):
    stream=path.open('rb');primary=None;raw=None
    try:
        raw=stream.read(1024*1024+1)
        if len(raw)>1024*1024 or hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('Externally selected command differs')
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
    return raw

def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode');parser.add_argument('--command',required=True,type=Path);parser.add_argument('--sha256',required=True);args=parser.parse_args()
    if args.mode not in ('setup','publication','query'):raise ValueError('Closed phase required')
    raw=read_command(args.command,args.sha256);command=json.loads(raw);primary=None
    try:
        kind='query' if args.mode=='query' else 'publication'
        sys.path[:0]=[command['hostSites'][kind]]+command['sdkRoots'][kind]
        if args.mode=='setup':runpy.run_path(str(ROOT/'setup-a.py'),run_name='__main__')
        elif args.mode=='publication':runpy.run_path(str(ROOT/'publication-g.py'),run_name='__main__')
        else:
            sys.argv=command['queryArgv']
            from ashlar.cli import main as cli_main
            cli_main()
    except BaseException as error:primary=error
    try:
        if read_command(args.command,args.sha256)!=raw:raise ValueError('Original command changed')
    except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
if __name__=='__main__':main()
