"""Explicit separately authorized fresh fixture using unchanged public setup."""
import importlib.util,json
from pathlib import Path
CONFIG=Path('/private/tmp/ashlar-original-commerce-workflow-prep-c/fixture-settings.json')
TOOL=Path('/private/tmp/ashlar-original-commerce-workflow-prep-c/host-source/tools/setup_private_outbox_fixture.py')
def main():
    spec=importlib.util.spec_from_file_location('selected_private_setup',TOOL)
    module=importlib.util.module_from_spec(spec)
    import sys
    sys.modules[spec.name]=module;spec.loader.exec_module(module)
    value=json.loads(CONFIG.read_bytes())
    sources=tuple(module.Source(module.AckScope(**s['scope']),s['schema'],s['writer'],s['reader'],s['ack']) for s in value['sources'])
    settings=module.Settings(Path(value['docker']),value['docker_host'],value['image'],value['container'],value['port'],value['database'],value['authentication'],sources,Path(value['output']))
    return module.setup(settings,module.Runtime())
if __name__=='__main__':main()
