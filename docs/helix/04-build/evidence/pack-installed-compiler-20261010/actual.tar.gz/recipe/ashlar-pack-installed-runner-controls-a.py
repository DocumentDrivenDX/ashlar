import importlib.util
s=importlib.util.spec_from_file_location('runner','/private/tmp/ashlar-pack-installed-compile-runner-a.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Stream:
 def __init__(self,body,closing):self.body=body;self.closing=closing
 def write(self,raw):raise self.body
 def close(self):raise self.closing
class Selected:
 def __init__(self,body,closing):self.stream=Stream(body,closing)
 def open(self,mode):return self.stream
for body,closing,expected in [(KeyboardInterrupt(),ValueError(),0),(ValueError(),SystemExit(),1),(KeyboardInterrupt(),SystemExit(),0)]:
 try:m.write(Selected(body,closing),b'x')
 except BaseException as actual:assert actual is (body if expected==0 else closing)
 else:raise AssertionError('failure lost')
print('3 cancellation identities PASS')
