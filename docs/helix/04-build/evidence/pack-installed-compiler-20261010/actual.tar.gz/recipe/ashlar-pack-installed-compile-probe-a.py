"""Installed public original17 compile APIs; no native/source authority grant."""
import sys
if sys.path[0]!='/private/tmp':raise ValueError('Explicit selected probe required')
del sys.path[0]
import json,hashlib
from pathlib import Path
from ashlar.weft_count_star_distribution import CountStarDistributionPaths
from ashlar_host.finite_pack import FinitePackDefinition
from ashlar_host.pack_count_star_compile import PackCountStarCompileConfig,compile_pack_count_star_cases
from ashlar_host.pack_count_star_oracle import pack_count_star_result_oracle
from ashlar_host.lifecycle import owned_context
WORK=Path('/private/tmp/ashlar-pack-installed-compile-a');REPO=Path('/Users/erik/Projects/ashlar');OUTPUT=WORK/'compile-output';OUTPUT.mkdir(mode=0o700)
SITE=WORK/'venv/lib/python3.11/site-packages'
import ashlar_host.pack_count_star_compile as selected
if not Path(selected.__file__).is_relative_to(SITE):raise ValueError('Installed package selection required')
config=PackCountStarCompileConfig(CountStarDistributionPaths(Path('/private/tmp/ashlar-count-star-fresh-install-e/checkout/distributions/index.json'),Path('/private/tmp/ashlar-count-star-installed-cli-c/weft-installation')),1048576)
results=[];observed=0
with owned_context((OUTPUT/'observations.jsonl').open('xb'))as log:
 for name in ('archaeology','ecology'):
  root=REPO/'examples/domain-packs'/name/'upstream';pack=(root/'pack.json').read_bytes();model=(root/'ontology.json').read_bytes();graph=(root/'graph/fixture.json').read_bytes();definition=FinitePackDefinition(name)
  report=json.loads((REPO/'docs/helix/04-build/evidence'/(name+'-native-publication-20261009.json')).read_bytes());manifest=report['native_manifest'];registry=report['table_registry'];aliases={table:table.replace('local.','spark_catalog.',1)for table in json.loads(manifest['table_versions_json'])};_,bindings=definition.build(model,graph)
  def observe(case,iteration,request,response):
   global observed
   if any(type(raw)is not bytes or len(raw)>1048576 for raw in (request,response)):raise ValueError('Raw compile artifact bound')
   raw=(json.dumps({'pack':name,'id':case,'iteration':iteration,'requestHex':request.hex(),'responseHex':response.hex()},separators=(',',':'))+'\n').encode();observed+=len(raw)
   if observed>33554432:raise ValueError('Complete original34 observation bound')
   for kind,body in (('request',request),('response',response)):
    with owned_context((OUTPUT/(name+'-'+case+'-'+str(iteration)+'.'+kind)).open('xb'))as stream:
     if stream.write(body)!=len(body):raise ValueError('Raw artifact write refused')
   if log.write(raw)!=len(raw):raise ValueError('Original compiler observation write refused')
   log.flush()
  compiled=compile_pack_count_star_cases(config,definition,pack,model,graph,bindings,manifest,registry,aliases,observe=observe)
  original=definition.cases(model,graph,pack)
  if [case['id']for case in compiled['cases']]!=[name for name,_ in original]:raise ValueError('Complete original case order differs')
  for case in compiled['cases']:
   if case['sourceOracle']!=pack_count_star_result_oracle(definition,case['id'],model,graph):raise ValueError('Complete independent original source bag differs')
   results.append({'pack':name,'id':case['id'],'requestSha256':hashlib.sha256(case['requestBytes']).hexdigest(),'responseSha256':hashlib.sha256(case['responseBytes']).hexdigest(),'requiredCapabilities':case['response']['logicalPlan']['requiredCapabilities'],'sourceOracle':case['sourceOracle']})
if len(results)!=17:raise ValueError('Complete original17 scenarios required')
result={'cases':results,'originalCases':17,'actualCompiles':34,'qualification':'Fresh installed public pack compile APIs: all original8archaeology/9ecology SQL twice, offline041admission and complete independent original graph oracle/carrier correspondence only. Retained publication metadata is compiler binding data, never source/native/publication/ACK authority.'}
body=bytearray()
for chunk in json.JSONEncoder(separators=(',',':'),ensure_ascii=True).iterencode(result):
 raw=chunk.encode()
 if len(body)+len(raw)+1>16777216:raise ValueError('Complete result report bound')
 body.extend(raw)
body.extend(b'\n')
with owned_context((OUTPUT/'report.json').open('xb'))as log:
 if log.write(body)!=len(body):raise ValueError('Complete compiler report write refused')
print(json.dumps({'originalCases':17,'actualCompiles':34,'qualification':result['qualification']}))
