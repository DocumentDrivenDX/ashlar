"""Import-only opening/closing selected runtime observation; no Spark or PG calls."""
import sys,json,os,hashlib,importlib.metadata as metadata
from pathlib import Path
import ashlar,ashlar.cli,ashlar_host.evolution_verification as owner
import pyspark,delta,psycopg,psycopg_binary,typing_extensions
WORK=Path('/private/tmp/ashlar-evolution-installed-verification-20261011-d');SITE=WORK/'venv/lib/python3.9/site-packages'
JAVA=Path('/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home')
assert sys.version_info[:2]==(3,9) and sys.executable==str(WORK/'venv/bin/python')
expected={ashlar:SITE/'ashlar/__init__.py',ashlar.cli:SITE/'ashlar/cli.py',owner:SITE/'ashlar_host/evolution_verification.py',pyspark:Path('/private/tmp/ashlar-spark4-python39-bridge/pyspark/__init__.py'),delta:Path('/private/tmp/ashlar-indexed-delta4-python-20261010-a/delta/__init__.py'),psycopg:Path('/private/tmp/ashlar-evolution-selected-pg-site-a/psycopg/__init__.py'),psycopg_binary:Path('/private/tmp/ashlar-evolution-selected-pg-site-a/psycopg_binary/__init__.py'),typing_extensions:WORK/'typing-site/typing_extensions.py'}
for module,path in expected.items():assert Path(module.__file__)==path and not path.is_symlink()
assert pyspark.__version__=='4.0.1' and metadata.version('pyspark')=='4.0.1'
assert metadata.version('delta-spark')=='4.0.0'
assert psycopg.__version__=='3.2.13' and metadata.version('psycopg_binary')=='3.2.13' and psycopg.pq.__impl__=='binary'
assert metadata.version('ashlar-graph-toolkit')=='0.1.0.dev0'
source=Path('/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages/typing_extensions-4.16.0.dist-info/METADATA')
assert source.stat().st_size<=65536 and '\nVersion: 4.16.0\n'in source.read_text()
assert (WORK/'typing-site/typing_extensions.py').stat().st_size<=1048576
assert hashlib.sha256((WORK/'typing-site/typing_extensions.py').read_bytes()).hexdigest()=='4040ca1a1ecbee00d1385c12a93084d1c5bd46f0b774f07e5ae7e91c4f55e696'
assert os.environ['JAVA_HOME']==str(JAVA)
release=JAVA/'release';assert release.stat().st_size<=16384
assert 'JAVA_VERSION="21.0.12.1"'in release.read_text()
print(json.dumps({'python':sys.executable,'pythonVersion':list(sys.version_info[:3]),'owners':{module.__name__:str(path)for module,path in expected.items()},'pyspark':'4.0.1','delta':'4.0.0','psycopg':'3.2.13','psycopgBinary':psycopg.pq.__impl__,'typingSourceVersion':'4.16.0','typingSourceSha256':'4040ca1a1ecbee00d1385c12a93084d1c5bd46f0b774f07e5ae7e91c4f55e696','javaHome':str(JAVA),'javaRelease':'21.0.12.1','scope':'Import-only selected origins; no Spark startup or PostgreSQL connection'},sort_keys=True))
