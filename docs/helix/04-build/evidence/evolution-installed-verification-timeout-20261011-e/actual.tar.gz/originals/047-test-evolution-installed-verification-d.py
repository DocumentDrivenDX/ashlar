"""Preparation-only real public typed interface and fixed runner call controls."""
import ast,importlib.util,json,sys,unittest
from pathlib import Path
from contextlib import contextmanager
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
from ashlar_host.evolution_verification_cli import parse_verification_invocation
BASE=Path('/private/tmp');PREFIX='ashlar-evolution-installed-verification'
def load(name):
 p=BASE/(PREFIX+'-'+name+'-d.py');spec=importlib.util.spec_from_file_location('prepared_verification_'+name,p);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);return module
class Tests(unittest.TestCase):
 def setUp(self):
  self.invocation=parse_verification_invocation((BASE/(PREFIX+'-invocation-a.json')).read_bytes());self.provider=load('provider')
 def test_actual_typed_parser_and_finite_actual_runner_call(self):
  self.assertEqual(self.invocation.ordinal,0);self.assertEqual(self.invocation.supervision.deadline_seconds,300)
  tree=ast.parse((BASE/(PREFIX+'-runner-a.py')).read_text());call=next(n for n in ast.walk(tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='run'and n.args and isinstance(n.args[0],ast.Constant)and n.args[0].value=='verify')
  configuration=json.loads((BASE/(PREFIX+'-invocation-a.json')).read_text());seen=[]
  def run(*args,**kwargs):seen.append((args,kwargs))
  node=ast.Expression(call)
  eval(compile(ast.fix_missing_locations(node),'<actual runner native call>','eval'),{'run':run,'WORK':BASE/(PREFIX+'-20261011-a'),'Path':Path,'str':str,'configuration':configuration,'path':BASE/'not-executed-config','provider':BASE/(PREFIX+'-provider-a.py'),'sha':lambda raw:__import__('hashlib').sha256(raw).hexdigest()})
  self.assertEqual(seen[0][1],{'timeout':300,'maximum':1048576});self.assertIn('verify-commerce-evolution-publication',seen[0][0][1]);self.assertNotIn('continue-commerce-evolution',seen[0][0][1])
 def test_closed_selection_refuses_before_sdk_acquisition(self):
  for invocation in (replace(self.invocation,ordinal=1),replace(self.invocation,expected_sha256='0'*64)):
   with patch.dict(sys.modules,{'pyspark':None,'pyspark.sql':None}):
    with self.assertRaises(PermissionError):
     with self.provider.open_verification(invocation):self.fail('refused selection entered')
 def test_actual_provider_cancellation_and_all_cleanup(self):
  events=[];primary=KeyboardInterrupt('owning body')
  class Builder:
   def master(self,value):events.append(('master',value));return self
   def appName(self,value):return self
   def config(self,key,value):events.append((key,value));return self
   def getOrCreate(self):events.append('start');return SimpleNamespace(stop=lambda:stop())
  def stop():events.append('stop');raise OSError('stop failure')
  class Operator:
   def __init__(self,*args):events.append(('operator',len(args[3]),len(args[4])))
   @contextmanager
   def open_verification(self,invocation):
    try:yield SimpleNamespace()
    finally:events.append('operator-close');raise OSError('closing failure')
  with patch.object(self.provider,'ExistingEvolutionOperator',Operator),patch.dict(sys.modules,{'pyspark':SimpleNamespace(),'pyspark.sql':SimpleNamespace(SparkSession=SimpleNamespace(builder=Builder()))}):
   with self.assertRaises(KeyboardInterrupt)as caught:
    with self.provider.open_verification(self.invocation):raise primary
  self.assertIs(caught.exception,primary);self.assertIn(('operator',6,2),events);self.assertLess(events.index('operator-close'),events.index('stop'))
  self.assertIn(('master','local[1]'),events);self.assertIn(('spark.driver.memory','512m'),events);self.assertIn(('spark.executorEnv.PYTHONDONTWRITEBYTECODE','1'),events)
 def test_actual_ordinary_factories_explicit_no_discovery_and_no_fault_transform(self):
  helper=load('helper');selected=helper.FixtureSelection.capture('/private/tmp/ashlar-private-outbox-fixture-prep-b/operation/fixture-c/inventory.json','f6f77011c66650b4eecc7efe034806a36db0e54c4bc1e4babdfd5d6eb8c1c7b9');seen=[]
  def connect(**kwargs):seen.append(kwargs);return SimpleNamespace(close=lambda:None)
  with patch.dict(sys.modules,{'psycopg':SimpleNamespace(connect=connect)}):
   for registration in helper.registrations(selected):
    registration.source.connection_factory(object());registration.metadata_factory(object())
  self.assertEqual(len(seen),4)
  for values in seen:
   self.assertEqual((values['host'],values['port'],values['dbname']),('127.0.0.1',25433,'truss_e2e'));self.assertEqual(values['password'],'');self.assertEqual(values['passfile'],'/dev/null');self.assertEqual(values['sslmode'],'disable');self.assertEqual(values['gssencmode'],'disable')
 def test_actual_probe_fixed_origin_guards_and_independent_runner_closing(self):
  import types,os,hashlib,importlib.metadata
  probe_path=BASE/(PREFIX+'-import-probe-b.py');raw=probe_path.read_bytes();code=compile(raw,str(probe_path),'exec')
  work=BASE/(PREFIX+'-20261011-b');site=work/'venv/lib/python3.9/site-packages'
  paths={'ashlar':site/'ashlar/__init__.py','ashlar.cli':site/'ashlar/cli.py','ashlar_host.evolution_verification':site/'ashlar_host/evolution_verification.py','pyspark':BASE/'ashlar-spark4-python39-bridge/pyspark/__init__.py','delta':BASE/'ashlar-indexed-delta4-python-20261010-a/delta/__init__.py','psycopg':BASE/'ashlar-evolution-selected-pg-site-a/psycopg/__init__.py','psycopg_binary':BASE/'ashlar-evolution-selected-pg-site-a/psycopg_binary/__init__.py','typing_extensions':work/'typing-site/typing_extensions.py'}
  modules={name:types.ModuleType(name)for name in paths}
  for name,module in modules.items():module.__file__=str(paths[name])
  modules['ashlar'].cli=modules['ashlar.cli'];modules['ashlar'].__path__=[]
  modules['ashlar_host']=types.ModuleType('ashlar_host');modules['ashlar_host'].__path__=[];modules['ashlar_host'].evolution_verification=modules['ashlar_host.evolution_verification']
  modules['pyspark'].__version__='4.0.1';modules['psycopg'].__version__='3.2.13';modules['psycopg'].pq=SimpleNamespace(__impl__='binary')
  versions={'pyspark':'4.0.1','delta-spark':'4.0.0','psycopg_binary':'3.2.13','ashlar-graph-toolkit':'0.1.0.dev0'}
  source=Path('/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages/typing_extensions.py').read_bytes()
  with patch.dict(sys.modules,modules),patch.object(sys,'executable',str(work/'venv/bin/python')),patch.object(sys,'version_info',(3,9,6)),patch.dict(os.environ,{'JAVA_HOME':'/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home'}),patch('importlib.metadata.version',side_effect=lambda name:versions[name]),patch.object(Path,'stat',return_value=SimpleNamespace(st_size=100)),patch.object(Path,'is_symlink',return_value=False),patch.object(Path,'read_bytes',return_value=source),patch.object(Path,'read_text',side_effect=lambda:'\nVersion: 4.16.0\nJAVA_VERSION="21.0.12.1"'),patch('builtins.print'):
   exec(code,{'__name__':'actual_probe_control'})
   modules['pyspark'].__file__='/unselected/pyspark/__init__.py'
   with self.assertRaises(AssertionError):exec(code,{'__name__':'actual_probe_control'})
   modules['pyspark'].__file__=str(paths['pyspark']);versions['delta-spark']='3.2.1'
   with self.assertRaises(AssertionError):exec(code,{'__name__':'actual_probe_control'})
  tree=ast.parse((BASE/(PREFIX+'-runner-b.py')).read_text())
  loops=[node for node in ast.walk(tree)if isinstance(node,ast.For)and isinstance(node.target,ast.Name)and node.target.id=='close']
  closing=next(node for node in loops if 'import_closing' in ast.unparse(node.iter))
  selected=ast.Module(body=[closing],type_ignores=[]);events=[];primary=KeyboardInterrupt('native body')
  def callback(label):
   def close():events.append(label);raise OSError('independent closing failure')
   return close
  scope={'primary':primary,'select_failure':lambda primary,closing:primary,'import_closing':callback('imports'),'source_custody':callback('source'),'interpreter':callback('interpreter'),'installed_custody':callback('installed'),'verify_namespace':callback('namespace'),'BaseException':BaseException}
  exec(compile(ast.fix_missing_locations(selected),'<actual independent runner closing>','exec'),scope)
  self.assertIs(scope['primary'],primary);self.assertEqual(events,['imports','source','interpreter','installed','namespace'])
 def test_actual_runner_input_pin_matches_selected_bytes_and_refuses_drift_before_write(self):
  tree=ast.parse((BASE/(PREFIX+'-runner-b.py')).read_text());main=next(node for node in tree.body if isinstance(node,ast.FunctionDef)and node.name=='main')
  body=next(node for node in main.body if isinstance(node,ast.Try)and any(isinstance(item,ast.Assign)and any(isinstance(target,ast.Name)and target.id=='invocation_raw'for target in item.targets)for item in node.body)).body
  start=next(index for index,node in enumerate(body)if isinstance(node,ast.Assign)and any(isinstance(target,ast.Name)and target.id=='invocation_raw'for target in node.targets))
  selected=ast.Module(body=body[start:start+5],type_ignores=[]);code=compile(ast.fix_missing_locations(selected),'<actual runner invocation gate>','exec')
  raw=(BASE/(PREFIX+'-invocation-b.json')).read_bytes();calls=[]
  def read(path,maximum):
   self.assertEqual(path,BASE/(PREFIX+'-invocation-b.json'));self.assertEqual(maximum,262144);return raw
  scope={'bounded_read':read,'Path':Path,'sha':lambda raw:__import__('hashlib').sha256(raw).hexdigest(),'json':json,'WORK':BASE/(PREFIX+'-20261011-b'),'write':lambda *args:calls.append(args),'ValueError':ValueError}
  exec(code,scope);self.assertEqual(scope['configuration'],json.loads(raw));self.assertEqual(calls[0][1],raw)
  scope['bounded_read']=lambda *args:raw+b' ';calls.clear()
  with self.assertRaises(ValueError):exec(code,scope)
  self.assertEqual(calls,[])
if __name__=='__main__':unittest.main()
