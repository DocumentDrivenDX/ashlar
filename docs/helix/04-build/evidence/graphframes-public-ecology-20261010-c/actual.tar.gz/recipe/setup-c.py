"""Actual installed shipped setup only. No provider/session or engine execution."""
import hashlib,json,os,sys
from pathlib import Path
from ashlar_host.finite_pack import FinitePackDefinition
from ashlar_host.finite_dataset import FiniteDatasetConfig
from ashlar_host.graphframes_local import RetainedGraphFramesLocalConfig,local_encoded
from ashlar_host.graphframes_local_setup import setup_retained_graphframes
from ashlar_host.graphframes_release import GraphFramesRuntimeConfig
from ashlar_host.lifecycle import finish
SELECTED=Path('/private/tmp/ashlar-graphframes-local-ecology-inputs-c/selected-operator.json')
raw=SELECTED.read_bytes()
if hashlib.sha256(raw).hexdigest()!='29fa6b186da776aea037f09eb9b21fcf7cddfe3ebf6b286a53a7a3fbffecf319':raise ValueError('Independently selected operator inputs changed')
s=json.loads(raw)
if sys.flags.isolated!=1 or str(Path(sys.executable))!=s['python']:raise ValueError('Selected actual installed isolated interpreter required')
if any(name==sdk or name.startswith(sdk+'.') for name in sys.modules for sdk in ('pyspark','delta','graphframes')):raise ValueError('Setup cannot import nativeSDK')
producer=FiniteDatasetConfig(FinitePackDefinition('ecology'),Path(s['source']),Path(s['bun']),Path(s['git']),s['producer_timeout_seconds'],s['producer_maximum_output_bytes'],s['producer_maximum_receipt_bytes'])
config=RetainedGraphFramesLocalConfig(producer,Path(s['model']),s['model_sha256'],Path(s['graph']),s['graph_sha256'],Path(s['pack']),s['pack_sha256'],Path(s['release']),s['release_sha256'],Path(s['custody']),s['custody_sha256'],local_encoded(s['ack_scope']),Path(s['runtime_plan']),s['runtime_plan_sha256'],Path(s['lease']))
runtime=GraphFramesRuntimeConfig(Path(s['python']),s['python_sha256'],Path(s['java_home']),s['java_sha256'],s['revision'],s['worker_inventory_sha256'],s['sdk_inventory_sha256'],Path(s['jars']),Path(s['output'])/'engine',300,1048576,16777216)
result=setup_retained_graphframes(config,runtime,Path(s['setup']),Path(s['output']))
if SELECTED.read_bytes()!=raw or any(name==sdk or name.startswith(sdk+'.') for name in sys.modules for sdk in ('pyspark','delta','graphframes')):raise ValueError('Setup closing original input orSDK state changed')
stream=None;primary=None
try:
 stream=(Path(s['setup']).parent/'setup-result.json').open('xb');body=local_encoded(result)
 if stream.write(body)!=len(body):raise ValueError('Incomplete setup result')
 stream.flush();os.fsync(stream.fileno())
except BaseException as error:primary=error
finish(primary,[lambda:stream.close() if stream is not None else None])
print(json.dumps(result,sort_keys=True))
