"""Reviewed Stage2 recipe: shipped setup -> generated provider -> installed console."""
import hashlib,importlib.util,json,os,sys,time
from pathlib import Path
ROOT=Path('/private/tmp/ashlar-graphframes-local-ecology-operation-c')
STAGE=Path('/private/tmp/ashlar-graphframes-local-installed-20261010-a')
CLOSURE=Path('/private/tmp/ashlar-graphframes-local-ecology-closure-c.json')
CLOSURE_SHA='2972004d0b3f41010a9e9ff110bac1506046c1cf065e964214992c767c323417'
SELECTED=Path('/private/tmp/ashlar-graphframes-local-ecology-inputs-c/selected-operator.json')
ENV={'PATH':'/private/tmp/ashlar-db-client/lib/python3.9/site-packages/jdk4py/java-runtime/bin:/usr/bin:/bin','JAVA_HOME':'/private/tmp/ashlar-db-client/lib/python3.9/site-packages/jdk4py/java-runtime','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','SPARK_LOCAL_IP':'127.0.0.1','SPARK_LOCAL_HOSTNAME':'localhost','PYSPARK_PYTHON':str(STAGE/'venv/bin/python'),'PYSPARK_DRIVER_PYTHON':str(STAGE/'venv/bin/python')}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def select(primary,closing):
 if primary is None or isinstance(primary,Exception) and not isinstance(closing,Exception):return closing
 return primary
def write(path,raw):
 stream=None;primary=None
 try:
  stream=path.open('xb')
  if stream.write(raw)!=len(raw):raise ValueError('Incomplete retained actual receipt')
  stream.flush();os.fsync(stream.fileno())
 except BaseException as error:primary=error
 if stream is not None:
  try:stream.close()
  except BaseException as error:primary=select(primary,error)
 if primary is not None:raise primary
def read(path,maximum):
 if path.is_symlink() or not path.is_file() or path.stat().st_size>maximum:raise ValueError('Selected file shape/bound')
 stream=None;primary=None;raw=None
 try:
  stream=path.open('rb');raw=stream.read(maximum+1)
  if len(raw)>maximum:raise ValueError('Selected file bound')
 except BaseException as error:primary=error
 if stream is not None:
  try:stream.close()
  except BaseException as error:primary=select(primary,error)
 if primary is not None:raise primary
 return raw

def verify():
 raw=read(CLOSURE,16777216)
 if sha(raw)!=CLOSURE_SHA:raise ValueError('Selected closure changed')
 plan=json.loads(raw)
 for path in plan['absent_startup_paths']:
  if Path(path).exists() or Path(path).is_symlink():raise ValueError('Selected startup absence changed')
 links=[{'path':str(p),'target':os.readlink(p),'resolved':str(p.resolve())}for root in plan['roots']for p in sorted(Path(root).rglob('*'))if p.is_symlink()]
 if links!=plan['symlinks']:raise ValueError('Complete selected namespace links changed')
 for root in plan['roots']:
  actual={str(p.resolve())for p in Path(root).rglob('*')if p.is_file()}
  expected={p for p in plan['files']if p.startswith(str(Path(root).resolve())+'/')}
  if actual!=expected:raise ValueError('Selected complete closure membership changed')
 if len(plan['files'])>12000 or sum(p['bytes']for p in plan['files'].values())>838860800:raise ValueError('Bounded selected closure required')
 for path,pin in plan['files'].items():
  p=Path(path)
  if p.is_symlink() or not p.is_file() or p.stat().st_size!=pin['bytes']:raise ValueError('Selected custody shape changed')
  h=hashlib.sha256();stream=None;primary=None
  try:
   stream=p.open('rb')
   for block in iter(lambda:stream.read(262144),b''):h.update(block)
  except BaseException as error:primary=error
  if stream is not None:
   try:stream.close()
   except BaseException as error:primary=select(primary,error)
  if primary is not None:raise primary
  if h.hexdigest()!=pin['sha256']:raise ValueError('Selected original bytes changed')

def main():
 verify()
 if ROOT.exists() or ROOT.is_symlink():raise ValueError('Fresh explicit Stage2 operation required')
 ROOT.mkdir(mode=0o700);(ROOT/'tmp').mkdir(mode=0o700);ENV['TMPDIR']=str(ROOT/'tmp')
 spec=importlib.util.spec_from_file_location('owned_capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
 selected=json.loads(read(SELECTED,65536));python=STAGE/'venv/bin/python';phases=[];deadline=time.monotonic()+420
 def run(label,argv,seconds):
  remaining=deadline-time.monotonic()
  if remaining<1:raise ValueError('Stage2 operation deadline')
  stdout=ROOT/(label+'.stdout');stderr=ROOT/(label+'.stderr')
  result=capture.capture(argv,str(ROOT),ENV,str(stdout),str(stderr),min(seconds,int(remaining)),16777216,None)
  value={'phase':label,**result,'stdout_sha256':sha(read(stdout,16777216)),'stderr_sha256':sha(read(stderr,16777216))};phases.append(value);write(ROOT/(label+'.json'),enc(value))
  if result['exitCode']!=0:raise ValueError('Actual public phase refused: '+label)
 run('public-setup',[str(python),'-I','-B','/private/tmp/ashlar-graphframes-local-ecology-setup-c.py'],60)
 setup_raw=read(ROOT/'setup-result.json',65536);setup=json.loads(setup_raw)
 if set(setup)!={'configuration','provider','provider_sha256','scope'} or setup['configuration']!=str(ROOT/'setup/invocation.json') or setup['provider']!=str(ROOT/'setup/provider.py'):raise ValueError('Closed actual public setup result required')
 provider=read(Path(setup['provider']),65536)
 if sha(provider)!=setup['provider_sha256']:raise ValueError('Generated selected provider bytes differ')
 # Exact actual installed public console; generated adapter only, no custom policy.
 run('public-query',[str(python),'-I','-B',str(STAGE/'venv/bin/ashlar'),'query-graphframes','--configuration',setup['configuration'],'--provider',setup['provider'],'--provider-sha256',setup['provider_sha256']],360)
 report_raw=read(ROOT/'output/report.json',16777216);report=json.loads(report_raw);result=report['result']
 pack=json.loads(read(Path(selected['pack']),1048576));expected=[{'id':case['id'],'sql':case['sql']}for case in pack['scenario_checks']]
 if len(expected)!=9 or [case['original_scenario']for case in result['cases']]!=expected or result['all_original_cases_passed']!=9:raise ValueError('All unchanged original nine cases required')
 if report['observations']!=28 or len(list((ROOT/'output').glob('observation-*.json')))!=28:raise ValueError('Whole scenario/common/projected/derived raw observations required')
 if Path(selected['lease']).exists() or Path(selected['lease']).is_symlink():raise ValueError('Owned source lease not released')
 if read(ROOT/'setup-result.json',65536)!=setup_raw or read(Path(setup['provider']),65536)!=provider:raise ValueError('Closing generated setup/adapter changed')
 verify()
 write(ROOT/'result.json',enc({'revision':selected['revision'],'pack':'ecology','all_original_cases':9,'observations':28,'phases':phases,'report_sha256':sha(report_raw),'source_lease_released':True,'scope':'Actual shipped public setup/generated provider/installed CLI retained protected ACK ecology only. Runtime digests and setup artifacts never grant current canonical/native source authority.'}))
primary=None;closing=False
try:main()
except BaseException as error:primary=error
try:verify();closing=True
except BaseException as error:primary=select(primary,error)
try:write(Path('/private/tmp/ashlar-graphframes-local-ecology-runner-c.receipt.json'),enc({'format':'ashlar-public-graphframes-setup-actual/0.1','failureType':type(primary).__name__ if primary is not None else None,'openingClosingCustody':closing,'scope':'Stage2 shipped public composition; complete actual result only if retained result/report exist.'}))
except BaseException as error:primary=select(primary,error)
if primary is not None:raise primary
