from pathlib import Path
from ashlar_host.graphframes_local_setup import open_local_graphframes_configuration
def open_graphframes(invocation, release, custody_bytes):
    return open_local_graphframes_configuration(Path('/private/tmp/ashlar-graphframes-local-ecology-operation-c/setup/operator.json'), '6b1d6012c1c52521740757e83ac1432eed9c289a5e2d41818de52a5884c965c9', invocation, release, custody_bytes)
