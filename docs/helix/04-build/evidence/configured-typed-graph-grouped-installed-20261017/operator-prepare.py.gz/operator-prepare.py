from pathlib import Path
import subprocess,tempfile,tarfile,io,json,hashlib,sys
commit=sys.argv[1];root=Path(tempfile.mkdtemp(prefix='ashlar-typed-graph-grouped-installed-20261017-',dir='/private/tmp'));root.chmod(0o700);source=root/'source';source.mkdir()
raw=subprocess.check_output(['/usr/bin/git','archive',commit,'src','README.md','pyproject.toml'],cwd='/Users/erik/Projects/ashlar')
with tarfile.open(fileobj=io.BytesIO(raw))as archive:archive.extractall(source,filter='data')
builder='/private/tmp/ashlar-weft-validation-wheel-20261016-cdc5wn_8/build-environment/bin/python';runtime='/private/tmp/ashlar-publication-query-runtime-20261016-b/bin/python'
with(root/'build.log').open('wb')as log:subprocess.run([builder,'-c',"import setuptools.build_meta as b;print(b.build_wheel('../dist'))"],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
wheel=next((root/'dist').glob('*.whl'))
with(root/'install.log').open('wb')as log:subprocess.run([builder,'-m','pip','--isolated','--python',runtime,'install','--no-index','--no-deps','--force-reinstall',str(wheel)],stdout=log,stderr=subprocess.STDOUT,check=True)
old=Path('/private/tmp/ashlar-typed-graph-installed-20261017-gfothazt');base=json.loads((old/'read-original.json').read_bytes());base.pop('selector');base.update(operation='query',output=str(root/'pending'))
(root/'base.json').write_text(json.dumps(base,indent=2)+'\n');(root/'preparation.json').write_text(json.dumps({'commit':commit,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'runtime':runtime,'retained_installation':str(old/'native'),'scope':'Three tiny grouped graph query invocations; existing local graph installation, no publication/source progress writes, cloud or protected ACK.'},indent=2)+'\n')
print(root)
