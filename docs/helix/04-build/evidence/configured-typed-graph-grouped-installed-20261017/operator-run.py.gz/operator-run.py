from pathlib import Path
import subprocess,json,os,time,sys,hashlib,sqlite3
from collections import Counter
root=Path(sys.argv[1]);base=json.loads((root/'base.json').read_bytes());python=base['python'];native=Path(base['installation'])
environment={'PATH':'/usr/bin:/bin','HOME':'/Users/erik','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','JAVA_HOME':base['java_home'],'PYSPARK_PYTHON':python,'PYSPARK_DRIVER_PYTHON':python,'PYTHONDONTWRITEBYTECODE':'1','SPARK_LOCAL_IP':'127.0.0.1'}
def write(name,value):(root/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def state():
 with sqlite3.connect('file:'+str(native/'operations.sqlite')+'?mode=ro',uri=True)as db:
  rows={t:sorted([list(r)for r in db.execute('SELECT * FROM "'+t+'"')],key=lambda x:json.dumps(x,sort_keys=True))for t in ('local_operation','local_plan','jsonl_consumer_progress')}
 return {'registry':hashlib.sha256((native/'installation.json').read_bytes()).hexdigest(),'logs':{str(p.relative_to(native)):hashlib.sha256(p.read_bytes()).hexdigest()for p in native.glob('*/_delta_log/*.json')},'journal':hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest(),'counts':{t:len(v)for t,v in rows.items()}}
# Original source-derived expectations: selfloop plus parallel paths yield3/2;
# two knows edges through Person2->Place1 yield2/1. That path is empty afterdelete.
cases=[('historical-same-type',1,'SELECT p.person_key, COUNT(*) AS paths, COUNT_DISTINCT_PATH_TARGETS(x) AS targets FROM Person p CROSS JOIN EXPAND_PATHS(p.knows, knows) AS x GROUP BY p.person_key',[['person-1','3','2']]),('historical-cross-type',1,'SELECT p.person_key, COUNT(*) AS paths, COUNT_DISTINCT_PATH_TARGETS(x) AS targets FROM Person p CROSS JOIN EXPAND_PATHS(p.knows, located) AS x GROUP BY p.person_key',[['person-1','2','1']]),('empty-current-global',3,'SELECT COUNT(*) AS paths, COUNT_DISTINCT_PATH_TARGETS(x) AS targets FROM Person p CROSS JOIN EXPAND_PATHS(p.knows, located) AS x',[['0','0']])]
results=[]
for name,ordinal,sql,expected in cases:
 c={**base,'ordinal':ordinal,'output':str(root/name),'query':{'profile':'ashlar-configured-local-weft/0.1','sql':sql,'compiler':{'index':'/private/tmp/ashlar-count-star-public-install-20261014-a/checkout/distributions/index.json','installation':'/private/tmp/ashlar-count-star-public-install-20261014-a/compiler'},'bounds':{'maximum_artifact_bytes':1048576,'maximum_rows':1000,'maximum_cell_bytes':65536,'maximum_total_cell_bytes':1048576}}}
 path=root/(name+'.json');path.write_text(json.dumps(c,indent=2)+'\n');path.chmod(0o600)
 before=state();write(name+'-before.json',before);start=time.monotonic()
 with(root/(name+'.stdout')).open('wb')as out,(root/(name+'.stderr')).open('wb')as err:process=subprocess.run([python,'-I','-B','-m','ashlar','run-configured-local','--configuration',str(path)],cwd=root,env=environment,stdout=out,stderr=err,timeout=240)
 assert process.returncode==0,(name,process.returncode)
 result=json.loads((root/(name+'.stdout')).read_bytes());assert result==json.loads((root/name/'report.json').read_bytes())==json.loads((root/name/'runtime-report.json').read_bytes())
 assert result['protected_ack']is False and result['completed_batches']==3 and result['local_checkpoint']=='5724'
 q=result['query'];assert Counter(map(tuple,q['rows']))==Counter(map(tuple,expected)),name
 assert q['protocol']['response']==q['protocol']['recompiled']
 assert all(g['native']['rows']==[['0']]for g in q['evidence']['guards'])
 after=state();write(name+'-after.json',after);assert before==after
 item={'name':name,'elapsed_seconds':time.monotonic()-start,'result':result};results.append(item);write(name+'-terminal.json',item);print(json.dumps({'name':name,'seconds':item['elapsed_seconds'],'status':'complete'}),flush=True)
write('results.json',{'status':'complete','cases':results,'scope':'Three installed original typed graph grouped/distinct local Delta/Weft queries on retained ordinal1 and3; no publication/source/ACK writes or cloud compute.'})
