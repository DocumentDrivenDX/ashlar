import sys,json,time,os
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;s=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a');o=r/'strings';o.mkdir(mode=0o700)
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical'];sys.path[:0]=[str(r/'ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_resume_setup import run_configure_truss_resume_command
from ashlar_host.truss_scalar_query_cli import run_query_truss_scalars_command
from ashlar_host.truss_typed_related_query_cli import run_query_truss_typed_related_keys_command
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_example import private_file
previous={k:os.environ.get(k)for k in ('JAVA_HOME','PYSPARK_PYTHON','PYSPARK_DRIVER_PYTHON')};primary=None;answer=None;t=time.monotonic();phases={}
def restore():
 for k,v in previous.items():
  if v is None:os.environ.pop(k,None)
  else:os.environ[k]=v
try:
 os.environ.update(JAVA_HOME='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home',PYSPARK_PYTHON=sys.executable,PYSPARK_DRIVER_PYTHON=sys.executable)
 with owned_context(LocalPostgres(s/'data')) as runtime:
  params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);administrator=psycopg.conninfo.make_conninfo(**params);params['user']=json.loads((s/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
  def conn():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
  before=read_page(conn,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(o/'checkpoint-before.bin',before);assert before==(r/'checkpoint-live-observation-d.bin').read_bytes()
  item=json.loads((s/'continued/continuation.json').read_bytes())['publications'][0];selection=json.loads((s/'native/publish.json').read_bytes());selection.update(connection_uri=ordinary,administrator_uri=administrator);reader=o/'reader.json';run_configure_truss_resume_command(private_file(o/'publisher-selection.json',selection),item['publication_intent']['path'],reader)
  start=time.monotonic();line=run_query_truss_scalars_command(reader,o/'line-query.json',compiler='/private/tmp/ashlar-compatible-weft-compile-20261013-a/weft-runtime',sql='SELECT l.id AS line_id FROM order_lines l',revision='1',document_id='urn:umf:domain:commerce',physical_revisions=('1',),maximum_rows=3);phases['line_string_query']=time.monotonic()-start
  group=json.loads((s/'native/group-result.json').read_bytes());expected=dict(next(x for x in group['objects']if x['record_id']=='order_lines')['values'])['id'];assert line['rows']==[{'line_id':expected}]
  start=time.monotonic();related=run_query_truss_typed_related_keys_command(reader,o/'supplier-query.json',compiler='/private/tmp/ashlar-compatible-weft-compile-20261013-a/weft-runtime',sql='SELECT p.sku AS product_sku,RELATED_KEYS(p."products.supplier_id",1) AS suppliers FROM products p',revision='1',document_id='urn:umf:domain:commerce',maximum_rows=3);phases['supplier_related_query']=time.monotonic()-start
  assert len(related['rows'])==1 and line['publication_id']==related['publication_id']==item['manifest']['publication_id']
  after=read_page(conn,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(o/'checkpoint-after.bin',after);assert before==after
  answer={'outcome':'passed','phases':phases,'publication_id':line['publication_id'],'line_rows':line['rows'],'related_rows':related['rows'],'source_checkpoint_unchanged':True,'scope':'Original commerce STRING projection and one-hop authored relationship query with original compiler/source oracle on existing full Truss-fed publication. No mathematical integer or join/lifecycle qualification.'}
except BaseException as error:primary=error
finish(primary,[restore]);answer['duration_seconds']=time.monotonic()-t;private_file(o/'result.json',answer);print(json.dumps(answer),flush=True)
