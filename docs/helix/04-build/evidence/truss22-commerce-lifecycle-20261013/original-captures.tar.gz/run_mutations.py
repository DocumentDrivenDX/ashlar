import sys,json,time
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;s=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a');p=Path('/private/tmp/ashlar-truss22-commerce-lifecycle-proposal-20261013-b')
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical'];sys.path[:0]=[str(r/'ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres
from ashlar_host.lifecycle import owned_context
from ashlar_host.truss_example import private_file
from ashlar_host.truss_note_publication import read_page
from ashlar.cli import main
phases={};started=time.monotonic()
def command(name,configuration,output):
 t=time.monotonic();sys.argv=['ashlar',name,'--configuration',str(configuration),'--output',str(output)];main();phases[name+':'+output.name]=time.monotonic()-t;return json.loads(output.read_bytes())
with owned_context(LocalPostgres(s/'data')) as runtime:
 params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);params['user']=json.loads((s/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
 def conn():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
 before=read_page(conn,'commerce22-full-native',maximum_bytes=2097152).prior.content;private_file(r/'mutation-checkpoint-before.bin',before);assert before==(r/'checkpoint-live-observation-d.bin').read_bytes()
 def config(name):
  body=json.loads((p/name).read_bytes());body['connection_uri']=ordinary;return body
 price=config('price-update.json');result=command('update-truss-record',private_file(r/'price-update.json',price),r/'price-update-result.json');assert result['before']['version']==1 and result['object']['version']==2 and dict(result['object']['values'])['unit_price']=={'kind':'decimal','text':'13.75'}
 replacement=config('edge-replacement.json');edge=command('mutate-truss-record-group',private_file(r/'edge-replacement.json',replacement),r/'edge-replacement-result.json')
 created=edge['group_original']['response']['semantic']['results'][0];observed=edge['observed'][0]['edge'];assert observed['identity']==created['identity'] and observed['version']==int(created['version'])==1 and observed['source']['id']=='6' and observed['target']['id']=='5' and observed['retained']==[] and observed['order_key'] is None
 deletion=config('fulfillment-delete-template.json');deletion['operations'][0]['entity_id']=int(created['identity']['id']);deletion['operations'][0]['expected_version']=int(created['version']);removed=command('mutate-truss-record-group',private_file(r/'fulfillment-delete.json',deletion),r/'fulfillment-delete-result.json')
 after=read_page(conn,'commerce22-full-native',maximum_bytes=2097152);private_file(r/'mutation-checkpoint-after.bin',after.prior.content);private_file(r/'pending-source-page.json',after.content);private_file(r/'pending-next.bin',after.next.content);assert after.prior.content==before
 answer={'outcome':'passed','phases':phases,'duration_seconds':time.monotonic()-started,'replacement_edge_id':created['identity']['id'],'price':'13.75','source_checkpoint_unchanged':True,'scope':'Actual public Truss22 original-commerce price update, required-edge replacement, and incident-edge/object deletion with exact committed readback/replay. No publication/ACK/Delta/query qualification.'};private_file(r/'mutation-result.json',answer)
print(json.dumps(answer),flush=True)
