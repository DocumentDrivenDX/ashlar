import sys,json,hashlib
from pathlib import Path
import psycopg,jsonschema,referencing
r=Path(__file__).parent;s=Path('/private/tmp/ashlar-truss22-commerce-preparation-20261013-a')
roots=json.loads(Path('/private/tmp/ashlar-commerce-graphframes-installed-prep-j/command-j.json').read_bytes())['sdkRoots']['canonical'];sys.path[:0]=[str(r/'ashlar-target'),'/private/tmp/ashlar-truss22-public-inspect-20261013-a/target',*roots]
from truss import LocalPostgres,Ok,CatalogRuntimeConfiguration,create_reference_assembly,adopt_psycopg_host
from ashlar_host.lifecycle import owned_context,finish
from ashlar_host.truss_note_publication import read_page
from ashlar_host.truss_example import private_file
from dataclasses import asdict
with owned_context(LocalPostgres(s/'data')) as runtime:
 params=psycopg.conninfo.conninfo_to_dict(runtime.info.connection_uri);params['user']=json.loads((s/'setup-result.json').read_bytes())['roles']['consumer'];ordinary=psycopg.conninfo.make_conninfo(**params)
 def conn():return psycopg.connect(ordinary,autocommit=False,connect_timeout=5)
 page=read_page(conn,'commerce22-full-native',maximum_bytes=2097152);private_file(r/'checkpoint-live-observation-d.bin',page.prior.content)
 assert page.prior.content==(s/'queried/checkpoint-after.bin').read_bytes()
 with conn() as connection:
  connection.execute("SET TRANSACTION ISOLATION LEVEL READ COMMITTED")
  connection.execute("SET LOCAL statement_timeout = '15000ms'")
  host=adopt_psycopg_host(connection);assembly=None;primary=None
  try:
   tx=host.adopt_transaction();assert isinstance(tx,Ok)
   a=create_reference_assembly(CatalogRuntimeConfiguration(),host);assert isinstance(a,Ok);assembly=a.value
   observed=[]
   for record,n in [('products',3),('fulfillments',6),('order_lines',5)]:
    found=assembly.get_object_in_transaction(tx.value,document_id='urn:umf:domain:commerce',module_id='domain',record_id=record,object_id=n);assert isinstance(found,Ok);observed.append(asdict(found.value))
   old=json.loads((s/'group-template.json').read_bytes())['edges'][4]
   found=assembly.get_edge_in_transaction(tx.value,document_id='urn:umf:domain:commerce',module_id='domain',relationship_id=old['relationship_id'],edge_id=16);assert isinstance(found,Ok);observed.append(asdict(found.value))
   private_file(r/'live-original-observation.json',observed)
  except BaseException as error:primary=error
  def detach():
   if not host.detach():raise RuntimeError('detach refused')
  finish(primary,([assembly.dispose]if assembly else [])+[detach])
print('Read-only current source and original checkpoint captured.',flush=True)
