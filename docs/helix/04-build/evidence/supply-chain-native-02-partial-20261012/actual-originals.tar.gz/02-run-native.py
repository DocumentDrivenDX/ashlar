"""Frozen recipe adapter to public bounded capture; no replacement native owner."""
from pathlib import Path
import os,json,hashlib,stat
from ashlar_host.graphframes_release import capture_graphframes_worker
from ashlar_host.lifecycle import finish
R=Path(__file__).parent
CUSTODY_SHA='683f6c2bb265b2669961a55b80c2f1c804d33156527b2189f6abc6f6df1e995e'

def write(path,raw):
 stream=None;primary=None
 try:
  stream=path.open('xb')
  if stream.write(raw)!=len(raw):raise ValueError('Complete retained bytes required')
  stream.flush();os.fsync(stream.fileno())
 except BaseException as e:primary=e
 finish(primary,[stream.close]if stream is not None else[])

def bounded_read(path,maximum,*,selected=None,collect=True):
 if type(maximum)is not int or maximum<0 or path.resolve()!=path:raise ValueError('Explicit canonical bounded resource required')
 fd=None;primary=None;answer=None
 try:
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK);before=os.fstat(fd);named=path.lstat()
  facts=lambda x:(x.st_dev,x.st_ino,x.st_uid,x.st_mode,x.st_nlink)
  if not stat.S_ISREG(before.st_mode)or facts(before)!=facts(named)or (selected is None and before.st_nlink!=1)or not 0<=before.st_size<=maximum:raise ValueError('Regular prebounded resource required')
  if selected is not None and ([before.st_dev,before.st_ino,before.st_mode,before.st_nlink]!=selected['identity']or before.st_size!=selected['bytes']):raise ValueError('Exact selected resource identity/size required')
  pieces=[]if collect else None;count=0;digest=hashlib.sha256()
  while True:
   block=os.read(fd,min(65536,maximum-count+1))
   if not block:break
   count+=len(block)
   if count>maximum:raise ValueError('Resource grew beyond selected bound')
   digest.update(block)
   if collect:pieces.append(block)
  after=os.fstat(fd);named=path.lstat()
  if path.resolve()!=path or facts(after)!=facts(before)or facts(named)!=facts(before)or(after.st_size,after.st_mtime_ns)!=(before.st_size,before.st_mtime_ns)or count!=before.st_size:raise ValueError('Current held/named bytes changed')
  if selected is not None and digest.hexdigest()!=selected['sha256']:raise ValueError('Exact selected resource digest required')
  answer=b''.join(pieces)if collect else None
 except BaseException as error:primary=error
 finish(primary,[lambda:os.close(fd)]if fd is not None else[])
 return answer

def renew():
 raw=bounded_read(R/'custody.json',8388608);assert hashlib.sha256(raw).hexdigest()==CUSTODY_SHA;record=json.loads(raw)
 for row in record['selectedFiles']:
  bounded_read(Path(row['path']),row['bytes'],selected=row,collect=False)
 actual={}
 for p in sorted((R/'venv').rglob('*')):
  assert not p.is_symlink();s=p.lstat()
  if p.is_dir():actual[str(p)]={'kind':'directory','identity':[s.st_dev,s.st_ino,s.st_mode]}
  elif p.is_file():actual[str(p)]={'kind':'file','bytes':s.st_size,'metadata':[s.st_dev,s.st_ino,s.st_mode,s.st_mtime_ns,s.st_nlink]}
  else:raise ValueError('Current environment namespace refused')
 assert actual==record['environmentNamespace']
 for root,expected in record['externalNamespace'].items():
  observed={}
  for p in sorted(Path(root).rglob('*')):
   s=p.lstat()
   if p.is_symlink():observed[str(p)]={'kind':'symlink','target':os.readlink(p),'resolved':str(p.resolve())}
   elif p.is_dir():observed[str(p)]={'kind':'directory','identity':[s.st_dev,s.st_ino,s.st_mode]}
   elif p.is_file():observed[str(p)]={'kind':'file','bytes':s.st_size,'metadata':[s.st_dev,s.st_ino,s.st_mode,s.st_mtime_ns,s.st_nlink]}
   else:raise ValueError('Current JDKnamespace refused')
  assert observed==expected

def retain(value):
 assert type(value)is dict and set(value)=={'stdoutHex','stderrHex','exit','complete','scope'}
 raw=(json.dumps(value,separators=(',',':'))+'\n').encode();assert len(raw)<=5242880
 primary=None
 try:write(R/'transport.json',raw)
 except BaseException as e:primary=e
 callbacks=[]
 for key,name in [('stdoutHex','native.stdout'),('stderrHex','native.stderr')]:
  body=bytes.fromhex(value[key]);assert len(body)<=1048576;callbacks.append(lambda name=name,body=body:write(R/name,body))
 finish(primary,callbacks)

def main():
 c=json.loads(bounded_read(R/'command-final.json',65536));primary=None;success=False
 try:
  renew();capture_graphframes_worker(c['argv'],cwd=R,environment=c['environment'],renew=renew,timeout_seconds=300,maximum_output_bytes=1048576,retain_transport=retain);success=True
 except BaseException as e:primary=e
 closed=[False]
 def closing():renew();closed[0]=True
 finish(primary,[closing,lambda:write(R/'outer-result.json',(json.dumps({'bodyReturned':success,'recipeClosingPassed':closed[0],'scope':'Transport/recipe outcome only; qualification requires actual terminal0 and complete report/currentsource-native closing review'})+'\n').encode())])
if __name__=='__main__':main()
