import importlib.util,sys,unittest
from pathlib import Path
from dataclasses import replace
from unittest import mock
sys.path.insert(0,'/Users/erik/Projects/ashlar/src')
root=Path('/private/tmp/ashlar-original-commerce-local-query-prep-a')
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=load('inert_original_controls',root/'test-preparation-a.py')
provider=load('corrected_provider',Path('/private/tmp/ashlar-original-commerce-local-query-prep-d/provider-d.py'))
class Tests(unittest.TestCase):
    def ports(self):
        config=old.Tests().config();return config,provider.selected(config)
    def test_actual_registration_reader_and_ack_select_distinct_public_callbacks(self):
        config,ports=self.ports();calls=[];reader=object();ack=object()
        source=replace(ports.registration.source,connection_factory=lambda context:(calls.append(('reader',context)),reader)[1])
        reg=replace(ports.registration,source=source,metadata_factory=lambda context:(calls.append(('ack',context)),ack)[1])
        with mock.patch.object(provider,'selected',return_value=replace(ports,registration=reg)):
            factory=provider.ordinary_query_connection_factory(config)
            self.assertIs(factory.open(reg.source_role),reader)
            self.assertIs(factory.open(reg.ack_role),ack)
            for role in (ports.writer_role,'foreign',True):
                with self.assertRaises(ValueError):factory.open(role)
        self.assertEqual(calls,[('reader',None),('ack',None)])
    def test_ack_error_and_cancel_preserve_exact_identity(self):
        config,ports=self.ports()
        for error in (ValueError('constant-test'),KeyboardInterrupt()):
            def fail(context):raise error
            reg=replace(ports.registration,metadata_factory=fail)
            with mock.patch.object(provider,'selected',return_value=replace(ports,registration=reg)):
                with self.assertRaises(type(error))as caught:provider.ordinary_query_connection_factory(config).open(reg.ack_role)
                self.assertIs(caught.exception,error)
if __name__=='__main__':unittest.main()
