"""Fresh offline installed four-query run; no initialization or publication."""
import argparse,base64,collections,csv,hashlib,importlib.util,json,os,stat,time,zipfile
from pathlib import Path

def choose(primary,error):
    return error if primary is None or isinstance(primary,Exception)and not isinstance(error,Exception)else primary

def read(path,maximum):
    stream=Path(path).open('rb');primary=None;raw=None
    try:
        raw=stream.read(maximum+1)
        if len(raw)>maximum:raise ValueError('Bounded input required')
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:primary=choose(primary,error)
    if primary is not None:raise primary
    return raw

def retain(path,value):
    stream=None;primary=None;raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
    try:
        stream=Path(path).open('xb')
        if stream.write(raw)!=len(raw):raise OSError('Short retention write')
        stream.flush();os.fsync(stream.fileno())
    except BaseException as error:primary=error
    if stream is not None:
        try:stream.close()
        except BaseException as error:primary=choose(primary,error)
    if primary is not None:raise primary

def namespace(root):
    values=[]
    for path in sorted(Path(root).rglob('*')):
        if path.is_symlink():raise ValueError('Namespace alias refused')
        kind='file'if path.is_file()else'directory'if path.is_dir()else None
        if kind is None:raise ValueError('Special namespace member refused')
        values.append([str(path.relative_to(root)),kind])
    return values

def wheel_members(path,expected):
    archive=None;primary=None;members={}
    try:
        archive=zipfile.ZipFile(path)
        if len(archive.namelist())!=len(set(archive.namelist())):raise ValueError('Duplicate wheel member')
        for name in archive.namelist():
            if name.startswith('/')or'..'in Path(name).parts or name.endswith('/'):raise ValueError('Closed wheel namespace required')
            if archive.getinfo(name).file_size>4194304:raise ValueError('Bounded wheel member required')
            value=archive.read(name)
            if len(value)>4194304:raise ValueError('Bounded wheel member required')
            members[name]=value
        observed={name:{'size':len(value),'sha256':hashlib.sha256(value).hexdigest()}for name,value in members.items()}
        if observed!=expected:raise ValueError('Previously qualified exact wheel correspondence required')
    except BaseException as error:primary=error
    if archive is not None:
        try:archive.close()
        except BaseException as error:primary=choose(primary,error)
    if primary is not None:raise primary
    return members

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--command',required=True,type=Path);parser.add_argument('--sha256',required=True);args=parser.parse_args()
    raw=read(args.command,1048576)
    if hashlib.sha256(raw).hexdigest()!=args.sha256:raise ValueError('Externally selected command required')
    command=json.loads(raw);start=time.monotonic();deadline=start+command['wholeSeconds'];output=Path(command['output']);primary=None;closing=False;phases=[];installed=[];installed_namespace=None;capture=None
    def pins(records):
        for item in records:
            path=Path(item['path'])
            if not stat.S_ISREG(path.lstat().st_mode):raise ValueError('Regular selected original required')
            value=read(path,max(1,item['size']))
            if len(value)!=item['size']or hashlib.sha256(value).hexdigest()!=item['sha256']:raise ValueError('Selected original changed')
            if time.monotonic()>=deadline-20:raise TimeoutError('Closing budget required')
    def verify():
        if read(args.command,1048576)!=raw:raise ValueError('Command changed')
        pins(command['resources']);pins(command['nativeFiles'])
        spec=importlib.util.spec_from_file_location('selected_sidecars',command['sidecarHelper']);sidecars=importlib.util.module_from_spec(spec);spec.loader.exec_module(sidecars)
        sidecars.classify(Path(command['nativeRoot']),Path(command['journal']),command['nativeNamespace'],command['nativeFiles'])
        if sorted(x.name for x in Path(command['jars']).iterdir())!=command['jarNamespace']:raise ValueError('Exact two-JAR namespace required')
    def verify_installed():
        if installed_namespace is not None:
            if namespace(Path(command['site']))!=installed_namespace:raise ValueError('Installed namespace changed')
            pins(installed)
    def phase(name,argv,seconds):
        remaining=deadline-time.monotonic()-20
        if remaining<1:raise TimeoutError('No phase budget remains')
        result=capture.capture(argv,str(output),command['environment'],output/(name+'.stdout'),output/(name+'.stderr'),min(seconds,remaining),4194304)
        phases.append({'phase':name,'argv':argv,'capture':result})
        if result['exitCode']!=0:raise RuntimeError('Required public phase refused')
    try:
        verify()
        if output.exists()or output.is_symlink():raise ValueError('Fresh exclusive query output required')
        output.mkdir(mode=0o700)
        spec=importlib.util.spec_from_file_location('selected_capture',command['captureModule']);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
        members=wheel_members(command['wheel'],command['wheelMembers'])
        env=output/'environment';python=str(env/'bin/python');site=Path(command['site'])
        phase('venv',[command['python311'],'-I','-B','-m','venv','--copies',str(env)],30)
        phase('install',[command['installer'],'-I','-B','-m','pip','--python',python,'install','--no-deps','--no-index','--no-compile',command['wheel']],30)
        for name,value in members.items():
            if name.endswith('/RECORD'):continue
            if read(site/name,max(1,len(value)))!=value:raise ValueError('Installed wheel correspondence differs')
        record=next(site.glob('ashlar_graph_toolkit-*.dist-info/RECORD'))
        for relative,hashed,size in csv.reader(read(record,1048576).decode().splitlines()):
            path=(site/relative).resolve()
            if not path.is_relative_to(env.resolve()):raise ValueError('Installed RECORD escapes environment')
            if not hashed:
                if path!=record.resolve():raise ValueError('Unknown unhashed RECORD member')
                continue
            value=read(path,4194304)
            if hashed!='sha256='+base64.urlsafe_b64encode(hashlib.sha256(value).digest()).decode().rstrip('=')or size!=str(len(value)):raise ValueError('Installed RECORD correspondence differs')
        stream=None;error=None
        try:
            stream=(site/'selected-sdk.pth').open('xb');value=('\n'.join(command['sdkRoots'])+'\n').encode()
            if stream.write(value)!=len(value):raise OSError('Short SDK path write')
            stream.flush();os.fsync(stream.fileno())
        except BaseException as failure:error=failure
        if stream is not None:
            try:stream.close()
            except BaseException as failure:error=choose(error,failure)
        if error is not None:raise error
        installed_namespace=namespace(site)
        for relative,kind in installed_namespace:
            if kind=='file':
                path=site/relative;value=read(path,4194304);installed.append({'path':str(path),'size':len(value),'sha256':hashlib.sha256(value).hexdigest()})
        retain(output/'installed-host.json',{'sourceRevision':command['sourceRevision'],'files':installed,'namespace':installed_namespace,'wheelSha256':command['wheelSha256']})
        phase('runtime-import',[python,'-I','-B','-c',command['importProbe']],15)
        phase('query',[python,'-I','-B',command['entry'],'--command',str(args.command),'--sha256',args.sha256],300)
        report=json.loads(read(output/'query/report.json',16777216));expected=json.loads(read(command['expected'],1048576))
        if [x['case']for x in report['cases']]!=expected['caseIds']or report['cleanup']!={'readerClosed':True,'sparkStopped':True}:raise ValueError('Four complete closed cases required')
        for case,sql,owned in zip(report['cases'],expected['originalSql'],expected['cases']):
            if json.loads(case['originalRequestText'])['sql']!=sql or case['originalResponseText']!=case['originalRecompiledText']:raise ValueError('Original SQL/compiler correspondence differs')
            def bag(rows):return collections.Counter(json.dumps(row,ensure_ascii=False,separators=(',',':'))for row in rows)
            if case['provisional']['oracle']!=owned['expected']or bag(case['provisional']['native_result']['rows'])!=bag(owned['expected']['rows']):raise ValueError('Complete independent original numeric bag differs')
        if report['opening_native_files']!=report['closing_native_files']:raise ValueError('Current native bytes changed')
        phase('runtime-import-closing',[python,'-I','-B','-c',command['importProbe']],15)
        if read(output/'runtime-import.stdout',1048576)!=read(output/'runtime-import-closing.stdout',1048576):raise ValueError('Runtime import correspondence changed')
    except BaseException as error:primary=error
    finally:
        closing=True
        def journal_registration_closing():
            if installed_namespace is not None:
                phase('journal-registration-closing',[str(Path(command['output'])/'environment/bin/python'),'-I','-B','-c',command['journalProof']],15)
        for callback in (journal_registration_closing,verify,verify_installed):
            try:callback()
            except BaseException as error:closing=False;primary=choose(primary,error)
        if output.is_dir():
            try:retain(output/'outer-receipt.json',{'commandSha256':args.sha256,'phases':phases,'closing':closing,'primary':None if primary is None else type(primary).__name__,'elapsedSeconds':time.monotonic()-start,'scope':'Four unchanged installed Weft042 queries only; no initialization/publication/append/reset; independent fullbag review required'})
            except BaseException as error:primary=choose(primary,error)
    if primary is not None:raise primary
if __name__=='__main__':main()
