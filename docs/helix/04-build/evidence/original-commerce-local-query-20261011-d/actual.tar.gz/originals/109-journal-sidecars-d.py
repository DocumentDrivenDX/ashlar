"""Recipe correspondence only: original bytes remain separately pinned authority."""
import os,stat
from pathlib import Path

def classify(root,journal,original_namespace,original_files):
    if type(root)is not type(Path())or type(journal)is not type(Path())or root.resolve()!=root or journal.parent!=root or journal.resolve()!=journal:
        raise ValueError('Exact canonical selected journal parent required')
    expected=dict(original_namespace);actual={};identities=set()
    for r in original_files:
        p=Path(r['path']);s=p.lstat()
        if not stat.S_ISREG(s.st_mode):raise ValueError('Original regular native member required')
        identities.add((s.st_dev,s.st_ino))
    for p in sorted(root.rglob('*')):
        s=p.lstat();kind='file'if stat.S_ISREG(s.st_mode)else'directory'if stat.S_ISDIR(s.st_mode)else None
        if kind is None:raise ValueError('Native aliases and special entries refused')
        actual[str(p.relative_to(root))]=kind
    if any(actual.get(name)!=kind for name,kind in expected.items()):raise ValueError('Original native namespace missing or changed')
    extras=set(actual)-set(expected);allowed={journal.name+'-wal':0,journal.name+'-shm':32768}
    if extras!=set(allowed):raise ValueError('Only both exact journal sidecars permitted')
    observations=[]
    for name,size in allowed.items():
        p=root/name;s=p.lstat()
        if (p.resolve()!=p or p.parent.resolve()!=root or actual[name]!='file' or s.st_uid!=os.getuid() or stat.S_IMODE(s.st_mode)!=0o600 or s.st_nlink!=1 or s.st_size!=size or (s.st_dev,s.st_ino)in identities):
            raise ValueError('Closed original journal sidecar correspondence required')
        identities.add((s.st_dev,s.st_ino));observations.append({'name':name,'size':size,'device':s.st_dev,'inode':s.st_ino})
    return {'scope':'SQLite sidecar correspondence only, never native or source authority','sidecars':observations}
