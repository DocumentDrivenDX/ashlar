import ast,json,unittest
from pathlib import Path
ROOT=Path('/private/tmp/ashlar-original-commerce-local-query-prep-d')
class Tests(unittest.TestCase):
 def test_actual_executable_probe_exact_host_and_sdk_correspondence(self):
  c=json.loads((ROOT/'command-d.json').read_bytes());tree=ast.parse(c['importProbe']);strings=[n.value for n in ast.walk(tree)if isinstance(n,ast.Constant)and isinstance(n.value,str)]
  expected=c['output']+'/environment/bin/python';owner=c['site']+'/ashlar_host/implicit_arithmetic_configuration.py'
  self.assertIn(expected,strings);self.assertIn(owner,strings)
  def assertions(field):
   return[n for n in ast.walk(tree)if isinstance(n,ast.Assert)and field in ast.unparse(n.test)]
  self.assertEqual(len(assertions('sys.executable')),1)
  self.assertEqual(ast.unparse(assertions('sys.executable')[0].test),'sys.executable == '+repr(expected))
  self.assertEqual(len(assertions('owner.__file__')),1)
  self.assertEqual(ast.unparse(assertions('owner.__file__')[0].test),'Path(owner.__file__) == Path('+repr(owner)+')')
  for s in strings:
   if '/ashlar-original-commerce-local-query-20261011-'in s:self.assertTrue(s.startswith(c['output']+'/'))
  for path in ['/private/tmp/ashlar-indexed-delta4-python-20261010-a/delta/__init__.py','/private/tmp/ashlar-indexed-psycopg-python311-20261010-c/psycopg/__init__.py','/private/tmp/ashlar-spark4-python39-bridge/pyspark/__init__.py']:self.assertIn(path,strings)
if __name__=='__main__':unittest.main()
