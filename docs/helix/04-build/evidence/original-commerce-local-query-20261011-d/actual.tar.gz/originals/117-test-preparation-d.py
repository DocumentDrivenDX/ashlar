import ast,hashlib,importlib.util,json,os,tempfile,unittest,zipfile,sys
sys.path.insert(0,"/Users/erik/Projects/ashlar/src")
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
ROOT=Path('/private/tmp/ashlar-original-commerce-local-query-prep-d')
def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'));value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
runner=module('runner-d');provider=module('provider-d');entry=module('entry-d')

class Tests(unittest.TestCase):
    def config(self):
        from ashlar_host.config import ProducerConfig
        from ashlar_host.implicit_arithmetic_configuration import QueryCommerceImplicitArithmeticConfig,ExplicitCommercePostgresEndpoint
        from ashlar_host.path_capture import PathCaptureConfig
        from ashlar.weft_path_decode import PathDecodeConfig
        s=json.loads((Path('/private/tmp/ashlar-original-commerce-local-query-prep-a/selection-draft-a.json')).read_bytes());args=s['queryArgv']
        def arg(name):return args[args.index(name)+1]
        return QueryCommerceImplicitArithmeticConfig(*(Path(arg(name))for name in ['--index','--installation','--publication','--output','--jars','--model','--graph']),ProducerConfig(Path(arg('--umf-source')),Path(arg('--bun')),Path(arg('--git')),30,1048576,4194304),ExplicitCommercePostgresEndpoint(arg('--postgres-container'),'127.0.0.1',25435,'truss_e2e'),16777216,PathCaptureConfig(1000,16777216,67108864),PathDecodeConfig(16777216))
    def test_actual_typed_provider_and_mixed_endpoint_refusal(self):
        from ashlar_host.commerce_publication_sources import OriginalCommerceSourcePorts
        from ashlar_host.commerce_query_sources import CommerceQuerySourceFactory
        cfg=self.config();ports=provider.selected(cfg)
        self.assertIs(type(ports),OriginalCommerceSourcePorts)
        self.assertEqual(ports.registration.source.scope.installation_id,'07c04255-73c9-40f3-a16a-000000000001')
        self.assertIs(type(provider.commerce_query_source_factory(cfg)),CommerceQuerySourceFactory)
        with self.assertRaises(ValueError):provider.selected(replace(cfg,postgres=replace(cfg.postgres,port=25434)))
        with self.assertRaises(ValueError):provider.selected(SimpleNamespace(postgres=cfg.postgres))
    def test_actual_ordinary_role_isolation_before_connection(self):
        cfg=self.config();factory=provider.ordinary_query_connection_factory(cfg)
        for role in ['ashlar_ack_writer_original_a','foreign',True]:
            with self.assertRaises(ValueError):factory.open(role)
    def test_ambient_libpq_refuses_before_connect_without_value(self):
        cfg=self.config()
        for key in ['PGHOSTADDR','PGSERVICE','PGUNKNOWNFUTURE']:
            with mock.patch.dict(os.environ,{key:'never-retained-sensitive-sentinel'}):
                factory=provider.ordinary_query_connection_factory(cfg)
                with self.assertRaises(Exception)as caught:factory.open('ashlar_ack_reader_original_a')
                self.assertNotIn('never-retained-sensitive-sentinel',str(caught.exception))
    def test_exact_qualified_actual_wheel_and_missing_extra_mutated_payloads(self):
        c=json.loads((ROOT/'command-d.json').read_bytes());self.assertEqual(len(runner.wheel_members(c['wheel'],c['wheelMembers'])),216)
        for change in ['missing','extra','hash','declared-data']:
            expected=json.loads(json.dumps(c['wheelMembers']))
            name=next(n for n in expected if n.endswith('.py'))
            if change=='missing':expected.pop(name)
            if change=='extra':expected['foreign.pth']={'size':1,'sha256':'0'*64}
            if change=='hash':expected[name]['sha256']='0'*64
            if change=='declared-data':expected.pop(next(n for n in expected if '/resources/'in n))
            with self.assertRaises(ValueError):runner.wheel_members(c['wheel'],expected)
    def test_external_digest_precedes_command_parse_or_cli_import(self):
        with tempfile.TemporaryDirectory()as directory:
            p=Path(directory)/'command.json';p.write_bytes(b'not-json')
            with mock.patch('sys.argv',['entry','--command',str(p),'--sha256','0'*64]):
                with self.assertRaisesRegex(ValueError,'Externally selected'):entry.main()
    def test_full_namespace_detects_new_pth_and_alias(self):
        with tempfile.TemporaryDirectory()as directory:
            p=Path(directory);(p/'host.py').write_text('');opening=runner.namespace(p)
            (p/'foreign.pth').write_text('unsafe');self.assertNotEqual(opening,runner.namespace(p))
            (p/'alias').symlink_to(p/'host.py')
            with self.assertRaises(ValueError):runner.namespace(p)
    def test_cancel_and_retention_open_error_primary_selection(self):
        original=KeyboardInterrupt()
        class Stream:
            def read(self,n):raise original
            def close(self):raise OSError('closing')
        with mock.patch.object(Path,'open',return_value=Stream()):
            with self.assertRaises(KeyboardInterrupt)as caught:runner.read(Path('/unused'),16)
            self.assertIs(caught.exception,original)
        self.assertIs(runner.choose(original,OSError()),original)
        with mock.patch.object(Path,'open',side_effect=OSError('open')):
            with self.assertRaises(OSError):runner.retain(Path('/unused'),{})
    def test_original_four_expected_bags_are_not_compiler_oracle(self):
        v=json.loads((ROOT/'expected-d.json').read_bytes());self.assertEqual(v['caseIds'],['partial-return','fulfillment','settlement','refund']);self.assertEqual(len(v['cases']),4)
        self.assertTrue(all(case['expected']['rows']for case in v['cases']))
        tree=ast.parse((ROOT/'runner-d.py').read_bytes());self.assertFalse(any(isinstance(n,ast.Constant)and n.value in ['publish-original-commerce','initialize-original-commerce']for n in ast.walk(tree)))
if __name__=='__main__':unittest.main()
