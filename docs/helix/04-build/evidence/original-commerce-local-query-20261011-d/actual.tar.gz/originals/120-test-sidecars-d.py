import importlib.util,os,tempfile,unittest
from pathlib import Path
p=Path('/private/tmp/ashlar-original-commerce-local-query-prep-d/journal-sidecars-d.py');s=importlib.util.spec_from_file_location('sidecars',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Tests(unittest.TestCase):
 def fixture(self,root):
  (root/'native-table').mkdir();journal=root/'operations.sqlite';journal.write_bytes(b'original');os.chmod(journal,0o600)
  for suffix,n in (('-wal',0),('-shm',32768)):
   q=Path(str(journal)+suffix);q.write_bytes(b'\0'*n);os.chmod(q,0o600)
  return journal,[['native-table','directory'],['operations.sqlite','file']],[{'path':str(journal)}]
 def test_exact_sidecars_only(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d).resolve();j,n,f=self.fixture(root);self.assertEqual(len(m.classify(root,j,n,f)['sidecars']),2)
 def test_negative_closed_guards(self):
  for change in ('walbytes','shmsize','mode','hardlink','symlink','extra','missing-original','missing-sidecar','parent-alias','foreign-uid'):
   with self.subTest(change=change),tempfile.TemporaryDirectory()as d:
    root=Path(d).resolve();j,n,f=self.fixture(root);wal=Path(str(j)+'-wal');shm=Path(str(j)+'-shm')
    if change=='walbytes':wal.write_bytes(b'x')
    elif change=='shmsize':shm.write_bytes(b'')
    elif change=='mode':os.chmod(shm,0o644)
    elif change=='hardlink':os.link(shm,root.parent/('outside-link-'+root.name))
    elif change=='symlink':shm.unlink();shm.symlink_to(j)
    elif change=='extra':(root/'extra').write_bytes(b'')
    elif change=='missing-original':j.unlink()
    elif change=='missing-sidecar':wal.unlink()
    elif change=='parent-alias':
     alias=root/'alias';alias.symlink_to(root);j=alias/'operations.sqlite'
    elif change=='foreign-uid':
     from unittest import mock
     with mock.patch.object(m.os,'getuid',return_value=-1):
      with self.assertRaises(ValueError):m.classify(root,j,n,f)
     continue
    try:
     with self.assertRaises((ValueError,FileNotFoundError)):m.classify(root,j,n,f)
    finally:
     outside=root.parent/('outside-link-'+root.name)
     if outside.exists():outside.unlink()
if __name__=='__main__':unittest.main()
