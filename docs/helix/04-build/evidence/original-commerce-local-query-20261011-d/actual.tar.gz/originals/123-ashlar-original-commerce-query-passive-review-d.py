import collections,hashlib,importlib.util,json
from decimal import Decimal
from pathlib import Path
from ashlar_host.commerce_original_scenarios import commerce_original_cases,original_commerce_scenario_oracle
from ashlar_host.implicit_arithmetic_request import commerce_implicit_arithmetic_request
from ashlar_host.commerce_source_receipt import encode_bounded_commerce_json
fp=Path('/private/tmp/ashlar-original-commerce-local-query-actual-freeze-d.json');f=json.loads(fp.read_bytes());assert hashlib.sha256(fp.read_bytes()).hexdigest()=='db862721279d6351d140a1d66982a501898b5ca6922cd3f36b0be74b9178490a'
for key in ['files','selectedResources','installedFiles','originalNativeOpeningPins']:
 for x in f[key]:
  b=Path(x['path']).read_bytes();assert len(b)==x['size']and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
root=Path('/private/tmp/ashlar-original-commerce-local-query-20261011-d');r=json.loads((root/'query/report.json').read_bytes());c=json.loads(Path('/private/tmp/ashlar-original-commerce-local-query-prep-d/command-d.json').read_bytes());pub=Path('/private/tmp/ashlar-original-commerce-local-publication-20261011-a/publication');pr=json.loads((pub/'report.json').read_bytes());manifest=pr['native_manifest'];model=(pub/'original-ontology.json').read_bytes();graph=(pub/'original-graph.json').read_bytes();bindings=json.loads((pub/'development-bindings.json').read_bytes());pack=Path('/Users/erik/Projects/ashlar/examples/domain-packs/commerce/upstream/pack.json').read_bytes();registry=pr['table_registry'];aliases={t:t.replace('local.','spark_catalog.',1)for t in json.loads(manifest['table_versions_json'])}
assert r['original_manifest']==manifest and r['original_publication_report_sha256']==hashlib.sha256((pub/'report.json').read_bytes()).hexdigest();assert r['cleanup']=={'readerClosed':True,'sparkStopped':True};assert r['opening_native_files']==r['closing_native_files']
cases=commerce_original_cases(pack);assert [x['case']for x in r['cases']]==[x[0]for x in cases]
def bag(rows):return collections.Counter(json.dumps(x,ensure_ascii=False,separators=(',',':'))for x in rows)
guardcounts=[];samplecounts=[]
for case,(name,sql)in zip(r['cases'],cases):
 request=commerce_implicit_arithmetic_request(sql,model,bindings,manifest,registry,aliases,pack_bytes=pack);assert case['originalRequestText']==encode_bounded_commerce_json(request,16777215)+'\n';assert case['originalResponseText']==case['originalRecompiledText'];artifact=json.loads(case['originalResponseText']);assert artifact['status']=='compiled'and artifact['interfaceVersion']=='weft-compile/0.4.2'and artifact['bindingSha256']==request['target']['bindingSha256']==hashlib.sha256(request['target']['bindingJson'].encode()).hexdigest()
 expected=original_commerce_scenario_oracle(model,graph,request);p=case['provisional'];assert p['oracle']==expected and bag(p['native_result']['rows'])==bag(expected['rows']);assert p['opening_native_files']==p['closing_native_files']==r['opening_native_files'];assert [[x['original']for x in row]for row in p['decoded']]==expected['rows']
 binding=json.loads(request['target']['bindingJson']);assert len(binding['records'])==10 and len(binding['relationships'])==9;assert binding['publication']['id']==manifest['publication_id'];assert binding['publication']['tables']==[x['table']for x in p['native_schemas']]
 for interval in [p['interval']]:
  assert interval['scope']==pr['protected_ack_scope'] and interval['source_signature_sha256']==pr['source_signature_sha256'];assert interval['opening_ack']['observation']==interval['closing_ack']['observation']
  for boundary in ['opening_ack','closing_ack']:
   ack=interval[boundary];session=ack['session'];assert session['current_user']==session['session_user']==pr['ack_role']and session['database']=='truss_e2e';assert session['source_schema']==pr['source_schema']and session['source_signature_sha256']==pr['source_signature_sha256'];obs=ack['observation'];assert obs['position']=='1';assert json.loads(bytes.fromhex(obs['manifest_hex']))==manifest;receipt=json.loads(bytes.fromhex(obs['receipt_hex']));assert receipt['manifest_sha256']==hashlib.sha256(bytes.fromhex(obs['manifest_hex'])).hexdigest()and receipt['request_sha256']==hashlib.sha256(bytes.fromhex(obs['request_hex'])).hexdigest();assert receipt['installation_id']==pr['installation_id']and receipt['publication_id']==manifest['publication_id']and receipt['position']=='1'
 samplecount=0
 for guard in p['guards']:
  if guard['check'].get('publicSourceOnly'):
   rows=guard['native']['rows'];types={x[1]for x in rows};assert len(types)==1;tid=next(iter(types));prop=guard['check']['propertyId'];expectedrows=[]
   for o in pr['complete_original_oracle']['object_current']:
    if o['type_id']==tid:
     props=json.loads(o['props_json'],parse_float=Decimal);value=props[prop];expectedrows.append([o['source_system'],o['type_id'],o['id'],o['schema_revision'],o['props_json'],str(value)])
   assert bag(rows)==bag(expectedrows);samplecount+=len(rows)
  else:assert guard['native']['rows']==[['0']]
 guardcounts.append(len(p['guards']));samplecounts.append(samplecount)
assert r['alias_interval']['opening_ack']['observation']==r['alias_interval']['closing_ack']['observation'];outer=json.loads((root/'outer-receipt.json').read_bytes());assert outer['closing']is True and outer['primary']is None and len(outer['phases'])==6 and all(x['capture']['exitCode']==0 for x in outer['phases']);assert (root/'runtime-import.stdout').read_bytes()==(root/'runtime-import-closing.stdout').read_bytes();assert json.loads((root/'journal-registration-closing.stdout').read_bytes())['registrationClosing']is True
spec=importlib.util.spec_from_file_location('sidecar',c['sidecarHelper']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.classify(Path(c['nativeRoot']),Path(c['journal']),c['nativeNamespace'],c['nativeFiles']);site=Path(c['site']);ns=[[str(p.relative_to(site)),'file'if p.is_file()else'directory']for p in sorted(site.rglob('*'))];assert ns==f['installedNamespace'];assert json.loads(Path('/private/tmp/ashlar-original-commerce-local-query-census-terminal-d.json').read_bytes())['matches']==[]
print(json.dumps({'cases':[x[0]for x in cases],'guardCounts':guardcounts,'completePublicNumericSampleRows':samplecounts,'fullBags':True,'rawCompilerPairs':4,'nativeVector':json.loads(manifest['table_versions_json']),'pins':{k:len(f[k])for k in ['files','selectedResources','installedFiles','originalNativeOpeningPins']},'closing':True,'census':[]}))
