"""Explicit original local source adapter; no provision/discovery/direct libpq fallback."""
import hashlib
from pathlib import Path
from ashlar_host.lifecycle import owned_context
from ashlar_host.original_commerce_local_cli import parse_original_commerce_local
from ashlar_host.original_commerce_local_setup import original_commerce_local_source_ports
from ashlar_host.ordinary_query_connection import OrdinaryQueryConnectionFactory
from ashlar_host.commerce_query_sources import CommerceQuerySourceFactory
from ashlar_host.implicit_arithmetic_configuration import ExplicitCommercePostgresEndpoint,QueryCommerceImplicitArithmeticConfig
CONFIGURATION=Path('/private/tmp/ashlar-original-commerce-local-publication-prep-a/publication.json')
CONFIGURATION_SHA256='dfc2764595b1c296ddae50e8d128712712a1522774aa99ae862cace73a73d090'
CONTAINER='ashlar-private-outbox-original-local-a'

def selected(config):
    if type(config)is not QueryCommerceImplicitArithmeticConfig or type(config.postgres) is not ExplicitCommercePostgresEndpoint:
        raise ValueError('Explicit original fixture endpoint required')
    with owned_context(CONFIGURATION.open('rb')) as stream:raw=stream.read(262145)
    if len(raw)>262144 or hashlib.sha256(raw).hexdigest()!=CONFIGURATION_SHA256:
        raise ValueError('Exact original publication configuration required')
    source=parse_original_commerce_local(raw,initialize=False).source
    endpoint=config.postgres
    if (endpoint.container,endpoint.host,endpoint.port,endpoint.database)!=(CONTAINER,source.host,source.port,source.database):
        raise ValueError('Explicit original query endpoint differs')
    ports=original_commerce_local_source_ports(source)
    return ports

def ordinary_query_connection_factory(config):
    ports=selected(config);registration=ports.registration
    def connection(role):
        if type(role)is not str:raise ValueError('Exact ordinary role required')
        if role==registration.source_role:return registration.source.connection_factory(None)
        if role==registration.ack_role:return registration.metadata_factory(None)
        raise ValueError('Unselected ordinary query role refused')
    return OrdinaryQueryConnectionFactory(connection)

def commerce_query_source_factory(config):
    return CommerceQuerySourceFactory(selected(config).registration)
