"""Explicit installed CLI original-F ordinal2 continuation; no import-time SDK."""
from contextlib import contextmanager
import importlib.util
import sys
import json
import hashlib
from pathlib import Path
from ashlar_host.evolution_cli import ContinueEvolutionInvocation, InvocationFile
from ashlar_host.evolution_operator import ExistingEvolutionOperator
from ashlar_host.delta_custody import DeltaTarget, LOCAL_OPERATION_CAPACITY_8M
from ashlar_host.lifecycle import finish, owned_context
from ashlar_host.evolution_run import EvolutionRunDefinition, EvolutionRunLedger
from ashlar_host.evolution_admission import admit_commerce_evolution, EvolutionSourceSet
import datetime
import os

ROOT=Path('/private/tmp/ashlar-evolution-installed-native-20261011-f/installation')
RUN='8abac861a6ada92aee0fb4080c1230867d358d776c16c92c5a776538ea657f95'
TARGETS='9cb62b91070d7cb499990a55c045096b288c432c515b7cff47efb8fc4198a154'

@contextmanager
def open_evolution(invocation):
    if type(invocation) is not ContinueEvolutionInvocation or invocation.through_ordinal != 2 or invocation.expected_sha256 != RUN or invocation.ledger_path != ROOT/'run.sqlite':
        raise PermissionError('Exact original-F ordinal2 invocation required')
    if (str(invocation.producer.source),str(invocation.producer.bun),str(invocation.producer.git),invocation.producer.timeout_seconds,invocation.producer.maximum_output_bytes,invocation.producer.maximum_receipt_bytes) != ('/private/tmp/ashlar-umf-evolution-land-6a292','/opt/homebrew/Cellar/bun/1.4.2/bin/bun','/usr/bin/git',30,1048576,4194304):
        raise PermissionError('Exact original producer selection required')
    original=InvocationFile.read(ROOT/'original-run.json',65536)
    targets_file=InvocationFile.read(ROOT/'targets.json',65536)
    if hashlib.sha256(original.raw).hexdigest()!=RUN or hashlib.sha256(targets_file.raw).hexdigest()!=TARGETS:
        raise PermissionError('Original run/target bytes differ')
    spec=importlib.util.spec_from_file_location('explicit_fixture_provider','/private/tmp/ashlar-evolution-installed-provider-b.py')
    helper=importlib.util.module_from_spec(spec);sys.modules[spec.name]=helper;spec.loader.exec_module(helper)
    selected=helper.FixtureSelection.capture('/private/tmp/ashlar-private-outbox-fixture-prep-b/operation/fixture-c/inventory.json','f6f77011c66650b4eecc7efe034806a36db0e54c4bc1e4babdfd5d6eb8c1c7b9')
    targets=tuple(DeltaTarget(row['table'],Path(row['path']),row['uuid']) for row in json.loads(targets_file.raw))
    spark=None;primary=None
    try:
        from pyspark.sql import SparkSession
        spark=(SparkSession.builder.master('local[1]').appName('Ashlar original-F continuation ordinal2')
            .config('spark.driver.memory','512m').config('spark.sql.shuffle.partitions','1')
            .config('spark.databricks.delta.snapshotPartitions','1').config('spark.ui.enabled','false')
            .config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true')
            .config('spark.jars','/private/tmp/ashlar-supply-chain-finite-native-jars-f/delta-spark_2.13-4.0.0.jar,/private/tmp/ashlar-supply-chain-finite-native-jars-f/delta-storage-4.0.0.jar')
            .config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension')
            .config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog').getOrCreate())
        @contextmanager
        def native():
            yield spark
        operator=ExistingEvolutionOperator('private-public-evolution-20261011-a',ROOT/'operations.sqlite',ROOT/'original-run.json',targets,helper.registrations(selected),LOCAL_OPERATION_CAPACITY_8M,native)
        original.renew(65536);targets_file.renew(65536);selected.renew()
        with owned_context(operator.open_evolution(invocation)) as configuration:
            yield configuration
            sources=EvolutionSourceSet(tuple(admit_commerce_evolution(invocation.producer,source_system=item['scope']['feed'],epoch=item['scope']['epoch']) for item in selected.document()['sources']))
            definition=EvolutionRunDefinition(original.raw)
            def custody(path,run,context):
                if path!=invocation.ledger_path or run.raw!=original.raw or context is not configuration.context:
                    raise PermissionError('Exact held original prefix required')
                return configuration.policy.admit_run(run,context)
            def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
            def cell(value):
                if type(value) is datetime.datetime:
                    if value.tzinfo is None:value=value.replace(tzinfo=datetime.timezone.utc)
                    delta=value-datetime.datetime(1970,1,1,tzinfo=datetime.timezone.utc)
                    return str((delta.days*86400+delta.seconds)*1000000+delta.microseconds)
                if type(value) is int:return str(value)
                if type(value) in (str,type(None)):return value
                raise ValueError('Unsupported original native scalar')
            with owned_context(configuration.driver.writer('original-prefix-oracles',configuration.context)):
                view=EvolutionRunLedger.inspect(invocation.ledger_path,definition,context=configuration.context,custody=custody)
                if any(row[1]!='completed' for row in view.slots[:3]) or any(row[1]!='unprepared' for row in view.slots[3:]):
                    raise PermissionError('Exact completed three-prefix/unprepared suffix required')
                prefixes={'A':0,'B':0};request=definition.document()['request'];clocks=dict(zip(request['source_order'],request['clocks']))
                observations=[]
                for step,slot in zip(definition.document()['schedule'][:3],view.slots[:3]):
                    prefixes[step['source']]=step['prefix'];descriptor=json.loads(slot[4]);versions=json.loads(descriptor['table_versions_json'])
                    expected=sources.oracle(dict(prefixes),materialized_at=clocks)
                    for role,rows in expected.items():
                        target=next(t for t in targets if t.table.endswith('.'+role))
                        if spark.sql('DESCRIBE DETAIL delta.`'+str(target.path)+'`').first().id!=target.uuid:raise PermissionError('Native original UUID differs')
                        frame=spark.read.format('delta').option('versionAsOf',versions[target.table]).load(str(target.path))
                        actual=[{name:cell(value) for name,value in row.asDict().items()} for row in frame.collect()]
                        observations.append({'ordinal':slot[0],'role':role,'uuid':target.uuid,'version':versions[target.table],'schema':frame.schema.jsonValue(),'rows':actual,'expected':rows})
                        wire=encoded(observations[-1])
                        if len(wire)>4194304:raise ValueError('Prefix oracle capture capacity')
                        with owned_context((invocation.receipt_path.parent/('prefix-'+str(slot[0])+'-'+role+'.json')).open('xb')) as stream:
                            stream.write(wire);stream.flush();os.fsync(stream.fileno())
                        if sorted(actual,key=encoded)!=sorted(rows,key=encoded):raise ValueError('Full original prefix native bag differs')
                path=invocation.receipt_path.parent/'prefix-native-oracles.json'
                with owned_context(path.open('xb')) as stream:
                    stream.write(encoded({'profile':'ashlar-original-prefix-native-observations/0.1','throughOrdinal':2,'observations':observations}));stream.flush();os.fsync(stream.fileno())
                closing=EvolutionRunLedger.inspect(invocation.ledger_path,definition,context=configuration.context,custody=custody)
                if closing!=view:raise PermissionError('Original prefix changed during oracle reads')
    except BaseException as error:
        primary=error
    def stop():
        if spark is not None:spark.stop()
    finish(primary,[stop,lambda:original.renew(65536),lambda:targets_file.renew(65536),selected.renew])
