from pathlib import Path
import json
from ashlar_host.original_medical_local_configuration import parse_original_medical_local
from ashlar_host.original_medical_local_sources import original_medical_local_source_ports
from ashlar_host.existing_outbox_authority import ordinary,privileges,one
from ashlar_host.postgres import Session
from ashlar_host.lifecycle import finish
r=Path(__file__).parent;c=parse_original_medical_local((r/'preflight.json').read_bytes());p=original_medical_local_source_ports(c.source);reg=p.registration;ctx=object();results={};connections=[];primary=None

def observe(connection,ack):
 session=Session(connection);ordinary(session,reg.ack_role if ack else reg.source_role,reg.database);privileges(session,reg,ack=ack)
 if ack:
  row=one(session,'SELECT "'+reg.source.scope.service_schema+'".scope_binding(CAST(:scope AS uuid)) AS binding',{'scope':reg.source.scope.scope_id},('binding',));expected=dict(reg.source.metadata()['scope']);expected.pop('service_schema');expected.update(source_schema=reg.source.source_schema,source_signature_sha256=reg.source.source_signature_sha256);assert row['binding']==expected;results['ackBinding']=row['binding']
  ack=one(session,'SELECT * FROM "'+reg.source.scope.service_schema+'".observe(CAST(:scope AS uuid),CAST(:position AS bigint))',{'scope':reg.source.scope.scope_id,'position':'1'},('position','request_hex','manifest_hex','receipt_hex'));assert ack=={'position':'0','request_hex':None,'manifest_hex':None,'receipt_hex':None};results['ackPosition']='0';results['ackReceiptPresent']=False
 else:
  row=one(session,'SELECT position::text AS position FROM "'+reg.source.source_schema+'".head WHERE id=1',{},('position',));assert row=={'position':'1'};count=one(session,'SELECT count(*) AS count FROM "'+reg.source.source_schema+'".batch',{},('count',));assert count=={'count':1};results['head']=row['position'];results['batches']=count['count']
try:
 reader=reg.source.connection_factory(ctx);connections.append((reader,False));observe(reader,False)
 ack=reg.metadata_factory(ctx);connections.append((ack,True));observe(ack,True)
except BaseException as error:primary=error
finish(primary,[lambda x=x,a=a:observe(x,a)for x,a in connections]+[x.rollback for x,a in connections]+[x.close for x,a in connections])
results['closing']=True;results['scope']='Current ordinary reader/ACK SELECT/privilege/signature observation only; no writer callback, append, ACK submit, native lease or publication authority.';(r/'source-post-preflight.json').write_text(json.dumps(results,indent=2)+'\n');print('Postfailure ordinary reader+ACK SELECT/independentclosing PASS',results['head'],results['batches'])
