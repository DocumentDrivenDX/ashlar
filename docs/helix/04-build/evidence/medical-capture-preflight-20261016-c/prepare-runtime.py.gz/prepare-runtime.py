from pathlib import Path
import json,hashlib,os,stat,uuid,csv,base64,zipfile
R=Path('/private/tmp/ashlar-medical-capture-preflight-20261016-c');V=Path('/private/tmp/ashlar-medical-capture-preflight-20261016-c/environment');S=V/'lib/python3.12/site-packages';TS=Path('/Users/erik/Projects/tablespec/.venv/lib/python3.12/site-packages');D=S;J=Path('/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home')
def pin(p):
 p=p.resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(n,v):p=R/n;p.write_text(json.dumps(v,indent=2)+'\n');return pin(p)
old={x['path']:x for x in json.loads(Path('/private/tmp/ashlar-medical-preflight-installed-prep-20261014-d/closure.json').read_bytes())['files']}
P=(S/'psycopg').resolve().parent

roots=[J,TS/'pyspark',TS/'pyspark-4.0.1.dist-info',TS/'py4j',TS/'py4j-0.10.9.9.dist-info',D,S,V/'bin',*[P/n for n in ['psycopg','psycopg_binary','psycopg-3.2.13.dist-info','psycopg_binary-3.2.13.dist-info','typing_extensions-4.16.0.dist-info']]];namespace={'roots':{},'links':[],'site_startups':{str(S):{}}};closure={};metadata={}
def record(p):
 q=p.resolve();k=str(q)
 if k in closure:return
 st=q.stat();original=old.get(k)
 if original:
  row=original if st.st_size==original['bytes'] else pin(q)
 else:row=pin(q)
 closure[k]=row;metadata[k]={'path':k,'dev':st.st_dev,'ino':st.st_ino,'mode':st.st_mode,'mtimeNs':st.st_mtime_ns,'bytes':st.st_size}
for root in roots:
 entries={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():
   entries[str(p)]={'kind':'symlink','target':os.readlink(p),'resolved':str(p.resolve())};namespace['links'].append({'path':str(p),'target':os.readlink(p),'resolved':str(p.resolve())})
  elif p.is_dir():entries[str(p)]={'kind':'directory'}
  elif p.is_file():entries[str(p)]={'kind':'file','bytes':p.stat().st_size};record(p)
  else:raise ValueError('Unexpected namespace entry')
 namespace['roots'][str(root)]=entries
for p in S.iterdir():
 if p.name.endswith('.pth')or p.name in ['sitecustomize.py','usercustomize.py']:
  namespace['site_startups'][str(S)][str(p)]=namespace['roots'][str(S)][str(p)]
python=(V/'bin/python3').resolve();bun=Path('/opt/homebrew/Cellar/bun/1.4.2/bin/bun');git=Path('/usr/bin/git');jars=[Path('/private/tmp/ashlar-current-commerce-preparation-20261015-9pn8k_h7/query-jars/delta-spark_2.13-4.0.0.jar'),Path('/private/tmp/ashlar-current-commerce-preparation-20261015-9pn8k_h7/query-jars/delta-storage-4.0.0.jar')]
selectedpaths=[python,J/'bin/java',J/'lib/jvm.cfg',bun,git,*jars,TS/'pyspark/__init__.py',TS/'pyspark-4.0.1.dist-info/METADATA',D/'delta/__init__.py',D/'delta_spark-4.0.0.dist-info/METADATA']
selectedpaths += [P/'typing_extensions.py',P/'psycopg/__init__.py',P/'psycopg_binary/__init__.py',P/'psycopg-3.2.13.dist-info/METADATA',P/'psycopg_binary-3.2.13.dist-info/METADATA']
for p in selectedpaths:record(p)
selected=[closure[str(p.resolve())]for p in selectedpaths]
assert len(closure)<=20000 and sum(len(x)for x in namespace['roots'].values())<=20000
refs=[{'kind':kind,'record':write(kind+'.json',value),'profile':profile,'scope':'Complete named selected roots/current metadata; SDK hashes reused from original J closure, fresh installed files hashed.'}for kind,value,profile in [('namespace',namespace,'ashlar-evolution-runtime-namespace-j/0.1'),('metadata',{'files':list(metadata.values()),'qualification':'Current named metadata only, not full payload rehash'},'ashlar-evolution-runtime-metadata-j/0.1'),('closure',{'files':list(closure.values()),'format':'ashlar-evolution-installed-runtime-closure/0.1','scope':'Original reviewed SDK hashes plus fresh installed files'},'ashlar-evolution-installed-runtime-closure/0.1')]]
runtime={'python':pin(python),'python_version':'3.12.14','java_home':str(J),'java':pin(J/'bin/java'),'java_version':'21.0.12','jvm_config':pin(J/'lib/jvm.cfg'),'pyspark_root':str(S),'spark_version':'4.0.1','delta_root':str(S),'delta_version':'4.0.0','jars':[pin(p)for p in jars]}
imports=[{'module':m,'distribution':dist,'version':ver,'origin':str(S/m/'__init__.py'),'metadata':pin(meta)}for m,dist,ver,meta in [('pyspark','pyspark','4.0.1',TS/'pyspark-4.0.1.dist-info/METADATA'),('delta','delta-spark','4.0.0',D/'delta_spark-4.0.0.dist-info/METADATA')]]
evidence=[{'kind':'spark-delta-native','record':pin(Path('/private/tmp/ashlar-medical-capture-preflight-20261016-c/prior-native-review.json')),'profile':'ashlar-supply-chain-installed-native-evidence/0.1','scope':'Prior finite Spark4/Delta4 supply-chain evidence; not medical native success or new Python312 success'}]
runtime['qualification']=write('runtime-selection.json',{'profile':'ashlar-original-medical-runtime-selection/0.1','runtime':runtime,'imports':imports,'selected_files':selected,'namespaces':refs,'evidence':evidence,'scope':'selected-runtime-correspondence-only'})

config=json.loads(Path('/private/tmp/ashlar-medical-preflight-installed-prep-20261014-d/configuration.json').read_bytes())
config['runtime']=runtime
config['output']=str(R/'preflight-output')
config['bounds']['native_seconds']=60
config['bounds']['whole_seconds']=150
write('configuration.json',config)
write('preparation-facts.json',{'closureFiles':len(closure),'namespaceEntries':sum(len(x)for x in namespace['roots'].values()),'referenceBytes':sum(x['record']['bytes']for x in refs),'selectedFiles':len(selected),'scope':'Fresh installed reviewed wheel; reviewed SDK hash reuse with current metadata. No native, source, ACK or full recovery execution; not OS closure.'})
