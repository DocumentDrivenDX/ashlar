"""One reviewed finite native process, full opening/closing custody and bounded capture."""
import hashlib,importlib.util,json,os,sys
from pathlib import Path
CLOSURE=Path('/private/tmp/ashlar-supply-chain-native-read-closure-h.json')
CLOSURE_SHA='b50e5be8d613f33b60339eba522ed871e35dc0984a82b83ad988ed1701cd3c00'
ROOT=Path('/private/tmp/ashlar-supply-chain-native-read-source-g')
OUTPUT=Path('/private/tmp/ashlar-supply-chain-native-read-h')
RECEIPT=Path('/private/tmp/ashlar-supply-chain-native-read-h.receipt.json')
CAPTURE=Path('/private/tmp/ashlar-count-star-installed-cli-capture-a.py')
PYTHON='/Users/erik/.local/share/uv/python/cpython-3.11.17-macos-aarch64-none/bin/python3.11'
JAVA='/opt/homebrew/Cellar/openjdk@21/21.0.12.1/libexec/openjdk.jdk/Contents/Home'
ENV={'PATH':JAVA+'/bin:/usr/bin:/bin','JAVA_HOME':JAVA,'LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1',
 'PYTHONPATH':str(ROOT/'src')+':/private/tmp/ashlar-indexed-delta4-python-20261010-a:/private/tmp/ashlar-spark4-python39-bridge:/private/tmp/truss-python-report-schema-env/lib/python3.11/site-packages',
 'PYSPARK_PYTHON':PYTHON,'PYSPARK_DRIVER_PYTHON':PYTHON,'SPARK_LOCAL_IP':'127.0.0.1','SPARK_LOCAL_HOSTNAME':'localhost',
 'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_TERMINAL_PROMPT':'0'}
COMMAND=[PYTHON,'-B','-S','/private/tmp/ashlar-supply-chain-native-read-probe-h.py']
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for block in iter(lambda:f.read(262144),b''):h.update(block)
 return h.hexdigest()
def verify():
 if digest(CLOSURE)!=CLOSURE_SHA:raise ValueError('closure pin')
 plan=json.loads(CLOSURE.read_bytes())
 if len(plan['files'])>plan['maximum_files']or sum(r['bytes']for r in plan['files'].values())>plan['maximum_total_bytes']:raise ValueError('closed custody capacity')
 for link in plan['symlinks']:
  p=Path(link['path'])
  if not p.is_symlink()or os.readlink(p)!=link['target']or str(p.resolve())!=link['resolved']:raise ValueError('dependency selection link changed')
 for root in plan['roots']:
  actual={str(p.resolve())for p in Path(root).rglob('*')if p.is_file()and '__pycache__'not in p.parts and p.name!='.DS_Store'and p.suffix!='.pyc'}
  expected={n for n in plan['files']if n.startswith(str(Path(root).resolve())+'/')}
  if actual!=expected:raise ValueError('complete selected custody inventory changed')
 for name,r in plan['files'].items():
  p=Path(name)
  if p.is_symlink()or not p.is_file()or p.stat().st_size!=r['bytes']or digest(p)!=r['sha256']:raise ValueError('selected custody bytes changed')
def write_receipt(path,value,primary,select_failure):
 stream=None
 try:
  stream=path.open('x');json.dump(value,stream,indent=2);stream.write('\n')
 except BaseException as error:primary=select_failure(primary,error)
 finally:
  if stream is not None:
   try:stream.close()
   except BaseException as error:primary=select_failure(primary,error)
 return primary
def main():
 if len(sys.argv)!=2 or digest(Path(__file__))!=sys.argv[1]:raise ValueError('reviewed runner pin')
 verify()
 if OUTPUT.exists()or RECEIPT.exists():raise ValueError('fresh native outputs required')
 spec=importlib.util.spec_from_file_location('capture',CAPTURE);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
 primary=None;result=None;closing=True
 try:result=capture.capture(COMMAND,ROOT,ENV,Path('/private/tmp/ashlar-supply-chain-native-read-h.stdout'),Path('/private/tmp/ashlar-supply-chain-native-read-h.stderr'),300,16*1024*1024)
 except BaseException as error:primary=error
 finally:
  try:verify()
  except BaseException as error:closing=False;primary=capture.select_failure(primary,error)
 primary=write_receipt(RECEIPT,{'result':result,'openingClosingCustody':closing,'failureType':None if primary is None else type(primary).__name__,'sourceRevision':'30a9dc4e31fac90218272a7f12d229fa931a99eb','qualification':'Retained F publication read-only diagnostic and fresh actual public dataset validation; no ingestion/replay or successful native query claim inferred from failure.'},primary,capture.select_failure)
 if primary is not None:raise primary
 if result['exitCode']:raise SystemExit(result['exitCode'])
if __name__=='__main__':main()
