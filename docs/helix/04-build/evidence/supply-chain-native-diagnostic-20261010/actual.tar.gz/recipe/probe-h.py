"""Fresh public dataset validation and retained-publication read-only diagnosis."""
import sys
if sys.path[0]!='/private/tmp':raise ValueError('Explicit probe selection required')
del sys.path[0]
import json,hashlib
from pathlib import Path
from ashlar.weft_count_star_distribution import CountStarDistributionPaths,installed_count_star_schema_bundle
from ashlar.weft_path_decode import PathDecodeConfig
from ashlar.native import quote_table_identifier
from ashlar_host.supply_chain_producer import SupplyChainProducerConfig,HeldSupplyChainDataset
from ashlar_host.supply_chain_finite_source import FiniteSupplyChainSource,UMF_REVISION
from ashlar_host.supply_chain_request import SOURCE_SYSTEM,SOURCE_SHA
from ashlar_host.supply_chain_native import PrivateFiniteLease
from ashlar_host.supply_chain_publication import FiniteSupplyChainDriver,GRAPH_ROLES
from ashlar_host.supply_chain_query import query_supply_chain_cases,finite_public_source
from ashlar_host.supply_chain_compile import SupplyChainCompileConfig
from ashlar_host.count_star_execution import CountStarExecutionConfig
from ashlar_host.count_star_admission import CountStarAdmissionConfig
from ashlar_host.count_star_schema import make_offline_count_star_schema_validation
from ashlar_host.path_capture import PathCaptureConfig
from ashlar_host.delta_custody import DeltaTarget
from ashlar_host.driver import PrivatePolicy
from ashlar_host.publication_reader import ReadOnlyTransport
from ashlar_host.schema_rows import fixture_columns
from ashlar_host.resources import RESOURCE_ROOT
from ashlar_host.evolution_producer import snapshot
from ashlar_host.lifecycle import finish,owned_context
from pyspark.sql import SparkSession
ORIGINAL=Path('/private/tmp/ashlar-supply-chain-finite-native-f')
OUTPUT=Path('/private/tmp/ashlar-supply-chain-native-read-h')
BASE=Path('/Users/erik/Projects/ashlar/examples/domain-packs/supply-chain/upstream')
JARS=Path('/private/tmp/ashlar-supply-chain-finite-native-jars-f')
compiler=CountStarDistributionPaths(Path('/private/tmp/ashlar-count-star-fresh-install-e/checkout/distributions/index.json'),Path('/private/tmp/ashlar-count-star-installed-cli-c/weft-installation'))
OUTPUT.mkdir(mode=0o700)
lease=PrivateFiniteLease(ORIGINAL,create=False);spark=None;transport=None;source=None;primary=None
try:
    producer=HeldSupplyChainDataset(SupplyChainProducerConfig(Path('/private/tmp/ashlar-umf-supply-chain-land-de11'),Path('/opt/homebrew/Cellar/bun/1.4.2/bin/bun'),Path('/usr/bin/git'),30,1048576,8388608),BASE/'ontology.json',BASE/'graph/fixture.json',OUTPUT/'public-dataset.json')
    if producer.raw!=snapshot(ORIGINAL/'public-dataset.json',8388608):raise ValueError('Fresh actual public receipt differs from original observation')
    source=FiniteSupplyChainSource(BASE/'ontology.json',BASE/'graph/fixture.json',current_dataset=producer)
    registry=json.loads(snapshot(ORIGINAL/'registry.json',1048576));request=json.loads(snapshot(ORIGINAL/'request.json',8388608));pack=snapshot(BASE/'pack.json',1048576)
    targets=tuple(DeltaTarget(r['table'],Path(r['path']),r['uuid'])for r in registry['targets']);tables=registry['tables'];context=object();policy=PrivatePolicy(context,targets);policy.initializing=False
    original={t.table:(str(t.path),t.uuid)for t in targets}
    def current_admission(held_source,held_request,manifest,supplied):
        if supplied is not context or held_source is not source:raise PermissionError('Original retained publication context differs')
        lease.renew();source.metadata()
        if held_request is not None:source.admit_request(held_request)
        if manifest is not None:
            if json.loads(manifest['schema_revisions_json'])!={SOURCE_SYSTEM:SOURCE_SHA}or set(json.loads(manifest['table_versions_json']))!={tables[r]for r in GRAPH_ROLES}:raise PermissionError('Complete original retained source/vector differs')
        if {t.table:(str(t.path),t.uuid)for t in targets}!=original:raise PermissionError('Original retained targets differ')
        lease.renew()
    spark=(SparkSession.builder.master('local[1]').appName('Retained original supply-chain read-only diagnosis').config('spark.driver.memory','512m').config('spark.ui.enabled','false').config('spark.sql.shuffle.partitions','1').config('spark.databricks.delta.snapshotPartitions','1').config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true').config('spark.sql.decimalOperations.allowPrecisionLoss','false').config('spark.jars',','.join(str(JARS/n)for n in ('delta-spark_2.13-4.0.0.jar','delta-storage-4.0.0.jar'))).config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension').config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog').config('spark.sql.warehouse.dir',str(OUTPUT/'warehouse')).getOrCreate())
    transport=ReadOnlyTransport.open(spark,ORIGINAL/'operations.sqlite',registry['installation'],targets,policy,capacity=registry['operation_capacity'])
    driver=FiniteSupplyChainDriver(transport,policy,context,tables,fixture_columns(RESOURCE_ROOT),source,registry['publication_id'],current_admission=current_admission);driver.restore_committed(request)
    aliases={tables[r]:'spark_catalog.supplychainfinite.'+r for r in GRAPH_ROLES}
    spark.sql('CREATE DATABASE IF NOT EXISTS supplychainfinite')
    for table,alias in aliases.items():spark.sql('CREATE TABLE '+quote_table_identifier(alias)+" USING DELTA LOCATION '"+str(transport.targets[table].path)+"'")
    maximum=16777216;schemas=dict(installed_count_star_schema_bundle(compiler));selected={n:schemas[n]for n in ('compile-request-v0.4.1.schema.json','compile-response-v0.4.1.schema.json','logical-plan-v0.4.1.schema.json')}
    execution=CountStarExecutionConfig(CountStarAdmissionConfig(maximum,make_offline_count_star_schema_validation(selected)),PathCaptureConfig(128,maximum,maximum),PathDecodeConfig(maximum),finite_public_source(source,maximum),UMF_REVISION)
    with owned_context((OUTPUT/'compiler-observations.jsonl').open('xb'))as compiler_log,owned_context((OUTPUT/'native-observations.jsonl').open('xb'))as native_log:
        counts={'compiler':0,'native':0}
        def record(log,key,value,limit):
            body=bytearray()
            for chunk in json.JSONEncoder(separators=(',',':'),ensure_ascii=True).iterencode(value):
                raw=chunk.encode()
                if counts[key]+len(body)+len(raw)+1>limit:raise ValueError('Diagnostic observation bound')
                body.extend(raw)
            body.extend(b'\n')
            if log.write(body)!=len(body):raise ValueError('Diagnostic write refused')
            log.flush();counts[key]+=len(body)
        def observe(name,iteration,request,response):record(compiler_log,'compiler',{'id':name,'iteration':iteration,'requestHex':request.hex(),'responseHex':response.hex()},8388608)
        def native(name,captured):record(native_log,'native',{'id':name,'captured':captured},67108864)
        result=query_supply_chain_cases(driver,pack,aliases,SupplyChainCompileConfig(compiler,maximum),execution,observe=observe,observe_native=native)
except BaseException as error:primary=error
callbacks=[]
if transport is not None:callbacks.append(transport.close)
if spark is not None:callbacks.append(spark.stop)
if source is not None:callbacks.append(source.renew)
callbacks.extend([lease.renew,lease.close]);finish(primary,callbacks)
print(json.dumps({'cases':len(result['cases']),'qualification':'Retained original publication read-only diagnosis with fresh actual public dataset validation; no ingestion/replay/native qualification inferred from failure.'}))
