"""Inert outer receipt cancellation identity; no child or native imports."""
import importlib.util,unittest
spec=importlib.util.spec_from_file_location('launcher','/private/tmp/ashlar-supply-chain-native-read-launcher-h.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class Controls(unittest.TestCase):
 def test_receipt_failure_priority(self):
  for body,closing in ((KeyboardInterrupt(),ValueError('close')),(SystemExit(),ValueError('close')),(GeneratorExit(),ValueError('close')),(ValueError('body'),KeyboardInterrupt())):
   class Stream:
    def write(self,*args):raise body
    def close(self):raise closing
   class Path:
    def open(self,mode):return Stream()
   expected=body if not isinstance(body,Exception)else closing
   with self.assertRaises(type(expected))as caught:module.write_receipt(Path(),{})
   self.assertIs(caught.exception,expected)
if __name__=='__main__':unittest.main()
