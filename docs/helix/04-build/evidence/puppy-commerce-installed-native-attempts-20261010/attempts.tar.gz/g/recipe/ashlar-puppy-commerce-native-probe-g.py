"""Actual installed public native commerce queries; explicit retained-fixture scope."""
import sys
# Script directory is not an import authority.
sys.path[:]=[p for p in sys.path if p not in ('','/private/tmp')]
import base64,hashlib,json,os,stat,fcntl
from pathlib import Path
from contextlib import contextmanager
from ashlar_host.commerce_admission import CommerceAdmission
from ashlar_host.puppy_commerce_prepare import PuppyCommercePrepareConfig,prepare_exact_commerce
from ashlar_host.puppy_commerce_scenarios import bag
from ashlar_host.lifecycle import finish,owned_context
from ashlar.commerce_source import build_transaction
WORK=Path('/private/tmp/ashlar-puppy-commerce-native-20261010-g')
REPO=Path('/Users/erik/Projects/ashlar')
SOURCE=REPO/'examples/domain-packs/commerce/upstream'
EXPORT=REPO/'docs/helix/04-build/evidence/commerce-graph-export-20261009'
PUBLIC=REPO/'docs/helix/04-build/evidence/commerce-public-dataset-20261009.json'
paths=[SOURCE/'ontology.json',SOURCE/'graph/fixture.json',SOURCE/'pack.json',EXPORT/'release.graph.json',EXPORT/'custody.json',PUBLIC]
def read(p,maximum=16777216):
 if p.is_symlink()or not p.is_file()or p.stat().st_size>maximum:raise ValueError('Exact ordinary bounded original required')
 with owned_context(p.open('rb'))as f:raw=f.read(maximum+1)
 if len(raw)>maximum:raise ValueError('Original bound')
 return raw
originals={str(p):(read(p),(p.stat().st_dev,p.stat().st_ino),str(p.parent.resolve()),(p.parent.stat().st_dev,p.parent.stat().st_ino))for p in paths}
model,graph,pack,release,custody,public=[originals[str(p)][0]for p in paths]
rs=hashlib.sha256(release).hexdigest();cs=hashlib.sha256(custody).hexdigest()
release_value=json.loads(release)
bindings_raw=base64.b64decode(json.loads(release_value['publication']['validation_report_json'])['source_admission']['original_bindings_base64'],validate=True)
binding_path=WORK/'original-bindings.json'
with owned_context(binding_path.open('xb'))as stream:stream.write(bindings_raw)
batch,bindings=build_transaction(model,graph,source_system=release_value['nodes'][0]['source_system'])
admission=CommerceAdmission(batch,bindings,paths[0],paths[1],binding_path,PUBLIC)
context=object()
class RetainedFixturePolicy:
 """Explicit operator-authorized original retained fixture; no production grant.

 Named file/inode readback and a cooperating local lease renew that selected
 finite fixture interval. Digests establish correspondence, not authorization.
 No source activation, graph model activation or live publication is permitted.
 """
 def __init__(self):self.fd=None;self.identity=None;self.opening=False;self.closing=False
 def current(self):
  for name,(raw,identity,parent,parent_identity)in originals.items():
   p=Path(name)
   if p.is_symlink()or(p.stat().st_dev,p.stat().st_ino)!=identity or str(p.parent.resolve())!=parent or(p.parent.stat().st_dev,p.parent.stat().st_ino)!=parent_identity or read(p)!=raw:raise PermissionError('Current selected retained fixture custody lost')
  admission.metadata()
  if self.fd is not None:
   p=WORK/'retained-source.lease';st=os.fstat(self.fd)
   if p.is_symlink()or not stat.S_ISREG(st.st_mode)or(st.st_dev,st.st_ino)!=self.identity or(p.stat().st_dev,p.stat().st_ino)!=self.identity or st.st_uid!=os.getuid()or st.st_mode&0o777!=0o600:raise PermissionError('Current owned retained fixture interval lost')
 @contextmanager
 def hold(self,c):
  if c is not context or self.fd is not None:raise PermissionError('Exact retained fixture context required')
  self.current();p=WORK/'retained-source.lease';fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_RDWR|os.O_NOFOLLOW,0o600);self.fd=fd;self.identity=(os.fstat(fd).st_dev,os.fstat(fd).st_ino);primary=None
  def close():
   self.fd=None;os.close(fd)
  def remove():
   if p.is_symlink()or(p.stat().st_dev,p.stat().st_ino)!=self.identity:raise PermissionError('Owned lease name changed; no foreign unlink')
   p.unlink()
  try:
   fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);self.current();self.opening=True;yield
  except BaseException as error:primary=error
  finish(primary,[self.current,lambda:fcntl.flock(fd,fcntl.LOCK_UN),remove,close])
  self.closing=True
 def admit_exact_commerce(self,facts,c):
  if c is not context or self.fd is None or facts['release_sha256']!=rs or facts['custody_sha256']!=cs:raise PermissionError('Only explicitly selected original retained fixture admitted')
  self.current()
  import duckdb
  if duckdb.__version__!='1.5.6':raise PermissionError('Exact selected native SDK required before database effects')
 def renew_exact_commerce(self,facts,c):self.admit_exact_commerce(facts,c)

import subprocess,time,urllib.request,urllib.error,importlib.util
from neo4j import GraphDatabase,Query
from gremlin_python.driver import client as gremlin_client,serializer
from ashlar_host.puppy_commerce_scenarios import PuppyCommerceScenarioConfig,execute_commerce_scenarios
from ashlar_host.puppy_native import admit_original_subset
BASE=Path('/private/tmp/ashlar-puppy-commerce-installed-20261010-b')
NUMERIC=BASE/'numeric';database=NUMERIC/'commerce-exact.duckdb'
prepared=json.loads(read(NUMERIC/'receipt.json'));model_value=json.loads(read(NUMERIC/'model.json'))
db_hash=prepared['database_sha256'];db_identity=(database.stat().st_dev,database.stat().st_ino)
model_value={'catalog':model_value['catalogs'],'node':model_value['node'],'edge':model_value['edge']}
model_value['catalog'][0]['jdbc']['jdbcUri']='jdbc:duckdb:/tmp/commerce-exact.duckdb'
model_raw=(json.dumps(model_value,sort_keys=True,separators=(',',':'))+'\n').encode()
NAME='ashlar-puppy-commerce-native-20261010-g'
IMAGE='sha256:6d016d5a7e3eab0a57bd4d23c4e218467d00c7661fcda215ea2a429941a68cee'
# Explicit nonsecret credentials only for this fresh owned isolated fixture.
USER='ashlarfixture';PASSWORD='ashlar-local-commerce-fixture'
ENV={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C','LC_ALL':'C','DOCKER_HOST':'unix:///Users/erik/.orbstack/run/docker.sock'}
spec=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
container=None;driver=None;remote=None;counter=0;primary=None;records=[];deadline=time.monotonic()+160
from importlib.metadata import version
if version('neo4j')!='5.28.2'or version('gremlinpython')!='3.7.3':raise PermissionError('Exact selected protocol SDKs required')

def retain(path,value):
 raw=(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
 if len(raw)>4194304:raise ValueError('Closed observation capture bound')
 with owned_context(path.open('xb'))as stream:
  if stream.write(raw)!=len(raw):raise ValueError('Complete raw capture required')
  stream.flush();os.fsync(stream.fileno())

def docker(*args):
 global counter
 counter+=1;label='docker-'+str(counter);out=WORK/(label+'.stdout');err=WORK/(label+'.stderr')
 remaining=15 if args[0]in ('logs','rm')else deadline-time.monotonic()
 if remaining<=0:raise TimeoutError('Native whole budget')
 argv=['/usr/local/bin/docker',*args];r=capture.capture(argv,str(WORK),ENV,str(out),str(err),min(15,remaining),1048576,None)
 retain(WORK/(label+'.json'),{'argv':argv,**r})
 if r['exitCode']:raise ValueError('Native Docker operation refused')
 return out.read_bytes().decode().strip()

def http(method,body=None):
 headers={'Authorization':'Basic '+base64.b64encode((USER+':'+PASSWORD).encode()).decode()}
 if body is not None:headers['Content-Type']='application/json'
 req=urllib.request.Request('http://127.0.0.1:18883'+('/schema?postUploadBehavior=none'if method=='POST'else'/schemajson'),data=body,headers=headers,method=method)
 response=None;failure=None;raw=None;status=None
 try:
  response=urllib.request.urlopen(req,timeout=15);status=response.status;raw=response.read(1048577)
 except urllib.error.HTTPError as error:response=error;status=error.code;raw=error.read(1048577)
 except BaseException as error:failure=error
 finally:
  records.append({'method':method,'request':None if body is None else body.decode(),'status':status,'response':None if raw is None else raw.decode(),'exception':None if failure is None else type(failure).__name__})
 finish(failure,[]if response is None else[response.close])
 if raw is None or len(raw)>1048576:raise ValueError('Complete HTTP capture bound')
 return status,raw

class NativePolicy(RetainedFixturePolicy):
 catalog_visible=None
 def current(self):
  super().current()
  if database.is_symlink()or(database.stat().st_dev,database.stat().st_ino)!=db_identity or hashlib.sha256(read(database,33554432)).hexdigest()!=db_hash:raise PermissionError('Sealed native source database changed')
  if container is not None:
   f=json.loads(docker('inspect',container))[0];h=f['HostConfig']
   expected_ports={'8081/tcp':[{'HostIp':'127.0.0.1','HostPort':'18883'}],'7687/tcp':[{'HostIp':'127.0.0.1','HostPort':'17690'}],'8182/tcp':[{'HostIp':'127.0.0.1','HostPort':'18182'}]}
   if f['Id']!=container or f['Image']!=IMAGE or f['Name']!='/'+NAME or not f['State']['Running']or h['Memory']!=3221225472 or h['NanoCpus']!=2000000000 or h['PortBindings']!=expected_ports:raise PermissionError('Exact owned bounded native instance changed')
   mounts=f['Mounts']
   if len(mounts)!=1 or mounts[0]['Source']!=str(database)or mounts[0]['Destination']!='/tmp/commerce-exact.duckdb'or mounts[0]['RW']is not False:raise PermissionError('Exact read-only native mount changed')
   if docker('exec',container,'sha256sum','/tmp/commerce-exact.duckdb').split()[0]!=db_hash:raise PermissionError('Mounted original database bytes changed')
   status,raw=http('GET')
   if status!=200:raise PermissionError('Current native schema response refused')
   active=json.loads(raw);self.catalog_visible='catalog'in active
   _,complete=admit_original_subset(active,{'catalog':[],'node':[],'edge':[]},model_value)
   if not complete:raise PermissionError('Complete independently selected native labels required')
policy=NativePolicy()
class Transport:
 def query(self,language,script,c):
  if c is not context:raise PermissionError('Exact current native context')
  if language=='Cypher':
   with owned_context(driver.session())as session:return session.run(Query(script,timeout=10)).data()
  return remote.submit(script).all().result(timeout=10)
try:
 if docker('ps','-aq','--filter','name=^/'+NAME+'$'):raise PermissionError('Fresh owned native name required')
 returned=docker('run','-d','--pull=never','--name',NAME,'--label','ashlar.commerce.fixture=20261010-g','--cpus','2','--memory','3g','-p','127.0.0.1:18883:8081','-p','127.0.0.1:17690:7687','-p','127.0.0.1:18182:8182','--mount','type=bind,source='+str(database)+',target=/tmp/commerce-exact.duckdb,readonly','-e','PUPPYGRAPH_USERNAME='+USER,'-e','PUPPYGRAPH_PASSWORD='+PASSWORD,IMAGE)
 if len(returned)!=64 or any(c not in '0123456789abcdef'for c in returned):raise PermissionError('Uncertain native launch identity; no ownership inferred')
 retain(WORK/'owned-launch.json',{'containerId':returned,'name':NAME,'image':IMAGE,'label':'20261010-g','scope':'Validated exact successful own docker-run return only'})
 container=returned
 start=time.monotonic()
 while True:
  try:
   status,raw=http('GET')
   if status==200:break
  except (OSError,urllib.error.URLError):pass
  if time.monotonic()-start>60:raise TimeoutError('Native readiness budget')
  time.sleep(1)
 if json.loads(raw)not in ({},{'catalog':[],'node':[],'edge':[]},{'node':[],'edge':[]}):raise PermissionError('Fresh unconfigured native model required')
 driver=GraphDatabase.driver('bolt://127.0.0.1:17690',auth=(USER,PASSWORD),connection_timeout=5,connection_acquisition_timeout=5,max_connection_pool_size=1)
 remote=gremlin_client.Client('ws://127.0.0.1:18182/gremlin','g',username=USER,password=PASSWORD,message_serializer=serializer.GraphSONSerializersV3d0())
 ready_start=time.monotonic();ready_attempt=0
 while True:
  ready_attempt+=1
  try:
   with owned_context(driver.session())as session:marker=session.run(Query('RETURN 1 AS ready',timeout=5)).data()
   retain(WORK/('cypher-readiness-attempt-'+str(ready_attempt)+'.json'),{'query':'RETURN 1 AS ready','rows':marker,'elapsedSeconds':time.monotonic()-ready_start})
   if marker!=[{'ready':1}]:raise ValueError('Native readiness marker differs')
   break
  except BaseException as error:
   def retain_error():retain(WORK/('cypher-readiness-error-'+str(ready_attempt)+'.json'),{'query':'RETURN 1 AS ready','exceptionType':type(error).__name__,'elapsedSeconds':time.monotonic()-ready_start})
   if not isinstance(error,Exception):finish(error,[retain_error])
   retain_error()
   if time.monotonic()-ready_start>15 or ready_attempt>=16:raise TimeoutError('Bounded native protocol readiness')from error
   time.sleep(1)
 retain(WORK/'cypher-readiness.json',{'query':'RETURN 1 AS ready','rows':marker})
 marker=remote.submit("g.inject('ashlar-ready')").all().result(timeout=10)
 retain(WORK/'gremlin-readiness.json',{'script':"g.inject('ashlar-ready')",'rows':marker})
 if marker!=['ashlar-ready']:raise ValueError('Native Gremlin readiness differs')
 status,raw=http('POST',model_raw)
 if status not in (200,201)or type(json.loads(raw))is not dict or json.loads(raw).get('ok')is not True:raise PermissionError('Native model activation refused')
 results=[]
 for language in ('Cypher','Gremlin'):
  def observe(value):retain(WORK/(language+'-'+value['case']+'.json'),value)
  result=execute_commerce_scenarios(prepared,PuppyCommerceScenarioConfig(language,release,custody,rs,cs,pack,1000,1048576),Transport(),policy,context,observe=observe,source_admission=admission)
  retain(WORK/(language+'-result.json'),result);results.append(result)
 if results[0]['actual']!=results[1]['actual']:raise ValueError('Original four language parity differs')
except BaseException as error:primary=error

def native_logs():
 if container:docker('logs','--tail','500',container)
def cleanup():
 if container:
  f=json.loads(docker('inspect',container))[0]
  if f['Id']!=container or f['Image']!=IMAGE or f['Config']['Labels'].get('ashlar.commerce.fixture')!='20261010-g':raise PermissionError('Refuse foreign native cleanup')
  docker('rm','-f',container)
finish(primary,[lambda:driver.close()if driver is not None else None,lambda:remote.close()if remote is not None else None,lambda:retain(WORK/'http-records.json',records),native_logs,cleanup,lambda:RetainedFixturePolicy.current(policy)])
retain(WORK/'summary.json',{'actual':results,'nativeContainer':container,'image':IMAGE,'allFourBothLanguages':True,'wholeCleanupComplete':True,'nativeCatalogVisible':policy.catalog_visible,'catalogQualification':'Catalog metadata is qualified only when actually visible; original mounted DB hash and complete native labels/incidence are independently renewed.','scope':'Actual installed public originalfour queries both languages; explicit retained private fixture only, no production grants/source activation/paid resources.'})
