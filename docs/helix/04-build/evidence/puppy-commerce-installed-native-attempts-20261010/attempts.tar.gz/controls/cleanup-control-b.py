import ast,json,tempfile
from pathlib import Path
source=ast.parse(Path('/private/tmp/ashlar-puppy-commerce-native-runner-b.py').read_text())
main=next(n for n in source.body if isinstance(n,ast.FunctionDef)and n.name=='main')
cleanup=next(n for n in ast.walk(main)if isinstance(n,ast.FunctionDef)and n.name=='cleanup')
class Capture:
 def __init__(self):self.calls=[]
 def capture(self,argv,cwd,env,out,err,*args):
  self.calls.append(argv)
  if argv[1]=='ps':raw='a'*64
  elif argv[1]=='inspect':raw=json.dumps([{'Id':'a'*64,'Name':'/ashlar-puppy-commerce-native-20261010-b','Image':image,'Config':{'Labels':{'ashlar.commerce.fixture':'20261010-b'}}}])
  else:raw='a'*64
  Path(out).write_text(raw);Path(err).write_text('');return{'exitCode':0}
image='sha256:6d016d5a7e3eab0a57bd4d23c4e218467d00c7661fcda215ea2a429941a68cee'
with tempfile.TemporaryDirectory()as root:
 capture=Capture();work=Path(root);ns={'WORK':work,'capture':capture,'env':{},'json':json,'read':lambda p,n:p.read_bytes()}
 exec(compile(ast.Module(body=[cleanup],type_ignores=[]),'<actual frozen cleanup>','exec'),ns)
 ns['cleanup']();assert capture.calls==[] # same-name preexisting native fixture is never even inspected
 own={'containerId':'a'*64,'name':'ashlar-puppy-commerce-native-20261010-b','image':image,'label':'20261010-b'}
 (work/'owned-launch.json').write_text(json.dumps(own));ns['cleanup']();assert capture.calls[-1]==['/usr/local/bin/docker','rm','-f','a'*64]
 capture.calls.clear();own['containerId']='unknown';(work/'owned-launch.json').write_text(json.dumps(own))
 try:ns['cleanup']()
 except ValueError:pass
 else:raise AssertionError('Ambiguous launch must refuse')
 assert capture.calls==[]
print('3 inert actual cleanup controls PASS; no Docker/SDK/native executed')
