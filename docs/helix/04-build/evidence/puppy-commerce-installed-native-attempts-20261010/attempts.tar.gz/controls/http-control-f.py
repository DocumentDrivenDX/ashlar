import ast,base64,types
from pathlib import Path
s=ast.parse(Path('/private/tmp/ashlar-puppy-commerce-native-probe-f.py').read_text());f=next(n for n in s.body if isinstance(n,ast.FunctionDef)and n.name=='http')
seen=[]
class Request:
 def __init__(self,url,**kw):self.url=url;self.kw=kw
class Response:
 status=200
 def read(self,n):return b'{"ok":true}'
 def close(self):pass
def open_(req,timeout):seen.append(req);return Response()
def finish(primary,callbacks):
 for cb in callbacks:cb()
 if primary:raise primary
ns={'urllib':types.SimpleNamespace(request=types.SimpleNamespace(Request=Request,urlopen=open_),error=types.SimpleNamespace(HTTPError=type('HttpError',(Exception,),{}))),'USER':'fixture','PASSWORD':'nonsecret','base64':base64,'records':[],'finish':finish}
exec(compile(ast.Module(body=[f],type_ignores=[]),'<actual frozen http>','exec'),ns)
assert ns['http']('POST',b'{}')==(200,b'{"ok":true}');assert seen[-1].url=='http://127.0.0.1:18883/schema?postUploadBehavior=none'
ns['http']('GET');assert seen[-1].url=='http://127.0.0.1:18883/schemajson'
print('Actual frozen HTTP POST/GET route controls PASS; no network/SDK/native executed')
