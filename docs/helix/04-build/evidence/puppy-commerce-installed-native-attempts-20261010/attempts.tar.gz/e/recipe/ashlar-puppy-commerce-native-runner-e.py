"""Bounded actual installed public commerce native queries; independently renewed custody."""
from contextlib import contextmanager
import base64
import csv
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile
import time
import zipfile

WORK = Path('/private/tmp/ashlar-puppy-commerce-native-20261010-e')
REPO = Path('/Users/erik/Projects/ashlar')
REVISION = '6fb8bb82e5726df1d839658c9b644f8221ae7455'
INVENTORY = Path('/private/tmp/ashlar-puppy-commerce-installed-source-inventory-a.json')
CLOSURE = Path('/private/tmp/ashlar-puppy-commerce-native-closure-a.json')
CLOSURE_SHA = '7d7b6efcef5d9e88c4e567dbafee3b0a9730ee40828b8a6178a06c656bf86d68'
BUILD_PYTHON = '/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
BASE_PYTHON = '/Users/erik/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
SDK = Path('/private/tmp/ashlar-duckdb-sdk-20261010-c')
ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC',
    'PYTHONDONTWRITEBYTECODE': '1', 'PIP_CONFIG_FILE': '/dev/null',
    'PIP_DISABLE_PIP_VERSION_CHECK': '1', 'PIP_NO_CACHE_DIR': '1',
    'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_SYSTEM': '/dev/null',
    'GIT_TERMINAL_PROMPT': '0', 'GIT_ALLOW_PROTOCOL': 'file'}


def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
def select(primary, closing):
    if primary is None or isinstance(primary, Exception) and not isinstance(closing, Exception): return closing
    return primary


@contextmanager
def owned(manager):
    primary = None
    try:
        with manager as value:
            try: yield value
            except BaseException as error: primary = error; raise
    except BaseException as error:
        raise select(primary, error)
    if primary is not None: raise primary


def write(path, raw):
    with owned(path.open('xb')) as stream:
        if stream.write(raw) != len(raw): raise ValueError('Incomplete owned retention')
        stream.flush(); os.fsync(stream.fileno())


def read(path, maximum):
    if path.is_symlink() or not path.is_file() or path.stat().st_size > maximum: raise ValueError('Selected regular file bound')
    with owned(path.open('rb')) as stream: raw = stream.read(maximum + 1)
    if len(raw) > maximum: raise ValueError('Selected file bound')
    return raw


def safe(name):
    path = PurePosixPath(name)
    if not name or path.is_absolute() or '\\' in name or any(p in ('', '.', '..') for p in name.split('/')): raise ValueError('Closed member path')


def verify():
    raw = read(CLOSURE, 16777216)
    if sha(raw) != CLOSURE_SHA: raise ValueError('Selected existing closure changed')
    plan = json.loads(raw)
    for path in plan['absent_startup_paths']:
        if Path(path).exists() or Path(path).is_symlink(): raise ValueError('Startup selection changed')
    actual_links = [{'path': str(p), 'target': os.readlink(p), 'resolved': str(p.resolve())}
        for root in plan['roots'] for p in sorted(Path(root).rglob('*')) if p.is_symlink()]
    actual_links += [{'path':'/usr/local/bin/docker','target':os.readlink('/usr/local/bin/docker'),'resolved':str(Path('/usr/local/bin/docker').resolve())}]
    actual_links.sort(key=lambda x:x['path'])
    if actual_links != plan['symlinks']: raise ValueError('Whole selected namespace links changed')
    for root in plan['roots']:
        actual = {str(p.resolve()) for p in Path(root).rglob('*') if p.is_file()}
        expected = set(plan['root_files'][root])
        if actual != expected: raise ValueError('Whole selected dependency membership changed')
    if len(plan['files']) > 16000 or sum(r['bytes'] for r in plan['files'].values()) > 1073741824: raise ValueError('Closed preparation custody bounds')
    for path, pin in plan['files'].items():
        p = Path(path)
        if p.is_symlink() or not p.is_file() or p.stat().st_size != pin['bytes']: raise ValueError('Original custody shape changed')
        digest = hashlib.sha256()
        with owned(p.open('rb')) as stream:
            for block in iter(lambda: stream.read(262144), b''): digest.update(block)
        if digest.hexdigest() != pin['sha256']: raise ValueError('Original selected byte custody changed')



def main():
 verify()
 if WORK.exists()or WORK.is_symlink():raise ValueError('Fresh native output required')
 WORK.mkdir(mode=0o700)
 spec=importlib.util.spec_from_file_location('capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
 primary=None;outcome=None
 env={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'/private/tmp/ashlar-puppy-release-sdk-20261010-a:/private/tmp/ashlar-gremlin-python','DOCKER_HOST':'unix:///Users/erik/.orbstack/run/docker.sock','TMPDIR':str(WORK)}
 try:
  outcome=capture.capture(['/private/tmp/ashlar-puppy-commerce-installed-20261010-b/venv/bin/python','-B','/private/tmp/ashlar-puppy-commerce-native-probe-e.py'],str(WORK),env,str(WORK/'native.stdout'),str(WORK/'native.stderr'),180,4194304,None)
  if outcome['exitCode']:raise ValueError('Actual native public workflow refused')
 except BaseException as error:primary=error
 def collect(callback):
  nonlocal primary
  try:callback()
  except BaseException as error:primary=select(primary,error)
 def cleanup():
  # Independently clean the exact fixture even if probe/group cancelled.
  name='ashlar-puppy-commerce-native-20261010-e'
  launch=WORK/'owned-launch.json'
  if not launch.exists():return # No positive own launch receipt: never infer authority from a matching name.
  if launch.is_symlink()or not launch.is_file():raise ValueError('Exact owned launch receipt required')
  own=json.loads(read(launch,4096));cid=own.get('containerId')
  if type(cid)is not str or len(cid)!=64 or any(c not in '0123456789abcdef'for c in cid)or own.get('name')!=name or own.get('label')!='20261010-e'or own.get('image')!='sha256:6d016d5a7e3eab0a57bd4d23c4e218467d00c7661fcda215ea2a429941a68cee':raise ValueError('Exact own launch lineage required')
  result=capture.capture(['/usr/local/bin/docker','ps','-aq','--filter','id='+cid],str(WORK),env,str(WORK/'cleanup-list.stdout'),str(WORK/'cleanup-list.stderr'),10,1048576,None)
  if result['exitCode']:raise ValueError('Owned cleanup listing refused')
  found=(WORK/'cleanup-list.stdout').read_text().strip()
  if found:
   result=capture.capture(['/usr/local/bin/docker','inspect',cid],str(WORK),env,str(WORK/'cleanup-inspect.stdout'),str(WORK/'cleanup-inspect.stderr'),10,1048576,None)
   if result['exitCode']:raise ValueError('Owned cleanup inspection refused')
   f=json.loads((WORK/'cleanup-inspect.stdout').read_bytes())[0]
   if f['Id']!=cid or f['Name']!='/'+name or f['Image']!=own['image']or f['Config']['Labels'].get('ashlar.commerce.fixture')!='20261010-e':raise ValueError('Foreign cleanup refused')
   result=capture.capture(['/usr/local/bin/docker','rm','-f',cid],str(WORK),env,str(WORK/'cleanup-remove.stdout'),str(WORK/'cleanup-remove.stderr'),15,1048576,None)
   if result['exitCode']:raise ValueError('Owned native cleanup refused')
 collect(cleanup);collect(verify)
 receipt={'format':'ashlar-installed-commerce-native/0.1','outcome':outcome,'openingClosingCustody':primary is None,'failureType':None if primary is None else type(primary).__name__,'scope':'Originalfour bothlanguages through installed publicAPI; retained privatefixture only.'}
 try:write(WORK/'runner-receipt.json',encoded(receipt))
 except BaseException as error:primary=select(primary,error)
 if primary is not None:raise primary
main()
