import cProfile,hashlib,io,json,pstats,signal,time
from pathlib import Path
from ashlar_host.config import ProducerConfig
from ashlar_host.medical_producer import HeldMedicalDataset
from ashlar_host.original_medical_publication import MedicalAdmission
from ashlar_host.medical_publication_plan import MedicalPublicationPlan,FEED,EPOCH,ROLES
from ashlar.medical_source import build_transaction
from ashlar.outbox import OutboxTransaction
root=Path(__file__).parent
started=time.monotonic()
def stop(*_):raise TimeoutError('30-second pure profile bound')
signal.signal(signal.SIGALRM,stop);signal.alarm(28)
v=json.loads(Path('/private/tmp/ashlar-medical-recovery-runtime-20261016-f/configuration.json').read_bytes())
try:
 p=v['producer'];producer=ProducerConfig(Path(p['source']),Path(p['bun']),Path(p['git']),20,p['maximum_output_bytes'],p['maximum_receipt_bytes'])
 paths=tuple(Path(v['inputs'][key]['path'])for key in ('model','graph','baseline'));raw=tuple(path.read_bytes()for path in paths)
 for key,data in zip(('model','graph','baseline'),raw):
  assert len(data)==v['inputs'][key]['bytes']and hashlib.sha256(data).hexdigest()==v['inputs'][key]['sha256']
 dataset=HeldMedicalDataset(producer,*paths,root/'public-revalidation.json')
 batch,bindings=build_transaction(*raw,source_system=FEED,binding_profile='ashlar-medical-development-bindings/0.2')
 admission=MedicalAdmission(batch,bindings,*paths,dataset)
 payload=batch.begin+b''.join(record.raw for record in batch.records)+batch.commit
 transaction=OutboxTransaction('ashlar-postgresql-outbox/0.1',FEED,EPOCH,'0','1',hashlib.sha256(payload).hexdigest(),batch)
 plan=MedicalPublicationPlan(admission,transaction,{role:'local.original_medical.'+role for role in ROLES})
 profile=cProfile.Profile();t=time.monotonic();profile.enable()
 try:plan.renew()
 finally:profile.disable()
 elapsed=time.monotonic()-t
 profile.dump_stats(str(root/'renew.pstats'));text=io.StringIO();pstats.Stats(profile,stream=text).strip_dirs().sort_stats('cumulative').print_stats(35);(root/'renew-top.txt').write_text(text.getvalue())
 report={'status':'passed','renew_wall_seconds':elapsed,'total_wall_seconds':time.monotonic()-started,'scope':'One pure MedicalPublicationPlan renewal with fresh actual public supplied-dataset revalidation; constructed exact outbox transaction correspondence only, no PostgreSQL/source/ACK authority, Spark or cloud','producer_timeout_seconds':20,'inputs':v['inputs'],'bindings_profile':bindings['profile'],'module':__import__('ashlar_host.medical_publication_plan',fromlist=['x']).__file__}
except BaseException as error:
 report={'status':'refused','error_type':type(error).__name__,'error':str(error),'total_wall_seconds':time.monotonic()-started}
finally:signal.alarm(0)
(root/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));print((root/'renew-top.txt').read_text()if(root/'renew-top.txt').exists()else'')
