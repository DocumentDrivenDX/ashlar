from pathlib import Path
import gzip,hashlib,json
r=Path(__file__).parent
d=Path('/Users/erik/Projects/ashlar/docs/helix/04-build/evidence/medical-effect-recovery-deadline-20261016-f');d.mkdir(exist_ok=False)
suffixes={'.json','.py','.log','.stdout','.stderr','.txt','.bin'}
pairs=[(p.name,p)for p in sorted(r.iterdir())if p.is_file()and p.suffix in suffixes]
pairs.extend((p.relative_to(r).as_posix(),p)for p in sorted((r/'recovery-output').iterdir())if p.is_file()and p.suffix=='.json')
e=Path('/private/tmp/ashlar-medical-held-recovery-20261016-e')
for name in ('configuration.json','runtime-selection.json','runtime-custody-exception.txt','recovery-attempt.json','recovery.stderr','recovery.stdout','run-recovery.py'):
    p=e/name
    if p.exists():pairs.append(('pre-runtime-limit/'+name,p))
profile=Path('/private/tmp/ashlar-medical-pure-profile-20261016-6f4i5mau')
for p in sorted(profile.iterdir()):
    if p.is_file()and p.suffix in ('.py','.json','.txt','.pstats'):pairs.append(('pure-plan-profile/'+p.name,p))
manifest={}
for name,p in pairs:
    raw=p.read_bytes();encoded=gzip.compress(raw,mtime=0);key=name+'.gz'
    dest=d/key;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(encoded)
    manifest[key]={'sha256':hashlib.sha256(raw).hexdigest(),'gzip_sha256':hashlib.sha256(encoded).hexdigest(),'bytes':len(raw)}
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(len(manifest),'retained records')
