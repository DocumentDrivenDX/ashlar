from pathlib import Path
import traceback,json
from ashlar_host.original_medical_local_cli import run_original_medical_recovery_command
r=Path(__file__).parent
try:
    result=run_original_medical_recovery_command(r/'configuration.json')
    (r/'diagnostic-parent-result.json').write_text(json.dumps(result,indent=2)+'\n')
except BaseException as error:
    capture=BaseException.__dict__['__dict__'].__get__(error,type(error)).get('medical_capture',{})
    for field in ('stdout','stderr','phase'):
        if type(capture.get(field))is bytes:(r/('diagnostic-child-'+field+'.bin')).write_bytes(capture[field])
    (r/'diagnostic-parent-exception.txt').write_text(traceback.format_exc())
    raise
