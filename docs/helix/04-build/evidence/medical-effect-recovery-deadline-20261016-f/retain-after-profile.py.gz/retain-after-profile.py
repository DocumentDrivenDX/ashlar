from pathlib import Path
import gzip,hashlib,json
r=Path(__file__).parent;d=Path('/Users/erik/Projects/ashlar/docs/helix/04-build/evidence/medical-effect-recovery-deadline-20261016-f')
m=json.loads((d/'manifest.json').read_bytes());p=Path('/private/tmp/ashlar-medical-pure-profile-after-20261016-ogfu1kzv')
pairs=[('pure-plan-profile-after/'+f.name,f)for f in sorted(p.iterdir())if f.is_file()and f.suffix in ('.py','.json','.txt','.pstats')]
pairs.append(('retain-after-profile.py',Path(__file__)))
for name,f in pairs:
    raw=f.read_bytes();packed=gzip.compress(raw,mtime=0);key=name+'.gz';assert key not in m
    target=d/key;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb')as output:output.write(packed)
    m[key]={'sha256':hashlib.sha256(raw).hexdigest(),'gzip_sha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw)}
(d/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(len(m),'retained records')
