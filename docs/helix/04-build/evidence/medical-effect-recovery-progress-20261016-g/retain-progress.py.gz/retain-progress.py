from pathlib import Path
import gzip,hashlib,json
r=Path(__file__).parent;out=Path('/Users/erik/Projects/ashlar/docs/helix/04-build/evidence/medical-effect-recovery-progress-20261016-g');out.mkdir(exist_ok=False)
pairs=[(p.name,p)for p in sorted(r.iterdir())if p.is_file() and p.suffix in ('.json','.py','.log','.sqlite','.stdout','.stderr')]
pairs += [('recovery-output/'+p.name,p)for p in sorted((r/'recovery-output').iterdir())if p.is_file()]
c=json.loads((r/'configuration.json').read_bytes());t=next(t for t in c['targets']if t['table']=='attempts');base=Path(t['path']);v=json.loads((r/'native-attempt-rows.json').read_bytes())
pairs += [('native-attempts/'+n,base/n)for n in v['active_files']]
pairs += [('native-attempts/_delta_log/'+p.name,p)for p in sorted((base/'_delta_log').glob('*.json'))]
m={}
for name,p in pairs:
 b=p.read_bytes();z=gzip.compress(b,mtime=0);key=name+'.gz';target=out/key;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z);m[key]={'sha256':hashlib.sha256(b).hexdigest(),'gzip_sha256':hashlib.sha256(z).hexdigest(),'bytes':len(b)}
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(len(m),'records')
