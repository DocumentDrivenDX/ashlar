"""Prepared explicit ordinary fixture provider; no import-time connections or SDK.

The enclosing reviewed runner owns the current local runtime session, freshly
initialized six-target installation and source inventory selection. Recorded
hashes prove correspondence; ExistingEvolutionOperator owns current authority.
"""
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from ashlar_host.ack import AckScope
from ashlar_host.source_sessions import OutboxSourceRegistration
from ashlar_host.existing_outbox_authority import OutboxAuthorityRegistration
from ashlar_host.evolution_operator import ExistingEvolutionOperator
from ashlar_host.lifecycle import owned_context, finish


@dataclass(frozen=True)
class FixtureSelection:
    path: Path
    sha256: str
    original: bytes
    identity: tuple

    @classmethod
    def capture(cls, path, expected_sha256):
        path = Path(path)
        if not path.is_absolute() or path.is_symlink() or not path.is_file():
            raise ValueError('Selected actual fixture inventory required')
        with owned_context(path.open('rb')) as stream:
            raw = stream.read(65537)
        info = path.stat()
        if not 0 < len(raw) <= 65536 or hashlib.sha256(raw).hexdigest() != expected_sha256:
            raise ValueError('Selected actual fixture inventory differs')
        value = cls(path, expected_sha256, raw, (info.st_dev, info.st_ino))
        value.renew()
        return value

    def renew(self):
        if self.path.is_symlink() or not self.path.is_file():
            raise ValueError('Original fixture inventory unavailable')
        info = self.path.stat()
        with owned_context(self.path.open('rb')) as stream:
            raw = stream.read(65537)
        if (info.st_dev, info.st_ino) != self.identity or raw != self.original:
            raise ValueError('Original fixture inventory changed')

    def document(self):
        self.renew()
        value = json.loads(self.original)
        if (value.get('format') != 'ashlar-private-outbox-fixture/0.1'
                or value.get('authentication') != 'isolated-loopback-trust'
                or value.get('endpoint') != {'host':'127.0.0.1','port':25433,'database':'truss_e2e'}
                or value.get('container_id') != '21a48d40d806ec38ada00ffdc2d557a3a35b891faf69b3f70401b15584961695'
                or type(value.get('sources')) is not list or len(value['sources']) != 2):
            raise ValueError('Exact independently selected actual two-source fixture required')
        return value


def registrations(selected, *, ack_transform=None):
    document = selected.document()
    result = []
    for original in document['sources']:
        scope = AckScope(**original['scope'])
        if original['binding']['source_schema'] != original['schema']:
            raise ValueError('Original source namespace differs')
        def factory(role, *, acknowledgement=False):
            def connect(context):
                selected.renew()
                import psycopg
                connection = psycopg.connect(host='127.0.0.1', port=25433,
                    dbname='truss_e2e', user=role, password='', sslmode='disable',
                    connect_timeout=2, options='-c statement_timeout=5000',
                    application_name='ashlar-private-evolution-qualified', autocommit=False)
                primary = None
                try:
                    selected.renew()
                    result = ack_transform(connection) if acknowledgement and ack_transform is not None else connection
                    selected.renew()
                except BaseException as error:
                    primary = error
                finish(primary, [] if primary is None else [connection.close])
                return result
            return connect
        source = OutboxSourceRegistration(scope, original['schema'],
            original['binding']['source_signature_sha256'], factory(original['reader_role']))
        result.append(OutboxAuthorityRegistration(source, original['reader_role'],
            original['ack_role'], 'truss_e2e', factory(original['ack_role'], acknowledgement=True)))
    return tuple(result)


@dataclass(frozen=True)
class PreparedEvolutionProvider:
    selected: FixtureSelection
    operator: ExistingEvolutionOperator

    @contextmanager
    def open_evolution(self, invocation):
        self.selected.renew()
        primary = None
        try:
            with owned_context(self.operator.open_evolution(invocation)) as configuration:
                self.selected.renew()
                yield configuration
        except BaseException as error:
            primary = error
        finish(primary, [self.selected.renew])
