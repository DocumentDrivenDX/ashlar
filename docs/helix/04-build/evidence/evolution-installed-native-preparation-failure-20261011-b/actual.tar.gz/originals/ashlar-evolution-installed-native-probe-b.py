"""Three-process public evolution exercise. No entrypoint runs on import."""
import argparse
from contextlib import contextmanager
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sqlite3

from ashlar.manifest import FIELDS
from ashlar_host.config import EvolutionAdmissionConfig
from ashlar_host.delta_custody import DeltaTarget, LocalDeltaTransport, LOCAL_OPERATION_CAPACITY_8M, LocalDeltaError
from ashlar_host.driver import PrivatePolicy, LostAfterManifest
from ashlar_host.evolution_admission import admit_commerce_evolution, EvolutionSourceSet
from ashlar_host.evolution_cli import FreshEvolutionInvocation, ResumeEvolutionInvocation, run_evolution_invocation
from ashlar_host.evolution_operator import ExistingEvolutionOperator, ExistingEvolutionLease
from ashlar_host.existing_outbox_authority import ExistingOutboxAuthority
from ashlar_host.postgres import Session
from ashlar_host.evolution_run import EvolutionRunRequest
from ashlar_host.lifecycle import finish, owned_context


def encode(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))+'\n').encode()


def retain(path, value):
    raw = value if type(value) is bytes else encode(value)
    with owned_context(path.open('xb')) as stream:
        if stream.write(raw) != len(raw): raise ValueError('Short evidence write')
        stream.flush(); os.fsync(stream.fileno())


def canonical(value):
    if type(value) is datetime.datetime:
        if value.tzinfo is None: value = value.replace(tzinfo=datetime.timezone.utc)
        elapsed = value - datetime.datetime(1970,1,1,tzinfo=datetime.timezone.utc)
        return str((elapsed.days*86400+elapsed.seconds)*1000000+elapsed.microseconds)
    if type(value) is int: return str(value)
    if type(value) in (str, type(None)): return value
    raise ValueError('Unsupported native witness carrier')


def native_history(spark, targets):
    result = {}
    for target in targets:
        rows = spark.sql('DESCRIBE HISTORY delta.`'+str(target.path)+'`').limit(129).collect()
        def primitive(value):
            if type(value) is datetime.datetime: return canonical(value)
            if type(value) is dict: return {key:primitive(item) for key,item in value.items()}
            if type(value) in (list,tuple): return [primitive(item) for item in value]
            if type(value) in (str,int,bool,float,type(None)): return value
            raise ValueError('Unsupported history witness')
        result[target.table] = [primitive(row.asDict()) for row in rows]
    return result


class BootstrapPolicy(PrivatePolicy):
    def __init__(self,context,targets,selected,root,fd):
        super().__init__(context,targets)
        self.selected,self.root,self.fd = selected,root,fd
        info=os.fstat(fd);self.identity=(info.st_dev,info.st_ino)
    def renew(self):
        self.selected.renew()
        info=self.root.lstat();held=os.fstat(self.fd)
        if self.root.resolve()!=self.root or (info.st_dev,info.st_ino)!=self.identity or (held.st_dev,held.st_ino)!=self.identity:
            raise PermissionError('Current original fresh bootstrap directory custody required')
    @contextmanager
    def writer(self,*args):
        self.renew()
        primary=None
        try:
            with owned_context(super().writer(*args)): yield
        except BaseException as error:primary=error
        finish(primary,[self.renew])
    def admit(self,intent,context):
        self.renew()
        return super().admit(intent,context)


class CompletedNativeReplyLoss(OSError): pass


class NativeReplyLoss:
    """Drop one selected real INSERT collect reply; retain result before loss."""
    def __init__(self, spark, path): self.spark, self.path, self.consumed = spark, path, False
    def __getattr__(self, name): return getattr(self.spark, name)
    def sql(self, statement, *args, **kwargs):
        frame = self.spark.sql(statement, *args, **kwargs)
        if self.consumed or not statement.startswith('INSERT INTO delta.') or 'object_current' not in statement:
            return frame
        owner = self
        class CompletedFrame:
            def __getattr__(self, name): return getattr(frame, name)
            def collect(self):
                result = frame.collect(); owner.consumed = True
                retain(owner.path, {'statement':statement,'boundary':'after actual native collect',
                    'returnedRows':len(result),'originalIntentRetained':True})
                raise CompletedNativeReplyLoss('Selected completed native reply loss')
        return CompletedFrame()


def run(config, mode):
    spec = importlib.util.spec_from_file_location('selected_provider', config['provider'])
    provider = importlib.util.module_from_spec(spec)
    import sys
    sys.modules[spec.name] = provider; spec.loader.exec_module(provider)
    selected = provider.FixtureSelection.capture(config['fixture'], config['fixture_sha256'])
    root = Path(config['installation']); output = Path(config['output'])
    output.mkdir(mode=0o700)
    producer = EvolutionAdmissionConfig(Path(config['producer']['source']),
        Path(config['producer']['bun']), Path(config['producer']['git']),30,1048576,4194304)
    sources = EvolutionSourceSet(tuple(admit_commerce_evolution(producer,
        source_system=item['scope']['feed'], epoch=item['scope']['epoch'])
        for item in selected.document()['sources']))
    retain(output/'source-admission.json', sources.metadata())
    request = EvolutionRunRequest(('A','B'),'private-public-evolution-20261011-a',
        'explicit-private-evolution-origin',
        tuple(tuple('2026-10-11T12:%02d:00+00:00'%i for i in range(4)) for _ in range(2)),
        tuple('private-public-evolution-20261011-a-'+str(i) for i in range(1,9)),
        tuple(str(i) for i in range(1,9)))
    primary = None; spark = None; transport = None; result = None; bootstrap_fd=None
    try:
        from pyspark.sql import SparkSession
        spark = (SparkSession.builder.master('local[1]').appName('Ashlar public two-source evolution')
            .config('spark.driver.memory','512m').config('spark.sql.shuffle.partitions','1')
            .config('spark.databricks.delta.snapshotPartitions','1').config('spark.ui.enabled','false')
            .config('spark.sql.session.timeZone','UTC').config('spark.sql.ansi.enabled','true')
            .config('spark.jars',','.join(config['jars']))
            .config('spark.sql.extensions','io.delta.sql.DeltaSparkSessionExtension')
            .config('spark.sql.catalog.spark_catalog','org.apache.spark.sql.delta.catalog.DeltaCatalog').getOrCreate())
        if mode == 'bootstrap':
            root.mkdir(mode=0o700)
            bootstrap_fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
            columns = dict(sources.columns)
            columns['attempts'] = tuple((name,'STRING') for name in ('stream','batch_id','phase','request_digest','payload_json','payload_digest'))
            columns['manifest'] = tuple((name,'TIMESTAMP' if name=='recorded_at' else 'STRING') for name in FIELDS)
            targets = []
            for role, schema in columns.items():
                path = root/role
                spark.sql('CREATE TABLE delta.`'+str(path)+'` ('+','.join(name+' '+kind for name,kind in schema)+') USING DELTA').collect()
                targets.append(DeltaTarget('local.evolution.'+role,path,spark.sql('DESCRIBE DETAIL delta.`'+str(path)+'`').first().id))
            targets = tuple(targets); context = object()
            policy = BootstrapPolicy(context,targets,selected,root,bootstrap_fd)
            transport = LocalDeltaTransport.initialize(spark,root/'operations.sqlite',config['installation_id'],
                targets,policy,context=context,capacity=LOCAL_OPERATION_CAPACITY_8M)
            transport.close(); transport = None
            retain(root/'targets.json',[{'table':t.table,'path':str(t.path),'uuid':t.uuid} for t in targets])
            @contextmanager
            def bootstrap_native(): yield spark
            bootstrap_operator=ExistingEvolutionOperator(config['installation_id'],root/'operations.sqlite',
                root/'original-run.json',targets,provider.registrations(selected),LOCAL_OPERATION_CAPACITY_8M,bootstrap_native)
            fresh=FreshEvolutionInvocation(root/'run.sqlite',output/'provisional.json',producer,request)
            with owned_context(ExistingEvolutionLease.open(bootstrap_operator,fresh,context)) as lease:
                authority=ExistingOutboxAuthority(bootstrap_operator.registrations,lease)
                import psycopg
                for source, admitted in zip(selected.document()['sources'],sources.admissions):
                    metadata = next(item for item in bootstrap_operator.registrations if item.source.scope.feed==source['scope']['feed'])
                    ack_connection=metadata.metadata_factory(context)
                    gate_error=None
                    try:authority.admit_scope(metadata.source.scope,Session(ack_connection),context)
                    except BaseException as error:gate_error=error
                    finish(gate_error,[ack_connection.rollback,ack_connection.close])
                    connection = psycopg.connect(host='127.0.0.1',port=25433,dbname='truss_e2e',
                        user=source['writer_role'],password='',sslmode='disable',connect_timeout=2,
                        options='-c statement_timeout=5000',autocommit=False)
                    body = None
                    try:
                        identity = connection.execute('SELECT current_user,session_user,current_database(),rolsuper,rolcreaterole,rolcreatedb,rolreplication,rolbypassrls FROM pg_catalog.pg_roles WHERE rolname=current_user').fetchone()
                        if identity != (source['writer_role'],source['writer_role'],'truss_e2e',False,False,False,False,False):
                            raise PermissionError('Actual ordinary writer identity differs')
                        for position,batch in enumerate(admitted.prepared.batches,1):
                            raw = batch.begin+b''.join(item.raw for item in batch.records)+batch.commit
                            retain(output/(source['scope']['feed']+'-'+str(position)+'.source.jsonl'),raw)
                            actual = connection.execute('SELECT '+source['schema']+'.append(%s,%s)',
                                (batch.batch_id,raw.decode('utf-8'))).fetchone()
                            if actual != (position,): raise ValueError('Original contiguous append differs')
                            connection.commit()
                    except BaseException as error: body = error
                    finish(body,[connection.rollback,connection.close])
                    reader=psycopg.connect(host='127.0.0.1',port=25433,dbname='truss_e2e',
                        user=source['reader_role'],password='',sslmode='disable',connect_timeout=2,
                        options='-c statement_timeout=5000',autocommit=False)
                    body=None
                    try:
                        observed=reader.execute('SELECT position::text,batch_id,payload,encode(digest,\'hex\') FROM '+source['schema']+'.batch ORDER BY position').fetchall()
                        expected=[]
                        for position,batch in enumerate(admitted.prepared.batches,1):
                            raw=batch.begin+b''.join(item.raw for item in batch.records)+batch.commit
                            expected.append((str(position),batch.batch_id,raw.decode('utf-8'),hashlib.sha256(raw).hexdigest()))
                        retain(output/(source['scope']['feed']+'-ordinary-source-read.json'),{'rows':observed,'expected':expected})
                        if observed!=expected:raise ValueError('Actual ordinary original source bytes differ')
                    except BaseException as error:body=error
                    finish(body,[reader.rollback,reader.close])
        else:
            targets = tuple(DeltaTarget(row['table'],Path(row['path']),row['uuid'])
                for row in json.loads((root/'targets.json').read_bytes()))

        loss = NativeReplyLoss(spark,output/'native-collect-loss.json') if mode=='bootstrap' else spark
        @contextmanager
        def native(): yield loss
        ack_events = []
        def ack_transform(connection):
            if ack_events: return connection
            class LostCommit:
                def __getattr__(self,name): return getattr(connection,name)
                def commit(self):
                    connection.commit()
                    ack_events.append({'boundary':'after actual ordinary PostgreSQL COMMIT'})
                    retain(output/'ack-commit-loss.json',ack_events)
                    raise OSError('Selected actual ACK commit reply loss')
            return LostCommit()
        operator = ExistingEvolutionOperator(config['installation_id'],root/'operations.sqlite',
            root/'original-run.json',targets,provider.registrations(selected,
                ack_transform=ack_transform if mode=='resume' else None),LOCAL_OPERATION_CAPACITY_8M,native)
        owner = provider.PreparedEvolutionProvider(selected,operator)
        if mode == 'bootstrap':
            invocation = FreshEvolutionInvocation(root/'run.sqlite',output/'provisional.json',producer,request)
            try: run_evolution_invocation(invocation,owner)
            except CompletedNativeReplyLoss:
                if not loss.consumed: raise
                retain(output/'expected-native-interruption.json',{'retainedOriginalRun':str(root/'original-run.json')})
            else: raise ValueError('Selected actual collect interruption did not occur')
        elif mode == 'manifest':
            original = (root/'original-run.json').read_bytes()
            invocation = ResumeEvolutionInvocation(root/'run.sqlite',output/'provisional.json',producer,
                hashlib.sha256(original).hexdigest())
            class ManifestLossProvider:
                @contextmanager
                def open_evolution(self, invocation):
                    with owned_context(owner.open_evolution(invocation)) as configuration:
                        configuration.driver.lose_manifest = True
                        yield configuration
            try: run_evolution_invocation(invocation,ManifestLossProvider())
            except LostAfterManifest:
                retain(output/'expected-manifest-interruption.json',{'boundary':'after real immutable manifest before PG ACK',
                    'originalRunSha256':invocation.expected_sha256})
            else: raise ValueError('Actual original manifest loss did not occur')
        else:
            original = (root/'original-run.json').read_bytes()
            invocation = ResumeEvolutionInvocation(root/'run.sqlite',output/'provisional.json',producer,
                hashlib.sha256(original).hexdigest())
            result = run_evolution_invocation(invocation,owner)
            if len(result['publications']) != 8 or len(ack_events) != 1: raise ValueError('Complete original eight publications and fresh ACK reconciliation required')
            observations = []
            prefixes = {'A':0,'B':0}; clocks = dict(zip(request.source_order,request.clocks))
            for step,descriptor in zip(request.schedule(),result['publications']):
                prefixes[step['source']] = step['prefix']
                expected = sources.oracle(dict(prefixes),materialized_at=clocks)
                for role,rows in expected.items():
                    target = next(t for t in targets if t.table.endswith('.'+role))
                    frame = spark.read.format('delta').option('versionAsOf',descriptor.versions[target.table]).load(str(target.path))
                    actual = [{name:canonical(value) for name,value in row.asDict().items()} for row in frame.collect()]
                    witness = {'publication':descriptor.publication_id,'role':role,'schema':frame.schema.jsonValue(),
                        'rows':actual,'expected':rows,'version':descriptor.versions[target.table],'uuid':target.uuid}
                    retain(output/(descriptor.publication_id+'-'+role+'.json'),witness)
                    if sorted(actual,key=encode)!=sorted(rows,key=encode): raise ValueError('Complete original native occurrence bag differs')
                    observations.append(witness)
            before_history=native_history(spark,targets)
            repeated = run_evolution_invocation(invocation,owner)
            if repeated != result: raise ValueError('Original resumed run replay changed descriptors')
            after_history=native_history(spark,targets)
            retain(output/'replay-native-history.json',{'before':before_history,'after':after_history})
            if before_history!=after_history:raise ValueError('Original replay changed native history')
            from ashlar_host.ack import receipt_bytes
            import psycopg
            manifests={item.publication_id:dict(item.raw) for item in result['publications']}
            for source in selected.document()['sources']:
                connection=psycopg.connect(host='127.0.0.1',port=25433,dbname='truss_e2e',
                    user=source['ack_role'],password='',sslmode='disable',connect_timeout=2,
                    options='-c statement_timeout=5000',autocommit=False)
                body=None
                try:
                    scope=provider.AckScope(**source['scope'])
                    receipts=[]
                    for position in range(1,5):
                        cursor=connection.execute('SELECT * FROM '+scope.service_schema+'.observe(%s::uuid,%s::bigint)',(scope.scope_id,str(position)))
                        columns=[column.name for column in cursor.description]
                        row=cursor.fetchone()
                        if row is None:raise ValueError('Actual durable source ACK absent')
                        observed=dict(zip(columns,row));receipts.append(observed)
                        request_raw=bytes.fromhex(observed['request_hex']);manifest_raw=bytes.fromhex(observed['manifest_hex'])
                        request_value,manifest_value,checkpoint,expected_receipt=receipt_bytes(scope,request_raw,manifest_raw)
                        if (manifest_value!=manifests.get(manifest_value['publication_id']) or checkpoint['position']!=str(position)
                                or observed['receipt_hex']!=expected_receipt.hex() or str(observed['position'])!='4'):
                            raise ValueError('Complete durable original ACK correspondence differs')
                    retain(output/(scope.feed+'-durable-ACKs.json'),receipts)
                except BaseException as error:body=error
                finish(body,[connection.rollback,connection.close])
            # Quiesce the original WAL before moving that same journal. There
            # are no provider/ordinary connections outstanding at this point.
            journal = root/'operations.sqlite'; retained = root/'retained-operations.sqlite'
            connection = sqlite3.connect(journal)
            body=None
            try:
                checkpoint = connection.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
                if checkpoint[0] != 0: raise ValueError('Original WAL not quiescent')
            except BaseException as error:body=error
            finish(body,[connection.close])
            identity = (journal.stat().st_dev,journal.stat().st_ino)
            raw_digest = hashlib.sha256(journal.read_bytes()).hexdigest()
            journal.rename(retained)
            refusal = None
            restoration_primary = None
            try:
                try: run_evolution_invocation(invocation,owner)
                except (PermissionError,FileNotFoundError): refusal = 'existing-operator-original-journal-refusal'
                else: raise ValueError('Missing original journal was accepted')
                context = object(); policy = PrivatePolicy(context,targets)
                try:
                    replacement = LocalDeltaTransport.initialize(spark,journal,config['installation_id'],
                        targets,policy,context=context,capacity=LOCAL_OPERATION_CAPACITY_8M)
                except LocalDeltaError: pass
                else:
                    replacement.close(); raise ValueError('Missing original journal was recreated')
                if journal.exists(): raise ValueError('Refusal recreated original custody')
            except BaseException as error: restoration_primary = error
            def restore_original():
                if (retained.stat().st_dev,retained.stat().st_ino)!=identity or journal.exists():
                    raise ValueError('Original journal restoration identity differs')
                retained.rename(journal)
            finish(restoration_primary,[restore_original])
            if native_history(spark,targets)!=before_history:
                raise ValueError('Missing-journal refusal changed native history')
            if hashlib.sha256(journal.read_bytes()).hexdigest()!=raw_digest:
                raise ValueError('Original restored journal bytes changed')
            retain(output/'missing-journal-refusal.json',{'refusal':refusal,'sameOriginalInodeRestored':True,
                'originalSha256':raw_digest,'reinitializationRefused':True})
            retain(output/'result.json',{'profile':'ashlar-public-evolution-provisional/0.1',
                'run_sha256':result['run_sha256'],'publications':[dict(item.raw) for item in result['publications']],
                'nativeWitnesses':len(observations),'ackCommitLoss':ack_events})
    except BaseException as error: primary = error
    finish(primary,([transport.close] if transport is not None else [])+
        ([spark.stop] if spark is not None else [])+[selected.renew]+
        ([lambda:os.close(bootstrap_fd)] if bootstrap_fd is not None else []))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--configuration',required=True)
    parser.add_argument('--mode',choices=('bootstrap','manifest','resume'),required=True)
    args=parser.parse_args();run(json.loads(Path(args.configuration).read_bytes()),args.mode)
