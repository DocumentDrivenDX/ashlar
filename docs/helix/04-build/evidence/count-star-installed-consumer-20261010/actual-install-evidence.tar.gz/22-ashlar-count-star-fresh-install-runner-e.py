"""Reviewed local Git delivery/install control; no build, network or native SQL."""
import gzip,hashlib,importlib.util,json,os,sys
from pathlib import Path
BASE=Path('/private/tmp/weft-count-star-build-20261010-b')
WORK=Path('/private/tmp/ashlar-count-star-fresh-install-e')
REV='bd490abc877a1992666c7b45412b14a0ca6c2cac'
ID='weft-5ddcebd-count-star-aarch64-apple-darwin-candidate'
ENV={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_TERMINAL_PROMPT':'0','GIT_ALLOW_PROTOCOL':'file'}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,raw):
 with path.open('xb')as f:f.write(raw)
def main():
 WORK.mkdir(mode=0o700)
 spec=importlib.util.spec_from_file_location('capture',Path('/private/tmp/ashlar-count-star-fresh-capture-e.py'));capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
 clone=WORK/'checkout';records=[]
 def git(label,args,cwd):
  out=WORK/(label+'.stdout');err=WORK/(label+'.stderr')
  result=capture.capture(['/usr/bin/git','-c','core.hooksPath=/dev/null',*args],str(cwd),ENV,str(out),str(err),30,1024*1024)
  records.append(dict(phase=label,**result));write(WORK/(label+'.json'),json.dumps(records[-1],sort_keys=True).encode()+b'\n')
  if result['exitCode']:raise ValueError('git-phase-refused')
  return out.read_bytes()
 old=os.umask(0o022)
 try:
  git('clone',['clone','--local','--shared','--no-checkout','--sparse','--no-hardlinks','/private/tmp/ashlar-weft-distribution-d2d',str(clone)],WORK)
  git('sparse',['sparse-checkout','set','--cone','distributions/realizations/'+ID],clone)
  git('checkout',['checkout','--detach',REV],clone)
 finally:os.umask(old)
 if git('head',['rev-parse','HEAD'],clone)!= (REV+'\n').encode():raise ValueError('git-revision')
 inventory=json.loads((BASE/'count-star-assembly-a-result-inventory.json').read_bytes())['candidateArtifacts']
 package=clone/'distributions/realizations'/ID
 def custody():
  actual={p.relative_to(package).as_posix()for p in package.rglob('*')if p.is_file()}
  if actual!={r['path']for r in inventory}:raise ValueError('closure')
  for r in inventory:
   p=package/r['path'];raw=p.read_bytes()
   if p.is_symlink()or len(raw)!=r['bytes']or sha(raw)!=r['sha256']or p.stat().st_mode&0o777!=(0o755 if r['path']=='bin/weft-paths-keys'else 0o644):raise ValueError('git-package-custody')
 custody()
 sys.path.insert(0,'/Users/erik/Projects/ashlar/src')
 from ashlar.weft_count_star_distribution import CountStarDistributionPaths,install_count_star_distribution,open_count_star_distribution,installed_count_star_schema_bundle,compile_count_star_distribution
 paths=CountStarDistributionPaths(clone/'distributions/index.json',WORK/'installed',package)
 installed=install_count_star_distribution(paths)
 reopened=open_count_star_distribution(CountStarDistributionPaths(paths.index,paths.output))
 if installed.ready_bytes!=reopened.ready_bytes:raise ValueError('reopen-ready')
 if len(installed_count_star_schema_bundle(paths))!=9:raise ValueError('schema-count')
 with gzip.open(BASE/'full041-a/actual-80-cases-d.json.gz','rb')as source:
  decoded=source.read(64*1024*1024+1)
 if len(decoded)>64*1024*1024:raise ValueError('decoded-case-bound')
 cases=json.loads(decoded)['cases']
 if len(cases)!=80:raise ValueError('case-count')
 observations=WORK/'observations.jsonl';seen=0;observed_bytes=0
 with observations.open('xb')as log:
  for iteration in range(2):
   for case in cases:
    response=compile_count_star_distribution(paths,bytes.fromhex(case['requestHex']))
    row={'iteration':iteration,'id':case['id'],'responseHex':response.hex(),'responseSha256':sha(response)}
    encoded=json.dumps(row,separators=(',',':')).encode()+b'\n'
    if observed_bytes+len(encoded)>64*1024*1024:raise ValueError('observation-bound')
    log.write(encoded);log.flush();observed_bytes+=len(encoded)
    if response!=bytes.fromhex(case['responseHex']):raise ValueError('installed-response-mismatch')
    seen+=1
 custody()
 for p in paths.output.rglob('*'):
  if p.is_file()and p.stat().st_mode&0o777!=(0o555 if p.name=='weft-paths-keys'else 0o444):raise ValueError('installed-mode')
 write(WORK/'result.json',json.dumps({'format':'ashlar-count-star-fresh-install/0.1','indexRevision':REV,'gitSourceModes':'0644/0755','installedModes':'0444/0555','sourceChmod':False,'observations':seen,'cases':80,'schemaCount':9,'qualification':'Fresh local sparse Git retrieval, public install/open and installed transport byte parity only; no Ashlar CLI/native SQL claim.'},sort_keys=True).encode()+b'\n')
if __name__=='__main__':main()
