"""External command pin precedes parse/import/effects and renews after child."""
import hashlib,importlib.util,json,argparse,re,os
from pathlib import Path
ROOT=Path('/private/tmp/ashlar-original-commerce-local-installed-prep-e')
def select(primary,error):
    return error if primary is None or isinstance(primary,Exception) and not isinstance(error,Exception) else primary

def read(path,maximum):
    stream=path.open('rb');primary=None;raw=None
    try:
        raw=stream.read(maximum+1)
        if len(raw)>maximum:raise ValueError('Outer bounded resource required')
    except BaseException as error:primary=error
    try:stream.close()
    except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
    return raw

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--command',required=True,type=Path);parser.add_argument('--sha256',required=True);args=parser.parse_args()
    if re.fullmatch('[0-9a-f]{64}',args.sha256) is None:raise ValueError('External command pin required')
    raw=read(args.command,1024*1024)
    if hashlib.sha256(raw).hexdigest()!=args.sha256:raise ValueError('Externally selected command differs')
    command=json.loads(raw)
    for item in command['launcherResources']:
        p=Path(item['path'])
        if p.is_symlink() or not p.is_file():raise ValueError('Frozen outer resource required')
        payload=read(p,max(1,item['size']))
        if len(payload)!=item['size'] or hashlib.sha256(payload).hexdigest()!=item['sha256']:raise ValueError('Outer resource changed')
    spec=importlib.util.spec_from_file_location('selected_capture',command['captureModule']);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
    primary=None;result=None
    try:
        result=capture.capture(['/usr/bin/python3','-I','-B','-S',str(ROOT/'runner-e.py'),'--command',str(args.command),'--sha256',args.sha256],'/private/tmp',command['environment'],ROOT/'outer-e.stdout',ROOT/'outer-e.stderr',540,4194304)
        if result['exitCode']!=0:raise SystemExit(result['exitCode'])
    except BaseException as error:primary=error
    try:
        if read(args.command,1024*1024)!=raw:raise ValueError('Original command changed')
    except BaseException as error:primary=select(primary,error)
    if result is not None:
        stream=None
        try:
            stream=(ROOT/'launch-receipt-e.json').open('xb')
            payload=(json.dumps({'commandSha256':args.sha256,'capture':result,'primary':None if primary is None else type(primary).__name__},sort_keys=True)+'\n').encode()
            if stream.write(payload)!=len(payload):raise OSError('Short launch receipt')
            stream.flush();os.fsync(stream.fileno())
        except BaseException as error:primary=select(primary,error)
        if stream is not None:
            try:stream.close()
            except BaseException as error:primary=select(primary,error)
    if primary is not None:raise primary
if __name__=='__main__':main()
