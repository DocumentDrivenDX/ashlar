"""Preparation-only launcher: selected setup, retained owned handle, bounded capture."""
import hashlib,importlib.util,json,os,stat,subprocess,time
from pathlib import Path
ROOT=Path('/private/tmp/ashlar-private-outbox-original-commerce-prep-a')
COMMAND=ROOT/'command-a.json'
primary=None

def select(primary,error):
    if primary is None:return error
    return error if isinstance(primary,Exception) and not isinstance(error,Exception) else primary

def read(path):
    stream=path.open('rb');error=None;raw=None
    try:raw=stream.read(128*1024*1024+1)
    except BaseException as e:error=e
    try:stream.close()
    except BaseException as e:error=select(error,e)
    if error is not None:raise error
    if len(raw)>128*1024*1024:raise ValueError('Resource capacity')
    return raw

def write(path,value):
    stream=path.open('xb');error=None
    try:
        stream.write(json.dumps(value,sort_keys=True,indent=2).encode()+b'\n');stream.flush();os.fsync(stream.fileno())
    except BaseException as e:error=e
    try:stream.close()
    except BaseException as e:error=select(error,e)
    if error is not None:raise error

command=json.loads(read(COMMAND));start=time.monotonic();deadline=start+command['wholeSeconds']
def verify():
    for item in command['resources']:
        if time.monotonic()>deadline-40:raise TimeoutError('Closing reserve')
        path=Path(item['path']);info=path.lstat()
        if not stat.S_ISREG(info.st_mode):raise ValueError('Exact regular resource required')
        raw=read(path)
        if len(raw)!=item['size'] or hashlib.sha256(raw).hexdigest()!=item['sha256']:raise ValueError('Resource changed')
    for link in command['symlinkChain']:
        path=Path(link['path']);info=path.lstat()
        if not stat.S_ISLNK(info.st_mode) or os.readlink(path)!=link['target'] or (info.st_dev,info.st_ino)!=(link['device'],link['inode']):raise ValueError('Original Docker symlink changed')
    if str(Path('/usr/local/bin/docker').resolve())!=command['resolvedDocker']:raise ValueError('Original Docker target changed')
    socket=command['socket'];info=Path(socket['path']).stat()
    if not stat.S_ISSOCK(info.st_mode) or (info.st_dev,info.st_ino)!=(socket['device'],socket['inode']):raise ValueError('Selected socket changed')

result=None;closing=False;cleanup=None;capture=None
try:
    verify()
    spec=importlib.util.spec_from_file_location('selected_capture','/private/tmp/ashlar-count-star-installed-cli-capture-a.py')
    capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
    if Path(command['fixtureOutput']).exists():raise ValueError('Fresh output required')
    result=capture.capture(command['argv'],command['cwd'],command['environment'],ROOT/'setup-a.stdout',ROOT/'setup-a.stderr',min(command['childSeconds'],deadline-time.monotonic()-40),command['streamBytes'])
    if result['exitCode']!=0:raise RuntimeError('Setup refused')
except BaseException as error:primary=error
finally:
    try:verify();closing=True
    except BaseException as error:primary=select(primary,error)
    if primary is not None:
        # The tool owns its direct returned-ID cleanup. After child interruption,
        # the outer process cannot authenticate a path-based retained handle.
        # Never delete a container using an unproven caller-replaceable file.
        cleanup={'completed':False,'reason':'Outer ownedID custody unproven; no Docker removal attempted. Inspect retained setup evidence through separate reviewed recovery.'}
    try:write(ROOT/'actual-receipt-a.json',{'commandSha256':hashlib.sha256(read(COMMAND)).hexdigest(),'result':result,'closing':closing,'cleanup':cleanup,'primary':None if primary is None else type(primary).__name__,'elapsedSeconds':time.monotonic()-start})
    except BaseException as error:primary=select(primary,error)
if primary is not None:raise primary
