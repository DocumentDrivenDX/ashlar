import os,sys,json,signal,faulthandler,hashlib,runpy
from pathlib import Path
R=Path(__file__).parent
selection=json.loads((R/'preparation.json').read_bytes())
for pin in selection['pins']:
 b=Path(pin['path']).read_bytes();assert len(b)==pin['bytes']and hashlib.sha256(b).hexdigest()==pin['sha256']
os.environ.update(json.loads((R/'operator-environment.json').read_bytes()))
boot=json.loads((R.parent/'native-bootstrap-control-r2/bootstrap-selection.json').read_bytes())
os.environ['JAVA_HOME']=boot['java_home'];os.environ['PYSPARK_PYTHON']=sys.executable;os.environ['PYSPARK_DRIVER_PYTHON']=sys.executable;os.environ['SPARK_LOCAL_IP']='127.0.0.1'
sys.argv=['ashlar','continue-commerce-evolution','--configuration',str(R/'configuration.json'),'--provider',str(R/'provider.py'),'--provider-sha256',hashlib.sha256((R/'provider.py').read_bytes()).hexdigest()]
def terminate(signum,frame):raise KeyboardInterrupt()
signal.signal(signal.SIGTERM,terminate)
with (R/'private-stack.txt').open('x')as stream:
 faulthandler.enable(file=stream);faulthandler.dump_traceback_later(120,file=stream,repeat=False)
 try:runpy.run_module('ashlar',run_name='__main__')
 finally:faulthandler.cancel_dump_traceback_later()
for pin in selection['pins']:
 b=Path(pin['path']).read_bytes();assert len(b)==pin['bytes']and hashlib.sha256(b).hexdigest()==pin['sha256']
