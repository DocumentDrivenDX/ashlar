import json,hashlib,sqlite3,datetime,collections
from pathlib import Path
import pyarrow,pyarrow.parquet as pq
from ashlar_host.source_identity import build_transaction
from ashlar_host.commerce_admission import original_commerce_oracle
from ashlar_host.schema_rows import fixture_columns
from ashlar_host.driver import ROOT
p=Path('/private/tmp/ashlar-original-commerce-local-publication-20261011-a');pub=p/'publication';r=json.loads((pub/'report.json').read_text());b,bindings=build_transaction((pub/'original-ontology.json').read_bytes(),(pub/'original-graph.json').read_bytes(),source_system='private-original-commerce-fixture')
assert b.begin+b''.join(x.raw for x in b.records)+b.commit==(pub/'source.jsonl').read_bytes()
o=original_commerce_oracle((pub/'original-ontology.json').read_bytes(),(pub/'original-graph.json').read_bytes(),bindings,b,fixture_columns(ROOT));assert o==r['complete_original_oracle']
files=[];counts={};vectors={}
def pin(f):files.append({'path':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
def norm(v):
 if type(v)is int:return str(v)
 if type(v)is datetime.datetime:
  assert v.tzinfo is None
  d=v-datetime.datetime(1970,1,1);return str((d.days*86400+d.seconds)*1000000+d.microseconds)
 assert v is None or type(v)is str;return v
def bag(rows):return collections.Counter(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')) for x in rows)
for entry in r['table_registry']:
 role=entry['table'].split('.')[-1];root=Path(entry['path']);active={};meta=None;logs=sorted((root/'_delta_log').glob('*.json'));vectors[role]=int(logs[-1].stem)
 for log in logs:
  pin(log)
  for line in log.read_text().splitlines():
   a=json.loads(line)
   if 'metaData'in a:meta=a['metaData']
   if 'add'in a:active[a['add']['path']]=a['add']
   if 'remove'in a:active.pop(a['remove']['path'],None)
 assert meta['id']==entry['uuid']
 rows=[]
 for name in active:
  f=root/name;pin(f);rows.extend(pq.read_table(f).to_pylist())
 normalized=[{k:norm(v) for k,v in row.items()} for row in rows]
 if role in o:assert bag(normalized)==bag(o[role]);counts[role]=len(rows)
 if role=='manifest':assert normalized==[r['native_manifest']]
 if role=='attempts':assert any(json.loads(x['payload_json']).get('descriptor_json') is not None for x in rows)
assert json.loads(r['native_manifest']['table_versions_json'])=={x['table']:vectors[x['table'].split('.')[-1]] for x in r['table_registry'] if x['table'].split('.')[-1] in o}
c=sqlite3.connect('file:'+r['original_journal_path']+'?mode=ro&immutable=1',uri=True)
assert c.execute('select count(*) from local_publication_artifact').fetchone()[0]==1
for table,receipt in c.execute('select json_extract(intent,\'$.table\'),receipt from local_operation'):
 a=json.loads(receipt);assert a['table']==table;role=table.split('.')[-1]
 if role in o:assert bag(a['snapshot']['rows'])==bag(o[role])
c.close()

print(json.dumps({'counts':counts,'vectors':vectors,'pyarrow':pyarrow.__version__,'activeArtifacts':files},sort_keys=True))
