"""Effect-free publisher composition/custody controls; no source or native effect."""
import unittest,importlib.util,sys,tempfile,json,hashlib,subprocess,ast
from pathlib import Path
from unittest import mock
ROOT=Path(__file__).parent

def load(name):
 spec=importlib.util.spec_from_file_location('selected_'+name.replace('-','_'),ROOT/name);owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner);return owner

class Controls(unittest.TestCase):
 def test_actual_external_digest_guard_precedes_parse_or_capture(self):
  owner=load('launch-a.py')
  with tempfile.TemporaryDirectory()as directory:
   path=Path(directory)/'command';path.write_bytes(b'{}')
   with mock.patch.object(sys,'argv',['launch','--command',str(path),'--sha256','0'*64]),mock.patch.object(owner.json,'loads',side_effect=AssertionError('Unadmitted parsing')):
    with self.assertRaises(ValueError):owner.main()
 def test_current_handoff_and_original_fixture_are_exactly_bound(self):
  c=json.loads((ROOT/'command-a.json').read_bytes());cfg=json.loads((ROOT/'publication.json').read_bytes());h=json.loads(Path(cfg['installation']).read_bytes());inv=json.loads(Path('/private/tmp/ashlar-private-outbox-original-commerce-a/inventory.json').read_bytes())
  self.assertEqual(hashlib.sha256(Path(cfg['installation']).read_bytes()).hexdigest(),cfg['installation_sha256']);self.assertEqual(cfg['source']['scope']['installation_id'],h['installation_id']);self.assertEqual(len(h['targets']),6)
  selected=[x for x in inv['sources']if x['scope']==cfg['source']['scope']];self.assertEqual(len(selected),1)
  for key in ('writer_role','reader_role','ack_role'):self.assertEqual(cfg['source'][key],selected[0][key])
  self.assertEqual(cfg['source']['source_signature_sha256'],selected[0]['binding']['source_signature_sha256']);self.assertEqual(cfg['source']['port'],25435)
  self.assertEqual(c['nativeOuterSeconds'],330);self.assertEqual(c['wholeSeconds'],510);self.assertFalse(any(k.startswith('PG')for k in c['environment']))
 def test_actual_installed_public_configuration_parser_without_sdk_effects(self):
  c=json.loads((ROOT/'command-a.json').read_bytes());code="from pathlib import Path;from ashlar_host.original_commerce_local_cli import parse_original_commerce_local;from ashlar_host.original_commerce_local_configuration import OriginalCommerceLocalPublicationConfig;x=parse_original_commerce_local(Path("+repr(str(ROOT/'publication.json'))+").read_bytes(),initialize=False);assert type(x)is OriginalCommerceLocalPublicationConfig;assert x.source.scope.installation_id=='07c04255-73c9-40f3-a16a-000000000001';print('typed-publication-configuration')"
  result=subprocess.run([c['python'],'-I','-B','-c',code],env=c['environment'],capture_output=True,timeout=10);self.assertEqual(result.returncode,0);self.assertEqual(result.stdout,b'typed-publication-configuration\n');self.assertEqual(result.stderr,b'')
 def test_actual_namespace_refuses_injected_pth_or_alias(self):
  owner=load('runner-a.py')
  with tempfile.TemporaryDirectory()as directory:
   root=Path(directory);(root/'original.py').write_bytes(b'original');expected=owner.namespace(root);(root/'extra.pth').write_bytes(b'foreign');self.assertNotEqual(owner.namespace(root),expected);(root/'extra.pth').unlink();(root/'alias').symlink_to(root/'original.py')
   with self.assertRaises(ValueError):owner.namespace(root)
 def test_cancel_read_and_receipt_open_failures_keep_primary(self):
  owner=load('runner-a.py');cancel=KeyboardInterrupt()
  class Stream:
   def read(self,n):raise cancel
   def close(self):raise OSError()
  path=mock.Mock();path.open.return_value=Stream()
  with mock.patch.object(owner,'Path',return_value=path):
   with self.assertRaises(KeyboardInterrupt)as caught:owner.read('/original',10)
  self.assertIs(caught.exception,cancel)
  self.assertIs(owner.choose(cancel,OSError()),cancel)
 def test_closed_public_operation_cannot_initialize_reset_or_query(self):
  tree=ast.parse((ROOT/'runner-a.py').read_bytes());values={node.value for node in ast.walk(tree)if isinstance(node,ast.Constant)and type(node.value)is str}
  self.assertIn('publish-original-commerce',values);self.assertFalse(values.intersection({'initialize-original-commerce','docker','query-commerce-implicit-arithmetic','reset','append'}))
if __name__=='__main__':unittest.main()
