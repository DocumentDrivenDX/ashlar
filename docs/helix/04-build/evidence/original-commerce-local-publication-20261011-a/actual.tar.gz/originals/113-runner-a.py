"""Bounded installed public publication; no initialization or provider discovery."""
import argparse,hashlib,importlib.util,json,os,stat,time
from pathlib import Path

def choose(primary,error):
 return error if primary is None or isinstance(primary,Exception)and not isinstance(error,Exception)else primary

def read(path,maximum):
 stream=Path(path).open('rb');primary=None;value=None
 try:
  value=stream.read(maximum+1)
  if len(value)>maximum:raise ValueError('Bounded selected input required')
 except BaseException as error:primary=error
 try:stream.close()
 except BaseException as error:primary=choose(primary,error)
 if primary is not None:raise primary
 return value

def retain(path,value):
 raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();stream=None;primary=None
 try:
  stream=path.open('xb')
  if stream.write(raw)!=len(raw):raise OSError('Short retained evidence')
  stream.flush();os.fsync(stream.fileno())
 except BaseException as error:primary=error
 if stream is not None:
  try:stream.close()
  except BaseException as error:primary=choose(primary,error)
 if primary is not None:raise primary

def namespace(root):
 values=[]
 for path in sorted(root.rglob('*')):
  if path.is_symlink():raise ValueError('Selected namespace alias refused')
  kind='file'if path.is_file()else'directory'if path.is_dir()else None
  if kind is None:raise ValueError('Selected namespace special member refused')
  values.append([str(path.relative_to(root)),kind])
 return values

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--command',required=True,type=Path);parser.add_argument('--sha256',required=True);args=parser.parse_args()
 raw=read(args.command,1048576)
 if hashlib.sha256(raw).hexdigest()!=args.sha256:raise ValueError('External immutable command required')
 command=json.loads(raw);start=time.monotonic();deadline=start+command['wholeSeconds'];output=Path(command['output']);primary=None;closing=False;phases=[]
 def pins(records):
  for item in records:
   path=Path(item['path']);info=path.lstat()
   if not stat.S_ISREG(info.st_mode):raise ValueError('Selected regular original required')
   value=read(path,max(1,item['size']))
   if len(value)!=item['size']or hashlib.sha256(value).hexdigest()!=item['sha256']:raise ValueError('Selected original changed')
   if time.monotonic()>=deadline-15:raise TimeoutError('Closing budget required')
 def verify():
  if read(args.command,1048576)!=raw:raise ValueError('Command changed')
  pins(command['resources'])
  if namespace(Path(command['site']))!=json.loads(read(command['installedNamespace'],1048576)):raise ValueError('Complete installed host namespace changed')
 def phase(name,argv,seconds):
  remaining=deadline-time.monotonic()-15
  if remaining<1:raise TimeoutError('No phase budget remains')
  result=capture.capture(argv,str(output),command['environment'],output/(name+'.stdout'),output/(name+'.stderr'),min(seconds,remaining),command['maximumStreamBytes'])
  phases.append({'phase':name,'argv':argv,'capture':result})
  if result['exitCode']!=0:raise RuntimeError('Required public phase refused')
 try:
  verify();pins(command['nativeOpeningFiles'])
  if namespace(Path(command['nativeRoot']))!=json.loads(read(command['nativeOpeningNamespace'],1048576)):raise ValueError('Original native opening namespace changed')
  if output.exists()or output.is_symlink():raise ValueError('Fresh exclusive output required')
  output.mkdir(mode=0o700)
  spec=importlib.util.spec_from_file_location('selected_capture',command['captureModule']);capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
  phase('runtime-import',[command['python'],'-I','-B','-c',command['importProbe']],15)
  phase('publish',[command['python'],'-I','-B','-m','ashlar','publish-original-commerce','--configuration',command['configuration']],command['nativeOuterSeconds'])
  configuration=json.loads(read(command['configuration'],262144));report_path=Path(configuration['output'])/'report.json'
  report=json.loads(read(report_path,8388608))
  if (report['format']!='ashlar-original-commerce-publication/0.1'or report['installation_id']!=configuration['source']['scope']['installation_id']or report['protected_ack_scope']!=configuration['source']['scope']or report['source_schema']!=configuration['source']['source_schema']or report['source_signature_sha256']!=configuration['source']['source_signature_sha256']or report['source_role']!=configuration['source']['reader_role']or report['ack_role']!=configuration['source']['ack_role']or report['exact_replay_unchanged']is not True or (report['record_count'],report['edge_count'],report['history_count'])!=(11,10,21)):raise ValueError('Actual public report correspondence refused')
  if json.loads(read(output/'publish.stdout',1048576))!=report:raise ValueError('Public report/stdout mismatch')
  phase('runtime-import-closing',[command['python'],'-I','-B','-c',command['importProbe']],15)
  if read(output/'runtime-import.stdout',1048576)!=read(output/'runtime-import-closing.stdout',1048576):raise ValueError('Runtime correspondence changed')
 except BaseException as error:primary=error
 finally:
  try:verify();closing=True
  except BaseException as error:primary=choose(primary,error)
  if output.exists():
   try:
    files=[];total=0
    for path in sorted(Path(command['nativeRoot']).rglob('*')):
     if path.is_symlink():raise ValueError('Native retained alias refused')
     if path.is_file():
      value=read(path,4194304);total+=len(value)
      if total>16777216:raise ValueError('Bounded native retention inventory required')
      files.append({'path':str(path),'size':len(value),'sha256':hashlib.sha256(value).hexdigest()})
    retain(output/'native-terminal-inventory.json',{'scope':'Post-attempt current native bytes, not equality to immutable initializer snapshots or authority grant','files':files})
   except BaseException as error:primary=choose(primary,error)
   try:retain(output/'outer-receipt.json',{'commandSha256':args.sha256,'phases':phases,'closing':closing,'primary':None if primary is None else type(primary).__name__,'elapsedSeconds':time.monotonic()-start,'scope':'Installed public original publication only; live public owner source/ACK/native checks mandatory; no init/query/fixture'})
   except BaseException as error:primary=choose(primary,error)
 if primary is not None:raise primary
if __name__=='__main__':main()
