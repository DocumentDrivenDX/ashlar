from pathlib import Path
import json,gzip,hashlib,sqlite3
r=Path(__file__).parent
out=Path('/Users/erik/Projects/ashlar/docs/helix/04-build/evidence/medical-held-recovery-20261016-d')
out.mkdir()
c=json.loads((r/'recovery.json').read_bytes())
with sqlite3.connect('file:'+c['journal']+'?mode=ro',uri=True) as db:
 with sqlite3.connect(r/'journal-backup.sqlite') as backup:db.backup(backup)
rows=[json.loads(p.read_bytes())for p in sorted((r/'recovery-output').glob('preflight-stage-*.json'))]
(r/'stage-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
files=[(p,p.name)for p in sorted(r.iterdir())if p.is_file()]
files += [(p,'output-'+p.name)for p in sorted((r/'recovery-output').iterdir())if p.is_file()]
root=Path(c['root'])
files += [(p,'native-'+str(p.relative_to(root)).replace('/','--'))for p in sorted(root.rglob('*'))if p.is_file()and(p.suffix=='.parquet'or p.parent.name=='_delta_log'and p.suffix=='.json')]
manifest={}
for p,name in files:
 raw=p.read_bytes();compressed=gzip.compress(raw,mtime=0);name += '.gz';(out/name).write_bytes(compressed)
 manifest[name]={'source':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'gzip_sha256':hashlib.sha256(compressed).hexdigest(),'bytes':len(raw)}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(len(manifest),out)
