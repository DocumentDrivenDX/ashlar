from pathlib import Path
import subprocess,json,os,time,sys,hashlib,sqlite3
root=Path(sys.argv[1]);base=json.loads((root/"base.json").read_bytes());python=base["python"]
environment={"PATH":"/usr/bin:/bin","HOME":"/Users/erik","LANG":"C.UTF-8","LC_ALL":"C.UTF-8","JAVA_HOME":base["java_home"],"PYSPARK_PYTHON":python,"PYSPARK_DRIVER_PYTHON":python,"PYTHONDONTWRITEBYTECODE":"1","SPARK_LOCAL_IP":"127.0.0.1"}
results=[]
def state():
 native=root/"native"
 with sqlite3.connect("file:"+str(native/"operations.sqlite")+"?mode=ro",uri=True)as db:
  rows={t:sorted([list(r)for r in db.execute('SELECT * FROM "'+t+'"')],key=lambda x:json.dumps(x,sort_keys=True))for t in ("local_operation","local_plan","jsonl_consumer_progress")}
 return {"registry":hashlib.sha256((native/"installation.json").read_bytes()).hexdigest(),"logs":{str(p.relative_to(native)):hashlib.sha256(p.read_bytes()).hexdigest()for p in native.glob("*/_delta_log/*.json")},"journal":hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest(),"counts":{t:len(v)for t,v in rows.items()}}
for name,op,ordinal,entity in [("initialize","initialize",0,None),("publish-1","publish",1,None),("publish-2","publish",2,None),("publish-3","publish",3,None),("replay-3","publish",3,None),("read-original","read",1,2),("read-deleted","read",3,2)]:
 config={**base,"operation":op,"ordinal":ordinal,"output":str(root/name)}
 if op!="initialize":config["installation_sha256"]=results[0]["result"]["installation_sha256"]
 if entity is not None:config["selector"]={"type_id":17,"entity_id":entity}
 path=root/(name+".json");path.write_text(json.dumps(config,indent=2)+"\n");path.chmod(0o600)
 before=state()if op=="read"or name=="replay-3"else None
 start=time.monotonic()
 with(root/(name+".stdout")).open("wb")as out,(root/(name+".stderr")).open("wb")as err:
  process=subprocess.run([python,"-I","-B","-m","ashlar","run-configured-local","--configuration",str(path)],cwd=root,env=environment,stdout=out,stderr=err,timeout=240)
 assert process.returncode==0,(name,process.returncode)
 result=json.loads((root/(name+".stdout")).read_bytes());assert result==json.loads((root/name/"report.json").read_bytes())
 assert result["protected_ack"]is False
 if before is not None:assert before==state(),(name,"unexpected mutation")
 if name=="replay-3":assert result["replayed"]is True
 if name=="read-original":
  assert result["row"]["props_json"]=='{"21":9007199254740993,"22":-0.00,"23":false,"24":null}'
 if name=="read-deleted":assert result["row"]is None
 item={"name":name,"elapsed_seconds":time.monotonic()-start,"result":result};results.append(item)
 (root/(name+"-terminal.json")).write_text(json.dumps(item,ensure_ascii=False,indent=2)+"\n");print(json.dumps({"name":name,"seconds":item["elapsed_seconds"],"status":"complete"}),flush=True)
(root/"after.json").write_text(json.dumps(state(),indent=2)+"\n")
(root/"results.json").write_text(json.dumps({"status":"complete","cases":results,"scope":"Installed tiny typed Delta initialization/publication/update/delete/replay/historical read. No cloud or protected ACK or typed query qualification."},ensure_ascii=False,indent=2)+"\n")
