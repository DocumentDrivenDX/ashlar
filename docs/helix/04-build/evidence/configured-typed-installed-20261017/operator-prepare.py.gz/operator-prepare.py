from pathlib import Path
import subprocess,tempfile,tarfile,io,json,hashlib,os
root=Path(tempfile.mkdtemp(prefix="ashlar-typed-installed-20261017-",dir="/private/tmp"));root.chmod(0o700)
commit="10ceb5692b418372585f219d8c5ae77ef4feb6b0";source=root/"source";source.mkdir()
raw=subprocess.check_output(["/usr/bin/git","archive",commit,"src","README.md","pyproject.toml"],cwd="/Users/erik/Projects/ashlar")
with tarfile.open(fileobj=io.BytesIO(raw))as archive:archive.extractall(source,filter="data")
builder="/private/tmp/ashlar-weft-validation-wheel-20261016-cdc5wn_8/build-environment/bin/python";runtime="/private/tmp/ashlar-publication-query-runtime-20261016-b/bin/python"
with(root/"build.log").open("wb")as log:subprocess.run([builder,"-c","import setuptools.build_meta as b;print(b.build_wheel('../dist'))"],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
wheel=next((root/"dist").glob("*.whl"))
with(root/"install.log").open("wb")as log:subprocess.run([builder,"-m","pip","--isolated","--python",runtime,"install","--no-index","--no-deps","--force-reinstall",str(wheel)],stdout=log,stderr=subprocess.STDOUT,check=True)
config=json.loads(Path("/private/tmp/ashlar-configured-local-read-installed-20261016-b8y_psej/current-updated.json").read_bytes());config.pop("selector")
config.update(operation="initialize",ordinal=0,installation=str(root/"native"),installation_id="typed-local-20261017-a",installation_sha256=None,output=str(root/"initialize"),stream="typed-local-20261017-a",source_configuration="/Users/erik/Projects/ashlar/examples/end-to-end/configured-typed-source.json")
config["bounds"]["whole_seconds"]=180
(root/"base.json").write_text(json.dumps(config,indent=2)+"\n")
(root/"preparation.json").write_text(json.dumps({"commit":commit,"wheel_sha256":hashlib.sha256(wheel.read_bytes()).hexdigest(),"runtime":runtime,"scope":"Actual installed typed local Delta lifecycle, four original events, no cloud compute"},indent=2)+"\n")
print(root)
